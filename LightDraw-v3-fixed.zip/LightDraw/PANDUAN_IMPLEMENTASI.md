# Panduan implementasi — LightDraw v2 (Shapes, Object, Pattern, FX, AA, Export)

> Status: kode ditulis tanpa compiler (tidak ada Rust/Kotlin/Android SDK di lingkungan pembuat).
> Jalankan CI (`.github/workflows/build.yml`) dan kirim error kompilasi bila ada; perbaikannya biasanya kecil.

## 0. Fakta arsitektur yang menentukan cakupan
App ini = **satu layer raster** (tile sparse 256×256 di Rust) + paper. Tidak ada daftar objek vektor dan tidak ada multi-layer.
Karena itu:
* **"Objek" = seleksi kotak** (tool *Select*). Semua operasi objek bekerja pada piksel di dalam kotak.
* **Duplicate Layer belum ada** karena belum ada konsep layer (lihat §9 untuk rancangan).

## 1. Peta fitur → file

| Fitur | UI | Kotlin | Rust |
|---|---|---|---|
| Transform (view) | Transform ▸ VIEW | `CanvasGLView.rotateView/resetRotation`, `fitCanvas` | – |
| Transform (seamless) | Transform ▸ SEAMLESS | `Tool.WRAP`, `CanvasScreen.wrapBy` | `fx_engine::offset_wrap` |
| Mirror | Transform ▸ MIRROR | (tidak berubah) | `symmetry.rs` |
| FX | Crop & FX | `CanvasScreen` → `nativeApplyFx` | `fx_engine::apply_fx` |
| Shapes | Shapes | `Tool.SHAPE`, `CanvasGLView.dragMove/finishDrag` | `fx_engine::draw_shape`, `nativeShape` |
| Pattern | **Color** (bagian PATTERN FILL) | `FloatingToolbar.PatternSection` | `pattern_fill` (kind 1–6) |
| Select / Duplicate Object | Object | `duplicateSelection`, `moveSelection` | `fx_engine::move_region` |
| Align | Object ▸ ALIGN | `alignSelection` | `fx_engine::align_region` |
| Object → Pattern | Object ▸ To Pattern | `selectionToPattern` | `region_to_tile` + `pattern_fill` kind 7 |
| Anti-aliasing | otomatis | `CanvasRenderer` (filter) | `brush_engine::StrokeCov`, `draw_shape` |
| Export | Gallery ▸ Export | `ExportManager.exportJpeg/exportWebpLossless` | – |

## 2. Kenapa FX & Transform "tidak berfungsi"
Versi sebelumnya: *Transform* hanya membuka menu Mirror, *FX* hanya memilih tool Fill/Same-Color. Tidak ada transformasi atau efek sungguhan.
Sekarang: Transform = rotasi/level/fit kanvas + Wrap + Mirror; FX = Brightness, Contrast, Hue, Saturation, Invert, Grayscale (semua bisa Undo).
Bila popup tidak muncul sama sekali di perangkatmu, kirim logcat; penyebab paling mungkin ada di sisi layout yang belum bisa diuji di sini.

## 3. Struktur menu baru
Bottom nav: **Brush · Shapes · Transform · Crop & FX · Object** + tombol Hand.
Top toolbar: Tools · Artboard · Brush · Shapes · Transform · FX · Pathfinder · Object · Duplicate · (warna).
**Pattern pindah ke popup Color** (lingkaran warna kanan atas): roda warna → swatch → PATTERN FILL (Gingham…Floral + Custom) → Fill / Same Color.

## 4. Algoritma alignment (`fx_engine::align_region`)
1. `content_bounds`: pindai kotak seleksi, ambil bbox piksel dengan alpha > 0 → (bx0,by0,bx1,by1). Ini "objek" sebenarnya (kotak seleksi boleh longgar).
2. bw = bx1-bx0+1, bh = by1-by0+1, W/H = ukuran artboard.
3. Hitung delta:
   * Left: dx = -bx0 · Right: dx = W-1-bx1 · Center H: dx = (W-bw)/2 - bx0
   * Top: dy = -by0 · Bottom: dy = H-1-by1 · Center V: dy = (H-bh)/2 - by0
   * Center (both): dx dan dy center.
4. `move_region(rect, dx, dy, copy=false, wrap=false)` lalu kotak seleksi digeser sebesar (dx,dy).
"Snap to canvas" = mode Center.

## 5. Algoritma seamless / wrap
**a) Wrap Drag & Wrap ½ (`offset_wrap`)** — seluruh gambar: `new(x,y) = old((x-dx) mod W, (y-dy) mod H)`.
Baca semua piksel ke buffer (≤ 4096², 64 MB), tulis ulang per tile dengan modulo. Wrap ½ (dx=W/2, dy=H/2) memindahkan sambungan tepi/sudut ke tengah supaya bisa digambar ulang → hasilnya tile yang bisa diulang tanpa garis sambung.
**b) Seret objek melewati tepi (`move_region(wrap=true)`)** — tujuan: `ox = (x0+dx) mod W`. Bila `ox + w > W` kotak dipecah di seam menjadi maksimal 2×2 potongan dan tiap potongan ditempel (`paste_piece`) → bagian yang keluar tepi muncul di sisi seberang (juga sudut).
Batasan jujur: pergeseran dilakukan saat jari diangkat (outline kotak mengikuti jari), bukan preview piksel langsung.

## 6. Convert Object → Pattern
`region_to_tile` menyalin kotak seleksi (maks 2048², unpremultiply) ke penyimpanan global `CUSTOM` di `pattern_fill.rs`.
`pattern_color(kind=7, x, y)` = `tile[(y/scale) mod h][(x/scale) mod w]`, dievaluasi dalam koordinat global sehingga seamless antar-tile. Setelah konversi app otomatis memilih Fill + pola Custom; ketuk area manapun untuk mengisi (atau seret kartu Custom ke kanvas). Kotak seleksi = satuan ulang (repeat unit), jadi atur margin kotak untuk mengatur jarak antar objek.

## 7. Anti-aliasing — akar masalah & perbaikan
Masalah lama: tiap dab di-composite dengan `over`. Piksel di tepi goresan kena puluhan dab → alfa tepi menumpuk 1-∏(1-aᵢ) → tepi menebal & "bergerigi". Selain itu renderer memakai GL_NEAREST mulai zoom 2×.
Perbaikan:
1. **Max-coverage per goresan** (`StrokeCov`): peta coverage u8 per tile selama satu goresan. Dab baru hanya menaikkan coverage dari `old` ke `new` dengan alfa inkremental `a' = (new-old)/(1-old)`, sehingga hasil = `base*(1-new)+color*new` tanpa perlu menyimpan piksel asli. Opacity slider sekarang akurat (tidak menumpuk). Mode Multiply/Screen/Overlay/Add & airbrush tetap pakai jalur lama.
2. Rim tepi dab memakai profil **smoothstep** 1 px.
3. **Shapes**: signed-distance analitik, coverage = clamp(0.5 − sd, 0, 1) → tepi ±1 px halus untuk rect/rounded/ellipse/triangle/line/diamond.
4. GL: filter bilinear sampai zoom 8× (sebelumnya blok-blok pada 2×).

## 8. Export
* JPEG: kualitas dikunci **100** (slider dihapus). JPEG tetap lossy secara format; ini kualitas maksimum yang tersedia dari encoder Android.
* Untuk hasil **identik piksel**: PNG (streaming, resolusi penuh) atau **WebP lossless** (Android 11+).
* >16 MP: JPEG/WebP diperkecil otomatis (batas memori); gunakan PNG untuk resolusi penuh.

## 9. Rancangan Duplicate Layer (tahap berikutnya)
1. Rust: `Engine.canvas: TiledCanvas` → `layers: Vec<Layer { canvas, visible, opacity, blend, name }>` + `active: usize`.
2. Semua tool menulis ke `layers[active].canvas`; undo menyimpan `(layer_id, EditRecord)`.
3. `nativeDuplicateLayer(i)`: buat `TiledCanvas` baru, salin tile resident + tile yang di-spill (`copy_tile_bytes`) → sisipkan di i+1, jadikan aktif.
4. Renderer: gambar tiap layer dari bawah ke atas (satu texture-set per layer, blend di shader) ; export & `.ldproj` (versi `LDRW2`) menulis daftar layer.
5. UI: Layers dialog → daftar layer (visible, opacity, urutan, **Duplicate**, Delete, Merge).
Perkiraan: 1–2 minggu kerja karena menyentuh renderer, history, export dan format project.

## 10. Uji manual cepat
1. Gambar goresan opacity 50% bolak-balik → tidak boleh ada area lebih gelap di tumpang-tindih.
2. Shapes → seret ellipse: preview langsung, tepi halus; Undo menghapusnya.
3. Select kotak di sekeliling gambar → Align ▸ Center → objek ke tengah artboard.
4. Duplicate → salinan bergeser 24 px; seret salinan melewati tepi kanan dengan Wrap aktif → muncul di kiri.
5. Object ▸ To Pattern → Fill area kosong → pola berulang.
6. FX ▸ Invert / Grayscale / Brightness → Undo.
7. Export JPEG → tidak ada slider, file tersimpan 100%.

---

# Tambahan v3 — touch-first, blend, crop/warp, high-res, seamless

> Sama seperti v2: ditulis tanpa compiler. Jalankan CI dan kirim error bila ada.

## A. Touch-first UI
**Accordion menu.** Sudah dijamin oleh desain state: hanya ada satu `DrawState.panel`. Membuka menu apa pun otomatis menutup yang lain (`togglePanel/selectGroup`).
**Auto-minimize saat drag swatch/pola.** Jebakan: kalau popup langsung dihapus dari komposisi, gesture drag ikut dibatalkan (`onDragCancel`) dan drop hilang. Solusi (`CanvasScreen`): popup tetap ada tapi `graphicsLayer { alpha = if (dd.payload != null) 0f else 1f }`; setelah drop `dd.onDrop` menutup panel (`state.panel = NONE`). Bila drag dibatalkan popup muncul lagi.
**HUD zoom.** `CanvasGLView.onViewChanged` → `zoomPercent()`; chip "NNN%" tampil 0,9 dtk, hanya bila nilai zoom berubah.
**Long-press eyedropper.** `CanvasGLView`: timer 480 ms dimulai di `ACTION_DOWN`, dibatalkan bila jari bergerak > ½ slop / jari ke-2 / jari diangkat. Saat menyala: goresan yang sudah berjalan dibatalkan (`nativeStrokeCancel`), warna di titik itu diambil (`nativePickColor`), haptic, sisa gesture "ditelan" (`swallow`).

## B. Blend mode
Rumus ada di `brush_engine::blend_channel` (cb = backdrop, cs = source, rentang 0..1):
Multiply `cb·cs` · Screen `cb+cs−cb·cs` · Overlay · Darken `min` · Lighten `max` · Hard Light · Soft Light (W3C) · Color Dodge `min(1, cb/(1−cs))` · Color Burn `1−min(1,(1−cb)/cs)` · Difference `|cb−cs|` · Exclusion `cb+cs−2·cb·cs`.
Komposit per piksel (premultiplied): `Cr = (1−αb)·αs·Cs + (1−αs)·αb·Cb + αs·αb·B(Cb,Cs)`, `αr = αs + αb(1−αs)` (`blend_px`).
**Sekarang**: dipakai sebagai blend mode *kuas* (Brush ▸ chip Normal … Exclusion).
**Belum**: blend mode *per layer*, karena belum ada layer (lihat C).

## C. Rancangan layer + blend per layer (belum diimplementasikan)
```rust
struct Layer { canvas: TiledCanvas, visible: bool, opacity: f32, blend: Blend, name: String }
struct Engine { layers: Vec<Layer>, active: usize, .. }
// komposit satu tile (256x256) untuk render & export
fn composite_tile(layers: &mut [Layer], idx: usize, out: &mut [u32]) {
    out.fill(0);                                   // transparan
    for l in layers.iter_mut().filter(|l| l.visible) {
        let Some(src) = l.canvas.tile_pixels(idx) else { continue };
        for (o, &s) in out.iter_mut().zip(src) {
            if s >> 24 == 0 { continue }
            let s = scale_alpha(s, l.opacity);
            *o = blend_premul(*o, s, l.blend);     // rumus B pada bagian B di atas
        }
    }
}
```
* Semua tool menulis ke `layers[active]`; undo menyimpan `(layer_id, EditRecord)`.
* GL: `nativeCompositeTile(idx, buf)` menggantikan `nativeCopyTile`; versi tile = jumlah versi semua layer.
* Duplicate layer = `TiledCanvas` baru + salin tile (`copy_tile_bytes`) → sisipkan di atas layer aktif.
* Project format `LDRW2`: header + daftar layer (nama, blend, opacity, tile).
Perkiraan 1–2 minggu (renderer, history, export, format).

## D. Crop, Perspective, Seleksi, Color Magic
* **Crop** (Object ▸ Crop): artboard dipotong ke kotak seleksi. Rust `nativeCropCanvas`: buat `TiledCanvas` baru, `copy_rect_into` (baca baris dari kanvas lama → tulis per tile), ganti `e.canvas`, `old.cleanup()`. Riwayat Undo dihapus (ada dialog konfirmasi). Karena hanya ada satu layer, "crop layer" = crop kanvas.
* **Perspective / corner-pin** (Object ▸ Perspective): 4 handle di sudut seleksi. Seret handle = scale/skew/perspektif, seret di dalam = pindah, ↺↻ 15° = rotasi. "Terapkan" → `fx_engine::warp_region`: homografi 3×3 dari rect sumber ke quad tujuan (eliminasi Gauss 8×8), diinversikan; tiap piksel tujuan di-map balik ke sumber, sampling bilinear (premultiplied) + tepi lunak ±1 px, lalu ditempel per tile.
* **Seleksi**: Marquee (kotak), tap kosong = hapus seleksi, geser di dalam = pindah, Duplicate, **Delete** (`clear_region`). Shape yang baru selesai digambar otomatis terseleksi → langsung bisa di-Perspective/Align. **Lasso & seleksi bebas belum ada** (butuh mask 1-bit per piksel; rancangan: `Vec<u64>` bitset per tile + `fill_polygon` scanline).
* **Color Magic** (`shuffle_colors`): lingkaran hue dibagi 12 bucket × 30°, bucket diacak dengan Fisher-Yates (seed = waktu); posisi dalam bucket, saturasi, lightness, alpha dipertahankan; abu-abu tidak diubah. Hue sama selalu pindah bersama sehingga motif tetap konsisten. Dipakai pada seleksi, atau seluruh gambar bila tidak ada seleksi (juga untuk area yang sudah diisi pola).

## E. Fill resolusi sangat tinggi (8K–16K)
Penyebab paling mungkin "app menutup": fill berjalan di **UI thread** → ANR. Perbaikan:
1. `CanvasGLView.runFill` kini di thread terpisah + overlay "busy"; input diabaikan selama fill.
2. Visited-bitmap sudah lazy per tile (8 KB/tile) dan tile baru dibatasi (`MAX_NEW_TILES` 400 → 1600, ±400 MB di disk; memori resident tetap dibatasi LRU spill).
3. Bila area melebihi batas: pesan jelas, bukan crash.
Untuk mengisi *seluruh* kanvas 16K dengan pola secara instan perlu **paper-pattern prosedural** (tanpa tile): simpan `Paint` di `Engine.paper_pattern`, port `pattern_color` ke GLSL di `FRAG_FLAT` (uniform kind/scale/c1/c2, `vCanvas` sudah tersedia), dan evaluasi per baris saat export. Belum dikerjakan.

## F. Export
* JPEG / WebP sampai **45 MP** (`MAX_EXPORT_PIXELS`), otomatis diperkecil bila memori kosong perangkat tidak cukup (`availMem/9` piksel ≈ bitmap 4 B + encoder 2,2×); catatan ukuran akhir ditampilkan setelah simpan. PNG tetap di-stream native pada resolusi penuh.
* Toggle kualitas: **Medium** (JPEG 85 / WebP lossy 85) vs **High** (JPEG 100 / WebP lossless).
* Tekstur kanvas belum ikut export (hanya tampil di layar).

## G. Seamless & pola
* **Seamless Mode** (Transform): brush mengulang dab di sisi seberang bila melewati tepi (`stamp_sym` + `Brush.wrap`); seret objek melewati tepi juga wrap.
* Wrap Drag / Wrap ½: lihat §5 v2.
* **To Pattern**: dialog Lebar × Tinggi px, kunci rasio, preset 25/50/100/200 %; resampling bilinear (`resize_bilinear`). Slider "Skala motif" (%) di Color ▸ Pattern.

## H. Tekstur kanvas
Shader prosedural di `FRAG_FLAT` (tanpa file tekstur): paper (fibre + blotch), canvas weave, noise; kekuatan 5–80 %; *di bawah* gambar (memodulasi kertas) atau *di atas* (multiply, `glBlendFunc(DST_COLOR, ZERO)`). Menu: Tools ▸ Tekstur Kanvas.

## I. Anti-aliasing
Lihat §7 v2 (max-coverage per goresan, smoothstep, SDF shape, bilinear GL sampai 8×). Semua tool tulis (brush, eraser, shape) memakainya; Fill/Same-Color bekerja per piksel pada area yang sudah anti-aliased.

## J. Yang belum dikerjakan (jujur)
Blend mode per layer & Duplicate Layer (C) · Lasso (D) · rotasi bebas dengan handle putar (kini: tombol ±15°) · paper-pattern GPU untuk fill instan 16K (E) · tekstur di export (H).
