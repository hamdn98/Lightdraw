package com.lightdraw.studio

import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Save / export / import via Android Scoped Storage (MediaStore, API 29+, no storage permission needed).
 *  - PNG / JPEG -> Pictures/DrawingApp/
 *  - Project (.ldproj) -> Download/DrawingApp/
 * Large canvases never allocate a full-size Bitmap: PNG is streamed natively row by row; JPEG / WebP are
 * down-scaled to at most 16 megapixels (use PNG for full resolution).
 */
class ExportManager(private val context: Context) {

    private val resolver = context.contentResolver

    val spillDir: String get() = File(context.cacheDir, "tiles").absolutePath

    fun maxResidentTiles(): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val lowRam = am.isLowRamDevice || mi.totalMem <= 4L * 1024 * 1024 * 1024
        return if (lowRam) 384 else 640 // 96 MB / 160 MB of native tiles
    }

    fun isLowRam(): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return am.isLowRamDevice || mi.totalMem <= 4L * 1024 * 1024 * 1024
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun insertImage(name: String, mime: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DrawingApp")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        return resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: error("MediaStore insert failed")
    }

    private fun publish(uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        resolver.update(uri, v, null, null)
    }

    /** PNG. [transparent] = keep alpha; otherwise the paper colour is baked in. */
    suspend fun exportPng(paperArgb: Int, transparent: Boolean): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val w = NativeEngine.nativeCanvasWidth()
            val h = NativeEngine.nativeCanvasHeight()
            val bg = if (transparent) 0 else opaque(paperArgb)
            val uri = insertImage("LightDraw_${stamp()}.png", "image/png")
            try {
                if (w.toLong() * h <= BITMAP_LIMIT) {
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    try {
                        check(NativeEngine.nativeRenderToBitmap(bmp, bg) == 0) { "render failed" }
                        resolver.openOutputStream(uri)!!.use { check(bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) { "encode failed" } }
                    } finally {
                        bmp.recycle()
                    }
                } else {
                    val fd = resolver.openFileDescriptor(uri, "w")!!.detachFd() // native side takes ownership
                    check(NativeEngine.nativeExportPng(fd, bg) == 0) { "png stream failed" }
                }
                publish(uri)
                uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }
    }

    /** JPEG is always written at the maximum quality (100). JPEG itself is lossy; use PNG / WebP lossless for bit-exact output. */
    suspend fun exportJpeg(paperArgb: Int): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val w = NativeEngine.nativeCanvasWidth()
            val h = NativeEngine.nativeCanvasHeight()
            val total = w.toLong() * h
            val s = if (total > BITMAP_LIMIT) sqrt(BITMAP_LIMIT.toDouble() / total) else 1.0
            val dw = max(1, (w * s).toInt())
            val dh = max(1, (h * s).toInt())
            val uri = insertImage("LightDraw_${stamp()}.jpg", "image/jpeg")
            try {
                val bmp = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                try {
                    check(NativeEngine.nativeRenderToBitmap(bmp, opaque(paperArgb)) == 0) { "render failed" }
                    resolver.openOutputStream(uri)!!.use {
                        check(bmp.compress(Bitmap.CompressFormat.JPEG, 100, it)) { "encode failed" }
                    }
                } finally {
                    bmp.recycle()
                }
                publish(uri)
                uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }
    }

    /** Lossless WebP (API 30+): bit-exact like PNG, usually smaller. Keeps transparency when [transparent]. */
    suspend fun exportWebpLossless(paperArgb: Int, transparent: Boolean): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val w = NativeEngine.nativeCanvasWidth()
            val h = NativeEngine.nativeCanvasHeight()
            val total = w.toLong() * h
            val s = if (total > BITMAP_LIMIT) sqrt(BITMAP_LIMIT.toDouble() / total) else 1.0
            val dw = max(1, (w * s).toInt())
            val dh = max(1, (h * s).toInt())
            val uri = insertImage("LightDraw_${stamp()}.webp", "image/webp")
            try {
                val bmp = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                try {
                    check(NativeEngine.nativeRenderToBitmap(bmp, if (transparent) 0 else opaque(paperArgb)) == 0) { "render failed" }
                    resolver.openOutputStream(uri)!!.use {
                        check(bmp.compress(Bitmap.CompressFormat.WEBP_LOSSLESS, 100, it)) { "encode failed" }
                    }
                } finally {
                    bmp.recycle()
                }
                publish(uri)
                uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }
    }

    /** Project file with all tiles (RLE compressed). */
    suspend fun saveProject(): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "LightDraw_${stamp()}.ldproj")
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/DrawingApp")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("MediaStore insert failed")
            try {
                val fd = resolver.openFileDescriptor(uri, "w")!!.detachFd()
                check(NativeEngine.nativeSaveProject(fd) == 0) { "save failed" }
                publish(uri)
                uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }
    }

    /** Returns (width, height) of the loaded project. */
    suspend fun loadProject(uri: Uri): Result<Pair<Int, Int>> = withContext(Dispatchers.IO) {
        runCatching {
            val fd = resolver.openFileDescriptor(uri, "r")!!.detachFd()
            val r = NativeEngine.nativeLoadProject(fd, spillDir, maxResidentTiles())
            check(r >= 0) { "bukan file project LightDraw yang valid" }
            Pair((r shr 32).toInt(), (r and 0xFFFFFFFFL).toInt())
        }
    }

    /** Decode an image from storage (fitted into the artboard) and blit it onto the tile canvas. */
    suspend fun importImage(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val cw = NativeEngine.nativeCanvasWidth()
            val ch = NativeEngine.nativeCanvasHeight()
            val maxSide = min(4096, max(cw, ch))
            val source = ImageDecoder.createSource(resolver, uri)
            var bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
                val iw = info.size.width
                val ih = info.size.height
                val fit = min(1f, min(cw.toFloat() / iw, ch.toFloat() / ih))
                val cap = min(1f, maxSide.toFloat() / max(iw, ih))
                val s = min(fit, cap)
                if (s < 1f) decoder.setTargetSize(max(1, (iw * s).roundToInt()), max(1, (ih * s).roundToInt()))
            }
            if (bmp.config != Bitmap.Config.ARGB_8888) {
                val copy = bmp.copy(Bitmap.Config.ARGB_8888, false)
                bmp.recycle()
                bmp = copy
            }
            try {
                val dx = (cw - bmp.width) / 2
                val dy = (ch - bmp.height) / 2
                check(NativeEngine.nativeImportBitmap(bmp, dx, dy) == 0) { "import failed" }
            } finally {
                bmp.recycle()
            }
        }
    }

    private fun opaque(argb: Int): Int = if ((argb ushr 24) == 0) -1 else argb or (0xFF shl 24)

    private companion object {
        const val BITMAP_LIMIT = 16_000_000L // pixels (64 MB ARGB_8888)
    }
}
