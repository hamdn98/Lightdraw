package com.lightdraw.studio

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.RectF
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.lightdraw.studio.ui.Tool
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Edge-to-edge GL canvas. All touch handling is allocation-free:
 *  - 1 finger: draw / tap tools (fill, eyedropper, select-same-colour); in Hand mode 1 finger pans
 *  - 2 fingers: pinch-zoom, pan, rotate (tap = undo)
 *  - 3 fingers tap = redo
 */
class CanvasGLView(context: Context) : GLSurfaceView(context) {

    // ---- tool state (written from Compose on the UI thread)
    var tool: Int = Tool.DRAW
    var fillKind = 0
    var fillColor = 0xFFFF3366.toInt()
    var fillScale = 1f
    var fillTolerance = 24
    var tolH = 15f
    var tolS = 0.2f
    var tolL = 0.2f

    // ---- shape tool (live preview through the engine, committed on release)
    var shapeKind = 0
    var shapeFlags = 1          // bit0 fill, bit1 stroke
    var shapeStrokeW = 6f

    // ---- selection ("object") in canvas pixels, inclusive; hasSel = false when nothing is selected
    var hasSel = false
    var selX0 = 0
    var selY0 = 0
    var selX1 = 0
    var selY1 = 0

    var onSelect: ((Int, Int, Int, Int) -> Unit)? = null      // (-1,-1,-1,-1) = clear
    var onMoveSelection: ((Int, Int) -> Unit)? = null         // canvas-pixel delta
    var onWrapDrag: ((Int, Int) -> Unit)? = null              // canvas-pixel delta of the wrap tool
    var onMarquee: ((RectF?) -> Unit)? = null                 // rubber band in view pixels
    var onGhost: ((Float, Float) -> Unit)? = null   // canvas-pixel shift of the selection outline while moving (NaN = off)
    var onViewChanged: (() -> Unit)? = null

    var onColorPicked: ((Int) -> Unit)? = null
    var onHistoryChanged: (() -> Unit)? = null
    var onMessage: ((String) -> Unit)? = null

    // ---- view transform (read by the GL thread)
    @Volatile var scale = 1f
    @Volatile var rot = 0f
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var cosR = 1f
    @Volatile var sinR = 0f
    @Volatile var bgArgb = 0xFFFFFFFF.toInt()
    @Volatile var canvasW = 2048
    @Volatile var canvasH = 2048

    private val renderer = CanvasRenderer(this)
    private var fitted = false
    private var minScale = 0.02f
    private val maxScale = 48f

    // ---- gesture state
    private var mode = MODE_IDLE
    private var downTime = 0L
    private var maxPointers = 0
    private var multiMoved = false
    private var downX = 0f
    private var downY = 0f
    private var lastMx = 0f
    private var lastMy = 0f
    private var lastD = 1f
    private var lastA = 0f
    private var dragKind = DRAG_NONE
    private var startCx = 0f
    private var startCy = 0f
    private val marqueeRect = RectF()
    private var outX = 0f
    private var outY = 0f
    private val slop = 24f * resources.displayMetrics.density

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 0, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        refreshDims()
    }

    fun totalTiles(): Int = ((canvasW + 255) / 256) * ((canvasH + 255) / 256)

    fun refreshDims() {
        canvasW = NativeEngine.nativeCanvasWidth().coerceAtLeast(64)
        canvasH = NativeEngine.nativeCanvasHeight().coerceAtLeast(64)
        renderer.requestReset(totalTiles())
    }

    /** Call after the native canvas was replaced (new artboard / project loaded). */
    fun onCanvasReplaced() {
        refreshDims()
        fitCanvas()
        onHistoryChanged?.invoke()
    }

    fun setPaper(argb: Int) {
        bgArgb = argb
        requestRender()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted && w > 0 && h > 0) fitCanvas()
    }

    fun fitCanvas() {
        if (width <= 0 || height <= 0) return
        fitted = true
        val s = min(width.toFloat() / canvasW, height.toFloat() / canvasH) * 0.88f
        minScale = s * 0.5f
        scale = s
        applyRotation(0f)
        tx = width / 2f - s * canvasW / 2f
        ty = height / 2f - s * canvasH / 2f
        requestRender()
        onViewChanged?.invoke()
    }

    /** Rotate the view around the screen centre (Transform > rotate view). */
    fun rotateView(deltaDeg: Float) {
        if (width <= 0 || height <= 0) return
        val cx = width / 2f
        val cy = height / 2f
        screenToCanvas(cx, cy)
        val qx = outX
        val qy = outY
        applyRotation(rot + Math.toRadians(deltaDeg.toDouble()).toFloat())
        tx = cx - scale * (cosR * qx - sinR * qy)
        ty = cy - scale * (sinR * qx + cosR * qy)
        requestRender()
        onViewChanged?.invoke()
    }

    fun resetRotation() = rotateView(-Math.toDegrees(rot.toDouble()).toFloat())

    /** Canvas pixel -> view pixel (writes x, y into [out]). */
    fun canvasToScreen(cx: Float, cy: Float, out: FloatArray) {
        out[0] = tx + scale * (cosR * cx - sinR * cy)
        out[1] = ty + scale * (sinR * cx + cosR * cy)
    }

    private fun applyRotation(r: Float) {
        rot = r
        cosR = cos(r)
        sinR = sin(r)
    }

    private fun screenToCanvas(sx: Float, sy: Float) {
        val dx = sx - tx
        val dy = sy - ty
        outX = (cosR * dx + sinR * dy) / scale
        outY = (-sinR * dx + cosR * dy) / scale
    }

    // ------------------------------------------------------------------ history
    fun undo() {
        if (NativeEngine.nativeUndo()) afterEdit()
    }

    fun redo() {
        if (NativeEngine.nativeRedo()) afterEdit()
    }

    private fun afterEdit() {
        requestRender()
        onHistoryChanged?.invoke()
    }

    // ------------------------------------------------------------------ tools
    private fun pressure(ev: MotionEvent): Float =
        if (ev.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) ev.pressure.coerceIn(0.05f, 1f) else 1f

    private fun isStrokeTool() = tool == Tool.DRAW || tool == Tool.ERASER

    /** Drop a colour / pattern at a screen position (drag & drop from the swatch panel). */
    fun dropFill(sx: Float, sy: Float, kind: Int, color: Int) {
        screenToCanvas(sx, sy)
        runFill(floor(outX).toInt(), floor(outY).toInt(), kind, color)
    }

    private fun runFill(x: Int, y: Int, kind: Int, color: Int) {
        val r = NativeEngine.nativeFill(x, y, kind, color, secondaryOf(color), fillScale, fillTolerance)
        when (r) {
            1 -> onMessage?.invoke("Di luar artboard")
            2 -> onMessage?.invoke("Area terlalu besar untuk fill. Ubah warna Paper di Layers.")
        }
        afterEdit()
    }

    private fun doTap(sx: Float, sy: Float) {
        screenToCanvas(sx, sy)
        val x = floor(outX).toInt()
        val y = floor(outY).toInt()
        when (tool) {
            Tool.FILL -> runFill(x, y, fillKind, fillColor)
            Tool.EYEDROPPER -> onColorPicked?.invoke(NativeEngine.nativePickColor(x, y))
            Tool.SELECT_COLOR -> {
                val n = NativeEngine.nativeSelectReplace(x, y, fillColor, tolH, tolS, tolL)
                onMessage?.invoke(if (n > 0) "$n piksel diganti" else "Tidak ada warna yang cocok")
                afterEdit()
            }
        }
    }

    // ------------------------------------------------------------------ touch
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downTime = ev.eventTime
                maxPointers = 1
                multiMoved = false
                downX = ev.x
                downY = ev.y
                mode = MODE_SINGLE
                lastMx = ev.x
                lastMy = ev.y
                dragKind = DRAG_NONE
                if (tool == Tool.SHAPE || tool == Tool.SELECT || tool == Tool.WRAP) {
                    screenToCanvas(ev.x, ev.y)
                    startCx = outX
                    startCy = outY
                    dragKind = when (tool) {
                        Tool.SHAPE -> DRAG_SHAPE
                        Tool.WRAP -> DRAG_WRAP
                        else -> if (hasSel && startCx >= selX0 && startCx <= selX1 + 1 && startCy >= selY0 && startCy <= selY1 + 1) DRAG_MOVE else DRAG_MARQUEE
                    }
                }
                if (isStrokeTool()) {
                    screenToCanvas(ev.x, ev.y)
                    NativeEngine.nativeStrokeBegin(outX, outY, pressure(ev), ev.eventTime)
                    requestRender()
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPointers = max(maxPointers, ev.pointerCount)
                val early = ev.eventTime - downTime < 300
                if (mode == MODE_SINGLE && (early || !isStrokeTool())) {
                    if (isStrokeTool()) {
                        NativeEngine.nativeStrokeCancel()
                        afterEdit()
                    }
                    if (dragKind != DRAG_NONE) cancelDrag()
                    mode = MODE_MULTI
                }
                if (mode == MODE_MULTI && ev.pointerCount == 2) beginTransform(ev)
            }

            MotionEvent.ACTION_MOVE -> when (mode) {
                MODE_SINGLE -> if (tool == Tool.HAND) {
                    tx += ev.x - lastMx
                    ty += ev.y - lastMy
                    lastMx = ev.x
                    lastMy = ev.y
                    requestRender()
                    onViewChanged?.invoke()
                } else if (dragKind != DRAG_NONE) {
                    dragMove(ev)
                } else if (isStrokeTool()) {
                    val hs = ev.historySize
                    for (h in 0 until hs) {
                        screenToCanvas(ev.getHistoricalX(0, h), ev.getHistoricalY(0, h))
                        NativeEngine.nativeStrokeMove(outX, outY, pressure(ev), ev.getHistoricalEventTime(h))
                    }
                    screenToCanvas(ev.x, ev.y)
                    NativeEngine.nativeStrokeMove(outX, outY, pressure(ev), ev.eventTime)
                    requestRender()
                }

                MODE_MULTI -> if (ev.pointerCount == 2) updateTransform(ev)
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == MODE_SINGLE && ev.actionIndex == 0 && isStrokeTool()) {
                    NativeEngine.nativeStrokeEnd()
                    afterEdit()
                    mode = MODE_IDLE
                } else if (mode == MODE_MULTI && ev.pointerCount - 1 == 2) {
                    beginTransformExcluding(ev, ev.actionIndex)
                }
            }

            MotionEvent.ACTION_UP -> {
                when (mode) {
                    MODE_SINGLE -> {
                        if (isStrokeTool()) {
                            NativeEngine.nativeStrokeEnd()
                            afterEdit()
                        } else if (dragKind != DRAG_NONE) {
                            finishDrag(ev)
                        } else if (hypot(ev.x - downX, ev.y - downY) < slop) {
                            doTap(ev.x, ev.y)
                        }
                    }

                    MODE_MULTI -> if (!multiMoved && ev.eventTime - downTime < 400) {
                        if (maxPointers == 2) undo() else if (maxPointers >= 3) redo()
                    }
                }
                mode = MODE_IDLE
            }

            MotionEvent.ACTION_CANCEL -> {
                if (dragKind != DRAG_NONE) cancelDrag()
                if (mode == MODE_SINGLE && isStrokeTool()) {
                    NativeEngine.nativeStrokeCancel()
                    afterEdit()
                }
                mode = MODE_IDLE
            }
        }
        return true
    }

    // ------------------------------------------------------------------ shape / select / wrap drags

    private fun cancelDrag() {
        if (dragKind == DRAG_SHAPE) {
            NativeEngine.nativeShapeCancel()
            requestRender()
        }
        onMarquee?.invoke(null)
        onGhost?.invoke(Float.NaN, Float.NaN)
        dragKind = DRAG_NONE
    }

    private fun dragMove(ev: MotionEvent) {
        screenToCanvas(ev.x, ev.y)
        val cx = outX
        val cy = outY
        when (dragKind) {
            DRAG_SHAPE -> {
                NativeEngine.nativeShape(shapeKind, startCx, startCy, cx, cy, fillColor, secondaryOf(fillColor), shapeFlags, shapeStrokeW, false)
                requestRender()
            }
            DRAG_MARQUEE -> {
                marqueeRect.set(min(downX, ev.x), min(downY, ev.y), max(downX, ev.x), max(downY, ev.y))
                onMarquee?.invoke(marqueeRect)
            }
            DRAG_MOVE -> onGhost?.invoke(cx - startCx, cy - startCy)
        }
    }

    private fun finishDrag(ev: MotionEvent) {
        screenToCanvas(ev.x, ev.y)
        val cx = outX
        val cy = outY
        val moved = hypot(ev.x - downX, ev.y - downY) >= 6f
        when (dragKind) {
            DRAG_SHAPE -> if (moved) {
                NativeEngine.nativeShape(shapeKind, startCx, startCy, cx, cy, fillColor, secondaryOf(fillColor), shapeFlags, shapeStrokeW, true)
                afterEdit()
            } else {
                NativeEngine.nativeShapeCancel()
                requestRender()
            }
            DRAG_MARQUEE -> {
                onMarquee?.invoke(null)
                if (moved) {
                    onSelect?.invoke(
                        floor(min(startCx, cx)).toInt(), floor(min(startCy, cy)).toInt(),
                        floor(max(startCx, cx)).toInt(), floor(max(startCy, cy)).toInt(),
                    )
                } else {
                    onSelect?.invoke(-1, -1, -1, -1)
                }
            }
            DRAG_MOVE -> {
                onGhost?.invoke(Float.NaN, Float.NaN)
                val dx = (cx - startCx).roundToInt()
                val dy = (cy - startCy).roundToInt()
                if (moved && (dx != 0 || dy != 0)) onMoveSelection?.invoke(dx, dy)
            }
            DRAG_WRAP -> {
                val dx = (cx - startCx).roundToInt()
                val dy = (cy - startCy).roundToInt()
                if (moved && (dx != 0 || dy != 0)) onWrapDrag?.invoke(dx, dy)
            }
        }
        dragKind = DRAG_NONE
    }

    private fun beginTransform(ev: MotionEvent) {
        beginTransformBetween(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1))
    }

    private fun beginTransformExcluding(ev: MotionEvent, lifted: Int) {
        var a = -1
        var b = -1
        for (i in 0 until ev.pointerCount) {
            if (i == lifted) continue
            if (a < 0) a = i else b = i
        }
        if (a >= 0 && b >= 0) beginTransformBetween(ev.getX(a), ev.getY(a), ev.getX(b), ev.getY(b))
    }

    private fun beginTransformBetween(x0: Float, y0: Float, x1: Float, y1: Float) {
        lastMx = (x0 + x1) * 0.5f
        lastMy = (y0 + y1) * 0.5f
        lastD = max(1f, hypot(x1 - x0, y1 - y0))
        lastA = atan2(y1 - y0, x1 - x0)
    }

    private fun updateTransform(ev: MotionEvent) {
        val x0 = ev.getX(0)
        val y0 = ev.getY(0)
        val x1 = ev.getX(1)
        val y1 = ev.getY(1)
        val mx = (x0 + x1) * 0.5f
        val my = (y0 + y1) * 0.5f
        val d = max(1f, hypot(x1 - x0, y1 - y0))
        val a = atan2(y1 - y0, x1 - x0)
        if (!multiMoved) {
            if (hypot(mx - lastMx, my - lastMy) < slop && kotlin.math.abs(d - lastD) < slop) return
            multiMoved = true
            lastMx = mx; lastMy = my; lastD = d; lastA = a // no jump when the gesture engages
            return
        }
        screenToCanvas(lastMx, lastMy) // canvas point that was under the previous centroid
        val qx = outX
        val qy = outY
        val ns = (scale * d / lastD).coerceIn(minScale, maxScale)
        var da = a - lastA
        if (da > PI.toFloat()) da -= 2f * PI.toFloat()
        if (da < -PI.toFloat()) da += 2f * PI.toFloat()
        applyRotation(rot + da)
        tx = mx - ns * (cosR * qx - sinR * qy)
        ty = my - ns * (sinR * qx + cosR * qy)
        scale = ns
        lastMx = mx; lastMy = my; lastD = d; lastA = a
        requestRender()
        onViewChanged?.invoke()
    }

    private companion object {
        const val MODE_IDLE = 0
        const val MODE_SINGLE = 1
        const val MODE_MULTI = 2
        const val DRAG_NONE = 0
        const val DRAG_SHAPE = 1
        const val DRAG_MARQUEE = 2
        const val DRAG_MOVE = 3
        const val DRAG_WRAP = 4
    }
}
