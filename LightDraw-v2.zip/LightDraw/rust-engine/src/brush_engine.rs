//! Brush dabs, blend modes (Normal, Multiply, Screen, Overlay, Add, Eraser) and
//! quadratic-Bezier stroke interpolation. No heap allocation in the stroke path
//! (apart from lazily created tiles).

use std::collections::HashMap;

use crate::symmetry::{unpack_x, unpack_y, Symmetry, MAX_COPIES};
use crate::tiled_canvas::{TiledCanvas, TILE};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Blend {
    Normal,
    Multiply,
    Screen,
    Overlay,
    Add,
    Eraser,
}

impl Blend {
    pub fn from_i32(v: i32) -> Blend {
        match v {
            1 => Blend::Multiply,
            2 => Blend::Screen,
            3 => Blend::Overlay,
            4 => Blend::Add,
            5 => Blend::Eraser,
            _ => Blend::Normal,
        }
    }
}

#[derive(Clone, Copy)]
pub struct Brush {
    pub size: f32,
    pub opacity: f32, // 0..1 (stroke opacity)
    pub hardness: f32,
    pub spacing: f32, // fraction of diameter
    pub angle: f32,   // radians (nib orientation)
    pub aspect: f32,  // 1 = round, <1 = flat nib
    pub color: u32,   // straight RGBA, alpha ignored
    pub blend: Blend,
    pub pressure_size: f32,
    pub pressure_opacity: f32,
    pub buildup: bool, // airbrush-like accumulation
    pub preset: i32,
}

impl Brush {
    pub fn new() -> Self {
        let mut b = Brush {
            size: 18.0,
            opacity: 1.0,
            hardness: 0.8,
            spacing: 0.08,
            angle: 0.0,
            aspect: 1.0,
            color: 0xFF66_33FF,
            blend: Blend::Normal,
            pressure_size: 0.35,
            pressure_opacity: 0.5,
            buildup: false,
            preset: 0,
        };
        b.set_preset(0);
        b
    }

    /// 0 Graphite pencil, 1 Soft airbrush, 2 Studio ink pen, 3 Calligraphy.
    pub fn set_preset(&mut self, id: i32) {
        self.preset = id;
        self.angle = 0.0;
        self.aspect = 1.0;
        self.buildup = false;
        match id {
            1 => {
                self.hardness = 0.0;
                self.spacing = 0.06;
                self.pressure_size = 0.0;
                self.pressure_opacity = 0.8;
                self.buildup = true;
            }
            2 => {
                self.hardness = 1.0;
                self.spacing = 0.05;
                self.pressure_size = 0.6;
                self.pressure_opacity = 0.0;
            }
            3 => {
                self.hardness = 1.0;
                self.spacing = 0.05;
                self.angle = 0.7;
                self.aspect = 0.25;
                self.pressure_size = 0.2;
                self.pressure_opacity = 0.0;
            }
            _ => {
                self.hardness = 0.8;
                self.spacing = 0.08;
                self.pressure_size = 0.35;
                self.pressure_opacity = 0.5;
            }
        }
    }

    /// Stroke opacity after pressure.
    fn stroke_opacity(&self, pressure: f32) -> f32 {
        (self.opacity * (1.0 - self.pressure_opacity + self.pressure_opacity * pressure)).clamp(0.0, 1.0)
    }

    /// True when the stroke can use max-coverage accumulation (Normal / Eraser, no build-up).
    fn uses_coverage(&self) -> bool {
        !self.buildup && matches!(self.blend, Blend::Normal | Blend::Eraser)
    }

    /// Alpha applied per dab for the legacy accumulating modes (Multiply, Screen, Overlay, Add, airbrush).
    fn dab_alpha(&self, pressure: f32) -> f32 {
        let op = self.stroke_opacity(pressure);
        if self.buildup {
            op * 0.2
        } else if op >= 0.999 {
            1.0
        } else {
            1.0 - (1.0 - op).powf((self.spacing * 0.785).clamp(0.01, 1.0))
        }
    }
}

/// Per-stroke coverage mask (sparse, one 256x256 u8 map per touched tile).
/// Overlapping dabs of one stroke take the MAXIMUM coverage instead of compositing on top of each other,
/// which keeps the silhouette edge anti-aliased (no bloated / jagged rim) and makes the opacity slider exact.
pub struct StrokeCov {
    tiles: HashMap<usize, Box<[u8]>>,
}

impl StrokeCov {
    pub fn new() -> Self {
        StrokeCov { tiles: HashMap::new() }
    }

    fn tile(&mut self, idx: usize) -> &mut [u8] {
        self.tiles.entry(idx).or_insert_with(|| vec![0u8; TILE * TILE].into_boxed_slice())
    }
}

/// Premultiplied source-over (integer).
#[inline]
pub fn over(dst: u32, src: u32) -> u32 {
    let sa = src >> 24;
    if sa == 255 {
        return src;
    }
    if sa == 0 {
        return dst;
    }
    let inv = 255 - sa;
    let mut out = 0u32;
    for sh in [0u32, 8, 16, 24] {
        let s = (src >> sh) & 255;
        let d = (dst >> sh) & 255;
        let v = (s + (d * inv + 127) / 255).min(255);
        out |= v << sh;
    }
    out
}

#[inline]
fn to_u8(v: f32) -> u32 {
    ((v * 255.0 + 0.5) as i32).clamp(0, 255) as u32
}

#[inline]
fn blend_channel(mode: Blend, cb: f32, cs: f32) -> f32 {
    match mode {
        Blend::Multiply => cb * cs,
        Blend::Screen => cb + cs - cb * cs,
        Blend::Overlay => {
            if cb <= 0.5 {
                2.0 * cb * cs
            } else {
                1.0 - 2.0 * (1.0 - cb) * (1.0 - cs)
            }
        }
        Blend::Add => (cb + cs).min(1.0),
        _ => cs,
    }
}

/// Blend a straight-colour source with coverage `sa` into a premultiplied destination pixel.
pub fn blend_px(dst: u32, color: u32, sa: f32, mode: Blend) -> u32 {
    let da = ((dst >> 24) & 255) as f32 / 255.0;
    let dr = (dst & 255) as f32 / 255.0;
    let dg = ((dst >> 8) & 255) as f32 / 255.0;
    let db = ((dst >> 16) & 255) as f32 / 255.0;
    let sr = (color & 255) as f32 / 255.0;
    let sg = ((color >> 8) & 255) as f32 / 255.0;
    let sb = ((color >> 16) & 255) as f32 / 255.0;

    let (or, og, ob, oa) = match mode {
        Blend::Eraser => {
            let k = 1.0 - sa;
            (dr * k, dg * k, db * k, da * k)
        }
        Blend::Normal => {
            let k = 1.0 - sa;
            (sr * sa + dr * k, sg * sa + dg * k, sb * sa + db * k, sa + da * k)
        }
        _ => {
            let (cbr, cbg, cbb) = if da > 0.0 { (dr / da, dg / da, db / da) } else { (0.0, 0.0, 0.0) };
            let f = |cs: f32, cb: f32, dpre: f32| -> f32 {
                (1.0 - da) * sa * cs + (1.0 - sa) * dpre + sa * da * blend_channel(mode, cb, cs)
            };
            (f(sr, cbr, dr), f(sg, cbg, dg), f(sb, cbb, db), sa + da * (1.0 - sa))
        }
    };
    to_u8(or) | (to_u8(og) << 8) | (to_u8(ob) << 16) | (to_u8(oa) << 24)
}

/// Stamp one dab centred at (cx, cy).
pub fn stamp(canvas: &mut TiledCanvas, b: &Brush, cov: &mut StrokeCov, cx: f32, cy: f32, pressure: f32) {
    let p = pressure.clamp(0.05, 1.0);
    let size = b.size * (1.0 - b.pressure_size + b.pressure_size * p);
    let use_cov = b.uses_coverage();
    let alpha = if use_cov { b.stroke_opacity(p) } else { b.dab_alpha(p) };
    if alpha <= 0.0005 {
        return;
    }
    let rx = (size * 0.5).max(0.5);
    let ry = (rx * b.aspect).max(0.5);
    let (sn, cs) = b.angle.sin_cos();
    let ext = rx.max(ry) + 1.0;
    let w = canvas.width as i32;
    let h = canvas.height as i32;
    let x0 = ((cx - ext).floor() as i32).max(0);
    let y0 = ((cy - ext).floor() as i32).max(0);
    let x1 = ((cx + ext).ceil() as i32).min(w - 1);
    let y1 = ((cy + ext).ceil() as i32).min(h - 1);
    if x0 > x1 || y0 > y1 {
        return;
    }
    let tiles_x = canvas.tiles_x;
    let hard = b.hardness.clamp(0.0, 0.999);
    let min_r = rx.min(ry);
    for ty in ((y0 >> 8) as usize)..=((y1 >> 8) as usize) {
        for tx in ((x0 >> 8) as usize)..=((x1 >> 8) as usize) {
            let idx = ty * tiles_x + tx;
            if b.blend == Blend::Eraser && !canvas.exists(idx) {
                continue;
            }
            let bx0 = x0.max((tx * TILE) as i32);
            let bx1 = x1.min(((tx + 1) * TILE) as i32 - 1);
            let by0 = y0.max((ty * TILE) as i32);
            let by1 = y1.min(((ty + 1) * TILE) as i32 - 1);
            let px = canvas.tile_mut(idx);
            let mut ctile: Option<&mut [u8]> = if use_cov { Some(cov.tile(idx)) } else { None };
            for y in by0..=by1 {
                let ly = (y as usize) & 255;
                let dy = y as f32 + 0.5 - cy;
                for x in bx0..=bx1 {
                    let dx = x as f32 + 0.5 - cx;
                    let u = (dx * cs + dy * sn) / rx;
                    let v = (-dx * sn + dy * cs) / ry;
                    let d = (u * u + v * v).sqrt();
                    if d >= 1.0 {
                        continue;
                    }
                    let e = ((1.0 - d) * min_r).clamp(0.0, 1.0); // 1px wide rim ...
                    let edge = e * e * (3.0 - 2.0 * e); // ... with a smoothstep profile
                    let fall = if d <= hard {
                        1.0
                    } else {
                        let t = ((d - hard) / (1.0 - hard)).clamp(0.0, 1.0);
                        1.0 - t * t * (3.0 - 2.0 * t)
                    };
                    let sa = edge * fall * alpha;
                    if sa <= 0.002 {
                        continue;
                    }
                    let lp = ly * TILE + ((x as usize) & 255);
                    if let Some(c) = ctile.as_mut() {
                        // Raise this pixel's coverage from `old` to `sa` with one incremental source-over:
                        // base*(1-old) + col*old  --over(a')-->  base*(1-sa) + col*sa
                        let old = c[lp] as f32 / 255.0;
                        if sa <= old + 0.004 {
                            continue;
                        }
                        let inc = ((sa - old) / (1.0 - old)).clamp(0.0, 1.0);
                        c[lp] = ((sa * 255.0) + 0.5).min(255.0) as u8;
                        px[lp] = blend_px(px[lp], b.color, inc, b.blend);
                    } else {
                        px[lp] = blend_px(px[lp], b.color, sa, b.blend);
                    }
                }
            }
        }
    }
}

/// Stamp a dab and all of its symmetric copies.
pub fn stamp_sym(canvas: &mut TiledCanvas, b: &Brush, sym: &Symmetry, cov: &mut StrokeCov, x: f32, y: f32, p: f32) {
    let mut out = [0u64; MAX_COPIES];
    let n = sym.expand(x, y, &mut out);
    for i in 0..n {
        stamp(canvas, b, cov, unpack_x(out[i]), unpack_y(out[i]), p);
    }
}

type Pt = (f32, f32, f32); // x, y, pressure

/// Incremental stroke builder: smooth points in, evenly spaced dabs along a Bezier spline out.
pub struct StrokeState {
    have_last: bool,
    last: Pt,
    mid: Pt,
    next_in: f32,
    dabbed: bool,
    cov: StrokeCov,
}

impl StrokeState {
    pub fn new() -> Self {
        StrokeState { have_last: false, last: (0.0, 0.0, 1.0), mid: (0.0, 0.0, 1.0), next_in: 0.0, dabbed: false, cov: StrokeCov::new() }
    }

    pub fn begin(&mut self) {
        *self = StrokeState::new();
    }

    pub fn add_point(&mut self, canvas: &mut TiledCanvas, b: &Brush, sym: &Symmetry, x: f32, y: f32, p: f32) {
        if !self.have_last {
            self.have_last = true;
            self.last = (x, y, p);
            self.mid = (x, y, p);
            return;
        }
        let ctrl = self.last;
        let start = self.mid;
        let m1: Pt = ((ctrl.0 + x) * 0.5, (ctrl.1 + y) * 0.5, (ctrl.2 + p) * 0.5);
        self.curve(canvas, b, sym, start, ctrl, m1);
        self.mid = m1;
        self.last = (x, y, p);
    }

    pub fn finish(&mut self, canvas: &mut TiledCanvas, b: &Brush, sym: &Symmetry) {
        if !self.have_last {
            return;
        }
        let end = self.last;
        let start = self.mid;
        self.line(canvas, b, sym, start, end);
        if !self.dabbed {
            stamp_sym(canvas, b, sym, &mut self.cov, end.0, end.1, end.2);
            self.dabbed = true;
        }
        self.have_last = false;
    }

    fn curve(&mut self, canvas: &mut TiledCanvas, b: &Brush, sym: &Symmetry, a: Pt, c: Pt, e: Pt) {
        let l1 = ((c.0 - a.0).powi(2) + (c.1 - a.1).powi(2)).sqrt();
        let l2 = ((e.0 - c.0).powi(2) + (e.1 - c.1).powi(2)).sqrt();
        let n = (((l1 + l2) / 4.0).ceil() as usize).clamp(1, 64);
        let mut prev = a;
        for i in 1..=n {
            let t = i as f32 / n as f32;
            let o = 1.0 - t;
            let pt: Pt = (
                o * o * a.0 + 2.0 * o * t * c.0 + t * t * e.0,
                o * o * a.1 + 2.0 * o * t * c.1 + t * t * e.1,
                o * o * a.2 + 2.0 * o * t * c.2 + t * t * e.2,
            );
            self.line(canvas, b, sym, prev, pt);
            prev = pt;
        }
    }

    fn line(&mut self, canvas: &mut TiledCanvas, b: &Brush, sym: &Symmetry, a: Pt, e: Pt) {
        let dx = e.0 - a.0;
        let dy = e.1 - a.1;
        let d = (dx * dx + dy * dy).sqrt();
        if d <= 0.0001 {
            return;
        }
        let step = (b.size * b.spacing).max(1.0);
        let mut s = self.next_in;
        while s <= d {
            let f = s / d;
            stamp_sym(canvas, b, sym, &mut self.cov, a.0 + dx * f, a.1 + dy * f, a.2 + (e.2 - a.2) * f);
            self.dabbed = true;
            s += step;
        }
        self.next_in = s - d;
    }
}
