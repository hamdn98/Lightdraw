//! Sparse tile-based virtual canvas (up to 16384 x 16384 px).
//!
//! * The canvas is split into 256x256 tiles stored as premultiplied RGBA8 (`u32`, byte order R,G,B,A).
//! * Tiles are allocated lazily (sparse). Fully transparent tiles cost nothing.
//! * A resident-tile budget is enforced: least-recently-used off-screen tiles are RLE-compressed
//!   and spilled to disk, then reloaded on demand.
//! * Stroke-level undo/redo is stored as RLE-compressed tile snapshots.

use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::sync::atomic::{AtomicU32, Ordering};

pub const TILE: usize = 256;
pub const TILE_PIXELS: usize = TILE * TILE;
pub const MIN_DIM: u32 = 64;
pub const MAX_DIM: u32 = 16384;
const MAX_UNDO: usize = 32;
const MAX_HISTORY_BYTES: usize = 96 * 1024 * 1024;
const PROJECT_MAGIC: &[u8; 5] = b"LDRW1";

static CANVAS_COUNTER: AtomicU32 = AtomicU32::new(0);

#[inline]
pub fn pack_rgba(r: u8, g: u8, b: u8, a: u8) -> u32 {
    (r as u32) | ((g as u32) << 8) | ((b as u32) << 16) | ((a as u32) << 24)
}

/// Straight (non-premultiplied) RGBA -> premultiplied RGBA.
#[inline]
pub fn premul(c: u32) -> u32 {
    let a = c >> 24;
    if a == 255 {
        return c;
    }
    let f = |v: u32| -> u8 { ((v * a + 127) / 255) as u8 };
    pack_rgba(f(c & 255), f((c >> 8) & 255), f((c >> 16) & 255), a as u8)
}

/// Premultiplied RGBA -> straight RGBA.
#[inline]
pub fn unpremul(p: u32) -> u32 {
    let a = p >> 24;
    if a == 0 || a == 255 {
        return p;
    }
    let f = |v: u32| -> u8 { ((v * 255 + a / 2) / a).min(255) as u8 };
    pack_rgba(f(p & 255), f((p >> 8) & 255), f((p >> 16) & 255), a as u8)
}

pub fn rle_encode(px: &[u32]) -> Vec<u8> {
    let mut out = Vec::with_capacity(256);
    let mut i = 0;
    while i < px.len() {
        let v = px[i];
        let mut j = i + 1;
        while j < px.len() && px[j] == v && (j - i) < 65536 {
            j += 1;
        }
        let run = (j - i - 1) as u16;
        out.extend_from_slice(&run.to_le_bytes());
        out.extend_from_slice(&v.to_le_bytes());
        i = j;
    }
    out
}

pub fn rle_decode(data: &[u8], out: &mut [u32]) -> bool {
    let mut pos = 0;
    let mut o = 0;
    while pos + 6 <= data.len() {
        let run = u16::from_le_bytes([data[pos], data[pos + 1]]) as usize + 1;
        let v = u32::from_le_bytes([data[pos + 2], data[pos + 3], data[pos + 4], data[pos + 5]]);
        pos += 6;
        if o + run > out.len() {
            return false;
        }
        out[o..o + run].fill(v);
        o += run;
    }
    o == out.len()
}

struct Tile {
    px: Vec<u32>,
    used: u64,
}

enum Slot {
    Empty,
    Resident(Tile),
    Spilled,
}

struct EditRecord {
    entries: Vec<(usize, Option<Vec<u8>>)>,
}

impl EditRecord {
    fn bytes(&self) -> usize {
        self.entries.iter().map(|e| e.1.as_ref().map_or(0, |v| v.len())).sum()
    }
}

pub struct TiledCanvas {
    pub width: u32,
    pub height: u32,
    pub tiles_x: usize,
    pub tiles_y: usize,
    pub max_resident: usize,
    slots: Vec<Slot>,
    versions: Vec<u32>,
    clock: u64,
    resident: usize,
    vp: (usize, usize, usize, usize),
    spill_dir: PathBuf,
    undo_stack: Vec<EditRecord>,
    redo_stack: Vec<EditRecord>,
    current: Option<EditRecord>,
    snap_mark: Vec<u32>,
    edit_id: u32,
}

impl TiledCanvas {
    pub fn new(width: u32, height: u32, base_dir: PathBuf, max_resident: usize) -> Self {
        let width = width.clamp(MIN_DIM, MAX_DIM);
        let height = height.clamp(MIN_DIM, MAX_DIM);
        let tiles_x = (width as usize + TILE - 1) / TILE;
        let tiles_y = (height as usize + TILE - 1) / TILE;
        let total = tiles_x * tiles_y;
        let spill_dir = base_dir.join(format!("c{}", CANVAS_COUNTER.fetch_add(1, Ordering::Relaxed)));
        let _ = fs::remove_dir_all(&spill_dir);
        let _ = fs::create_dir_all(&spill_dir);
        let mut slots = Vec::with_capacity(total);
        for _ in 0..total {
            slots.push(Slot::Empty);
        }
        TiledCanvas {
            width,
            height,
            tiles_x,
            tiles_y,
            max_resident: max_resident.max(32),
            slots,
            versions: vec![0; total],
            clock: 0,
            resident: 0,
            vp: (0, 0, tiles_x - 1, tiles_y - 1),
            spill_dir,
            undo_stack: Vec::new(),
            redo_stack: Vec::new(),
            current: None,
            snap_mark: vec![0; total],
            edit_id: 0,
        }
    }

    /// Remove all spill files of this canvas (call when the canvas is replaced).
    pub fn cleanup(&self) {
        let _ = fs::remove_dir_all(&self.spill_dir);
    }

    pub fn tile_count(&self) -> usize {
        self.slots.len()
    }

    pub fn exists(&self, idx: usize) -> bool {
        !matches!(self.slots[idx], Slot::Empty)
    }

    pub fn version(&self, idx: usize) -> u32 {
        self.versions[idx]
    }

    fn spill_path(&self, idx: usize) -> PathBuf {
        self.spill_dir.join(format!("t{}.rle", idx))
    }

    // ---------------------------------------------------------------- residency

    fn in_viewport(&self, idx: usize) -> bool {
        let tx = idx % self.tiles_x;
        let ty = idx / self.tiles_x;
        tx >= self.vp.0 && tx <= self.vp.2 && ty >= self.vp.1 && ty <= self.vp.3
    }

    /// Set the visible tile rectangle (inclusive). A one-tile margin is added and off-screen tiles pruned.
    pub fn set_viewport(&mut self, tx0: i32, ty0: i32, tx1: i32, ty1: i32) {
        let mx = self.tiles_x as i32 - 1;
        let my = self.tiles_y as i32 - 1;
        self.vp = (
            (tx0 - 1).clamp(0, mx) as usize,
            (ty0 - 1).clamp(0, my) as usize,
            (tx1 + 1).clamp(0, mx) as usize,
            (ty1 + 1).clamp(0, my) as usize,
        );
        self.prune_offscreen();
    }

    fn prune_offscreen(&mut self) {
        let soft = self.max_resident * 3 / 5;
        while self.resident > soft {
            if !self.evict_one(usize::MAX) {
                break;
            }
        }
    }

    fn evict_one(&mut self, protect: usize) -> bool {
        let mut best: Option<usize> = None;
        let mut best_used = u64::MAX;
        for (i, s) in self.slots.iter().enumerate() {
            if let Slot::Resident(t) = s {
                if i == protect || self.in_viewport(i) {
                    continue;
                }
                if t.used < best_used {
                    best_used = t.used;
                    best = Some(i);
                }
            }
        }
        match best {
            Some(i) => {
                self.spill(i);
                true
            }
            None => false,
        }
    }

    fn spill(&mut self, idx: usize) {
        let old = std::mem::replace(&mut self.slots[idx], Slot::Empty);
        if let Slot::Resident(t) = old {
            if t.px.iter().all(|&p| p == 0) {
                self.resident -= 1; // fully transparent -> becomes sparse again
                return;
            }
            let data = rle_encode(&t.px);
            if fs::write(self.spill_path(idx), data).is_ok() {
                self.slots[idx] = Slot::Spilled;
                self.resident -= 1;
            } else {
                self.slots[idx] = Slot::Resident(t); // keep data if disk write fails
            }
        } else {
            self.slots[idx] = old;
        }
    }

    fn ensure_resident(&mut self, idx: usize, create: bool) -> bool {
        self.clock += 1;
        let clock = self.clock;
        if let Slot::Resident(t) = &mut self.slots[idx] {
            t.used = clock;
            return true;
        }
        let spilled = matches!(self.slots[idx], Slot::Spilled);
        if !spilled && !create {
            return false;
        }
        while self.resident >= self.max_resident {
            if !self.evict_one(idx) {
                break;
            }
        }
        let mut px = vec![0u32; TILE_PIXELS];
        if spilled {
            let path = self.spill_path(idx);
            let ok = match fs::read(&path) {
                Ok(d) => rle_decode(&d, &mut px),
                Err(_) => false,
            };
            if !ok {
                px.fill(0);
            }
            let _ = fs::remove_file(&path);
        }
        self.slots[idx] = Slot::Resident(Tile { px, used: clock });
        self.resident += 1;
        true
    }

    fn px_ref(&self, idx: usize) -> Option<&[u32]> {
        match &self.slots[idx] {
            Slot::Resident(t) => Some(&t.px[..]),
            _ => None,
        }
    }

    fn drop_tile(&mut self, idx: usize) {
        let was_res = matches!(self.slots[idx], Slot::Resident(_));
        let was_spill = matches!(self.slots[idx], Slot::Spilled);
        if was_res {
            self.resident -= 1;
        }
        if was_spill {
            let _ = fs::remove_file(self.spill_path(idx));
        }
        self.slots[idx] = Slot::Empty;
    }

    // ---------------------------------------------------------------- pixel access

    /// Read-only access to a tile (loads it from disk if spilled). `None` when the tile is empty.
    pub fn tile_pixels(&mut self, idx: usize) -> Option<&[u32]> {
        if !self.ensure_resident(idx, false) {
            return None;
        }
        self.px_ref(idx)
    }

    /// Writable access to a tile (allocates it if needed, records undo snapshot, bumps version).
    pub fn tile_mut(&mut self, idx: usize) -> &mut [u32] {
        self.snapshot_for_edit(idx);
        self.ensure_resident(idx, true);
        self.versions[idx] = self.versions[idx].wrapping_add(1);
        match &mut self.slots[idx] {
            Slot::Resident(t) => &mut t.px[..],
            _ => unreachable!(),
        }
    }

    pub fn get_pixel(&mut self, x: i32, y: i32) -> u32 {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return 0;
        }
        let idx = ((y as usize) >> 8) * self.tiles_x + ((x as usize) >> 8);
        let local = ((y as usize) & 255) * TILE + ((x as usize) & 255);
        match self.tile_pixels(idx) {
            Some(px) => px[local],
            None => 0,
        }
    }

    /// Fill `dst` with pixels of row `y` starting at `x0`. Out-of-range parts are transparent.
    pub fn read_row(&mut self, y: u32, x0: u32, dst: &mut [u32]) {
        if y >= self.height || x0 >= self.width {
            dst.fill(0);
            return;
        }
        let avail = (self.width - x0) as usize;
        let len = dst.len().min(avail);
        if len < dst.len() {
            dst[len..].fill(0);
        }
        let ty = (y as usize) >> 8;
        let ly = (y as usize) & 255;
        let mut x = x0 as usize;
        let end = x0 as usize + len;
        let mut o = 0usize;
        while x < end {
            let tx = x >> 8;
            let lx = x & 255;
            let n = (TILE - lx).min(end - x);
            let idx = ty * self.tiles_x + tx;
            match self.tile_pixels(idx) {
                Some(px) => dst[o..o + n].copy_from_slice(&px[ly * TILE + lx..ly * TILE + lx + n]),
                None => dst[o..o + n].fill(0),
            }
            x += n;
            o += n;
        }
    }

    /// Copy a tile as RGBA bytes (premultiplied) for GPU upload. Returns false if the tile is empty.
    pub fn copy_tile_bytes(&mut self, idx: usize, dst: &mut [u8]) -> bool {
        if dst.len() < TILE_PIXELS * 4 {
            return false;
        }
        match self.tile_pixels(idx) {
            Some(px) => {
                for (chunk, p) in dst.chunks_exact_mut(4).zip(px.iter()) {
                    chunk.copy_from_slice(&p.to_le_bytes());
                }
                true
            }
            None => false,
        }
    }

    /// List existing tiles inside an inclusive tile rectangle (indices + versions). Returns the count.
    pub fn visible_tiles(&mut self, tx0: i32, ty0: i32, tx1: i32, ty1: i32, idx_out: &mut [i32], ver_out: &mut [i32]) -> usize {
        if tx1 < tx0 || ty1 < ty0 {
            return 0;
        }
        let mx = self.tiles_x as i32 - 1;
        let my = self.tiles_y as i32 - 1;
        let (x0, x1) = (tx0.clamp(0, mx), tx1.clamp(0, mx));
        let (y0, y1) = (ty0.clamp(0, my), ty1.clamp(0, my));
        let cap = idx_out.len().min(ver_out.len());
        let mut n = 0usize;
        for ty in y0..=y1 {
            for tx in x0..=x1 {
                let idx = ty as usize * self.tiles_x + tx as usize;
                if self.exists(idx) && n < cap {
                    idx_out[n] = idx as i32;
                    ver_out[n] = self.versions[idx] as i32;
                    n += 1;
                }
            }
        }
        n
    }

    // ---------------------------------------------------------------- history

    pub fn begin_edit(&mut self) {
        self.end_edit();
        self.edit_id = self.edit_id.wrapping_add(1);
        if self.edit_id == 0 {
            self.snap_mark.fill(0);
            self.edit_id = 1;
        }
        self.current = Some(EditRecord { entries: Vec::new() });
    }

    fn snapshot_for_edit(&mut self, idx: usize) {
        if self.current.is_none() || self.snap_mark[idx] == self.edit_id {
            return;
        }
        self.snap_mark[idx] = self.edit_id;
        let snap = if self.ensure_resident(idx, false) {
            self.px_ref(idx).map(rle_encode)
        } else {
            None
        };
        if let Some(rec) = self.current.as_mut() {
            rec.entries.push((idx, snap));
        }
    }

    pub fn end_edit(&mut self) {
        if let Some(rec) = self.current.take() {
            if rec.entries.is_empty() {
                return;
            }
            self.undo_stack.push(rec);
            self.redo_stack.clear();
            loop {
                let total: usize = self.undo_stack.iter().map(|r| r.bytes()).sum();
                if self.undo_stack.len() > MAX_UNDO || (total > MAX_HISTORY_BYTES && self.undo_stack.len() > 1) {
                    self.undo_stack.remove(0);
                } else {
                    break;
                }
            }
        }
    }

    /// Abort the running edit and restore the canvas to its state at `begin_edit`.
    pub fn cancel_edit(&mut self) {
        if let Some(mut rec) = self.current.take() {
            self.apply_record(&mut rec);
        }
    }

    fn apply_record(&mut self, rec: &mut EditRecord) {
        for e in rec.entries.iter_mut() {
            let idx = e.0;
            let cur = if self.ensure_resident(idx, false) {
                self.px_ref(idx).map(rle_encode)
            } else {
                None
            };
            let old = std::mem::replace(&mut e.1, cur);
            self.restore_tile(idx, old.as_deref());
        }
    }

    fn restore_tile(&mut self, idx: usize, data: Option<&[u8]>) {
        match data {
            None => self.drop_tile(idx),
            Some(d) => {
                self.ensure_resident(idx, true);
                if let Slot::Resident(t) = &mut self.slots[idx] {
                    if !rle_decode(d, &mut t.px) {
                        t.px.fill(0);
                    }
                }
            }
        }
        self.versions[idx] = self.versions[idx].wrapping_add(1);
    }

    pub fn can_undo(&self) -> bool {
        !self.undo_stack.is_empty()
    }

    pub fn can_redo(&self) -> bool {
        !self.redo_stack.is_empty()
    }

    pub fn undo(&mut self) -> bool {
        if self.current.is_some() {
            return false;
        }
        match self.undo_stack.pop() {
            Some(mut rec) => {
                self.apply_record(&mut rec);
                self.redo_stack.push(rec);
                true
            }
            None => false,
        }
    }

    pub fn redo(&mut self) -> bool {
        if self.current.is_some() {
            return false;
        }
        match self.redo_stack.pop() {
            Some(mut rec) => {
                self.apply_record(&mut rec);
                self.undo_stack.push(rec);
                true
            }
            None => false,
        }
    }

    /// Erase the whole canvas (undoable).
    pub fn clear_all(&mut self) {
        self.begin_edit();
        for idx in 0..self.slots.len() {
            if self.exists(idx) {
                self.snapshot_for_edit(idx);
                self.drop_tile(idx);
                self.versions[idx] = self.versions[idx].wrapping_add(1);
            }
        }
        self.end_edit();
    }

    // ---------------------------------------------------------------- project file

    pub fn write_project<W: Write>(&mut self, w: &mut W, bg: u32) -> io::Result<()> {
        w.write_all(PROJECT_MAGIC)?;
        w.write_all(&self.width.to_le_bytes())?;
        w.write_all(&self.height.to_le_bytes())?;
        w.write_all(&bg.to_le_bytes())?;
        let list: Vec<usize> = (0..self.slots.len()).filter(|&i| self.exists(i)).collect();
        w.write_all(&(list.len() as u32).to_le_bytes())?;
        for idx in list {
            let data = match self.tile_pixels(idx) {
                Some(px) => rle_encode(px),
                None => Vec::new(),
            };
            w.write_all(&(idx as u32).to_le_bytes())?;
            w.write_all(&(data.len() as u32).to_le_bytes())?;
            w.write_all(&data)?;
        }
        Ok(())
    }

    pub fn read_project<R: Read>(r: &mut R, base_dir: PathBuf, max_resident: usize) -> io::Result<(TiledCanvas, u32)> {
        let bad = |m: &str| io::Error::new(io::ErrorKind::InvalidData, m.to_string());
        let mut magic = [0u8; 5];
        r.read_exact(&mut magic)?;
        if &magic != PROJECT_MAGIC {
            return Err(bad("bad magic"));
        }
        let w = read_u32(r)?;
        let h = read_u32(r)?;
        let bg = read_u32(r)?;
        if !(MIN_DIM..=MAX_DIM).contains(&w) || !(MIN_DIM..=MAX_DIM).contains(&h) {
            return Err(bad("bad size"));
        }
        let count = read_u32(r)? as usize;
        let mut canvas = TiledCanvas::new(w, h, base_dir, max_resident);
        if count > canvas.slots.len() {
            canvas.cleanup();
            return Err(bad("bad tile count"));
        }
        for _ in 0..count {
            let idx = read_u32(r)? as usize;
            let len = read_u32(r)? as usize;
            if idx >= canvas.slots.len() || len > TILE_PIXELS * 6 {
                canvas.cleanup();
                return Err(bad("bad tile"));
            }
            let mut data = vec![0u8; len];
            r.read_exact(&mut data)?;
            canvas.restore_tile(idx, Some(&data));
        }
        Ok((canvas, bg))
    }
}

fn read_u32<R: Read>(r: &mut R) -> io::Result<u32> {
    let mut b = [0u8; 4];
    r.read_exact(&mut b)?;
    Ok(u32::from_le_bytes(b))
}
