# LightDraw — Android drawing app (Rust + OpenGL ES 3 + Compose)

Aplikasi gambar ringan untuk perangkat RAM rendah (target 3 GB, Android 10+).
Artboard hingga **16384 × 16384 px** lewat kanvas virtual *sparse tile* (256×256) di memori native.
UI mengikuti mockup terbaru: toolbar pill di atas (Gallery + tool + warna), popup dropdown (Brush Library, Pattern Motif, Mirror, Crop & FX, Pathfinder, Color Studio), slider vertikal ukuran/opacity + undo/redo di kiri, dan navigasi bawah (Brush / Shapes / Transform / Crop & FX + mode Hand).
Ikon aplikasi: kentang membawa brush (adaptive icon vektor, `res/drawable/ic_launcher_*.xml`).

## Struktur
```
rust-engine/src/
  tiled_canvas.rs   kanvas tile sparse, LRU spill ke disk, undo/redo, file project
  color_engine.rs   Select & Edit Same Color (toleransi H/S/L, lintas tile)
  pattern_fill.rs   scanline flood fill + pola seamless (gingham, argyle, seigaiha, houndstooth, plaid, floral)
  brush_engine.rs   dab, blend mode (Normal/Multiply/Screen/Overlay/Add/Eraser), spline Bezier
  stabilizer.rs     streamline: damped spring + moving average
  symmetry.rs       horizontal / vertical / radial 2–12 sektor, koordinat 64-bit packed
  engine_core.rs    JNI bridge + export PNG streaming + project save/load
app/src/main/java/com/lightdraw/studio/
  CanvasGLView.kt / CanvasRenderer.kt   GL ES 3.0, matriks proyeksi zoom/pan/rotate, gesture tanpa alokasi
  CanvasScreen.kt   layar edge-to-edge + dialog (Artboard, Export, Layers)
  ExportManager.kt  MediaStore (Pictures/DrawingApp, Download/DrawingApp), import gambar
  ui/               Theme, Icons (vektor), ColorPicker (roda HSL + kotak HSV), FloatingToolbar (toolbar pill, popup, slider, bottom nav)
.github/workflows/build.yml   CI: JDK17 + Rust + cargo-ndk -> assembleRelease -> app-release.zip
```

## Build lokal
```
cd rust-engine && cargo ndk -t arm64-v8a -t armeabi-v7a -o ../app/src/main/jniLibs build --release
cd .. && gradle wrapper --gradle-version 8.9   # sekali saja, membuat gradlew
./gradlew assembleRelease
```
APK release ditandatangani dengan debug keystore agar bisa langsung di-install. Ganti dengan keystore sendiri untuk rilis.

## Gestur
- 1 jari: gambar / tap untuk Fill, Eyedropper, Select Color
- 2 jari: cubit zoom, geser, putar; **tap 2 jari = Undo**, **tap 3 jari = Redo**
- Seret swatch warna atau kartu pola ke kanvas = isi di titik itu
- Tombol tangan hijau (kanan bawah) = mode Hand: 1 jari menggeser kanvas

## Batasan yang perlu diketahui
- Satu layer gambar + Paper (latar). Belum ada multi-layer.
- Fill pada area kosong raksasa dibatasi 400 tile baru (~100 MB); untuk latar penuh pakai warna Paper.
- Export PNG di atas 16 MP di-stream native; JPEG di atas 16 MP diperkecil otomatis.
- Pola dihitung di Rust (seamless karena koordinat global), bukan shader GL.
- Tidak ada autosave; project disimpan manual lewat Export > Project.
- Kode belum pernah dikompilasi di lingkungan pembuatnya; jalankan CI dan perbaiki error kompilasi bila ada.
