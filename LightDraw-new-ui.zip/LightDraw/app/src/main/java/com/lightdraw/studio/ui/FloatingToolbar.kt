package com.lightdraw.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlin.math.sqrt

object Tool {
    const val DRAW = 0
    const val ERASER = 1
    const val FILL = 2
    const val SELECT_COLOR = 3
    const val EYEDROPPER = 4
    const val HAND = 5
}

/** Popup panels that drop down under the top toolbar. BRUSH..FX double as the bottom-nav groups. */
object Panel {
    const val NONE = -1
    const val TOOLS = 0
    const val BRUSH = 1
    const val PATTERN = 2
    const val MIRROR = 3
    const val FX = 4
    const val PATHFINDER = 5
    const val COLOR = 6
}

private val AccentAmber = Color(0xFFF5A623)
private val AccentGreen = Color(0xFF22C55E)
private val ButtonBg = Color(0xFF26262E)
private val IconIdle = Color(0xFFC8CDD6)

/** All UI-visible drawing state. Pushed to the native engine by CanvasScreen. */
@Stable
class DrawState {
    var tool by mutableIntStateOf(Tool.DRAW)
    private var prevTool = Tool.DRAW
    var color by mutableIntStateOf(0xFFA066FF.toInt())

    var brushPreset by mutableIntStateOf(0)
    var size by mutableFloatStateOf(18f)
    var opacity by mutableFloatStateOf(100f)      // %
    var stabilizer by mutableFloatStateOf(65f)    // %
    var blend by mutableIntStateOf(0)             // 0 normal 1 multiply 2 screen 3 overlay 4 add

    var pattern by mutableIntStateOf(0)           // 0 = solid colour
    var patternScale by mutableFloatStateOf(1f)
    var fillTolerance by mutableFloatStateOf(24f)

    var symMode by mutableIntStateOf(0)           // 0 off 1 horizontal 2 vertical 3 radial
    var sectors by mutableIntStateOf(6)
    var symMirror by mutableStateOf(false)

    var tolH by mutableFloatStateOf(15f)          // degrees
    var tolS by mutableFloatStateOf(20f)          // %
    var tolL by mutableFloatStateOf(20f)          // %

    var paperColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var paperVisible by mutableStateOf(true)

    /** Popup currently open (Panel.*), and the last bottom-nav group that was chosen. */
    var panel by mutableIntStateOf(Panel.NONE)
    var group by mutableIntStateOf(Panel.BRUSH)

    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    fun togglePanel(id: Int) {
        panel = if (panel == id) Panel.NONE else id
    }

    /** Brush / Shapes / Transform / FX groups: highlight the group, toggle its popup and switch to a matching tool. */
    fun selectGroup(id: Int) {
        group = id
        when (id) {
            Panel.BRUSH -> if (tool != Tool.DRAW && tool != Tool.ERASER) tool = Tool.DRAW
            Panel.PATTERN -> tool = Tool.FILL
        }
        togglePanel(id)
    }

    fun toggleEyedropper() {
        if (tool == Tool.EYEDROPPER) {
            tool = prevTool
        } else {
            if (tool != Tool.HAND) prevTool = tool
            tool = Tool.EYEDROPPER
        }
    }

    fun finishEyedropper() {
        if (tool == Tool.EYEDROPPER) tool = prevTool
    }

    fun toggleHand() {
        if (tool == Tool.HAND) {
            tool = prevTool
        } else {
            if (tool != Tool.EYEDROPPER) prevTool = tool
            tool = Tool.HAND
        }
    }
}

// ------------------------------------------------------------------ top pill toolbar

@Composable
private fun TbIcon(icon: ImageVector, desc: String, active: Boolean, open: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .size(34.dp)
            .clip(shape)
            .background(
                when {
                    active -> Palette.AccentPurple.copy(alpha = 0.18f)
                    open -> Color(0xFF2E2E36)
                    else -> Color.Transparent
                }
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, desc,
            tint = when {
                active -> Palette.AccentPurple
                open -> Color.White
                else -> IconIdle
            },
            modifier = Modifier.size(20.dp),
        )
    }
}

/** "‹ Gallery | tools… | colour dot" pill, like the mock-up. */
@Composable
fun TopToolbar(
    state: DrawState,
    onGallery: () -> Unit,
    onArtboard: () -> Unit,
    onLayers: () -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            val gShape = RoundedCornerShape(12.dp)
            Row(
                Modifier
                    .clip(gShape)
                    .background(Palette.DarkBg.copy(alpha = 0.6f))
                    .border(1.dp, Palette.PanelBorder, gShape)
                    .clickable { onGallery() }
                    .padding(start = 6.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(DrawIcons.ChevronLeft, null, tint = Palette.TextMuted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text("Gallery", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(24.dp).background(Palette.PanelBorder))
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TbIcon(DrawIcons.Wrench, "Tools", false, state.panel == Panel.TOOLS) { state.togglePanel(Panel.TOOLS) }
                TbIcon(DrawIcons.Crop, "Artboard", false, false) { onArtboard() }
                TbIcon(DrawIcons.Brush, "Brush", state.group == Panel.BRUSH, state.panel == Panel.BRUSH) { state.selectGroup(Panel.BRUSH) }
                TbIcon(DrawIcons.Shapes, "Shapes", state.group == Panel.PATTERN, state.panel == Panel.PATTERN) { state.selectGroup(Panel.PATTERN) }
                TbIcon(DrawIcons.Transform, "Transform", state.group == Panel.MIRROR, state.panel == Panel.MIRROR) { state.selectGroup(Panel.MIRROR) }
                TbIcon(DrawIcons.Wand, "FX", state.group == Panel.FX, state.panel == Panel.FX) { state.selectGroup(Panel.FX) }
                TbIcon(DrawIcons.Pathfinder, "Pathfinder", false, state.panel == Panel.PATHFINDER) { state.togglePanel(Panel.PATHFINDER) }
                TbIcon(DrawIcons.Align, "Layers", false, false) { onLayers() }
                TbIcon(DrawIcons.Copy, "Import", false, false) { onImport() }
            }
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(state.color))
                    .border(2.dp, Color.White.copy(alpha = if (state.panel == Panel.COLOR) 0.7f else 0.25f), CircleShape)
                    .clickable { state.togglePanel(Panel.COLOR) },
            )
        }
    }
}

// ------------------------------------------------------------------ left vertical sliders

@Composable
fun VerticalSlider(fraction: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val push by rememberUpdatedState(onChange)
    Box(
        modifier
            .width(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) },
                ) { change, _ ->
                    change.consume()
                    push((1f - change.position.y / size.height).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.width(7.dp).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFF2E2E36))) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(fraction.coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFC4C4CC))
            )
        }
    }
}

@Composable
private fun PanelDivider() {
    Box(Modifier.padding(vertical = 8.dp).width(20.dp).height(1.dp).background(Palette.PanelBorder))
}

@Composable
private fun SmallBtn(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = if (enabled) IconIdle else Palette.TextMuted.copy(alpha = 0.35f), modifier = Modifier.size(20.dp))
    }
}

/** Size + opacity vertical sliders with undo / redo underneath. */
@Composable
fun SideSliderPanel(
    state: DrawState,
    sliderHeight: Dp,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Quadratic mapping: fine control for small brushes, still reaches 200 px.
    val sizeFrac = sqrt(((state.size - 1f) / 199f).coerceIn(0f, 1f))
    val dot = (4f + 10f * sizeFrac).dp
    FloatingPanel(modifier.width(38.dp), shape = RoundedCornerShape(19.dp)) {
        Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(16.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(dot).clip(CircleShape).background(Color(0xFFB4B8C2)))
            }
            Spacer(Modifier.height(6.dp))
            VerticalSlider(sizeFrac, { state.size = 1f + 199f * it * it }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${(sizeFrac * 100f).roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            Icon(DrawIcons.Drop, "Opacity", tint = Color(0xFFB4B8C2), modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(6.dp))
            VerticalSlider(state.opacity / 100f, { state.opacity = (it * 100f).coerceIn(1f, 100f) }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${state.opacity.roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            SmallBtn(DrawIcons.Undo, "Undo", state.canUndo, onUndo)
            SmallBtn(DrawIcons.Redo, "Redo", state.canRedo, onRedo)
        }
    }
}

// ------------------------------------------------------------------ popups

@Composable
private fun Popup(
    title: String,
    tag: String,
    tagColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
                Text(tag, color = tagColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(Modifier.padding(vertical = 10.dp).fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content,
            )
        }
    }
}

@Composable
private fun OpButton(icon: ImageVector, label: String, tint: Color, selected: Boolean, modifier: Modifier, clickMod: Modifier, iconRotation: Float = 0f) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) tint.copy(alpha = 0.14f) else ButtonBg)
            .border(1.dp, if (selected) tint else Palette.PanelBorder, shape)
            .then(clickMod)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp).rotate(iconRotation))
        Text(label, color = if (selected) Color.White else Palette.TextPrimary, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: Color = Palette.AccentPurple, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) accent else Palette.TextMuted,
        fontSize = 11.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) accent else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Palette.TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
}

private class BrushInfo(val icon: ImageVector, val title: String, val sub: String)

private val Brushes = listOf(
    BrushInfo(DrawIcons.Brush, "Graphite Pencil", "Pressure Sensitivity"),
    BrushInfo(DrawIcons.Palette, "Soft Airbrush", "Smooth Gradient"),
    BrushInfo(DrawIcons.Eyedropper, "Studio Ink Pen", "Sharp Line Art"),
    BrushInfo(DrawIcons.Zigzag, "Calligraphy", "Angled Stroke"),
)

private val Blends = listOf("Normal", "Multiply", "Screen", "Overlay", "Add")

private class PatternInfo(val id: Int, val icon: ImageVector, val title: String)

private val Patterns = listOf(
    PatternInfo(1, DrawIcons.Grid, "Gingham"),
    PatternInfo(2, DrawIcons.Diamond, "Argyle"),
    PatternInfo(3, DrawIcons.Waves, "Seigaiha"),
    PatternInfo(4, DrawIcons.Zigzag, "Houndstooth"),
    PatternInfo(5, DrawIcons.Plaid, "Plaid"),
    PatternInfo(6, DrawIcons.Flower, "Floral"),
)

@Composable
private fun BrushPopup(state: DrawState, modifier: Modifier) {
    Popup("Brush Library", "Dynamics Active", Palette.AccentCyan, modifier) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpButton(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.tool != Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.DRAW })
            OpButton(DrawIcons.Eraser, "Eraser", Palette.AccentPink, state.tool == Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.ERASER })
        }
        Brushes.chunked(2).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEachIndexed { c, b ->
                    val id = r * 2 + c
                    val sel = state.brushPreset == id
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.10f) else ButtonBg)
                            .border(1.dp, if (sel) Palette.AccentPurple else Palette.PanelBorder, RoundedCornerShape(12.dp))
                            .clickable { state.brushPreset = id; if (state.tool != Tool.ERASER) state.tool = Tool.DRAW }
                            .padding(10.dp),
                    ) {
                        Icon(b.icon, b.title, tint = if (sel) Palette.AccentPurple else Palette.TextMuted, modifier = Modifier.size(20.dp))
                        Text(b.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(b.sub, color = Palette.TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Blends.forEachIndexed { i, n -> Chip(n, state.blend == i) { state.blend = i } }
        }
        LabeledSlider("Streamline Stabilizer", "${state.stabilizer.toInt()}%", state.stabilizer, 0f..99f, Palette.AccentCyan) { state.stabilizer = it }
        Hint("Ukuran & opacity diatur lewat slider di sisi kiri kanvas.")
    }
}

@Composable
private fun PatternPopup(state: DrawState, dd: DragDropState, modifier: Modifier) {
    Popup("Pattern Motif", "Seamless Tiling", Palette.AccentCyan, modifier) {
        Patterns.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { p ->
                    OpButton(
                        p.icon, p.title, Palette.AccentCyan, state.pattern == p.id, Modifier.weight(1f),
                        Modifier.dragSource(dd, DragPayload(p.id, state.color)) {
                            state.pattern = if (state.pattern == p.id) 0 else p.id
                            state.tool = Tool.FILL
                        },
                    )
                }
            }
        }
        Hint("Ketuk motif lalu ketuk kanvas (Fill), atau geser motif langsung ke kanvas.")
        LabeledSlider("Skala Tile Pattern", "%.1fx".format(state.patternScale), state.patternScale, 0.2f..5f, Palette.AccentCyan) { state.patternScale = it }
        LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }
    }
}

@Composable
private fun MirrorPopup(state: DrawState, modifier: Modifier) {
    Popup("Mirror & Symmetry", "Native Rust Math", Palette.AccentPurple, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Close, "Off", Palette.TextMuted, state.symMode == 0, Modifier.weight(1f), Modifier.clickable { state.symMode = 0 })
            OpButton(DrawIcons.Symmetry, "Horizontal", Palette.AccentPurple, state.symMode == 1, Modifier.weight(1f), Modifier.clickable { state.symMode = 1 })
            OpButton(DrawIcons.Symmetry, "Vertical", Palette.AccentPurple, state.symMode == 2, Modifier.weight(1f), Modifier.clickable { state.symMode = 2 }, iconRotation = 90f)
            OpButton(DrawIcons.Flower, "Radial", Palette.AccentPurple, state.symMode == 3, Modifier.weight(1f), Modifier.clickable { state.symMode = 3 })
        }
        if (state.symMode == 3) {
            LabeledSlider("Jumlah Sektor", "${state.sectors}", state.sectors.toFloat(), 2f..12f) { state.sectors = it.toInt().coerceIn(2, 12) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mirror tiap sektor", color = Palette.TextMuted, fontSize = 12.sp)
                Switch(
                    checked = state.symMirror, onCheckedChange = { state.symMirror = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple),
                )
            }
        }
        Hint("Pusat simetri = tengah artboard.")
    }
}

@Composable
private fun FxPopup(state: DrawState, onArtboard: () -> Unit, modifier: Modifier) {
    Popup("Crop & FX", "Color Magic", Palette.AccentPink, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Fill, "Fill", Palette.AccentCyan, state.tool == Tool.FILL, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.FILL })
            OpButton(DrawIcons.Wand, "Same Color", Palette.AccentPink, state.tool == Tool.SELECT_COLOR, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.SELECT_COLOR })
            OpButton(DrawIcons.Eyedropper, "Eyedropper", Palette.AccentPurple, state.tool == Tool.EYEDROPPER, Modifier.weight(1f), Modifier.clickable { state.toggleEyedropper() })
            OpButton(DrawIcons.Crop, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
        if (state.tool == Tool.SELECT_COLOR) {
            Hint("Ketuk warna di kanvas: semua piksel yang cocok (seluruh artboard) diganti ke warna aktif.")
            LabeledSlider("Toleransi Hue", "${state.tolH.toInt()}°", state.tolH, 0f..180f) { state.tolH = it }
            LabeledSlider("Toleransi Saturation", "${state.tolS.toInt()}%", state.tolS, 0f..100f) { state.tolS = it }
            LabeledSlider("Toleransi Luminance", "${state.tolL.toInt()}%", state.tolL, 0f..100f) { state.tolL = it }
        } else if (state.tool == Tool.FILL) {
            LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }
        } else {
            Hint("Pilih Fill atau Same Color untuk mengatur toleransinya.")
        }
    }
}

@Composable
private fun PathfinderPopup(state: DrawState, modifier: Modifier) {
    fun mode(tool: Int, blend: Int) { state.tool = tool; if (tool != Tool.ERASER) state.blend = blend }
    val drawing = state.tool != Tool.ERASER
    Popup("Shape Pathfinder", "Boolean Ops", Palette.AccentCyan, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Unite, "Unite", Palette.AccentPurple, drawing && state.blend == 0, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 0) })
            OpButton(DrawIcons.Minus, "Minus", Palette.AccentPink, state.tool == Tool.ERASER, Modifier.weight(1f), Modifier.clickable { mode(Tool.ERASER, 0) })
            OpButton(DrawIcons.Intersect, "Intersect", Palette.AccentCyan, drawing && state.blend == 1, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 1) })
            OpButton(DrawIcons.Exclude, "Exclude", AccentAmber, drawing && state.blend == 3, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 3) })
        }
        Hint("Mode gabung goresan: Unite = Normal, Minus = Hapus, Intersect = Multiply, Exclude = Overlay.")
    }
}

@Composable
private fun ToolsPopup(onImport: () -> Unit, onExport: () -> Unit, onLayers: () -> Unit, onArtboard: () -> Unit, modifier: Modifier) {
    Popup("Studio Tools", "Project", Palette.AccentCyan, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Import, "Import", Palette.AccentCyan, false, Modifier.weight(1f), Modifier.clickable { onImport() })
            OpButton(DrawIcons.Export, "Export", Palette.AccentPink, false, Modifier.weight(1f), Modifier.clickable { onExport() })
            OpButton(DrawIcons.Layers, "Layers", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { onLayers() })
            OpButton(DrawIcons.Settings, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
    }
}

@Composable
private fun ColorPopup(state: DrawState, dd: DragDropState, modifier: Modifier) {
    Popup("Color Studio", "#%06X".format(state.color and 0xFFFFFF), Palette.AccentPink, modifier) {
        ColorPicker(
            color = state.color,
            onColor = { state.color = it },
            eyedropperActive = state.tool == Tool.EYEDROPPER,
            onEyedropper = { state.toggleEyedropper() },
            dd = dd,
        )
    }
}

/** Dropdown popup for whichever panel is open. Place it TopEnd inside the canvas area. */
@Composable
fun PopupHost(
    state: DrawState,
    dd: DragDropState,
    onImport: () -> Unit,
    onExport: () -> Unit,
    onLayers: () -> Unit,
    onArtboard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (state.panel) {
        Panel.TOOLS -> ToolsPopup(onImport, onExport, onLayers, onArtboard, modifier)
        Panel.BRUSH -> BrushPopup(state, modifier)
        Panel.PATTERN -> PatternPopup(state, dd, modifier)
        Panel.MIRROR -> MirrorPopup(state, modifier)
        Panel.FX -> FxPopup(state, onArtboard, modifier)
        Panel.PATHFINDER -> PathfinderPopup(state, modifier)
        Panel.COLOR -> ColorPopup(state, dd, modifier)
    }
}

// ------------------------------------------------------------------ bottom nav pill

@Composable
private fun NavItem(icon: ImageVector, label: String, accent: Color, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Color.Transparent)
            .border(1.dp, if (selected) accent.copy(alpha = 0.35f) else Color.Transparent, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Icon(icon, label, tint = accent, modifier = Modifier.size(18.dp))
        Text(
            label,
            color = if (selected) accent else Palette.TextPrimary,
            fontSize = 14.sp, lineHeight = 16.sp, textAlign = TextAlign.Center,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** "BRUSH NAV | Brush  Shapes  Transform  Crop & FX | ✋" */
@Composable
fun BottomNav(state: DrawState, modifier: Modifier = Modifier) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            val cShape = RoundedCornerShape(16.dp)
            Column(
                Modifier
                    .clip(cShape)
                    .background(Palette.DarkBg.copy(alpha = 0.6f))
                    .border(1.dp, Palette.PanelBorder, cShape)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
            ) {
                Text("BRUSH", color = Palette.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, lineHeight = 12.sp)
                Text("NAV", color = Palette.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, lineHeight = 12.sp)
            }
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavItem(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.group == Panel.BRUSH) { state.selectGroup(Panel.BRUSH) }
                NavItem(DrawIcons.Shapes, "Shapes", Palette.AccentCyan, state.group == Panel.PATTERN) { state.selectGroup(Panel.PATTERN) }
                NavItem(DrawIcons.Transform, "Transform", AccentAmber, state.group == Panel.MIRROR) { state.selectGroup(Panel.MIRROR) }
                NavItem(DrawIcons.Wand, "Crop\n& FX", Palette.AccentPink, state.group == Panel.FX) { state.selectGroup(Panel.FX) }
            }
            val hShape = RoundedCornerShape(16.dp)
            val handOn = state.tool == Tool.HAND
            Box(
                Modifier
                    .size(42.dp)
                    .clip(hShape)
                    .background(AccentGreen.copy(alpha = if (handOn) 0.28f else 0.12f))
                    .border(1.dp, AccentGreen.copy(alpha = if (handOn) 0.9f else 0.35f), hShape)
                    .clickable { state.toggleHand() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Hand, "Hand: geser kanvas", tint = AccentGreen, modifier = Modifier.size(22.dp))
            }
        }
    }
}
