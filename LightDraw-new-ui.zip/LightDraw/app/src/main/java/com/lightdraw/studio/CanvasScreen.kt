package com.lightdraw.studio

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.lightdraw.studio.ui.DragDropState
import com.lightdraw.studio.ui.DrawIcons
import com.lightdraw.studio.ui.DrawState
import com.lightdraw.studio.ui.FloatingPanel
import com.lightdraw.studio.ui.BottomNav
import com.lightdraw.studio.ui.LabeledSlider
import com.lightdraw.studio.ui.Palette
import com.lightdraw.studio.ui.Panel
import com.lightdraw.studio.ui.PopupHost
import com.lightdraw.studio.ui.SideSliderPanel
import com.lightdraw.studio.ui.TopToolbar
import com.lightdraw.studio.ui.Tool
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun CanvasScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val export = remember { ExportManager(ctx) }
    // Default artboard 2048x2048: light on RAM; pick a bigger one in Artboard settings.
    remember { NativeEngine.nativeInit(2048, 2048, export.spillDir, export.maxResidentTiles()) }

    val state = remember { DrawState() }
    val dd = remember { DragDropState() }
    var canvasView by remember { mutableStateOf<CanvasGLView?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var showArtboard by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun refreshHistory() {
        val h = NativeEngine.nativeHistoryState()
        state.canUndo = h and 1 != 0
        state.canRedo = h and 2 != 0
    }

    fun afterCanvasReplaced() {
        canvasView?.onCanvasReplaced()
        generation++
        refreshHistory()
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = export.importImage(uri)
            busy = false
            r.onSuccess { canvasView?.requestRender(); refreshHistory(); toast("Gambar diimpor ke kanvas") }
                .onFailure { toast("Gagal impor: ${it.message}") }
        }
    }
    val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = export.loadProject(uri)
            busy = false
            r.onSuccess { afterCanvasReplaced(); toast("Project dibuka (${it.first}×${it.second})") }
                .onFailure { toast("Gagal membuka project: ${it.message}") }
        }
    }

    // ---- push UI state to the native engine
    LaunchedEffect(state.brushPreset, state.size, state.opacity, state.color, state.blend, state.tool, generation) {
        NativeEngine.nativeSetBrush(
            state.brushPreset, state.size, state.opacity / 100f, state.color,
            if (state.tool == Tool.ERASER) 5 else state.blend,
        )
    }
    LaunchedEffect(state.stabilizer, generation) { NativeEngine.nativeSetStabilizer(state.stabilizer / 100f) }
    LaunchedEffect(state.symMode, state.sectors, state.symMirror, generation) {
        NativeEngine.nativeSetSymmetry(state.symMode, state.sectors, state.symMirror)
    }
    LaunchedEffect(state.paperColor, state.paperVisible, canvasView, generation) {
        val bg = if (state.paperVisible) state.paperColor else 0
        NativeEngine.nativeSetBg(bg)
        canvasView?.setPaper(bg)
    }
    // The canvas now sits inside a rounded frame, so drop positions (root coords) are made view-local.
    var canvasOrigin by remember { mutableStateOf(Offset.Zero) }
    SideEffect {
        dd.onDrop = { p, pos -> canvasView?.dropFill(pos.x - canvasOrigin.x, pos.y - canvasOrigin.y, p.kind, p.color) }
    }

    Box(Modifier.fillMaxSize().background(Palette.DarkBg)) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(8.dp)) {
            // ---- pill toolbar: Gallery | tools | colour
            TopToolbar(
                state = state,
                onGallery = { showExport = true },
                onArtboard = { showArtboard = true },
                onLayers = { showLayers = true },
                onImport = { imagePicker.launch("image/*") },
            )
            Spacer(Modifier.height(8.dp))

            // ---- canvas area (rounded frame) with floating sliders + dropdown popup
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { canvasOrigin = it.positionInRoot() },
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> CanvasGLView(c).also { canvasView = it } },
                    update = { v ->
                        v.tool = state.tool
                        v.fillKind = state.pattern
                        v.fillColor = state.color
                        v.fillScale = state.patternScale
                        v.fillTolerance = state.fillTolerance.toInt()
                        v.tolH = state.tolH
                        v.tolS = state.tolS / 100f
                        v.tolL = state.tolL / 100f
                        v.onColorPicked = { argb -> state.color = argb; state.finishEyedropper() }
                        v.onHistoryChanged = { refreshHistory() }
                        v.onMessage = { m -> toast(m) }
                    },
                )
                CanvasFrame(Modifier.fillMaxSize())

                val sliderH = ((maxHeight - 200.dp) / 2).coerceIn(48.dp, 110.dp)
                SideSliderPanel(
                    state = state,
                    sliderHeight = sliderH,
                    onUndo = { canvasView?.undo() },
                    onRedo = { canvasView?.redo() },
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp),
                )

                if (state.panel != Panel.NONE) {
                    PopupHost(
                        state = state,
                        dd = dd,
                        onImport = { state.panel = Panel.NONE; imagePicker.launch("image/*") },
                        onExport = { state.panel = Panel.NONE; showExport = true },
                        onLayers = { state.panel = Panel.NONE; showLayers = true },
                        onArtboard = { state.panel = Panel.NONE; showArtboard = true },
                        modifier = Modifier.align(Alignment.TopEnd).padding(start = 54.dp, top = 8.dp, end = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            BottomNav(state)
        }

        // ---- drag ghost
        val payload = dd.payload
        if (payload != null) {
            Box(
                Modifier
                    .offset { IntOffset(dd.pos.x.roundToInt() - 24, dd.pos.y.roundToInt() - 24) }
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(payload.color).copy(alpha = 0.85f))
                    .border(2.dp, if (payload.kind == 0) Color.White else Palette.AccentCyan, CircleShape)
            )
        }

        if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Palette.AccentPurple)
        }
    }

    if (showArtboard) ArtboardDialog(
        lowRam = remember { export.isLowRam() },
        onDismiss = { showArtboard = false },
        onCreate = { w, h ->
            showArtboard = false
            NativeEngine.nativeInit(w, h, export.spillDir, export.maxResidentTiles())
            afterCanvasReplaced()
            toast("Artboard baru ${w}×${h}")
        },
    )

    if (showExport) ExportDialog(
        paperVisible = state.paperVisible,
        onDismiss = { showExport = false },
        onOpenProject = { showExport = false; projectPicker.launch(arrayOf("*/*")) },
        onExport = { fmt, transparent, quality ->
            showExport = false
            scope.launch {
                busy = true
                val r = when (fmt) {
                    0 -> export.exportPng(state.paperColor, transparent)
                    1 -> export.exportJpeg(state.paperColor, quality)
                    else -> export.saveProject()
                }
                busy = false
                r.onSuccess {
                    toast(
                        when (fmt) {
                            2 -> "Project disimpan di Download/DrawingApp"
                            else -> "Tersimpan di Pictures/DrawingApp"
                        }
                    )
                }.onFailure { toast("Export gagal: ${it.message}") }
            }
        },
    )

    if (showLayers) LayersDialog(
        state = state,
        onClear = { NativeEngine.nativeClear(); canvasView?.requestRender(); refreshHistory() },
        onDismiss = { showLayers = false },
    )
}

// ------------------------------------------------------------------ canvas frame

/** Rounds the corners of the (rectangular) GL surface by painting the outside corners in the app background. */
@Composable
private fun CanvasFrame(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val r = CornerRadius(22.dp.toPx())
        val rect = Rect(0f, 0f, size.width, size.height)
        val mask = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(rect)
            addRoundRect(RoundRect(rect, r))
        }
        drawPath(mask, Palette.DarkBg)
        drawRoundRect(Palette.PanelBorder, cornerRadius = r, style = Stroke(1.dp.toPx()))
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
private fun FormatChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) Palette.AccentPurple else Palette.TextMuted,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(shape)
            .background(if (selected) Palette.AccentPurple.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) Palette.AccentPurple else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

private val ArtboardPresets = listOf(
    "512²" to (512 to 512), "1024²" to (1024 to 1024), "2048²" to (2048 to 2048),
    "4096²" to (4096 to 4096), "8192²" to (8192 to 8192), "16384²" to (16384 to 16384),
    "A4 300dpi" to (2480 to 3508), "Full HD" to (1080 to 1920),
)

@Composable
private fun ArtboardDialog(lowRam: Boolean, onDismiss: () -> Unit, onCreate: (Int, Int) -> Unit) {
    var wText by remember { mutableStateOf("2048") }
    var hText by remember { mutableStateOf("2048") }
    val w = wText.toIntOrNull()
    val h = hText.toIntOrNull()
    val error = when {
        w == null || h == null -> "Masukkan angka yang valid"
        w !in 512..16384 || h !in 512..16384 -> "Ukuran harus 512 – 16384 px"
        else -> null
    }
    val warning = when {
        error != null -> null
        lowRam && maxOf(w!!, h!!) > 8192 -> "RAM perangkat terbatas: hanya tile yang dilukis memakai memori; fill area sangat luas dibatasi. Gunakan Export PNG."
        w!!.toLong() * h!! > 8192L * 8192L -> "Artboard sangat besar. Tile kosong tidak memakai RAM."
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Artboard Resolution") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ArtboardPresets.forEach { (label, size) ->
                        FormatChip(label, w == size.first && h == size.second) { wText = size.first.toString(); hText = size.second.toString() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        wText, { wText = it.filter(Char::isDigit).take(5) }, label = { Text("Lebar px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        hText, { hText = it.filter(Char::isDigit).take(5) }, label = { Text("Tinggi px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                }
                if (error != null) Text(error, color = Palette.AccentPink, fontSize = 12.sp)
                if (warning != null) Text(warning, color = Palette.TextMuted, fontSize = 11.sp)
                Text("Membuat artboard baru menggantikan kanvas saat ini. Simpan project dulu bila perlu.", color = Palette.TextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(enabled = error == null, onClick = { onCreate(w!!, h!!) }) { Text("Buat") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun ExportDialog(
    paperVisible: Boolean,
    onDismiss: () -> Unit,
    onOpenProject: () -> Unit,
    onExport: (fmt: Int, transparent: Boolean, quality: Int) -> Unit,
) {
    var fmt by remember { mutableIntStateOf(0) }
    var transparent by remember { mutableStateOf(!paperVisible) }
    var quality by remember { mutableIntStateOf(95) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Export Studio") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FormatChip("PNG", fmt == 0) { fmt = 0 }
                    FormatChip("JPEG", fmt == 1) { fmt = 1 }
                    FormatChip("Project", fmt == 2) { fmt = 2 }
                }
                when (fmt) {
                    0 -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Background transparan", fontSize = 13.sp)
                            Switch(transparent, { transparent = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                        }
                        Text("Disimpan ke Pictures/DrawingApp. Kanvas besar di-stream langsung dari tile native (tanpa Bitmap raksasa).", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    1 -> {
                        LabeledSlider("Kualitas", "$quality%", quality.toFloat(), 50f..100f) { quality = it.toInt() }
                        Text("JPEG memakai warna Paper sebagai latar. Di atas 16 MP gambar diperkecil otomatis.", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    else -> Text("Menyimpan semua tile (terkompresi) ke Download/DrawingApp sebagai .ldproj.", color = Palette.TextMuted, fontSize = 11.sp)
                }
                TextButton(onClick = onOpenProject) { Text("Buka project (.ldproj)…", color = Palette.AccentCyan) }
            }
        },
        confirmButton = { TextButton(onClick = { onExport(fmt, transparent, quality) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private val PaperChoices = listOf(0xFFFFFFFF, 0xFFFFF8E7, 0xFFD9D9D9, 0xFF3A3A44, 0xFF18181C, 0xFF000000).map { it.toInt() }

@Composable
private fun LayersDialog(state: DrawState, onClear: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Layers") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.AccentPurple.copy(alpha = 0.12f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Drawing", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Sparse tile layer (aktif)", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    TextButton(onClick = onClear) { Text("Hapus semua", color = Palette.AccentPink) }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.DarkBg.copy(alpha = 0.5f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Paper", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Latar kanvas (dipakai export JPEG)", color = Palette.TextMuted, fontSize = 11.sp)
                        }
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { state.paperVisible = !state.paperVisible }, contentAlignment = Alignment.Center) {
                            Icon(DrawIcons.Eye, "Visible", tint = if (state.paperVisible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PaperChoices.forEach { c ->
                            Box(
                                Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                                    .border(if (c == state.paperColor) 2.dp else 1.dp, if (c == state.paperColor) Palette.AccentPurple else Color.White.copy(alpha = 0.25f), CircleShape)
                                    .clickable { state.paperColor = c; state.paperVisible = true }
                            )
                        }
                    }
                    Text("Paper tersembunyi = transparan (kotak-kotak).", color = Palette.TextMuted, fontSize = 11.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}
