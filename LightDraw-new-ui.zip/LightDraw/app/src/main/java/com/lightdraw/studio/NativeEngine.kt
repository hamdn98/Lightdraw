package com.lightdraw.studio

import android.graphics.Bitmap
import java.nio.ByteBuffer

/** JNI facade for the Rust engine (liblightdraw_engine.so). */
object NativeEngine {
    init {
        System.loadLibrary("lightdraw_engine")
    }

    external fun nativeInit(w: Int, h: Int, spillDir: String, maxResident: Int): Boolean
    external fun nativeCanvasWidth(): Int
    external fun nativeCanvasHeight(): Int

    external fun nativeVisibleTiles(tx0: Int, ty0: Int, tx1: Int, ty1: Int, idx: IntArray, ver: IntArray): Int
    external fun nativeCopyTile(idx: Int, buf: ByteBuffer): Boolean

    external fun nativeSetBrush(preset: Int, size: Float, opacity: Float, color: Int, blend: Int)
    external fun nativeSetStabilizer(strength: Float)
    external fun nativeSetSymmetry(mode: Int, sectors: Int, mirror: Boolean)
    external fun nativeSetBg(argb: Int)

    external fun nativeStrokeBegin(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeMove(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeEnd()
    external fun nativeStrokeCancel()

    /** 0 ok, 1 out of bounds, 2 region too large. */
    external fun nativeFill(x: Int, y: Int, kind: Int, color: Int, color2: Int, scale: Float, tol: Int): Int
    external fun nativeSelectReplace(x: Int, y: Int, newColor: Int, tolH: Float, tolS: Float, tolL: Float): Int
    external fun nativePickColor(x: Int, y: Int): Int

    external fun nativeUndo(): Boolean
    external fun nativeRedo(): Boolean
    /** bit0 = can undo, bit1 = can redo */
    external fun nativeHistoryState(): Int
    external fun nativeClear()

    external fun nativeRenderToBitmap(bmp: Bitmap, bg: Int): Int
    external fun nativeExportPng(fd: Int, bg: Int): Int
    external fun nativeSaveProject(fd: Int): Int
    /** (width shl 32) or height, or -1 on failure. */
    external fun nativeLoadProject(fd: Int, spillDir: String, maxResident: Int): Long
    external fun nativeImportBitmap(bmp: Bitmap, dx: Int, dy: Int): Int
}

/** Second colour for two-tone patterns, derived from the active colour. */
fun secondaryOf(argb: Int): Int {
    val r = (argb shr 16) and 255
    val g = (argb shr 8) and 255
    val b = argb and 255
    val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    val target = if (lum > 0.55) 0 else 255
    val t = if (lum > 0.55) 0.65 else 0.85
    fun mix(c: Int): Int = (c + (target - c) * t).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (mix(r) shl 16) or (mix(g) shl 8) or mix(b)
}
