# Panduan implementasi — LightDraw v2 (Shapes, Object, Pattern, FX, AA, Export)

> Status: kode ditulis tanpa compiler (tidak ada Rust/Kotlin/Android SDK di lingkungan pembuat).
> Jalankan CI (`.github/workflows/build.yml`) dan kirim error kompilasi bila ada; perbaikannya biasanya kecil.

## 0. Fakta arsitektur yang menentukan cakupan
App ini = **satu layer raster** (tile sparse 256×256 di Rust) + paper. Tidak ada daftar objek vektor dan tidak ada multi-layer.
Karena itu:
* **"Objek" = seleksi kotak** (tool *Select*). Semua operasi objek bekerja pada piksel di dalam kotak.
* **Duplicate Layer belum ada** karena belum ada konsep layer (lihat §9 untuk rancangan).

## 1. Peta fitur → file

| Fitur | UI | Kotlin | Rust |
|---|---|---|---|
| Transform (view) | Transform ▸ VIEW | `CanvasGLView.rotateView/resetRotation`, `fitCanvas` | – |
| Transform (seamless) | Transform ▸ SEAMLESS | `Tool.WRAP`, `CanvasScreen.wrapBy` | `fx_engine::offset_wrap` |
| Mirror | Transform ▸ MIRROR | (tidak berubah) | `symmetry.rs` |
| FX | Crop & FX | `CanvasScreen` → `nativeApplyFx` | `fx_engine::apply_fx` |
| Shapes | Shapes | `Tool.SHAPE`, `CanvasGLView.dragMove/finishDrag` | `fx_engine::draw_shape`, `nativeShape` |
| Pattern | **Color** (bagian PATTERN FILL) | `FloatingToolbar.PatternSection` | `pattern_fill` (kind 1–6) |
| Select / Duplicate Object | Object | `duplicateSelection`, `moveSelection` | `fx_engine::move_region` |
| Align | Object ▸ ALIGN | `alignSelection` | `fx_engine::align_region` |
| Object → Pattern | Object ▸ To Pattern | `selectionToPattern` | `region_to_tile` + `pattern_fill` kind 7 |
| Anti-aliasing | otomatis | `CanvasRenderer` (filter) | `brush_engine::StrokeCov`, `draw_shape` |
| Export | Gallery ▸ Export | `ExportManager.exportJpeg/exportWebpLossless` | – |

## 2. Kenapa FX & Transform "tidak berfungsi"
Versi sebelumnya: *Transform* hanya membuka menu Mirror, *FX* hanya memilih tool Fill/Same-Color. Tidak ada transformasi atau efek sungguhan.
Sekarang: Transform = rotasi/level/fit kanvas + Wrap + Mirror; FX = Brightness, Contrast, Hue, Saturation, Invert, Grayscale (semua bisa Undo).
Bila popup tidak muncul sama sekali di perangkatmu, kirim logcat; penyebab paling mungkin ada di sisi layout yang belum bisa diuji di sini.

## 3. Struktur menu baru
Bottom nav: **Brush · Shapes · Transform · Crop & FX · Object** + tombol Hand.
Top toolbar: Tools · Artboard · Brush · Shapes · Transform · FX · Pathfinder · Object · Duplicate · (warna).
**Pattern pindah ke popup Color** (lingkaran warna kanan atas): roda warna → swatch → PATTERN FILL (Gingham…Floral + Custom) → Fill / Same Color.

## 4. Algoritma alignment (`fx_engine::align_region`)
1. `content_bounds`: pindai kotak seleksi, ambil bbox piksel dengan alpha > 0 → (bx0,by0,bx1,by1). Ini "objek" sebenarnya (kotak seleksi boleh longgar).
2. bw = bx1-bx0+1, bh = by1-by0+1, W/H = ukuran artboard.
3. Hitung delta:
   * Left: dx = -bx0 · Right: dx = W-1-bx1 · Center H: dx = (W-bw)/2 - bx0
   * Top: dy = -by0 · Bottom: dy = H-1-by1 · Center V: dy = (H-bh)/2 - by0
   * Center (both): dx dan dy center.
4. `move_region(rect, dx, dy, copy=false, wrap=false)` lalu kotak seleksi digeser sebesar (dx,dy).
"Snap to canvas" = mode Center.

## 5. Algoritma seamless / wrap
**a) Wrap Drag & Wrap ½ (`offset_wrap`)** — seluruh gambar: `new(x,y) = old((x-dx) mod W, (y-dy) mod H)`.
Baca semua piksel ke buffer (≤ 4096², 64 MB), tulis ulang per tile dengan modulo. Wrap ½ (dx=W/2, dy=H/2) memindahkan sambungan tepi/sudut ke tengah supaya bisa digambar ulang → hasilnya tile yang bisa diulang tanpa garis sambung.
**b) Seret objek melewati tepi (`move_region(wrap=true)`)** — tujuan: `ox = (x0+dx) mod W`. Bila `ox + w > W` kotak dipecah di seam menjadi maksimal 2×2 potongan dan tiap potongan ditempel (`paste_piece`) → bagian yang keluar tepi muncul di sisi seberang (juga sudut).
Batasan jujur: pergeseran dilakukan saat jari diangkat (outline kotak mengikuti jari), bukan preview piksel langsung.

## 6. Convert Object → Pattern
`region_to_tile` menyalin kotak seleksi (maks 2048², unpremultiply) ke penyimpanan global `CUSTOM` di `pattern_fill.rs`.
`pattern_color(kind=7, x, y)` = `tile[(y/scale) mod h][(x/scale) mod w]`, dievaluasi dalam koordinat global sehingga seamless antar-tile. Setelah konversi app otomatis memilih Fill + pola Custom; ketuk area manapun untuk mengisi (atau seret kartu Custom ke kanvas). Kotak seleksi = satuan ulang (repeat unit), jadi atur margin kotak untuk mengatur jarak antar objek.

## 7. Anti-aliasing — akar masalah & perbaikan
Masalah lama: tiap dab di-composite dengan `over`. Piksel di tepi goresan kena puluhan dab → alfa tepi menumpuk 1-∏(1-aᵢ) → tepi menebal & "bergerigi". Selain itu renderer memakai GL_NEAREST mulai zoom 2×.
Perbaikan:
1. **Max-coverage per goresan** (`StrokeCov`): peta coverage u8 per tile selama satu goresan. Dab baru hanya menaikkan coverage dari `old` ke `new` dengan alfa inkremental `a' = (new-old)/(1-old)`, sehingga hasil = `base*(1-new)+color*new` tanpa perlu menyimpan piksel asli. Opacity slider sekarang akurat (tidak menumpuk). Mode Multiply/Screen/Overlay/Add & airbrush tetap pakai jalur lama.
2. Rim tepi dab memakai profil **smoothstep** 1 px.
3. **Shapes**: signed-distance analitik, coverage = clamp(0.5 − sd, 0, 1) → tepi ±1 px halus untuk rect/rounded/ellipse/triangle/line/diamond.
4. GL: filter bilinear sampai zoom 8× (sebelumnya blok-blok pada 2×).

## 8. Export
* JPEG: kualitas dikunci **100** (slider dihapus). JPEG tetap lossy secara format; ini kualitas maksimum yang tersedia dari encoder Android.
* Untuk hasil **identik piksel**: PNG (streaming, resolusi penuh) atau **WebP lossless** (Android 11+).
* >16 MP: JPEG/WebP diperkecil otomatis (batas memori); gunakan PNG untuk resolusi penuh.

## 9. Rancangan Duplicate Layer (tahap berikutnya)
1. Rust: `Engine.canvas: TiledCanvas` → `layers: Vec<Layer { canvas, visible, opacity, blend, name }>` + `active: usize`.
2. Semua tool menulis ke `layers[active].canvas`; undo menyimpan `(layer_id, EditRecord)`.
3. `nativeDuplicateLayer(i)`: buat `TiledCanvas` baru, salin tile resident + tile yang di-spill (`copy_tile_bytes`) → sisipkan di i+1, jadikan aktif.
4. Renderer: gambar tiap layer dari bawah ke atas (satu texture-set per layer, blend di shader) ; export & `.ldproj` (versi `LDRW2`) menulis daftar layer.
5. UI: Layers dialog → daftar layer (visible, opacity, urutan, **Duplicate**, Delete, Merge).
Perkiraan: 1–2 minggu kerja karena menyentuh renderer, history, export dan format project.

## 10. Uji manual cepat
1. Gambar goresan opacity 50% bolak-balik → tidak boleh ada area lebih gelap di tumpang-tindih.
2. Shapes → seret ellipse: preview langsung, tepi halus; Undo menghapusnya.
3. Select kotak di sekeliling gambar → Align ▸ Center → objek ke tengah artboard.
4. Duplicate → salinan bergeser 24 px; seret salinan melewati tepi kanan dengan Wrap aktif → muncul di kiri.
5. Object ▸ To Pattern → Fill area kosong → pola berulang.
6. FX ▸ Invert / Grayscale / Brightness → Undo.
7. Export JPEG → tidak ada slider, file tersimpan 100%.

---
## 11. v3 — perubahan yang sudah digabung ke kode (belum dikompilasi)

| Area | File |
|---|---|
| Crash 8K–16K: batas memori tile keras (tile di viewport ikut di-evict) | `tiled_canvas.rs` (`evict_one(.., allow_viewport)`) |
| Fill bertahap di thread latar + progres + Batal (rollback) | `fill_job.rs`, `engine_core.rs` (`nativeFillBegin/Step/Cancel/Painted`), `CanvasGLView.runFill` |
| Pola Custom tanpa lock per piksel, ubah ukuran W×H | `pattern_fill.rs` (`CustomTile`, `paint_px`, `resize_custom`), `FloatingToolbar.CustomSizeEditor` |
| Wrap seamless untuk kanvas besar (hemat RAM) | `wrap_stream.rs`, `nativeOffsetWrap` |
| Export JPEG streaming sampai 45 MP + kualitas Medium/Maksimum | `export_stream.rs`, `ExportManager`, `ExportDialog` |
| Panik Rust tidak lagi mematikan app | `Cargo.toml` (`panic = "unwind"`), `guard()` di `engine_core.rs` |
| Auto-dismiss menu (pilih opsi / sentuh kanvas / drop) | `DrawState.closePanel`, `FloatingToolbar`, `CanvasGLView.onCanvasTouch` |
| HUD zoom %, eyedropper tekan-lama (450 ms) | `CanvasGLView` (`onZoomChanged`, `longPress`), `CanvasScreen` |
| Commit transform affine (dasar handle live) | `transform.rs`, `nativeTransformRegion` (UI handle belum dibuat) |

Belum ada: Duplicate Layer (butuh refactor multi-layer, lihat §9), overlay handle transform/warp di UI.
Tes cepat: kanvas 16384², zoom fit, Fill pola Gingham → tidak crash, ada pill "Mengisi… MP", Batal mengembalikan kanvas.

### 11.1 Isi menyatu dengan garis (fill di bawah tepi anti-alias)
`fill_job.rs`: piksel tepi setengah transparan (alpha 1–254) yang menempel pada area isian digabung sebagai
`piksel lama OVER isian`, jadi tidak ada lagi pinggiran pucat di antara isian dan garis. Hanya 1 piksel dari tepi;
untuk tepi kuas yang sangat lembut naikkan Toleransi Fill. Berlaku untuk isian baru (isian lama tidak berubah).

## 12. v3.1 — layer, mode fokus, brush (belum dikompilasi)

**Layer** (`layers.rs`, `engine_core.rs`, `CanvasScreen.LayersDialog`)
- Sampai 12 layer. `Engine.canvas` selalu = layer aktif, jadi semua tool lama (kuas, fill, wrap, align, import) otomatis mengedit layer aktif.
- Dialog Layers (Tools → Layers): pilih, tampil/sembunyi, kunci 🔒, opacity, + Baru, Duplikat, Hapus, Naik/Turun, Gabung ↓, Kosongkan.
- Layer terkunci: kuas, fill, bentuk, seleksi, FX, wrap, duplikat, align, import ditolak dengan pesan "Layer terkunci"; zoom/geser/pinch dan eyedropper tetap jalan.
- Tampilan, eyedropper, export PNG/JPEG, dan render memakai gabungan semua layer yang tampil.
- Memori: budget tile dibagi rata antar layer (minimal 48 tile per layer).

Batasan yang disengaja:
- Undo/redo **per layer** (riwayat ikut layer). Tambah/hapus/urut/gabung layer tidak bisa di-undo.
- `.ldproj` masih satu layer: saat disimpan dengan banyak layer, yang tersimpan hasil gabungan.
- Nama layer belum bisa diubah ("Layer n" menurut urutan).

**Mode Fokus**: tombol bulat kecil di pojok kanan bawah kanvas menyembunyikan toolbar atas dan nav bawah; pilihan diingat (SharedPreferences `lightdraw_ui`).

**Brush** (`brush_engine.rs`, `FloatingToolbar.kt`): 12 brush (Technical Pen, G-Pen, Fineliner, Mechanical Pencil, Charcoal, Marker, Dry Brush, Watercolor Wash ditambah 4 lama). Tiap brush punya ukuran awal sendiri yang otomatis dipakai saat dipilih; daftar bisa di-scroll.

**Belum dikerjakan**: handle transform/warp di layar, duplikat/tempel lewat gestur, garis bantu perataan, grup objek, bicubic, pinggiran antar-tile di renderer.

### 12.1 Perbaikan build (log CI 17 Okt)
Rust (3 ABI, termasuk `jpeg-encoder`) sudah lolos compile. Satu-satunya error Kotlin: `AnimatedVisibility` ambigu di dalam
`BoxWithConstraints` yang berada di dalam `Column`. HUD zoom diganti `animateFloatAsState` + `graphicsLayer`.
