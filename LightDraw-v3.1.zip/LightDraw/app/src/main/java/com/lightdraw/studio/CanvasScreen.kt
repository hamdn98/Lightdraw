package com.lightdraw.studio

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.delay
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.lightdraw.studio.ui.DragDropState
import com.lightdraw.studio.ui.EditActions
import com.lightdraw.studio.ui.SelRect
import com.lightdraw.studio.ui.DrawIcons
import com.lightdraw.studio.ui.DrawState
import com.lightdraw.studio.ui.FloatingPanel
import com.lightdraw.studio.ui.BottomNav
import com.lightdraw.studio.ui.LabeledSlider
import com.lightdraw.studio.ui.Palette
import com.lightdraw.studio.ui.Panel
import com.lightdraw.studio.ui.PopupHost
import com.lightdraw.studio.ui.SideSliderPanel
import com.lightdraw.studio.ui.TopToolbar
import com.lightdraw.studio.ui.Tool
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun CanvasScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val export = remember { ExportManager(ctx) }
    // Default artboard 2048x2048: light on RAM; pick a bigger one in Artboard settings.
    remember { NativeEngine.nativeInit(2048, 2048, export.spillDir, export.maxResidentTiles()) }

    val state = remember { DrawState() }
    val dd = remember { DragDropState() }
    var canvasView by remember { mutableStateOf<CanvasGLView?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var showArtboard by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    // zoom HUD + big-fill progress
    var zoomPct by remember { mutableIntStateOf(100) }
    var hudTick by remember { mutableIntStateOf(0) }
    var hudVisible by remember { mutableStateOf(false) }
    var fillBusy by remember { mutableStateOf(false) }
    var fillPainted by remember { mutableStateOf(0L) }
    LaunchedEffect(hudTick) {
        if (hudTick > 0) {
            hudVisible = true
            delay(900)
            hudVisible = false
        }
    }
    var showLayers by remember { mutableStateOf(false) }
    var layerTick by remember { mutableIntStateOf(0) }
    var activeLocked by remember { mutableStateOf(false) }
    val uiPrefs = remember { ctx.getSharedPreferences("lightdraw_ui", 0) }
    var focusMode by remember { mutableStateOf(uiPrefs.getBoolean("focus", false)) } // hide toolbars, canvas only

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun refreshHistory() {
        val h = NativeEngine.nativeHistoryState()
        state.canUndo = h and 1 != 0
        state.canRedo = h and 2 != 0
    }

    /** Re-read the layer stack after any change (add / select / lock / opacity ...). */
    fun syncLayers() {
        activeLocked = (NativeEngine.nativeLayerInfo(NativeEngine.nativeLayerActive()) and 2) != 0
        layerTick++
        canvasView?.requestRender()
        refreshHistory()
    }

    fun layerLockedToast(): Boolean {
        if (activeLocked) toast("Layer terkunci")
        return activeLocked
    }

    fun afterCanvasReplaced() {
        canvasView?.onCanvasReplaced()
        generation++
        refreshHistory()
        syncLayers()
    }

    // ---- overlay state (selection outline, rubber band, move ghost, view changes)
    var viewTick by remember { mutableIntStateOf(0) }
    var marquee by remember { mutableStateOf<Rect?>(null) }
    var ghost by remember { mutableStateOf<Offset?>(null) }

    fun afterEditRefresh() {
        canvasView?.requestRender()
        refreshHistory()
    }

    fun canvasW() = NativeEngine.nativeCanvasWidth()
    fun canvasH() = NativeEngine.nativeCanvasHeight()

    fun clampSel(r: SelRect): SelRect {
        val w = canvasW()
        val h = canvasH()
        val x0 = r.x0.coerceIn(0, w - 1)
        val y0 = r.y0.coerceIn(0, h - 1)
        return SelRect(x0, y0, r.x1.coerceIn(x0, w - 1), r.y1.coerceIn(y0, h - 1))
    }

    /** New selection rectangle after moving by (dx, dy); with wrap the origin re-enters on the opposite edge. */
    fun movedSel(s: SelRect, dx: Int, dy: Int): SelRect {
        if (!state.wrapEdges) return clampSel(s.shift(dx, dy))
        val w = canvasW()
        val h = canvasH()
        val x0 = Math.floorMod(s.x0 + dx, w)
        val y0 = Math.floorMod(s.y0 + dy, h)
        return SelRect(x0, y0, minOf(x0 + s.w - 1, w - 1), minOf(y0 + s.h - 1, h - 1))
    }

    fun requireSel(): SelRect? {
        val s = state.selection
        if (s == null) toast("Pilih objek dulu: tool Select, lalu seret kotak di sekeliling objek")
        return s
    }

    fun duplicateSelection() {
        if (layerLockedToast()) return
        val s = requireSel() ?: return
        val off = 24
        when (NativeEngine.nativeMoveRegion(s.x0, s.y0, s.x1, s.y1, off, off, true, state.wrapEdges)) {
            0 -> { state.selection = movedSel(s, off, off); afterEditRefresh(); toast("Objek diduplikasi") }
            2 -> toast("Seleksi terlalu besar (maks 16 MP)")
            else -> toast("Seleksi kosong / di luar artboard")
        }
    }

    fun moveSelection(dx: Int, dy: Int) {
        val s = state.selection ?: return
        when (NativeEngine.nativeMoveRegion(s.x0, s.y0, s.x1, s.y1, dx, dy, false, state.wrapEdges)) {
            0 -> { state.selection = movedSel(s, dx, dy); afterEditRefresh() }
            2 -> toast("Seleksi terlalu besar (maks 16 MP)")
            else -> toast("Seleksi di luar artboard")
        }
    }

    fun alignSelection(mode: Int) {
        if (layerLockedToast()) return
        val s = requireSel() ?: return
        val r = NativeEngine.nativeAlignRegion(s.x0, s.y0, s.x1, s.y1, mode)
        if (r == Long.MIN_VALUE) {
            toast("Tidak ada piksel objek di dalam seleksi")
            return
        }
        state.selection = clampSel(s.shift((r shr 32).toInt(), r.toInt()))
        afterEditRefresh()
    }

    fun selectionToPattern() {
        val s = requireSel() ?: return
        val r = NativeEngine.nativeSetPatternFromRegion(s.x0, s.y0, s.x1, s.y1)
        when {
            r > 0 -> {
                val w = r ushr 16
                val h = r and 0xFFFF
                state.customPatternSize = "${w}×${h}"
                state.pattern = 7
                state.tool = Tool.FILL
                state.panel = Panel.COLOR
                toast("Pola Custom ${w}×${h} siap: ketuk area untuk mengisi")
            }
            r == -1 -> toast("Seleksi kosong, tidak ada gambar untuk dijadikan pola")
            else -> toast("Seleksi terlalu besar untuk pola (maks 2048×2048)")
        }
    }

    fun wrapBy(dx: Int, dy: Int) {
        if (layerLockedToast()) return
        if (NativeEngine.nativeOffsetWrap(dx, dy) == 3) toast("Ruang penyimpanan kurang untuk Wrap") else afterEditRefresh()
    }

    val actions = EditActions(
        duplicate = { duplicateSelection() },
        align = { alignSelection(it) },
        toPattern = { selectionToPattern() },
        fx = { op, a, b ->
            if (!layerLockedToast()) {
                val n = NativeEngine.nativeApplyFx(op, a, b)
                afterEditRefresh()
                toast(if (n > 0) "FX diterapkan" else "Belum ada gambar untuk diubah")
            }
        },
        wrapHalf = { wrapBy(canvasW() / 2, canvasH() / 2) },
        rotateView = { canvasView?.rotateView(it) },
        resetRotation = { canvasView?.resetRotation() },
        fitView = { canvasView?.fitCanvas() },
    )

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !layerLockedToast()) scope.launch {
            busy = true
            val r = export.importImage(uri)
            busy = false
            r.onSuccess { canvasView?.requestRender(); refreshHistory(); toast("Gambar diimpor ke kanvas") }
                .onFailure { toast("Gagal impor: ${it.message}") }
        }
    }
    val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = export.loadProject(uri)
            busy = false
            r.onSuccess { afterCanvasReplaced(); toast("Project dibuka (${it.first}×${it.second})") }
                .onFailure { toast("Gagal membuka project: ${it.message}") }
        }
    }

    // ---- push UI state to the native engine
    LaunchedEffect(state.brushPreset, state.size, state.opacity, state.color, state.blend, state.tool, generation) {
        NativeEngine.nativeSetBrush(
            state.brushPreset, state.size, state.opacity / 100f, state.color,
            if (state.tool == Tool.ERASER) 5 else state.blend,
        )
    }
    LaunchedEffect(state.stabilizer, generation) { NativeEngine.nativeSetStabilizer(state.stabilizer / 100f) }
    LaunchedEffect(state.symMode, state.sectors, state.symMirror, generation) {
        NativeEngine.nativeSetSymmetry(state.symMode, state.sectors, state.symMirror)
    }
    LaunchedEffect(state.paperColor, state.paperVisible, canvasView, generation) {
        val bg = if (state.paperVisible) state.paperColor else 0
        NativeEngine.nativeSetBg(bg)
        canvasView?.setPaper(bg)
    }
    // The canvas now sits inside a rounded frame, so drop positions (root coords) are made view-local.
    var canvasOrigin by remember { mutableStateOf(Offset.Zero) }
    SideEffect {
        dd.onDrop = { p, pos ->
            state.closePanel()
            canvasView?.dropFill(pos.x - canvasOrigin.x, pos.y - canvasOrigin.y, p.kind, p.color)
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.DarkBg)) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(8.dp)) {
            // ---- pill toolbar: Gallery | tools | colour
            if (!focusMode) {
                TopToolbar(
                    state = state,
                    onGallery = { showExport = true },
                    onArtboard = { showArtboard = true },
                    onDuplicate = { duplicateSelection() },
                )
                Spacer(Modifier.height(8.dp))
            }

            // ---- canvas area (rounded frame) with floating sliders + dropdown popup
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { canvasOrigin = it.positionInRoot() },
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> CanvasGLView(c).also { canvasView = it } },
                    update = { v ->
                        v.tool = state.tool
                        v.fillKind = state.pattern
                        v.fillColor = state.color
                        v.fillScale = state.patternScale
                        v.fillTolerance = state.fillTolerance.toInt()
                        v.tolH = state.tolH
                        v.tolS = state.tolS / 100f
                        v.tolL = state.tolL / 100f
                        v.shapeKind = state.shapeKind
                        v.shapeFlags = (if (state.shapeFilled) 1 else 0) or (if (state.shapeStroked) 2 else 0)
                        v.shapeStrokeW = state.shapeStrokeW
                        val sel = state.selection
                        v.hasSel = sel != null
                        if (sel != null) { v.selX0 = sel.x0; v.selY0 = sel.y0; v.selX1 = sel.x1; v.selY1 = sel.y1 }
                        v.onSelect = { x0, y0, x1, y1 ->
                            state.selection = if (x0 == -1 && y0 == -1 && x1 == -1 && y1 == -1) null else clampSel(SelRect(x0, y0, x1, y1))
                        }
                        v.onMoveSelection = { dx, dy -> moveSelection(dx, dy) }
                        v.onWrapDrag = { dx, dy -> wrapBy(dx, dy) }
                        v.onMarquee = { r -> marquee = r?.let { Rect(it.left, it.top, it.right, it.bottom) } }
                        v.onGhost = { dx, dy -> ghost = if (dx.isNaN()) null else Offset(dx, dy) }
                        v.onViewChanged = { viewTick++ }
                        v.onColorPicked = { argb -> state.color = argb; state.finishEyedropper() }
                        v.onHistoryChanged = { refreshHistory() }
                        v.onMessage = { m -> toast(m) }
                        v.layerLocked = activeLocked
                        v.fillScope = scope
                        v.onBusy = { b, n -> fillBusy = b; fillPainted = n }
                        v.onCanvasTouch = { if (state.panel != Panel.NONE) state.closePanel() }
                        v.onZoomChanged = { sc -> zoomPct = (sc * 100f).roundToInt(); hudTick++ }
                    },
                )
                CanvasFrame(state.selection, ghost, marquee, canvasView, viewTick, Modifier.fillMaxSize())

                // focus mode toggle: hides / shows the toolbars (remembered between launches)
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp).size(36.dp).clip(CircleShape)
                        .background(Color(0x991B1B22))
                        .clickable {
                            focusMode = !focusMode
                            uiPrefs.edit().putBoolean("focus", focusMode).apply()
                            state.closePanel()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(DrawIcons.Fit, "Mode Fokus", tint = if (focusMode) Palette.AccentCyan else Color.White, modifier = Modifier.size(18.dp))
                }

                // zoom percentage HUD (shown briefly while pinching)
                AnimatedVisibility(
                    visible = hudVisible,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    Text(
                        "$zoomPct%", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xCC1B1B22)).padding(horizontal = 14.dp, vertical = 6.dp),
                    )
                }

                // big fill progress + cancel
                if (fillBusy) {
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
                            .clip(RoundedCornerShape(20.dp)).background(Color(0xE61B1B22)).padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        CircularProgressIndicator(color = Palette.AccentPurple, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text("Mengisi… %.1f MP".format(fillPainted / 1_000_000.0), color = Color.White, fontSize = 12.sp)
                        TextButton(onClick = { canvasView?.cancelFill() }) { Text("Batal", color = Palette.AccentPink) }
                    }
                }

                val sliderH = ((maxHeight - 200.dp) / 2).coerceIn(48.dp, 110.dp)
                SideSliderPanel(
                    state = state,
                    sliderHeight = sliderH,
                    onUndo = { canvasView?.undo() },
                    onRedo = { canvasView?.redo() },
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp),
                )

                if (state.panel != Panel.NONE) {
                    PopupHost(
                        state = state,
                        dd = dd,
                        actions = actions,
                        onImport = { state.panel = Panel.NONE; imagePicker.launch("image/*") },
                        onExport = { state.panel = Panel.NONE; showExport = true },
                        onLayers = { state.panel = Panel.NONE; showLayers = true },
                        onArtboard = { state.panel = Panel.NONE; showArtboard = true },
                        modifier = Modifier.align(Alignment.TopEnd).padding(start = 54.dp, top = 8.dp, end = 8.dp),
                    )
                }
            }
            if (!focusMode) {
                Spacer(Modifier.height(8.dp))
                BottomNav(state)
            }
        }

        // ---- drag ghost
        val payload = dd.payload
        if (payload != null) {
            Box(
                Modifier
                    .offset { IntOffset(dd.pos.x.roundToInt() - 24, dd.pos.y.roundToInt() - 24) }
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(payload.color).copy(alpha = 0.85f))
                    .border(2.dp, if (payload.kind == 0) Color.White else Palette.AccentCyan, CircleShape)
            )
        }

        if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Palette.AccentPurple)
        }
    }

    if (showArtboard) ArtboardDialog(
        lowRam = remember { export.isLowRam() },
        onDismiss = { showArtboard = false },
        onCreate = { w, h ->
            showArtboard = false
            NativeEngine.nativeInit(w, h, export.spillDir, export.maxResidentTiles())
            afterCanvasReplaced()
            toast("Artboard baru ${w}×${h}")
        },
    )

    if (showExport) ExportDialog(
        paperVisible = state.paperVisible,
        outSize = remember { export.outputSize() },
        onDismiss = { showExport = false },
        onOpenProject = { showExport = false; projectPicker.launch(arrayOf("*/*")) },
        onExport = { fmt, transparent, quality ->
            showExport = false
            scope.launch {
                busy = true
                val r = when (fmt) {
                    0 -> export.exportPng(state.paperColor, transparent, if (quality == 1) ExportQuality.MAXIMUM else ExportQuality.MEDIUM)
                    1 -> export.exportJpeg(state.paperColor, if (quality == 1) ExportQuality.MAXIMUM else ExportQuality.MEDIUM)
                    3 -> export.exportWebpLossless(state.paperColor, transparent)
                    else -> export.saveProject()
                }
                busy = false
                r.onSuccess {
                    toast(
                        when (fmt) {
                            2 -> "Project disimpan di Download/DrawingApp"
                            else -> "Tersimpan di Pictures/DrawingApp"
                        }
                    )
                }.onFailure { toast("Export gagal: ${it.message}") }
            }
        },
    )

    if (showLayers) LayersDialog(
        state = state,
        tick = layerTick,
        onChanged = { syncLayers() },
        onRender = { canvasView?.requestRender() },
        onClear = { if (!layerLockedToast()) { NativeEngine.nativeClear(); syncLayers() } },
        onToast = { toast(it) },
        onDismiss = { showLayers = false },
    )
}

// ------------------------------------------------------------------ canvas frame

/**
 * Rounds the corners of the (rectangular) GL surface by painting the outside corners in the app background,
 * and draws the selection outline (follows pan / zoom / rotate), the rubber band and the move ghost.
 */
@Composable
private fun CanvasFrame(
    sel: SelRect?,
    ghost: Offset?,
    marquee: Rect?,
    view: CanvasGLView?,
    tick: Int,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val r = CornerRadius(22.dp.toPx())
        val rect = Rect(0f, 0f, size.width, size.height)
        val mask = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(rect)
            addRoundRect(RoundRect(rect, r))
        }
        drawPath(mask, Palette.DarkBg)
        drawRoundRect(Palette.PanelBorder, cornerRadius = r, style = Stroke(1.dp.toPx()))

        @Suppress("UNUSED_VARIABLE") val redrawOnViewChange = tick
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
        if (sel != null && view != null) {
            val sx = ghost?.x ?: 0f
            val sy = ghost?.y ?: 0f
            val pts = FloatArray(2)
            val path = Path()
            val corners = arrayOf(
                sel.x0 to sel.y0, (sel.x1 + 1) to sel.y0, (sel.x1 + 1) to (sel.y1 + 1), sel.x0 to (sel.y1 + 1),
            )
            corners.forEachIndexed { i, (cx, cy) ->
                view.canvasToScreen(cx + sx, cy + sy, pts)
                if (i == 0) path.moveTo(pts[0], pts[1]) else path.lineTo(pts[0], pts[1])
            }
            path.close()
            drawPath(path, Color.White, style = Stroke(3.dp.toPx(), pathEffect = dash))
            drawPath(path, Color(0xFF60A5FA), style = Stroke(1.5.dp.toPx(), pathEffect = dash))
        }
        if (marquee != null) {
            drawRect(Color(0xFF60A5FA), topLeft = marquee.topLeft, size = marquee.size, style = Stroke(2.dp.toPx(), pathEffect = dash))
        }
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
private fun FormatChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) Palette.AccentPurple else Palette.TextMuted,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(shape)
            .background(if (selected) Palette.AccentPurple.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) Palette.AccentPurple else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

private val ArtboardPresets = listOf(
    "512²" to (512 to 512), "1024²" to (1024 to 1024), "2048²" to (2048 to 2048),
    "4096²" to (4096 to 4096), "8192²" to (8192 to 8192), "16384²" to (16384 to 16384),
    "A4 300dpi" to (2480 to 3508), "Full HD" to (1080 to 1920),
)

@Composable
private fun ArtboardDialog(lowRam: Boolean, onDismiss: () -> Unit, onCreate: (Int, Int) -> Unit) {
    var wText by remember { mutableStateOf("2048") }
    var hText by remember { mutableStateOf("2048") }
    val w = wText.toIntOrNull()
    val h = hText.toIntOrNull()
    val error = when {
        w == null || h == null -> "Masukkan angka yang valid"
        w !in 512..16384 || h !in 512..16384 -> "Ukuran harus 512 – 16384 px"
        else -> null
    }
    val warning = when {
        error != null -> null
        lowRam && maxOf(w!!, h!!) > 8192 -> "RAM perangkat terbatas: hanya tile yang dilukis memakai memori; fill area sangat luas dibatasi. Gunakan Export PNG."
        w!!.toLong() * h!! > 8192L * 8192L -> "Artboard sangat besar. Tile kosong tidak memakai RAM."
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Artboard Resolution") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ArtboardPresets.forEach { (label, size) ->
                        FormatChip(label, w == size.first && h == size.second) { wText = size.first.toString(); hText = size.second.toString() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        wText, { wText = it.filter(Char::isDigit).take(5) }, label = { Text("Lebar px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        hText, { hText = it.filter(Char::isDigit).take(5) }, label = { Text("Tinggi px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                }
                if (error != null) Text(error, color = Palette.AccentPink, fontSize = 12.sp)
                if (warning != null) Text(warning, color = Palette.TextMuted, fontSize = 11.sp)
                Text("Membuat artboard baru menggantikan kanvas saat ini. Simpan project dulu bila perlu.", color = Palette.TextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(enabled = error == null, onClick = { onCreate(w!!, h!!) }) { Text("Buat") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun ExportDialog(
    paperVisible: Boolean,
    outSize: Pair<Int, Int>,
    onDismiss: () -> Unit,
    onOpenProject: () -> Unit,
    onExport: (fmt: Int, transparent: Boolean, quality: Int) -> Unit,
) {
    var fmt by remember { mutableIntStateOf(0) }
    var transparent by remember { mutableStateOf(!paperVisible) }
    var quality by remember { mutableIntStateOf(1) } // 0 = Medium, 1 = High / Maximum
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Export Studio") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FormatChip("PNG", fmt == 0) { fmt = 0 }
                    FormatChip("JPEG", fmt == 1) { fmt = 1 }
                    FormatChip("Project", fmt == 2) { fmt = 2 }
                    if (Build.VERSION.SDK_INT >= 30) FormatChip("WebP lossless", fmt == 3) { fmt = 3 }
                }
                if (fmt == 0 || fmt == 1) {
                    Text("KUALITAS EXPORT", color = Palette.TextMuted, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FormatChip("Medium", quality == 0) { quality = 0 }
                        FormatChip("High / Maksimum", quality == 1) { quality = 1 }
                    }
                }
                when (fmt) {
                    0 -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Background transparan", fontSize = 13.sp)
                            Switch(transparent, { transparent = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                        }
                        Text("Disimpan ke Pictures/DrawingApp pada resolusi penuh (lossless). Di-stream langsung dari tile native; Maksimum = kompresi terbaik (lebih lambat, file lebih kecil).", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    1 -> {
                        Text(if (quality == 1) "High / Maksimum: JPEG kualitas 100, chroma penuh (4:4:4). JPEG tetap lossy; untuk hasil identik piksel-per-piksel pakai PNG." else "Medium: JPEG kualitas 85 (4:2:0), file jauh lebih kecil.", color = Palette.TextMuted, fontSize = 11.sp)
                        Text("Hasil: ${outSize.first}×${outSize.second} (%.1f MP). Maksimum 45 MP; kanvas lebih besar diperkecil otomatis. JPEG memakai warna Paper sebagai latar.".format(outSize.first.toLong() * outSize.second / 1_000_000.0), color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    3 -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Background transparan", fontSize = 13.sp)
                            Switch(transparent, { transparent = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                        }
                        Text("WebP lossless: tepi tajam tanpa artefak, ukuran biasanya lebih kecil dari PNG. Di atas 16 MP diperkecil otomatis.", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    else -> Text("Menyimpan semua tile (terkompresi) ke Download/DrawingApp sebagai .ldproj.", color = Palette.TextMuted, fontSize = 11.sp)
                }
                TextButton(onClick = onOpenProject) { Text("Buka project (.ldproj)…", color = Palette.AccentCyan) }
            }
        },
        confirmButton = { TextButton(onClick = { onExport(fmt, transparent, quality) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private val PaperChoices = listOf(0xFFFFFFFF, 0xFFFFF8E7, 0xFFD9D9D9, 0xFF3A3A44, 0xFF18181C, 0xFF000000).map { it.toInt() }

@Composable
private fun LayersDialog(
    state: DrawState,
    tick: Int,
    onChanged: () -> Unit,
    onRender: () -> Unit,
    onClear: () -> Unit,
    onToast: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val count = remember(tick) { NativeEngine.nativeLayerCount() }
    val active = remember(tick) { NativeEngine.nativeLayerActive() }
    var opacity by remember(tick, active) { mutableFloatStateOf(((NativeEngine.nativeLayerInfo(active) shr 8) and 255) / 255f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Layers") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // top layer first
                for (i in count - 1 downTo 0) {
                    val inf = NativeEngine.nativeLayerInfo(i)
                    val vis = inf and 1 != 0
                    val locked = inf and 2 != 0
                    val sel = i == active
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.22f) else Palette.DarkBg.copy(alpha = 0.5f))
                            .clickable { if (NativeEngine.nativeLayerSelect(i)) onChanged() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { NativeEngine.nativeLayerSetVisible(i, !vis); onChanged() }, contentAlignment = Alignment.Center) {
                            Icon(DrawIcons.Eye, "Tampil", tint = if (vis) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                            Text("Layer ${i + 1}", fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal, fontSize = 13.sp)
                            Text(
                                "${(((inf shr 8) and 255) * 100 / 255)}%" + if (sel) " · aktif" else "",
                                color = Palette.TextMuted, fontSize = 11.sp,
                            )
                        }
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { NativeEngine.nativeLayerSetLocked(i, !locked); onChanged() }, contentAlignment = Alignment.Center) {
                            Text(if (locked) "🔒" else "🔓", fontSize = 16.sp)
                        }
                    }
                }

                Text("OPACITY LAYER AKTIF  ${(opacity * 100).toInt()}%", color = Palette.TextMuted, fontSize = 11.sp)
                Slider(
                    value = opacity,
                    onValueChange = { opacity = it; NativeEngine.nativeLayerSetOpacity(active, (it * 255f).roundToInt()); onRender() },
                    onValueChangeFinished = { onChanged() },
                    colors = SliderDefaults.colors(thumbColor = Palette.AccentPurple, activeTrackColor = Palette.AccentPurple),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FormatChip("+ Baru", false) {
                        if (NativeEngine.nativeLayerAdd() < 0) onToast("Maksimum 12 layer") else onChanged()
                    }
                    FormatChip("Duplikat", false) {
                        if (NativeEngine.nativeLayerDuplicate() < 0) onToast("Maksimum 12 layer") else onChanged()
                    }
                    FormatChip("Hapus", false) {
                        if (NativeEngine.nativeLayerDelete()) onChanged() else onToast("Layer terakhir tidak bisa dihapus")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FormatChip("Naik", false) { NativeEngine.nativeLayerMove(1); onChanged() }
                    FormatChip("Turun", false) { NativeEngine.nativeLayerMove(-1); onChanged() }
                    FormatChip("Gabung ↓", false) {
                        if (NativeEngine.nativeLayerMergeDown()) { onChanged(); onToast("Digabung ke layer bawah (tidak bisa di-undo)") } else onToast("Tidak ada layer di bawahnya")
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Kosongkan isi layer aktif", color = Palette.TextMuted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClear) { Text("Kosongkan", color = Palette.AccentPink) }
                }

                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.DarkBg.copy(alpha = 0.5f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Paper", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Latar kanvas (dipakai export JPEG)", color = Palette.TextMuted, fontSize = 11.sp)
                        }
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { state.paperVisible = !state.paperVisible }, contentAlignment = Alignment.Center) {
                            Icon(DrawIcons.Eye, "Visible", tint = if (state.paperVisible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PaperChoices.forEach { c ->
                            Box(
                                Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                                    .border(if (c == state.paperColor) 2.dp else 1.dp, if (c == state.paperColor) Palette.AccentPurple else Color.White.copy(alpha = 0.25f), CircleShape)
                                    .clickable { state.paperColor = c; state.paperVisible = true }
                            )
                        }
                    }
                    Text("Paper tersembunyi = transparan (kotak-kotak).", color = Palette.TextMuted, fontSize = 11.sp)
                }
                Text("Undo/redo berlaku per layer. Project (.ldproj) menyimpan hasil gabungan satu layer.", color = Palette.TextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}
