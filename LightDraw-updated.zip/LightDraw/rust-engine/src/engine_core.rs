//! JNI bindings (Kotlin object `com.lightdraw.studio.NativeEngine`) and the global engine instance.
//!
//! This file is only glue: every behaviour lives in `engine.rs` / `scene.rs` (plain Rust, unit-tested on a
//! desktop). A function here converts the JNI types, takes the global lock and calls one engine method.
#![allow(non_snake_case)]
#![allow(unused_mut)]

use std::ffi::c_void;
use std::fs;
use std::fs::File;
use std::io::{BufReader, BufWriter, Write};
use std::os::unix::io::FromRawFd;
use std::path::PathBuf;
use std::sync::Mutex;

use jni::objects::{JByteBuffer, JFloatArray, JIntArray, JObject, JString};
use jni::sys::{jboolean, jfloat, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

use crate::brush_engine::Blend;
use crate::color_engine::HslTolerance;
use crate::engine::{argb_to_px, px_to_argb, Engine};
use crate::scene::Scene;
use crate::shapes::ShapeParams;
use crate::tiled_canvas::{unpremul, TILE_PIXELS};

// ---------------------------------------------------------------- Android bitmap FFI

#[repr(C)]
struct AndroidBitmapInfo {
    width: u32,
    height: u32,
    stride: u32,
    format: i32,
    flags: u32,
}

#[cfg_attr(target_os = "android", link(name = "jnigraphics"))]
extern "C" {
    fn AndroidBitmap_getInfo(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject, info: *mut AndroidBitmapInfo) -> i32;
    fn AndroidBitmap_lockPixels(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject, addr: *mut *mut c_void) -> i32;
    fn AndroidBitmap_unlockPixels(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject) -> i32;
}

const BITMAP_FORMAT_RGBA_8888: i32 = 1;

// ---------------------------------------------------------------- engine state

static ENGINE: Mutex<Option<Engine>> = Mutex::new(None);

fn with_engine<R, F: FnOnce(&mut Engine) -> R>(default: R, f: F) -> R {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    match g.as_mut() {
        Some(e) => f(e),
        None => default,
    }
}

fn replace_engine(new_engine: Engine) {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(old) = g.take() {
        old.scene.cleanup();
    }
    *g = Some(new_engine);
}

#[inline]
fn jb(v: bool) -> jboolean {
    if v {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

// ---------------------------------------------------------------- init / info

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeInit(
    mut env: JNIEnv,
    _this: JObject,
    w: jint,
    h: jint,
    dir: JString,
    max_resident: jint,
) -> jboolean {
    let dir: String = match env.get_string(&dir) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let first = ENGINE.lock().unwrap_or_else(|e| e.into_inner()).is_none();
    if first {
        let _ = fs::remove_dir_all(&dir); // stale spill files from a previous process
    }
    replace_engine(Engine::new(w.max(0) as u32, h.max(0) as u32, PathBuf::from(dir), max_resident.max(64) as usize));
    JNI_TRUE
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCanvasWidth(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.scene.width as jint)
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCanvasHeight(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.scene.height as jint)
}

// ---------------------------------------------------------------- GPU feed

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeVisibleTiles(
    mut env: JNIEnv,
    _this: JObject,
    tx0: jint,
    ty0: jint,
    tx1: jint,
    ty1: jint,
    idx: JIntArray,
    ver: JIntArray,
) -> jint {
    let mut ib = [0i32; 4096];
    let mut vb = [0i32; 4096];
    let n = with_engine(0usize, |e| e.scene.visible_tiles(tx0, ty0, tx1, ty1, &mut ib, &mut vb));
    if n > 0 {
        let _ = env.set_int_array_region(&idx, 0, &ib[..n]);
        let _ = env.set_int_array_region(&ver, 0, &vb[..n]);
    }
    n as jint
}

/// RGBA bytes of one *composited* tile (all visible layers + live stroke + floating object).
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCopyTile(
    mut env: JNIEnv,
    _this: JObject,
    idx: jint,
    buf: JByteBuffer,
) -> jboolean {
    let ptr = match env.get_direct_buffer_address(&buf) {
        Ok(p) => p,
        Err(_) => return JNI_FALSE,
    };
    let cap = env.get_direct_buffer_capacity(&buf).unwrap_or(0);
    if ptr.is_null() || cap < TILE_PIXELS * 4 || idx < 0 {
        return JNI_FALSE;
    }
    let dst = unsafe { std::slice::from_raw_parts_mut(ptr, TILE_PIXELS * 4) };
    jb(with_engine(false, |e| {
        let i = idx as usize;
        i < e.scene.tile_count() && e.scene.copy_tile_bytes(i, dst)
    }))
}

// ---------------------------------------------------------------- settings

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetBrush(
    _env: JNIEnv,
    _this: JObject,
    preset: jint,
    size: jfloat,
    opacity: jfloat,
    color: jint,
    blend: jint,
) {
    with_engine((), |e| {
        e.brush.set_preset(preset);
        e.brush.size = size.clamp(1.0, 512.0);
        e.brush.opacity = opacity.clamp(0.0, 1.0);
        e.brush.color = argb_to_px(color);
        e.brush.blend = Blend::from_i32(blend);
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetStabilizer(_env: JNIEnv, _this: JObject, strength: jfloat) {
    with_engine((), |e| e.stab.set_strength(strength));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetSymmetry(
    _env: JNIEnv,
    _this: JObject,
    mode: jint,
    sectors: jint,
    mirror: jboolean,
) {
    with_engine((), |e| e.sym.configure(mode, sectors, mirror != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetBg(_env: JNIEnv, _this: JObject, argb: jint) {
    with_engine((), |e| e.bg = argb_to_px(argb));
}

/// Seamless repeat on/off: strokes, shapes and dragged objects wrap around the canvas edges.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetWrap(_env: JNIEnv, _this: JObject, on: jboolean) {
    with_engine((), |e| e.scene.set_wrap(on != 0));
}

// ---------------------------------------------------------------- strokes

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeBegin(
    _env: JNIEnv,
    _this: JObject,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    t: jlong,
) {
    with_engine((), |e| e.stroke_begin(x, y, p, t));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeMove(
    _env: JNIEnv,
    _this: JObject,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    t: jlong,
) {
    with_engine((), |e| e.stroke_move(x, y, p, t));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeEnd(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.stroke_end());
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeCancel(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.stroke_cancel());
}

// ---------------------------------------------------------------- shapes

/// Redraw the live shape preview (anti-aliased, optionally pattern filled). Call `nativeShapeEnd` to bake it.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeShapeUpdate(
    _env: JNIEnv,
    _this: JObject,
    kind: jint,
    x0: jfloat,
    y0: jfloat,
    x1: jfloat,
    y1: jfloat,
    outline: jboolean,
    stroke: jfloat,
    corner: jfloat,
    sides: jint,
    color: jint,
    opacity: jfloat,
    blend: jint,
    paint_kind: jint,
    color2: jint,
    pattern_scale: jfloat,
) {
    with_engine((), |e| {
        let p = ShapeParams { kind, x0, y0, x1, y1, outline: outline != 0, stroke, corner, sides };
        e.shape_update(&p, argb_to_px(color), opacity.clamp(0.0, 1.0), Blend::from_i32(blend), paint_kind, argb_to_px(color2), pattern_scale);
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeShapeEnd(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.shape_end());
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeShapeCancel(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.shape_cancel());
}

// ---------------------------------------------------------------- fill / colour tools

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFill(
    _env: JNIEnv,
    _this: JObject,
    x: jint,
    y: jint,
    kind: jint,
    color: jint,
    color2: jint,
    scale: jfloat,
    tol: jint,
) -> jint {
    with_engine(-1, |e| e.fill(x, y, kind, argb_to_px(color), argb_to_px(color2), scale, tol))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSelectReplace(
    _env: JNIEnv,
    _this: JObject,
    x: jint,
    y: jint,
    new_color: jint,
    tol_h: jfloat,
    tol_s: jfloat,
    tol_l: jfloat,
) -> jint {
    with_engine(-1, |e| {
        let tol = HslTolerance { hue_deg: tol_h.clamp(0.0, 180.0), sat: tol_s.clamp(0.0, 1.0), lum: tol_l.clamp(0.0, 1.0) };
        e.select_replace(x, y, argb_to_px(new_color), tol).min(i32::MAX as u32) as jint
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativePickColor(_env: JNIEnv, _this: JObject, x: jint, y: jint) -> jint {
    with_engine(0, |e| px_to_argb(e.pick_color(x, y)))
}

// ---------------------------------------------------------------- history

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeUndo(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.undo()))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeRedo(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.redo()))
}

/// bit0 = can undo, bit1 = can redo
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeHistoryState(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| (e.scene.can_undo() as jint) | ((e.scene.can_redo() as jint) << 1))
}

/// Erase the active layer (undoable).
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeClear(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.scene.clear_active_layer());
}

// ---------------------------------------------------------------- layers

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerCount(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.scene.layers.len() as jint)
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeActiveLayer(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.scene.active as jint)
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerName(mut env: JNIEnv, _this: JObject, i: jint) -> jstring {
    let name = with_engine(String::new(), |e| e.scene.layers.get(i.max(0) as usize).map(|l| l.name.clone()).unwrap_or_default());
    match env.new_string(name) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerVisible(_env: JNIEnv, _this: JObject, i: jint) -> jboolean {
    jb(with_engine(false, |e| e.scene.layers.get(i.max(0) as usize).map_or(false, |l| l.visible)))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerOpacity(_env: JNIEnv, _this: JObject, i: jint) -> jfloat {
    with_engine(1.0, |e| e.scene.layers.get(i.max(0) as usize).map_or(1.0, |l| l.opacity))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeAddLayer(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.add_layer()))
}

/// Copy the active layer (all pixels, visibility, opacity) above itself.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeDuplicateLayer(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.duplicate_layer()))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeDeleteLayer(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.delete_layer()))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeMoveLayer(_env: JNIEnv, _this: JObject, from: jint, to: jint) -> jboolean {
    jb(with_engine(false, |e| from >= 0 && to >= 0 && e.scene.move_layer(from as usize, to as usize)))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetActiveLayer(_env: JNIEnv, _this: JObject, i: jint) {
    with_engine((), |e| {
        if i >= 0 {
            e.scene.set_active(i as usize)
        }
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetLayerVisible(_env: JNIEnv, _this: JObject, i: jint, v: jboolean) {
    with_engine((), |e| {
        if i >= 0 {
            e.scene.set_visible(i as usize, v != 0)
        }
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetLayerOpacity(_env: JNIEnv, _this: JObject, i: jint, o: jfloat) {
    with_engine((), |e| {
        if i >= 0 {
            e.scene.set_opacity(i as usize, o)
        }
    });
}

// ---------------------------------------------------------------- objects (select / transform / align / duplicate)

/// Select the connected object under (x, y) on the active layer. 0 ok, 1 nothing there, 2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSelectAt(_env: JNIEnv, _this: JObject, x: jint, y: jint) -> jint {
    with_engine(-1, |e| e.scene.select_at(x, y))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSelectRect(
    _env: JNIEnv,
    _this: JObject,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
) -> jint {
    with_engine(-1, |e| e.scene.select_rect(x0, y0, x1, y1))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSelectAll(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(-1, |e| e.scene.select_all())
}

/// Bake the floating object back into its layer ("deselect / apply").
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCommit(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.scene.commit_float());
}

/// Throw the floating object away (if it was cut out of the layer, the pixels stay removed; undo brings them back).
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeDeleteObject(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.scene.delete_float());
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeHasObject(_env: JNIEnv, _this: JObject) -> jboolean {
    jb(with_engine(false, |e| e.scene.has_float()))
}

/// Move the floating object by (dx, dy) canvas pixels. With seamless repeat on it wraps around the edges.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectMove(_env: JNIEnv, _this: JObject, dx: jfloat, dy: jfloat) {
    with_engine((), |e| e.scene.float_move(dx, dy));
}

/// Absolute uniform scale (1.0 = 100 %) and rotation in degrees.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectTransform(_env: JNIEnv, _this: JObject, scale: jfloat, rot_deg: jfloat) {
    with_engine((), |e| e.scene.float_set_transform(scale, rot_deg));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectFlip(_env: JNIEnv, _this: JObject, horizontal: jboolean) {
    with_engine((), |e| e.scene.float_flip(horizontal != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectRotate90(_env: JNIEnv, _this: JObject, clockwise: jboolean) {
    with_engine((), |e| e.scene.float_rotate90(clockwise != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectHit(_env: JNIEnv, _this: JObject, x: jfloat, y: jfloat) -> jboolean {
    jb(with_engine(false, |e| e.scene.float_hit(x, y)))
}

/// out[0..7] = scale, rotation (deg), wrap (0/1), min_x, min_y, max_x, max_y. False when nothing is selected.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectInfo(mut env: JNIEnv, _this: JObject, out: JFloatArray) -> jboolean {
    match with_engine(None, |e| e.scene.float_info()) {
        Some(info) => {
            let _ = env.set_float_array_region(&out, 0, &info);
            JNI_TRUE
        }
        None => JNI_FALSE,
    }
}

/// out[0..8] = x,y of the four corners (top-left, top-right, bottom-right, bottom-left) in canvas pixels.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectCorners(mut env: JNIEnv, _this: JObject, out: JFloatArray) -> jboolean {
    match with_engine(None, |e| e.scene.float_corners()) {
        Some(c) => {
            let flat = [c[0].0, c[0].1, c[1].0, c[1].1, c[2].0, c[2].1, c[3].0, c[3].1];
            let _ = env.set_float_array_region(&out, 0, &flat);
            JNI_TRUE
        }
        None => JNI_FALSE,
    }
}

/// Align the selected object (or, with no selection, all content of the layer) to the canvas.
/// mode: 0 left, 1 centre horizontally, 2 right, 3 top, 4 centre vertically, 5 bottom, 6 centre on canvas.
/// Returns 0 ok, 1 nothing to align, 2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeAlign(_env: JNIEnv, _this: JObject, mode: jint) -> jint {
    with_engine(-1, |e| e.scene.align(mode))
}

/// Duplicate the selected object (or the whole layer content): the original is baked in place, the copy floats.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeDuplicateObject(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(-1, |e| e.scene.duplicate_object())
}

// ---------------------------------------------------------------- patterns

/// Turn the selected object into a repeatable pattern. Returns the slot (paint kind = 100 + slot),
/// -1 nothing selected, -2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeObjectToPattern(
    _env: JNIEnv,
    _this: JObject,
    spacing: jint,
    brick: jboolean,
) -> jint {
    with_engine(-1, |e| e.scene.float_to_pattern(spacing.max(0) as usize, brick != 0))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativePatternCount(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.scene.patterns.len() as jint)
}

/// Fill `out` (size*size Android ARGB ints) with a 2x2 repeat preview of pattern `i`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativePatternThumb(
    mut env: JNIEnv,
    _this: JObject,
    i: jint,
    size: jint,
    out: JIntArray,
) -> jboolean {
    if i < 0 || size <= 0 || size > 512 {
        return JNI_FALSE;
    }
    let n = (size * size) as usize;
    let mut buf = vec![0u32; n];
    let ok = with_engine(false, |e| e.scene.pattern_thumb(i as usize, size as usize, &mut buf));
    if !ok {
        return JNI_FALSE;
    }
    let argb: Vec<i32> = buf.iter().map(|&p| px_to_argb(unpremul(p))).collect();
    let _ = env.set_int_array_region(&out, 0, &argb);
    JNI_TRUE
}

/// Classic "Offset" for seamless tiles: shift the active layer by (dx, dy) with wrap-around (one undo step).
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeOffsetWrap(_env: JNIEnv, _this: JObject, dx: jint, dy: jint) -> jint {
    with_engine(-1, |e| e.scene.offset_wrap(dx, dy))
}

// ---------------------------------------------------------------- FX

/// Apply an effect to the selected object, or to the active layer when nothing is selected.
/// kind: 0 blur (a = radius) | 1 sharpen (a = amount) | 2 brightness/contrast (a, b) | 3 hue/sat (a = degrees, b = %)
///       4 invert | 5 grayscale | 6 pixelate (a = block px).  Returns 0 ok, 1 nothing to process, 2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeApplyFx(_env: JNIEnv, _this: JObject, kind: jint, a: jfloat, b: jfloat) -> jint {
    with_engine(-1, |e| e.scene.apply_fx(kind, a, b))
}

// ---------------------------------------------------------------- export / import

/// Render the whole canvas, scaled (nearest) to the bitmap size, over the given paper colour.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeRenderToBitmap(mut env: JNIEnv, _this: JObject, bitmap: JObject, bg: jint) -> jint {
    let raw_env = env.get_raw();
    let bmp = bitmap.as_raw();
    let mut info = AndroidBitmapInfo { width: 0, height: 0, stride: 0, format: 0, flags: 0 };
    unsafe {
        if AndroidBitmap_getInfo(raw_env, bmp, &mut info) != 0 {
            return 1;
        }
        if info.format != BITMAP_FORMAT_RGBA_8888 {
            return 2;
        }
        let mut addr: *mut c_void = std::ptr::null_mut();
        if AndroidBitmap_lockPixels(raw_env, bmp, &mut addr) != 0 || addr.is_null() {
            return 3;
        }
        let bgp = argb_to_px(bg);
        let (dw, dh, stride) = (info.width as usize, info.height as usize, info.stride as usize);
        let base = addr as *mut u8;
        let r = with_engine(4, |e| {
            if dw == 0 || dh == 0 {
                return 5;
            }
            e.render_rows(dw, dh, bgp, |y, row| {
                let dst = std::slice::from_raw_parts_mut(base.add(y * stride) as *mut u32, dw);
                dst.copy_from_slice(&row[..dw]);
            });
            0
        });
        AndroidBitmap_unlockPixels(raw_env, bmp);
        r
    }
}

fn export_png(e: &mut Engine, fd: i32, bg: u32) -> Result<(), String> {
    let file = unsafe { File::from_raw_fd(fd) };
    let out = BufWriter::with_capacity(1 << 20, file);
    let (cw, ch) = (e.scene.width as usize, e.scene.height as usize);
    let transparent = bg >> 24 == 0;
    let mut enc = png::Encoder::new(out, cw as u32, ch as u32);
    enc.set_color(if transparent { png::ColorType::Rgba } else { png::ColorType::Rgb });
    enc.set_depth(png::BitDepth::Eight);
    enc.set_compression(png::Compression::Fast);
    let mut writer = enc.write_header().map_err(|e| e.to_string())?;
    let mut err: Option<String> = None;
    {
        let mut stream = writer.stream_writer().map_err(|e| e.to_string())?;
        let mut bytes: Vec<u8> = Vec::with_capacity(cw * 4);
        e.render_rows(cw, ch, bg, |_, row| {
            if err.is_some() {
                return;
            }
            bytes.clear();
            for &p in row.iter() {
                if transparent {
                    let s = unpremul(p);
                    bytes.extend_from_slice(&[(s & 255) as u8, ((s >> 8) & 255) as u8, ((s >> 16) & 255) as u8, (s >> 24) as u8]);
                } else {
                    bytes.extend_from_slice(&[(p & 255) as u8, ((p >> 8) & 255) as u8, ((p >> 16) & 255) as u8]);
                }
            }
            if let Err(x) = stream.write_all(&bytes) {
                err = Some(x.to_string());
            }
        });
        // dropping the stream finalises the IDAT stream; dropping the writer finishes the file
    }
    drop(writer);
    match err {
        Some(m) => Err(m),
        None => Ok(()),
    }
}

/// Streaming PNG export (row by row) - safe for 16K canvases. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeExportPng(_env: JNIEnv, _this: JObject, fd: jint, bg: jint) -> jint {
    let bgp = argb_to_px(bg);
    with_engine(-1, |e| match export_png(e, fd, bgp) {
        Ok(()) => 0,
        Err(_) => 1,
    })
}

/// Full-size, maximum-fidelity JPEG (quality 100 = quantiser steps of 1, 4:4:4 chroma, never down-scaled),
/// streamed row by row so even a 16384 x 16384 artboard fits in memory. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeExportJpeg(
    _env: JNIEnv,
    _this: JObject,
    fd: jint,
    bg: jint,
    quality: jint,
) -> jint {
    let bgp = argb_to_px(bg);
    let q = quality.clamp(1, 100) as u32;
    with_engine(-1, |e| {
        let file = unsafe { File::from_raw_fd(fd) };
        let out = BufWriter::with_capacity(1 << 20, file);
        match e.export_jpeg(out, bgp, q).and_then(|mut w| w.flush()) {
            Ok(()) => 0,
            Err(_) => 1,
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSaveProject(_env: JNIEnv, _this: JObject, fd: jint) -> jint {
    with_engine(-1, |e| {
        let file = unsafe { File::from_raw_fd(fd) };
        let mut w = BufWriter::with_capacity(1 << 20, file);
        let bg = e.bg;
        match e.scene.write_project(&mut w, bg).and_then(|_| w.flush()) {
            Ok(()) => 0,
            Err(_) => 1,
        }
    })
}

/// Returns (width << 32) | height, or -1 on failure. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLoadProject(
    mut env: JNIEnv,
    _this: JObject,
    fd: jint,
    dir: JString,
    max_resident: jint,
) -> jlong {
    let dir: String = match env.get_string(&dir) {
        Ok(s) => s.into(),
        Err(_) => return -1,
    };
    let file = unsafe { File::from_raw_fd(fd) };
    let mut r = BufReader::with_capacity(1 << 20, file);
    match Scene::read_project(&mut r, PathBuf::from(dir), max_resident.max(64) as usize) {
        Ok((scene, bg)) => {
            let (w, h) = (scene.width as i64, scene.height as i64);
            replace_engine(Engine::from_scene(scene, bg));
            (w << 32) | h
        }
        Err(_) => -1,
    }
}

/// Put an ARGB_8888 (premultiplied) bitmap on the canvas as a *floating object* at (dx, dy), so it can be
/// moved / scaled / rotated / aligned before it is baked into the active layer.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeImportBitmap(mut env: JNIEnv, _this: JObject, bitmap: JObject, dx: jint, dy: jint) -> jint {
    let raw_env = env.get_raw();
    let bmp = bitmap.as_raw();
    let mut info = AndroidBitmapInfo { width: 0, height: 0, stride: 0, format: 0, flags: 0 };
    unsafe {
        if AndroidBitmap_getInfo(raw_env, bmp, &mut info) != 0 {
            return 1;
        }
        if info.format != BITMAP_FORMAT_RGBA_8888 {
            return 2;
        }
        let mut addr: *mut c_void = std::ptr::null_mut();
        if AndroidBitmap_lockPixels(raw_env, bmp, &mut addr) != 0 || addr.is_null() {
            return 3;
        }
        let (bw, bh, stride) = (info.width as usize, info.height as usize, info.stride as usize);
        let mut px = vec![0u32; bw * bh];
        for y in 0..bh {
            let row = std::slice::from_raw_parts((addr as *const u8).add(y * stride) as *const u32, bw);
            px[y * bw..(y + 1) * bw].copy_from_slice(row);
        }
        AndroidBitmap_unlockPixels(raw_env, bmp);
        with_engine(4, |e| if e.scene.import_float(px, bw, bh, dx, dy) { 0 } else { 5 })
    }
}
