//! Desktop unit tests for the engine (run with `cargo test`).

use std::sync::atomic::{AtomicU32, Ordering};

use crate::brush_engine::Blend;
use crate::engine::{argb_to_px, Engine};
use crate::scene::Scene;
use crate::shapes::{ShapeParams, ELLIPSE, RECT};

static N: AtomicU32 = AtomicU32::new(0);

fn eng(w: u32, h: u32) -> Engine {
    let dir = std::env::temp_dir().join(format!("ldtest_{}_{}", std::process::id(), N.fetch_add(1, Ordering::Relaxed)));
    Engine::new(w, h, dir, 128)
}

/// Premultiplied pixel exactly as the GPU would receive it (layers + live stroke + floating object).
fn px(e: &mut Engine, x: i32, y: i32) -> u32 {
    let tiles_x = e.scene.tiles_x();
    let idx = (y as usize >> 8) * tiles_x + (x as usize >> 8);
    let mut tile = vec![0u32; crate::tiled_canvas::TILE_PIXELS];
    e.scene.composite_tile(idx, &mut tile);
    tile[(y as usize & 255) * 256 + (x as usize & 255)]
}

fn alpha(e: &mut Engine, x: i32, y: i32) -> u32 {
    px(e, x, y) >> 24
}

fn black_pen(e: &mut Engine, size: f32) {
    e.brush.set_preset(2); // hard ink pen
    e.brush.size = size;
    e.brush.opacity = 1.0;
    e.brush.color = argb_to_px(0xFF000000u32 as i32);
    e.brush.blend = Blend::Normal;
}

fn line(e: &mut Engine, x0: f32, y0: f32, x1: f32, y1: f32) {
    e.stroke_begin(x0, y0, 1.0, 0);
    let n = 40;
    for i in 1..=n {
        let t = i as f32 / n as f32;
        e.stroke_move(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, 1.0, i as i64 * 8);
    }
    e.stroke_end();
}

/// Bounding box of everything with alpha > 0 on the composited canvas.
fn bbox(e: &mut Engine) -> Option<(i32, i32, i32, i32)> {
    let (w, h) = (e.scene.width as i32, e.scene.height as i32);
    let tiles_x = e.scene.tiles_x();
    let mut tiles: Vec<Vec<u32>> = Vec::new();
    for idx in 0..e.scene.tile_count() {
        let mut t = vec![0u32; crate::tiled_canvas::TILE_PIXELS];
        e.scene.composite_tile(idx, &mut t);
        tiles.push(t);
    }
    let (mut x0, mut y0, mut x1, mut y1) = (i32::MAX, i32::MAX, i32::MIN, i32::MIN);
    for y in 0..h {
        for x in 0..w {
            let idx = (y as usize >> 8) * tiles_x + (x as usize >> 8);
            if tiles[idx][(y as usize & 255) * 256 + (x as usize & 255)] >> 24 != 0 {
                x0 = x0.min(x);
                y0 = y0.min(y);
                x1 = x1.max(x + 1);
                y1 = y1.max(y + 1);
            }
        }
    }
    if x0 == i32::MAX {
        None
    } else {
        Some((x0, y0, x1, y1))
    }
}

// ------------------------------------------------------------------------------------------ anti-aliasing

#[test]
fn stroke_edges_are_antialiased_and_correctly_sized() {
    let mut e = eng(512, 512);
    black_pen(&mut e, 6.0);
    // horizontal line whose centre is exactly on a pixel row boundary: rows 197..203 are fully covered
    line(&mut e, 60.0, 200.0, 400.0, 200.0);
    let col: Vec<u32> = (190..210).map(|y| alpha(&mut e, 200, y)).collect();
    let sum: f32 = col.iter().map(|&a| a as f32 / 255.0).sum();
    assert!((sum - 6.0).abs() < 0.15, "line thickness should be ~6px, got {sum} ({col:?})");

    // a line whose edge falls mid-pixel must produce a partially covered edge pixel (not 0 or 255)
    let mut e = eng(512, 512);
    black_pen(&mut e, 6.0);
    line(&mut e, 60.0, 200.5, 400.0, 200.5);
    let col: Vec<u32> = (190..210).map(|y| alpha(&mut e, 200, y)).collect();
    let partial = col.iter().filter(|&&a| a > 0 && a < 255).count();
    let sum: f32 = col.iter().map(|&a| a as f32 / 255.0).sum();
    assert!(partial >= 2, "expected soft edge pixels, got {col:?}");
    assert!((sum - 6.0).abs() < 0.15, "thickness {sum} ({col:?})");
}

#[test]
fn diagonal_stroke_has_smooth_alpha_ramp() {
    let mut e = eng(256, 256);
    black_pen(&mut e, 10.0);
    line(&mut e, 20.0, 20.0, 230.0, 163.13);
    // along a diagonal edge the sub-pixel position changes continuously -> many distinct coverage levels
    let mut levels = std::collections::BTreeSet::new();
    let mut hard_pixels = 0;
    let mut soft_pixels = 0;
    for y in 0..256 {
        for x in 0..256 {
            let a = alpha(&mut e, x, y);
            if a == 255 {
                hard_pixels += 1;
            } else if a > 0 {
                soft_pixels += 1;
                levels.insert(a);
            }
        }
    }
    assert!(levels.len() >= 40, "diagonal edge should have many alpha levels, got {}", levels.len());
    assert!(soft_pixels > 300 && hard_pixels > 1500, "soft {soft_pixels} hard {hard_pixels}");
}

#[test]
fn stroke_opacity_is_exact_even_when_it_overlaps_itself() {
    let mut e = eng(300, 300);
    black_pen(&mut e, 12.0);
    e.brush.opacity = 0.5;
    // path crossing itself twice
    e.stroke_begin(40.0, 150.0, 1.0, 0);
    let pts = [(260.0, 150.0), (260.0, 160.0), (40.0, 160.0), (40.0, 150.0), (260.0, 150.0)];
    let mut t = 0;
    for (px, py) in pts {
        for k in 1..=30 {
            let _ = k;
        }
        t += 10;
        e.stroke_move(px, py, 1.0, t);
    }
    e.stroke_end();
    let a = alpha(&mut e, 150, 155);
    assert!((a as i32 - 128).abs() <= 2, "single-stroke opacity 50% must stay 50% when overlapping, got {a}");
}

#[test]
fn soft_airbrush_builds_up_but_is_capped_by_opacity() {
    let mut e = eng(200, 200);
    e.brush.set_preset(1);
    e.brush.size = 40.0;
    e.brush.opacity = 0.6;
    e.brush.color = argb_to_px(0xFFFF0000u32 as i32);
    // scribble three circles of radius 6 around (100,100)
    e.stroke_begin(106.0, 100.0, 1.0, 0);
    for i in 1..=96 {
        let a = i as f32 * std::f32::consts::TAU / 32.0;
        e.stroke_move(100.0 + 6.0 * a.cos(), 100.0 + 6.0 * a.sin(), 1.0, i * 8);
    }
    e.stroke_end();
    let a = alpha(&mut e, 100, 100);
    assert!(a <= 154 && a >= 140, "airbrush centre builds up to the 60% opacity cap, got {a}");
    let edge = alpha(&mut e, 100, 100 - 18);
    assert!(edge < a, "airbrush must fade towards the rim");
}

#[test]
fn shapes_are_antialiased() {
    let mut e = eng(256, 256);
    e.brush.color = argb_to_px(0xFF0000FFu32 as i32);
    let p = ShapeParams { kind: ELLIPSE, x0: 30.0, y0: 40.0, x1: 200.0, y1: 150.3, outline: false, stroke: 4.0, corner: 0.0, sides: 5 };
    e.shape_update(&p, e.brush.color, 1.0, Blend::Normal, 0, e.brush.color, 1.0);
    e.shape_end();
    let mut levels = std::collections::BTreeSet::new();
    for y in 30..170 {
        for x in 20..215 {
            let a = alpha(&mut e, x, y);
            if a > 0 && a < 255 {
                levels.insert(a);
            }
        }
    }
    assert!(levels.len() > 30, "ellipse rim should span many alpha levels, got {}", levels.len());
    assert_eq!(alpha(&mut e, 115, 95), 255);
    assert_eq!(alpha(&mut e, 5, 5), 0);
}

// ------------------------------------------------------------------------------------------ layers

#[test]
fn duplicate_layer_copies_all_pixels_and_is_undoable() {
    let mut e = eng(300, 300);
    black_pen(&mut e, 8.0);
    line(&mut e, 20.0, 20.0, 280.0, 200.0);
    assert!(e.scene.duplicate_layer());
    assert_eq!(e.scene.layers.len(), 2);
    assert_eq!(e.scene.active, 1);
    // compare layer pixels
    let (mut a, mut b) = (vec![0u32; 300], vec![0u32; 300]);
    for y in 0..300 {
        e.scene.layers[0].canvas.read_row(y, 0, &mut a);
        e.scene.layers[1].canvas.read_row(y, 0, &mut b);
        assert_eq!(a, b, "row {y}");
    }
    // editing the copy does not touch the original
    black_pen(&mut e, 8.0);
    line(&mut e, 20.0, 250.0, 280.0, 250.0);
    assert_eq!(e.scene.layers[0].canvas.get_pixel(150, 250), 0);
    assert!(e.scene.layers[1].canvas.get_pixel(150, 250) >> 24 != 0);
    // undo the stroke, then undo the duplicate
    assert!(e.scene.undo());
    assert_eq!(e.scene.layers[1].canvas.get_pixel(150, 250), 0);
    assert!(e.scene.undo());
    assert_eq!(e.scene.layers.len(), 1);
    assert!(e.scene.redo());
    assert_eq!(e.scene.layers.len(), 2);
    assert_eq!(e.scene.layers[1].name, "Layer 1 copy");
}

#[test]
fn layer_opacity_and_visibility_affect_the_composite() {
    let mut e = eng(128, 128);
    black_pen(&mut e, 20.0);
    line(&mut e, 20.0, 64.0, 100.0, 64.0);
    assert_eq!(alpha(&mut e, 60, 64), 255);
    e.scene.set_opacity(0, 0.5);
    let a = alpha(&mut e, 60, 64);
    assert!((a as i32 - 128).abs() <= 1, "{a}");
    e.scene.set_visible(0, false);
    assert_eq!(alpha(&mut e, 60, 64), 0);
}

#[test]
fn undo_is_ordered_across_layers() {
    let mut e = eng(128, 128);
    black_pen(&mut e, 10.0);
    line(&mut e, 10.0, 30.0, 110.0, 30.0); // layer 1
    assert!(e.scene.add_layer());
    line(&mut e, 10.0, 90.0, 110.0, 90.0); // layer 2
    assert_eq!(e.scene.layers.len(), 2);
    assert!(e.scene.undo()); // stroke on layer 2
    assert_eq!(alpha(&mut e, 60, 90), 0);
    assert!(alpha(&mut e, 60, 30) != 0);
    assert!(e.scene.undo()); // add layer
    assert_eq!(e.scene.layers.len(), 1);
    assert!(e.scene.undo()); // stroke on layer 1
    assert_eq!(alpha(&mut e, 60, 30), 0);
    assert!(!e.scene.undo());
}

// ------------------------------------------------------------------------------------------ objects

fn rect_obj(e: &mut Engine, x0: f32, y0: f32, x1: f32, y1: f32) {
    e.brush.color = argb_to_px(0xFFFF0000u32 as i32);
    let p = ShapeParams { kind: RECT, x0, y0, x1, y1, outline: false, stroke: 2.0, corner: 0.0, sides: 4 };
    e.shape_update(&p, e.brush.color, 1.0, Blend::Normal, 0, e.brush.color, 1.0);
    e.shape_end();
}

#[test]
fn select_move_commit_undo_is_a_single_step() {
    let mut e = eng(256, 256);
    rect_obj(&mut e, 20.0, 20.0, 60.0, 60.0);
    assert_eq!(e.scene.select_at(40, 40), 0);
    assert!(e.scene.has_float());
    assert_eq!(alpha(&mut e, 40, 40), 255, "floating object is still drawn");
    e.scene.float_move(100.0, 50.0);
    assert_eq!(alpha(&mut e, 40, 40), 0);
    assert_eq!(alpha(&mut e, 140, 90), 255);
    e.scene.commit_float();
    assert_eq!(alpha(&mut e, 140, 90), 255);
    // one undo restores the original position (lift + commit were merged)
    assert!(e.scene.undo());
    assert_eq!(alpha(&mut e, 140, 90), 0);
    assert_eq!(alpha(&mut e, 40, 40), 255);
    assert!(e.scene.redo());
    assert_eq!(alpha(&mut e, 140, 90), 255);
    assert_eq!(alpha(&mut e, 40, 40), 0);
}

#[test]
fn align_all_modes() {
    let (cw, ch) = (400i32, 300i32);
    let modes: [(i32, Box<dyn Fn((i32, i32, i32, i32)) -> bool>); 7] = [
        (0, Box::new(|b| b.0 == 0)),
        (1, Box::new(move |b| (b.0 + b.2 - cw).abs() <= 1)),
        (2, Box::new(move |b| b.2 == cw)),
        (3, Box::new(|b| b.1 == 0)),
        (4, Box::new(move |b| (b.1 + b.3 - ch).abs() <= 1)),
        (5, Box::new(move |b| b.3 == ch)),
        (6, Box::new(move |b| (b.0 + b.2 - cw).abs() <= 1 && (b.1 + b.3 - ch).abs() <= 1)),
    ];
    for (mode, ok) in modes {
        let mut e = eng(cw as u32, ch as u32);
        rect_obj(&mut e, 50.0, 70.0, 90.0, 150.0);
        assert_eq!(e.scene.select_at(60, 80), 0);
        assert_eq!(e.scene.align(mode), 0);
        e.scene.commit_float();
        let b = bbox(&mut e).unwrap();
        assert!(ok(b), "mode {mode}: bbox {b:?}");
        assert_eq!((b.2 - b.0, b.3 - b.1), (40, 80), "size must be preserved");
    }
}

#[test]
fn align_without_selection_uses_whole_layer_content() {
    let mut e = eng(200, 200);
    rect_obj(&mut e, 10.0, 10.0, 30.0, 30.0);
    rect_obj(&mut e, 60.0, 10.0, 90.0, 30.0);
    assert_eq!(e.scene.align(6), 0);
    e.scene.commit_float();
    let b = bbox(&mut e).unwrap();
    assert_eq!((b.0 + b.2, b.1 + b.3), (200, 200), "{b:?}");
    assert_eq!(b.2 - b.0, 80, "relative layout of both rects kept");
}

#[test]
fn duplicate_object_leaves_original_and_floats_a_copy() {
    let mut e = eng(300, 300);
    rect_obj(&mut e, 50.0, 50.0, 90.0, 90.0);
    assert_eq!(e.scene.select_at(60, 60), 0);
    assert_eq!(e.scene.duplicate_object(), 0);
    assert!(e.scene.has_float());
    assert_eq!(alpha(&mut e, 60, 60), 255, "original baked back");
    e.scene.float_move(120.0, 0.0);
    e.scene.commit_float();
    assert_eq!(alpha(&mut e, 60, 60), 255);
    assert_eq!(alpha(&mut e, 60 + 120 + 12, 60 + 12), 255, "copy is offset by 12px by default + 120 moved");
    // nothing selected -> duplicating still works on the layer content; nothing on an empty layer
    let mut e2 = eng(100, 100);
    assert_eq!(e2.scene.duplicate_object(), 1);
}

#[test]
fn seamless_wrap_moves_object_across_edges_and_corners() {
    let mut e = eng(200, 200);
    rect_obj(&mut e, 80.0, 80.0, 120.0, 120.0); // 40x40 in the middle
    e.scene.set_wrap(true);
    assert_eq!(e.scene.select_at(100, 100), 0);
    // drag so the object straddles the bottom-right corner: centre goes to (195, 195)
    e.scene.float_move(95.0, 95.0);
    // all four corners show a quarter of the object
    for (x, y) in [(190, 190), (5, 190), (190, 5), (5, 5)] {
        assert_eq!(alpha(&mut e, x, y), 255, "corner pixel ({x},{y})");
    }
    assert_eq!(alpha(&mut e, 100, 100), 0);
    // drag far past the edge: centre re-enters from the other side
    e.scene.float_move(30.0, 0.0);
    assert_eq!(alpha(&mut e, 25, 190), 255);
    e.scene.commit_float();
    assert_eq!(alpha(&mut e, 25, 190), 255);
    assert_eq!(alpha(&mut e, 25, 5), 255, "still wrapped vertically");
    assert_eq!(alpha(&mut e, 190, 190), 0, "the object left that corner");
}

#[test]
fn wrap_off_clips_at_the_edge() {
    let mut e = eng(200, 200);
    rect_obj(&mut e, 80.0, 80.0, 120.0, 120.0);
    assert_eq!(e.scene.select_at(100, 100), 0);
    e.scene.float_move(95.0, 95.0);
    e.scene.commit_float();
    assert_eq!(alpha(&mut e, 190, 190), 255);
    assert_eq!(alpha(&mut e, 5, 5), 0);
}

#[test]
fn brush_strokes_wrap_when_seamless_mode_is_on() {
    let mut e = eng(200, 200);
    e.scene.set_wrap(true);
    black_pen(&mut e, 20.0);
    line(&mut e, 180.0, 100.0, 195.0, 100.0);
    // dab radius 10 around x=195 spills 5px over the right edge -> must re-enter on the left edge
    assert_eq!(alpha(&mut e, 3, 100), 255);
    let mut e2 = eng(200, 200);
    black_pen(&mut e2, 20.0);
    line(&mut e2, 180.0, 100.0, 195.0, 100.0);
    assert_eq!(alpha(&mut e2, 3, 100), 0);
}

#[test]
fn shapes_wrap_in_seamless_mode() {
    let mut e = eng(200, 200);
    e.scene.set_wrap(true);
    e.brush.color = argb_to_px(0xFF00FF00u32 as i32);
    let p = ShapeParams { kind: ELLIPSE, x0: 170.0, y0: 170.0, x1: 230.0, y1: 230.0, outline: false, stroke: 2.0, corner: 0.0, sides: 5 };
    e.shape_update(&p, e.brush.color, 1.0, Blend::Normal, 0, e.brush.color, 1.0);
    e.shape_end();
    assert!(alpha(&mut e, 10, 10) > 200, "wrapped quarter in the top-left corner");
    assert!(alpha(&mut e, 195, 195) > 200);
}

#[test]
fn offset_wrap_shifts_layer_with_wrap_around() {
    let mut e = eng(200, 100);
    rect_obj(&mut e, 150.0, 20.0, 190.0, 60.0);
    assert_eq!(e.scene.offset_wrap(100, 0), 0);
    // 150..190 + 100 = 250..290 -> wraps to 50..90
    assert_eq!(alpha(&mut e, 70, 40), 255);
    assert_eq!(alpha(&mut e, 170, 40), 0);
    // exactly one undo step
    assert!(e.scene.undo());
    assert_eq!(alpha(&mut e, 170, 40), 255);
    assert_eq!(alpha(&mut e, 70, 40), 0);
}

// ------------------------------------------------------------------------------------------ patterns

#[test]
fn object_to_pattern_then_fill_repeats_it() {
    let mut e = eng(300, 300);
    rect_obj(&mut e, 10.0, 10.0, 30.0, 30.0); // 20x20 red square
    assert_eq!(e.scene.select_at(15, 15), 0);
    let slot = e.scene.float_to_pattern(10, false);
    assert_eq!(slot, 0);
    e.scene.delete_float();
    assert!(e.scene.add_layer());
    // flood-fill the empty layer with pattern 100 + slot: 20px square every 30px
    assert_eq!(e.fill(150, 150, 100 + slot, 0xFF000000, 0xFF000000, 1.0, 0), 0);
    // tile = 30x30, object centred with a 5px margin: red at tile-local 5..25
    let red = |e: &mut Engine, x, y| alpha(e, x, y) == 255;
    assert!(red(&mut e, 5 + 30 * 3 + 2, 5 + 30 * 4 + 2));
    assert!(!red(&mut e, 30 * 3 + 2, 30 * 4 + 2), "spacing between repeats is transparent");
    assert!(red(&mut e, 5 + 30 * 8 + 10, 5 + 30 * 2 + 10));
    // seamless: the tile joins itself across the canvas
    assert!(red(&mut e, 5 + 5, 5 + 5));
    // brick mode shifts every second row by half a tile
    let mut e = eng(300, 300);
    rect_obj(&mut e, 10.0, 10.0, 30.0, 30.0);
    assert_eq!(e.scene.select_at(15, 15), 0);
    let slot = e.scene.float_to_pattern(10, true);
    e.scene.delete_float();
    assert!(e.scene.add_layer());
    assert_eq!(e.fill(150, 150, 100 + slot, 0, 0, 1.0, 0), 0);
    assert!(alpha(&mut e, 5 + 2, 5 + 2) == 255); // row 0 not shifted
    assert!(alpha(&mut e, 5 + 15 + 2, 5 + 30 + 2) == 255, "row 1 shifted by half a tile");
    assert!(alpha(&mut e, 15, 5 + 30 + 2) == 0, "unshifted tiles would be red here, shifted ones have the gap");
}

#[test]
fn pattern_without_selection_reports_error() {
    let mut e = eng(100, 100);
    assert_eq!(e.scene.float_to_pattern(0, false), -1);
}

#[test]
fn pattern_fills_shapes() {
    let mut e = eng(300, 300);
    rect_obj(&mut e, 10.0, 10.0, 30.0, 30.0);
    assert_eq!(e.scene.select_at(15, 15), 0);
    let slot = e.scene.float_to_pattern(10, false);
    e.scene.delete_float();
    assert!(e.scene.add_layer());
    let c = argb_to_px(0xFF000000u32 as i32);
    let p = ShapeParams { kind: RECT, x0: 60.0, y0: 60.0, x1: 240.0, y1: 240.0, outline: false, stroke: 2.0, corner: 0.0, sides: 4 };
    e.shape_update(&p, c, 1.0, Blend::Normal, 100 + slot, c, 1.0);
    e.shape_end();
    assert_eq!(alpha(&mut e, 50, 50), 0);
    let inside: Vec<u32> = (60..90).map(|x| alpha(&mut e, x, 100)).collect();
    assert!(inside.iter().any(|&a| a == 255) && inside.iter().any(|&a| a == 0), "{inside:?}");
}

// ------------------------------------------------------------------------------------------ fx

#[test]
fn fx_invert_blur_and_layer_fallback() {
    let mut e = eng(200, 200);
    rect_obj(&mut e, 80.0, 80.0, 120.0, 120.0);
    // no selection: applies to the layer content
    assert_eq!(e.scene.apply_fx(crate::fx::INVERT, 0.0, 0.0), 0);
    let p = px(&mut e, 100, 100);
    assert_eq!((p & 255, (p >> 8) & 255, (p >> 16) & 255), (0, 255, 255), "red inverted to cyan");
    assert!(e.scene.undo());
    let p = px(&mut e, 100, 100);
    assert_eq!(p & 255, 255);
    // blur on a selected object grows it
    assert_eq!(e.scene.select_at(100, 100), 0);
    assert_eq!(e.scene.apply_fx(crate::fx::BLUR, 4.0, 0.0), 0);
    e.scene.commit_float();
    let b = bbox(&mut e).unwrap();
    assert!(b.0 < 80 && b.2 > 120, "blur halo expands the object: {b:?}");
    assert!(alpha(&mut e, 100, 100) > 200 && alpha(&mut e, 80, 100) < 200);
    // empty layer
    let mut e2 = eng(100, 100);
    assert_eq!(e2.scene.apply_fx(crate::fx::BLUR, 3.0, 0.0), 1);
}

// ------------------------------------------------------------------------------------------ io

#[test]
fn project_roundtrip_keeps_layers() {
    let mut e = eng(300, 200);
    black_pen(&mut e, 8.0);
    line(&mut e, 10.0, 10.0, 200.0, 100.0);
    assert!(e.scene.add_layer());
    rect_obj(&mut e, 100.0, 100.0, 150.0, 150.0);
    e.scene.set_opacity(1, 0.5);
    let mut buf: Vec<u8> = Vec::new();
    e.scene.write_project(&mut buf, 0xFFAABBCC).unwrap();
    let dir = std::env::temp_dir().join(format!("ldtest_load_{}", std::process::id()));
    let (mut s2, bg) = Scene::read_project(&mut std::io::Cursor::new(buf), dir, 128).unwrap();
    assert_eq!(bg, 0xFFAABBCC);
    assert_eq!(s2.layers.len(), 2);
    assert!((s2.layers[1].opacity - 0.5).abs() < 1e-6);
    assert_eq!(s2.composite_pixel(125, 125) >> 24, 128);
    assert!(s2.composite_pixel(100, 55) >> 24 != 0);
}

#[test]
fn jpeg_export_is_valid_and_near_lossless() {
    let mut e = eng(203, 117); // odd size on purpose (padding path)
    e.brush.color = argb_to_px(0xFFC03020u32 as i32);
    let p = ShapeParams { kind: ELLIPSE, x0: 20.0, y0: 15.0, x1: 150.0, y1: 100.0, outline: false, stroke: 2.0, corner: 0.0, sides: 5 };
    e.shape_update(&p, e.brush.color, 1.0, Blend::Normal, 0, e.brush.color, 1.0);
    e.shape_end();
    let out = e.export_jpeg(Vec::new(), 0xFFFFFFFF, 100).unwrap();
    let path = std::env::temp_dir().join("ld_export_q100.jpg");
    std::fs::write(&path, &out).unwrap();
    assert!(out.starts_with(&[0xFF, 0xD8]) && out.ends_with(&[0xFF, 0xD9]));
    // raw RGB of the canvas for comparison from Python
    let mut raw = Vec::new();
    e.render_rows(203, 117, 0xFFFFFFFF, |_, row| {
        for &p in row {
            raw.extend_from_slice(&[(p & 255) as u8, ((p >> 8) & 255) as u8, ((p >> 16) & 255) as u8]);
        }
    });
    std::fs::write(std::env::temp_dir().join("ld_export_q100.rgb"), &raw).unwrap();
    // lower quality is smaller
    let small = e.export_jpeg(Vec::new(), 0xFFFFFFFF, 50).unwrap();
    assert!(small.len() < out.len());
    std::fs::write(std::env::temp_dir().join("ld_export_q50.jpg"), &small).unwrap();
}

fn thickness(e: &mut Engine, x: i32, y0: i32, y1: i32) -> f32 {
    (y0..y1).map(|y| alpha(e, x, y) as f32 / 255.0).sum()
}

fn dense_line(e: &mut Engine, x0: f32, x1: f32, y: f32) {
    e.stroke_begin(x0, y, 1.0, 0);
    let n = 200;
    for i in 1..=n {
        e.stroke_move(x0 + (x1 - x0) * i as f32 / n as f32, y, 1.0, i as i64 * 4);
    }
    e.stroke_end();
}

#[test]
fn pen_start_and_end_taper() {
    let mut e = eng(600, 200);
    black_pen(&mut e, 12.0);
    // taper length = 0.3 * 16 * 12 = 57.6 px, tips at 10 %
    e.brush.apply_pen(&[1.0, 0.05, 0.0, 0.0, 1.0, 0.0, 0.3, 0.1, 0.3, 0.1]);
    dense_line(&mut e, 60.0, 500.0, 100.0);
    let start = thickness(&mut e, 64, 80, 120);
    let mid = thickness(&mut e, 280, 80, 120);
    let end = thickness(&mut e, 496, 80, 120);
    assert!((mid - 12.0).abs() < 0.6, "mid {mid}");
    assert!(start < 3.5, "start should be thin, got {start}");
    assert!(end < 3.5, "end should be thin, got {end}");
    assert!(start > 0.5 && end > 0.5, "taper must not vanish: {start} {end}");
}

#[test]
fn pen_bulb_ends_are_thicker() {
    let mut e = eng(600, 200);
    black_pen(&mut e, 10.0);
    e.brush.apply_pen(&[1.0, 0.05, 0.0, 0.0, 1.0, 0.0, 0.1, 1.6, 0.1, 1.6]);
    dense_line(&mut e, 60.0, 500.0, 100.0);
    let start = thickness(&mut e, 62, 70, 130);
    let mid = thickness(&mut e, 280, 70, 130);
    let end = thickness(&mut e, 498, 70, 130);
    assert!((mid - 10.0).abs() < 0.6, "mid {mid}");
    assert!(start > 14.0 && end > 14.0, "bulb ends expected, got {start} / {end}");
}

#[test]
fn short_stroke_with_tapers_still_draws() {
    let mut e = eng(300, 200);
    black_pen(&mut e, 12.0);
    e.brush.apply_pen(&[1.0, 0.05, 0.0, 0.0, 1.0, 0.0, 0.5, 0.0, 0.5, 0.0]);
    dense_line(&mut e, 100.0, 130.0, 100.0);
    assert!(thickness(&mut e, 115, 80, 120) > 3.0, "spindle shape expected");
}

#[test]
fn fill_leaves_no_halo_under_antialiased_outline() {
    let mut e = eng(300, 300);
    e.brush.set_preset(0); // soft-ish pencil: wide anti-aliased rim
    e.brush.size = 10.0;
    e.brush.opacity = 1.0;
    e.brush.color = argb_to_px(0xFFC03060u32 as i32);
    e.brush.blend = Blend::Normal;
    let (cx, cy, r) = (150.0f32, 150.0f32, 80.0f32);
    for i in 0..=120 {
        let a = i as f32 / 120.0 * std::f32::consts::TAU;
        let (x, y) = (cx + r * a.cos(), cy + r * a.sin());
        if i == 0 {
            e.stroke_begin(x, y, 1.0, 0);
        } else {
            e.stroke_move(x, y, 1.0, i as i64 * 4);
        }
    }
    e.stroke_end();
    let c = argb_to_px(0xFFA066FFu32 as i32);
    assert_eq!(e.fill(150, 150, 0, c, c, 1.0, 24), 0);
    // walk from the centre to the outline: alpha must stay fully opaque (no light ring)
    let mut min_a = 255;
    for x in 150..=(150 + r as i32) {
        min_a = min_a.min(alpha(&mut e, x, 150));
    }
    assert!(min_a >= 250, "halo between fill and outline: min alpha {min_a}");
    // outside of the outline stays empty
    assert_eq!(alpha(&mut e, 150 + r as i32 + 12, 150), 0);
}
