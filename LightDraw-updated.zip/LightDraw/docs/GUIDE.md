# LightDraw — panduan perubahan (layer, objek, align, pola, anti-alias, JPEG 100%)

## 1. Peta kode

| Lapisan | File | Peran |
|---|---|---|
| UI | `ui/FloatingToolbar.kt` | state (`DrawState`), toolbar, popup (Brush, Shape, Pattern→Color, FX, Transform, Mirror), `SelectionBar` |
| UI | `CanvasScreen.kt` | menghubungkan UI ↔ engine (`ObjectActions`), dialog Layers/Export, overlay seleksi |
| View | `CanvasGLView.kt` | gestur: gambar, bentuk (drag), seleksi (tap/marquee), geser/skala objek |
| JNI | `NativeEngine.kt` ↔ `engine_core.rs` | 62 fungsi `external` (nama dan tipe sudah dicocokkan) |
| Engine | `scene.rs` | layer, objek mengambang, wrap seamless, riwayat undo |
| Engine | `brush_engine.rs`, `shapes.rs` | dab/bentuk anti-alias via `StrokeBuf` |
| Engine | `float_obj.rs`, `object_select.rs` | objek mengambang (angkat → transform → commit) |
| Engine | `pattern_fill.rs` | pola bawaan + `TilePattern` (pola buatan pengguna) |
| Engine | `fx.rs`, `jpeg_enc.rs` | efek, encoder JPEG streaming |

## 2. Kenapa FX dan Transform mati, dan perbaikannya
Source awal setengah termigrasi. Engine baru sudah ada, tetapi JNI dan UI masih versi satu layer. FX tidak punya JNI maupun UI. Tombol "Transform" di bottom nav membuka panel Mirror. Sekarang:
- `nativeApplyFx(kind, a, b)` berlaku pada objek terpilih, atau pada seluruh layer aktif jika tidak ada objek.
- Transform memakai model **objek mengambang**: angkat dari layer → geser/skala/rotasi/flip/rotate90 → `nativeCommit` (satu langkah undo).

## 3. UI
- **Shape** dan **Pattern** terpisah. Shape memilih garis/persegi/rounded/elips/segitiga/poligon/bintang, outline atau isi, tebal, sudut dan jumlah sisi.
- Pola dipilih di menu **Color → tab Pattern** (bawaan + pola buatanmu, ID 100+). Pola dipakai oleh Fill dan oleh Shape terisi.
- **Transform** berisi Select All, Duplikat, Align (6 + Center ke Canvas), skala/rotasi, flip, putar 90°, *Jadikan Pola*, Seamless, dan *Offset ½*.
- **Layers**: tambah, duplikat, hapus, naik/turun, kosongkan, visibilitas, opacity, Paper.

## 4. Algoritma

### 4.1 Anti-aliasing (`StrokeBuf`)
Dab dan bentuk tidak langsung menulis warna. Keduanya menulis **coverage u8** ke `StrokeBuf` memakai rampa jarak bertanda `cov = clamp(0.5 − sd, 0, 1)` (kira-kira 1 px lebar tepi). Tumpang tindih memakai `max` (airbrush: akumulasi). Pada akhir goresan `apply_to` mem-bake sekali: warna × coverage × opacity (+ pola, blend). Hasilnya:
- tepi halus untuk brush, pen dan semua bentuk;
- opacity tepat meski goresan menimpa dirinya sendiri (tidak ada tumpukan alpha).
Batasan: tepi hasil flood-fill tidak di-anti-alias.

### 4.2 Alignment
`nativeAlign(mode)`: ambil AABB objek setelah transform lalu geser:
```
0 kiri:     dx = -minX            3 atas:     dy = -minY
1 tengah H: dx = W/2 - (minX+maxX)/2   4 tengah V: dy = H/2 - (minY+maxY)/2
2 kanan:    dx = W - maxX         5 bawah:    dy = H - maxY
6 tengah canvas: dx dan dy sekaligus
```
Tanpa seleksi, engine memilih seluruh isi layer, menyejajarkan, lalu commit otomatis.

### 4.3 Seamless repeat (wrap)
Saat `Seamless` aktif (`nativeSetWrap`):
- Goresan: koordinat memakai `rem_euclid`, dan dab yang menyentuh tepi distempel juga pada ±W / ±H. Dab yang keluar di kanan muncul di kiri, dan di sudut muncul di sudut yang berlawanan.
- Bentuk: digambar bersama salinan geser (3×3).
- Objek: pusatnya di-wrap `rem_euclid` saat digeser dan digambar 3×3. Objek yang diseret ke tepi atau sudut muncul di sisi seberang.
- **Offset ½** (`nativeOffsetWrap(W/2, H/2)`) menggeser seluruh layer secara melingkar, sehingga sambungan tepi pindah ke tengah dan bisa diperbaiki. Ini cara klasik membuat tile mulus.

### 4.4 Objek → Pola
`nativeObjectToPattern(spacing, brick)` memotong objek ke bounding box + `spacing`, menjadikannya `TilePattern`. Sampling memakai koordinat global `x % w, y % h`, sehingga tile selalu bersambung. Mode *brick* menggeser baris ganjil sebesar `w/2`. Maksimum 8 pola. Pola dipakai sebagai kind `100 + slot`.

### 4.5 Duplikat
- Objek: aslinya tetap, salinan diberi offset kecil dan mengambang untuk diseret.
- Layer: menyalin semua tile, visibilitas, opacity (maks 8 layer).

### 4.6 Export JPEG 100%
`jpeg_enc.rs` meng-encode streaming (per baris MCU), jadi tidak butuh RAM sebesar kanvas. Kualitas 100 berarti tabel kuantisasi bernilai 1, 4:4:4 tanpa chroma subsampling, ukuran penuh artboard (tidak pernah diperkecil). Hasilnya **hampir lossless** (selisih maksimum ≈ 3 pada uji PIL), tetapi JPEG tetap lossy. Gunakan PNG bila butuh identik per piksel. JPEG tidak punya alpha, jadi warna Paper dipakai sebagai latar.

## 5. Verifikasi
- `cd rust-engine && cargo test` (23 tes): AA, opacity, align 7 mode, duplikat, wrap tepi/sudut, offset, pola (+brick), FX, round trip project, JPEG q100.
- Kotlin **belum dikompilasi** di lingkungan pengembangan ini (tanpa Android SDK/Compose). Hanya sintaks yang dicek. Jalankan CI GitHub Actions dan laporkan error kompilasi bila ada.
- Crate `jni` asli juga belum di-build di sini (hanya cek tipe terhadap stub).
