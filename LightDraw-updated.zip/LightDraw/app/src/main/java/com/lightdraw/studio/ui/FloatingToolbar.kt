package com.lightdraw.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lightdraw.studio.NativeEngine
import kotlin.math.roundToInt
import kotlin.math.sqrt

object Tool {
    const val DRAW = 0
    const val ERASER = 1
    const val FILL = 2
    const val SELECT_COLOR = 3
    const val EYEDROPPER = 4
    const val HAND = 5
    const val SHAPE = 6
    const val SELECT = 7
}

/** Popup panels that drop down under the top toolbar. BRUSH..FX double as the bottom-nav groups. */
object Panel {
    const val NONE = -1
    const val TOOLS = 0
    const val BRUSH = 1
    const val SHAPES = 2
    const val TRANSFORM = 3
    const val FX = 4
    const val PATHFINDER = 5
    const val COLOR = 6
}

private val AccentAmber = Color(0xFFF5A623)
private val AccentGreen = Color(0xFF22C55E)
private val ButtonBg = Color(0xFF26262E)
private val IconIdle = Color(0xFFC8CDD6)

/** All UI-visible drawing state. Pushed to the native engine by CanvasScreen. */
@Stable
class DrawState {
    var tool by mutableIntStateOf(Tool.DRAW)
    private var prevTool = Tool.DRAW
    var color by mutableIntStateOf(0xFFA066FF.toInt())

    var brushPreset by mutableIntStateOf(0)
    var size by mutableFloatStateOf(18f)
    var opacity by mutableFloatStateOf(100f)      // %
    var stabilizer by mutableFloatStateOf(65f)    // %
    var blend by mutableIntStateOf(0)             // 0 normal 1 multiply 2 screen 3 overlay 4 add

    var pattern by mutableIntStateOf(0)           // 0 = solid colour
    var patternScale by mutableFloatStateOf(1f)
    var fillTolerance by mutableFloatStateOf(24f)

    var symMode by mutableIntStateOf(0)           // 0 off 1 horizontal 2 vertical 3 radial
    var sectors by mutableIntStateOf(6)
    var symMirror by mutableStateOf(false)

    var tolH by mutableFloatStateOf(15f)          // degrees
    var tolS by mutableFloatStateOf(20f)          // %
    var tolL by mutableFloatStateOf(20f)          // %

    var paperColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var paperVisible by mutableStateOf(true)

    /** Popup currently open (Panel.*), and the last bottom-nav group that was chosen. */
    var panel by mutableIntStateOf(Panel.NONE)
    var group by mutableIntStateOf(Panel.BRUSH)

    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    // ---- shapes (kind: 0 line, 1 rect, 2 rounded rect, 3 ellipse, 4 triangle, 5 polygon, 6 star)
    var shapeKind by mutableIntStateOf(1)
    var shapeOutline by mutableStateOf(false)
    var shapeStroke by mutableFloatStateOf(8f)
    var shapeCorner by mutableFloatStateOf(0.3f)
    var shapeSides by mutableIntStateOf(5)
    var shapeErase by mutableStateOf(false)

    // ---- colour menu: 0 = Color, 1 = Pattern
    var colorTab by mutableIntStateOf(0)
    var customPatterns by mutableIntStateOf(0)    // user patterns made from objects (fill kind 100 + index)
    var patternRev by mutableIntStateOf(0)        // bumps when a pattern is (re)created so thumbnails refresh
    var patSpacing by mutableFloatStateOf(12f)
    var patBrick by mutableStateOf(false)

    /** Seamless repeat: strokes, shapes and dragged objects wrap around the canvas edges. */
    var seamless by mutableStateOf(false)

    // ---- transform menu: 0 Object, 1 Align, 2 Mirror
    var transformTab by mutableIntStateOf(0)
    var hasObject by mutableStateOf(false)
    var objScale by mutableFloatStateOf(1f)
    var objRot by mutableFloatStateOf(0f)
    var fxKind by mutableIntStateOf(0)

    fun togglePanel(id: Int) {
        panel = if (panel == id) Panel.NONE else id
    }

    /** Brush / Shapes / Transform / FX groups: highlight the group, toggle its popup and switch to a matching tool. */
    fun selectGroup(id: Int) {
        group = id
        when (id) {
            Panel.BRUSH -> if (tool != Tool.DRAW && tool != Tool.ERASER) tool = Tool.DRAW
            Panel.SHAPES -> tool = Tool.SHAPE
            Panel.TRANSFORM -> tool = Tool.SELECT
        }
        togglePanel(id)
    }

    /** Pick (or un-pick) a fill pattern. Patterns are used by the Fill bucket and by filled shapes. */
    fun selectPattern(id: Int) {
        pattern = if (pattern == id) 0 else id
        if (pattern != 0 && tool != Tool.SHAPE) tool = Tool.FILL
    }

    fun toggleEyedropper() {
        if (tool == Tool.EYEDROPPER) {
            tool = prevTool
        } else {
            if (tool != Tool.HAND) prevTool = tool
            tool = Tool.EYEDROPPER
        }
    }

    fun finishEyedropper() {
        if (tool == Tool.EYEDROPPER) tool = prevTool
    }

    fun toggleHand() {
        if (tool == Tool.HAND) {
            tool = prevTool
        } else {
            if (tool != Tool.EYEDROPPER) prevTool = tool
            tool = Tool.HAND
        }
    }
}

// ------------------------------------------------------------------ top pill toolbar

@Composable
private fun TbIcon(icon: ImageVector, desc: String, active: Boolean, open: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .size(34.dp)
            .clip(shape)
            .background(
                when {
                    active -> Palette.AccentPurple.copy(alpha = 0.18f)
                    open -> Color(0xFF2E2E36)
                    else -> Color.Transparent
                }
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, desc,
            tint = when {
                active -> Palette.AccentPurple
                open -> Color.White
                else -> IconIdle
            },
            modifier = Modifier.size(20.dp),
        )
    }
}

/** "‹ Gallery | tools… | colour dot" pill, like the mock-up. */
@Composable
fun TopToolbar(
    state: DrawState,
    onGallery: () -> Unit,
    onArtboard: () -> Unit,
    onLayers: () -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            val gShape = RoundedCornerShape(12.dp)
            Row(
                Modifier
                    .clip(gShape)
                    .background(Palette.DarkBg.copy(alpha = 0.6f))
                    .border(1.dp, Palette.PanelBorder, gShape)
                    .clickable { onGallery() }
                    .padding(start = 6.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(DrawIcons.ChevronLeft, null, tint = Palette.TextMuted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text("Gallery", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(24.dp).background(Palette.PanelBorder))
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TbIcon(DrawIcons.Wrench, "Tools", false, state.panel == Panel.TOOLS) { state.togglePanel(Panel.TOOLS) }
                TbIcon(DrawIcons.Crop, "Artboard", false, false) { onArtboard() }
                TbIcon(DrawIcons.Brush, "Brush", state.group == Panel.BRUSH, state.panel == Panel.BRUSH) { state.selectGroup(Panel.BRUSH) }
                TbIcon(DrawIcons.Shapes, "Shapes", state.group == Panel.SHAPES, state.panel == Panel.SHAPES) { state.selectGroup(Panel.SHAPES) }
                TbIcon(DrawIcons.Transform, "Transform", state.group == Panel.TRANSFORM, state.panel == Panel.TRANSFORM) { state.selectGroup(Panel.TRANSFORM) }
                TbIcon(DrawIcons.Wand, "FX", state.group == Panel.FX, state.panel == Panel.FX) { state.selectGroup(Panel.FX) }
                TbIcon(DrawIcons.Pathfinder, "Pathfinder", false, state.panel == Panel.PATHFINDER) { state.togglePanel(Panel.PATHFINDER) }
                TbIcon(DrawIcons.Layers, "Layers", false, false) { onLayers() }
                TbIcon(DrawIcons.Import, "Import", false, false) { onImport() }
            }
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(state.color))
                    .border(2.dp, Color.White.copy(alpha = if (state.panel == Panel.COLOR) 0.7f else 0.25f), CircleShape)
                    .clickable { state.togglePanel(Panel.COLOR) },
            )
        }
    }
}

// ------------------------------------------------------------------ left vertical sliders

@Composable
fun VerticalSlider(fraction: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val push by rememberUpdatedState(onChange)
    Box(
        modifier
            .width(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) },
                ) { change, _ ->
                    change.consume()
                    push((1f - change.position.y / size.height).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.width(7.dp).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFF2E2E36))) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(fraction.coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFC4C4CC))
            )
        }
    }
}

@Composable
private fun PanelDivider() {
    Box(Modifier.padding(vertical = 8.dp).width(20.dp).height(1.dp).background(Palette.PanelBorder))
}

@Composable
private fun SmallBtn(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = if (enabled) IconIdle else Palette.TextMuted.copy(alpha = 0.35f), modifier = Modifier.size(20.dp))
    }
}

/** Size + opacity vertical sliders with undo / redo underneath. */
@Composable
fun SideSliderPanel(
    state: DrawState,
    sliderHeight: Dp,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Quadratic mapping: fine control for small brushes, still reaches 200 px.
    val sizeFrac = sqrt(((state.size - 1f) / 199f).coerceIn(0f, 1f))
    val dot = (4f + 10f * sizeFrac).dp
    FloatingPanel(modifier.width(38.dp), shape = RoundedCornerShape(19.dp)) {
        Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(16.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(dot).clip(CircleShape).background(Color(0xFFB4B8C2)))
            }
            Spacer(Modifier.height(6.dp))
            VerticalSlider(sizeFrac, { state.size = 1f + 199f * it * it }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${(sizeFrac * 100f).roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            Icon(DrawIcons.Drop, "Opacity", tint = Color(0xFFB4B8C2), modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(6.dp))
            VerticalSlider(state.opacity / 100f, { state.opacity = (it * 100f).coerceIn(1f, 100f) }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${state.opacity.roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            SmallBtn(DrawIcons.Undo, "Undo", state.canUndo, onUndo)
            SmallBtn(DrawIcons.Redo, "Redo", state.canRedo, onRedo)
        }
    }
}

// ------------------------------------------------------------------ popups

@Composable
private fun Popup(
    title: String,
    tag: String,
    tagColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
                Text(tag, color = tagColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(Modifier.padding(vertical = 10.dp).fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content,
            )
        }
    }
}

@Composable
private fun OpButton(icon: ImageVector, label: String, tint: Color, selected: Boolean, modifier: Modifier, clickMod: Modifier, iconRotation: Float = 0f) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) tint.copy(alpha = 0.14f) else ButtonBg)
            .border(1.dp, if (selected) tint else Palette.PanelBorder, shape)
            .then(clickMod)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp).rotate(iconRotation))
        Text(label, color = if (selected) Color.White else Palette.TextPrimary, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: Color = Palette.AccentPurple, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) accent else Palette.TextMuted,
        fontSize = 11.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) accent else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Palette.TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
}

private class BrushInfo(val icon: ImageVector, val title: String, val sub: String)

private val Brushes = listOf(
    BrushInfo(DrawIcons.Brush, "Graphite Pencil", "Pressure Sensitivity"),
    BrushInfo(DrawIcons.Palette, "Soft Airbrush", "Smooth Gradient"),
    BrushInfo(DrawIcons.Eyedropper, "Studio Ink Pen", "Sharp Line Art"),
    BrushInfo(DrawIcons.Zigzag, "Calligraphy", "Angled Stroke"),
)

private val Blends = listOf("Normal", "Multiply", "Screen", "Overlay", "Add")

private class PatternInfo(val id: Int, val icon: ImageVector, val title: String)

private val Patterns = listOf(
    PatternInfo(1, DrawIcons.Grid, "Gingham"),
    PatternInfo(2, DrawIcons.Diamond, "Argyle"),
    PatternInfo(3, DrawIcons.Waves, "Seigaiha"),
    PatternInfo(4, DrawIcons.Zigzag, "Houndstooth"),
    PatternInfo(5, DrawIcons.Plaid, "Plaid"),
    PatternInfo(6, DrawIcons.Flower, "Floral"),
)

@Composable
private fun BrushPopup(state: DrawState, modifier: Modifier) {
    Popup("Brush Library", "Dynamics Active", Palette.AccentCyan, modifier) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpButton(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.tool != Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.DRAW })
            OpButton(DrawIcons.Eraser, "Eraser", Palette.AccentPink, state.tool == Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.ERASER })
        }
        Brushes.chunked(2).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEachIndexed { c, b ->
                    val id = r * 2 + c
                    val sel = state.brushPreset == id
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.10f) else ButtonBg)
                            .border(1.dp, if (sel) Palette.AccentPurple else Palette.PanelBorder, RoundedCornerShape(12.dp))
                            .clickable { state.brushPreset = id; if (state.tool != Tool.ERASER) state.tool = Tool.DRAW }
                            .padding(10.dp),
                    ) {
                        Icon(b.icon, b.title, tint = if (sel) Palette.AccentPurple else Palette.TextMuted, modifier = Modifier.size(20.dp))
                        Text(b.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(b.sub, color = Palette.TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Blends.forEachIndexed { i, n -> Chip(n, state.blend == i) { state.blend = i } }
        }
        LabeledSlider("Streamline Stabilizer", "${state.stabilizer.toInt()}%", state.stabilizer, 0f..99f, Palette.AccentCyan) { state.stabilizer = it }
        Hint("Ukuran & opacity diatur lewat slider di sisi kiri kanvas.")
    }
}

/** Everything the popups can ask the canvas to do with the selected object / layer. Built in CanvasScreen. */
class ObjectActions(
    val selectAll: () -> Unit,
    val commit: () -> Unit,
    val delete: () -> Unit,
    val duplicate: () -> Unit,
    /** 0 left, 1 centre H, 2 right, 3 top, 4 centre V, 5 bottom, 6 centre on canvas */
    val align: (Int) -> Unit,
    val setTransform: (scale: Float, rotDeg: Float) -> Unit,
    val flip: (horizontal: Boolean) -> Unit,
    val rotate90: (clockwise: Boolean) -> Unit,
    val toPattern: () -> Unit,
    val offsetHalf: () -> Unit,
    /** kind: 0 blur, 1 sharpen, 2 brightness/contrast, 3 hue/sat, 4 invert, 5 grayscale, 6 pixelate */
    val applyFx: (kind: Int, a: Float, b: Float) -> Unit,
)

@Composable
private fun ActionButton(text: String, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
        modifier = modifier
            .clip(shape)
            .background(accent.copy(alpha = 0.28f))
            .border(1.dp, accent, shape)
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 12.dp),
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Palette.TextPrimary, fontSize = 12.sp)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple),
        )
    }
}

private fun patternName(id: Int): String = when (id) {
    0 -> "Solid"
    1 -> "Gingham"
    2 -> "Argyle"
    3 -> "Seigaiha"
    4 -> "Houndstooth"
    5 -> "Plaid"
    6 -> "Floral"
    else -> "Pola saya ${id - 99}"
}

// ------------------------------------------------------------------ Shapes

private class ShapeInfo(val kind: Int, val icon: ImageVector, val title: String)

private val ShapeList = listOf(
    ShapeInfo(0, DrawIcons.ShapeLine, "Line"),
    ShapeInfo(1, DrawIcons.ShapeRect, "Rect"),
    ShapeInfo(2, DrawIcons.ShapeRound, "Rounded"),
    ShapeInfo(3, DrawIcons.ShapeEllipse, "Ellipse"),
    ShapeInfo(4, DrawIcons.ShapeTriangle, "Triangle"),
    ShapeInfo(5, DrawIcons.ShapePolygon, "Polygon"),
    ShapeInfo(6, DrawIcons.ShapeStar, "Star"),
)

@Composable
private fun ShapesPopup(state: DrawState, modifier: Modifier) {
    Popup("Shapes", "Anti-aliased", Palette.AccentCyan, modifier) {
        ShapeList.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { sh ->
                    OpButton(
                        sh.icon, sh.title, Palette.AccentCyan, state.tool == Tool.SHAPE && state.shapeKind == sh.kind, Modifier.weight(1f),
                        Modifier.clickable { state.shapeKind = sh.kind; state.tool = Tool.SHAPE },
                    )
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        val isLine = state.shapeKind == 0
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Chip("Isi", !state.shapeOutline && !isLine) { state.shapeOutline = false }
            Chip("Garis tepi", state.shapeOutline || isLine) { state.shapeOutline = true }
            Chip("Minus (hapus)", state.shapeErase, Palette.AccentPink) { state.shapeErase = !state.shapeErase }
        }
        if (state.shapeOutline || isLine) {
            LabeledSlider("Tebal garis", "${state.shapeStroke.toInt()} px", state.shapeStroke, 1f..80f, Palette.AccentCyan) { state.shapeStroke = it }
        }
        if (state.shapeKind == 2) {
            LabeledSlider("Sudut membulat", "${(state.shapeCorner * 100).toInt()}%", state.shapeCorner, 0f..1f, Palette.AccentCyan) { state.shapeCorner = it }
        }
        if (state.shapeKind == 5 || state.shapeKind == 6) {
            LabeledSlider("Jumlah sisi / ujung", "${state.shapeSides}", state.shapeSides.toFloat(), 3f..12f, Palette.AccentCyan) { state.shapeSides = it.toInt().coerceIn(3, 12) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(Color(state.color)).border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape))
            Text("Isi: ${patternName(state.pattern)}", color = Palette.TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Chip("Ubah di Color ▸ Pattern", false) { state.colorTab = 1; state.panel = Panel.COLOR }
        }
        SwitchRow("Seamless Repeat (bungkus tepi)", state.seamless) { state.seamless = it }
        Hint("Seret di kanvas untuk menggambar. Setiap bentuk dirender dengan anti-aliasing (jarak bertanda per piksel), jadi tepinya halus di semua ukuran & sudut. Warna dan pola dipilih di menu Color.")
    }
}

// ------------------------------------------------------------------ Transform (object / align / mirror)

private class AlignInfo(val mode: Int, val icon: ImageVector, val title: String)

private val AlignList = listOf(
    AlignInfo(0, DrawIcons.AlignLeft, "Kiri"),
    AlignInfo(1, DrawIcons.AlignCenterH, "Tengah H"),
    AlignInfo(2, DrawIcons.AlignRight, "Kanan"),
    AlignInfo(3, DrawIcons.AlignTop, "Atas"),
    AlignInfo(4, DrawIcons.AlignCenterV, "Tengah V"),
    AlignInfo(5, DrawIcons.AlignBottom, "Bawah"),
)

@Composable
private fun ObjectTab(state: DrawState, actions: ObjectActions) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OpButton(DrawIcons.Select, "Pilih", Palette.AccentCyan, state.tool == Tool.SELECT, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.SELECT })
        OpButton(DrawIcons.Layers, "Semua", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.selectAll() })
        OpButton(DrawIcons.Copy, "Duplikat", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.duplicate() })
        OpButton(DrawIcons.Trash, "Hapus", Palette.AccentPink, false, Modifier.weight(1f), Modifier.clickable { actions.delete() })
    }
    Text(
        if (state.hasObject) "Objek terpilih" else "Belum ada objek: ketuk gambar di kanvas, atau tarik kotak di area kosong.",
        color = if (state.hasObject) Palette.AccentCyan else Palette.TextMuted, fontSize = 11.sp,
    )
    Column(Modifier.alpha(if (state.hasObject) 1f else 0.45f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LabeledSlider("Skala", "${(state.objScale * 100).roundToInt()}%", state.objScale, 0.1f..4f, AccentAmber) {
            state.objScale = it
            actions.setTransform(state.objScale, state.objRot)
        }
        LabeledSlider("Rotasi", "${state.objRot.roundToInt()}°", state.objRot, -180f..180f, AccentAmber) {
            state.objRot = it
            actions.setTransform(state.objScale, state.objRot)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.FlipH, "Flip H", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.flip(true) })
            OpButton(DrawIcons.FlipV, "Flip V", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.flip(false) })
            OpButton(DrawIcons.RotateCcw, "-90°", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.rotate90(false) })
            OpButton(DrawIcons.RotateCw, "+90°", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.rotate90(true) })
        }
    }
    ActionButton("Selesai (terapkan ke layer)", AccentGreen, Modifier.fillMaxWidth()) { actions.commit() }
    SwitchRow("Seamless Repeat", state.seamless) { state.seamless = it }
    Hint("Seamless Repeat aktif: seret objek ke tepi atau sudut kanvas, bagian yang keluar otomatis muncul di sisi seberang (offset tile).")
}

@Composable
private fun AlignTab(state: DrawState, actions: ObjectActions) {
    AlignList.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { a ->
                OpButton(a.icon, a.title, Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.align(a.mode) })
            }
        }
    }
    OpButton(
        DrawIcons.CenterCanvas, "Snap / Pusatkan ke kanvas", Palette.AccentCyan, false, Modifier.fillMaxWidth(),
        Modifier.clickable { actions.align(6) },
    )
    Hint(
        if (state.hasObject) "Menyejajarkan objek terpilih terhadap tepi / tengah kanvas."
        else "Tanpa seleksi: seluruh isi layer aktif disejajarkan sebagai satu kelompok."
    )
}

@Composable
private fun MirrorTab(state: DrawState) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OpButton(DrawIcons.Close, "Off", Palette.TextMuted, state.symMode == 0, Modifier.weight(1f), Modifier.clickable { state.symMode = 0 })
        OpButton(DrawIcons.Symmetry, "Horizontal", Palette.AccentPurple, state.symMode == 1, Modifier.weight(1f), Modifier.clickable { state.symMode = 1 })
        OpButton(DrawIcons.Symmetry, "Vertical", Palette.AccentPurple, state.symMode == 2, Modifier.weight(1f), Modifier.clickable { state.symMode = 2 }, iconRotation = 90f)
        OpButton(DrawIcons.Flower, "Radial", Palette.AccentPurple, state.symMode == 3, Modifier.weight(1f), Modifier.clickable { state.symMode = 3 })
    }
    if (state.symMode == 3) {
        LabeledSlider("Jumlah Sektor", "${state.sectors}", state.sectors.toFloat(), 2f..12f) { state.sectors = it.toInt().coerceIn(2, 12) }
        SwitchRow("Mirror tiap sektor", state.symMirror) { state.symMirror = it }
    }
    Hint("Simetri berlaku untuk kuas. Pusat simetri = tengah artboard. Pilih Brush untuk mulai menggambar.")
}

@Composable
private fun TransformPopup(state: DrawState, actions: ObjectActions, modifier: Modifier) {
    Popup("Transform", "Object · Align · Mirror", AccentAmber, modifier) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Objek", state.transformTab == 0, AccentAmber) { state.transformTab = 0 }
            Chip("Align", state.transformTab == 1, AccentAmber) { state.transformTab = 1 }
            Chip("Mirror", state.transformTab == 2, AccentAmber) { state.transformTab = 2 }
        }
        when (state.transformTab) {
            0 -> ObjectTab(state, actions)
            1 -> AlignTab(state, actions)
            else -> MirrorTab(state)
        }
    }
}

// ------------------------------------------------------------------ Crop & FX

private val FxNames = listOf("Blur", "Sharpen", "Bright/Contrast", "Hue/Sat", "Invert", "Grayscale", "Pixelate")

@Composable
private fun FxPopup(state: DrawState, actions: ObjectActions, onArtboard: () -> Unit, modifier: Modifier) {
    var blur by remember { mutableFloatStateOf(4f) }
    var sharpen by remember { mutableFloatStateOf(1f) }
    var bright by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var hue by remember { mutableFloatStateOf(0f) }
    var sat by remember { mutableFloatStateOf(0f) }
    var block by remember { mutableFloatStateOf(8f) }

    Popup("Crop & FX", "Color Magic", Palette.AccentPink, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Fill, "Fill", Palette.AccentCyan, state.tool == Tool.FILL, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.FILL })
            OpButton(DrawIcons.Wand, "Same Color", Palette.AccentPink, state.tool == Tool.SELECT_COLOR, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.SELECT_COLOR })
            OpButton(DrawIcons.Eyedropper, "Eyedropper", Palette.AccentPurple, state.tool == Tool.EYEDROPPER, Modifier.weight(1f), Modifier.clickable { state.toggleEyedropper() })
            OpButton(DrawIcons.Crop, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
        if (state.tool == Tool.SELECT_COLOR) {
            Hint("Ketuk warna di kanvas: semua piksel yang cocok (seluruh layer) diganti ke warna aktif.")
            LabeledSlider("Toleransi Hue", "${state.tolH.toInt()}°", state.tolH, 0f..180f) { state.tolH = it }
            LabeledSlider("Toleransi Saturation", "${state.tolS.toInt()}%", state.tolS, 0f..100f) { state.tolS = it }
            LabeledSlider("Toleransi Luminance", "${state.tolL.toInt()}%", state.tolL, 0f..100f) { state.tolL = it }
        } else if (state.tool == Tool.FILL) {
            LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("EFEK PIKSEL", color = Palette.AccentPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(if (state.hasObject) "→ objek terpilih" else "→ layer aktif", color = Palette.TextMuted, fontSize = 11.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            FxNames.forEachIndexed { i, n -> Chip(n, state.fxKind == i, Palette.AccentPink) { state.fxKind = i } }
        }
        when (state.fxKind) {
            0 -> LabeledSlider("Radius", "${blur.toInt()} px", blur, 1f..48f, Palette.AccentPink) { blur = it }
            1 -> LabeledSlider("Jumlah", "%.1f".format(sharpen), sharpen, 0.1f..3f, Palette.AccentPink) { sharpen = it }
            2 -> {
                LabeledSlider("Brightness", "${bright.toInt()}", bright, -100f..100f, Palette.AccentPink) { bright = it }
                LabeledSlider("Contrast", "${contrast.toInt()}", contrast, -100f..100f, Palette.AccentPink) { contrast = it }
            }
            3 -> {
                LabeledSlider("Hue", "${hue.toInt()}°", hue, -180f..180f, Palette.AccentPink) { hue = it }
                LabeledSlider("Saturation", "${sat.toInt()}", sat, -100f..100f, Palette.AccentPink) { sat = it }
            }
            6 -> LabeledSlider("Ukuran blok", "${block.toInt()} px", block, 2f..64f, Palette.AccentPink) { block = it }
            else -> Hint("Efek ini tidak punya parameter.")
        }
        ActionButton("Terapkan ${FxNames[state.fxKind]}", Palette.AccentPink, Modifier.fillMaxWidth()) {
            when (state.fxKind) {
                0 -> actions.applyFx(0, blur, 0f)
                1 -> actions.applyFx(1, sharpen, 0f)
                2 -> actions.applyFx(2, bright, contrast)
                3 -> actions.applyFx(3, hue, sat)
                4 -> actions.applyFx(4, 0f, 0f)
                5 -> actions.applyFx(5, 0f, 0f)
                else -> actions.applyFx(6, block, 0f)
            }
        }
        Hint("Efek bisa di-undo. Tanpa seleksi, efek memproses seluruh isi layer aktif.")
    }
}


@Composable
private fun PathfinderPopup(state: DrawState, modifier: Modifier) {
    fun mode(tool: Int, blend: Int) { state.tool = tool; if (tool != Tool.ERASER) state.blend = blend }
    val drawing = state.tool != Tool.ERASER
    Popup("Shape Pathfinder", "Boolean Ops", Palette.AccentCyan, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Unite, "Unite", Palette.AccentPurple, drawing && state.blend == 0, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 0) })
            OpButton(DrawIcons.Minus, "Minus", Palette.AccentPink, state.tool == Tool.ERASER, Modifier.weight(1f), Modifier.clickable { mode(Tool.ERASER, 0) })
            OpButton(DrawIcons.Intersect, "Intersect", Palette.AccentCyan, drawing && state.blend == 1, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 1) })
            OpButton(DrawIcons.Exclude, "Exclude", AccentAmber, drawing && state.blend == 3, Modifier.weight(1f), Modifier.clickable { mode(Tool.DRAW, 3) })
        }
        Hint("Mode gabung goresan: Unite = Normal, Minus = Hapus, Intersect = Multiply, Exclude = Overlay.")
    }
}

@Composable
private fun ToolsPopup(onImport: () -> Unit, onExport: () -> Unit, onLayers: () -> Unit, onArtboard: () -> Unit, modifier: Modifier) {
    Popup("Studio Tools", "Project", Palette.AccentCyan, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Import, "Import", Palette.AccentCyan, false, Modifier.weight(1f), Modifier.clickable { onImport() })
            OpButton(DrawIcons.Export, "Export", Palette.AccentPink, false, Modifier.weight(1f), Modifier.clickable { onExport() })
            OpButton(DrawIcons.Layers, "Layers", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { onLayers() })
            OpButton(DrawIcons.Settings, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
    }
}

// ------------------------------------------------------------------ Color menu (Color + Pattern tabs)

@Composable
private fun PatternThumb(index: Int, rev: Int, selected: Boolean, dd: DragDropState, color: Int, onTap: () -> Unit) {
    val bmp = remember(index, rev) {
        val size = 64
        val px = IntArray(size * size)
        if (NativeEngine.nativePatternThumb(index, size, px)) {
            android.graphics.Bitmap.createBitmap(px, size, size, android.graphics.Bitmap.Config.ARGB_8888).asImageBitmap()
        } else {
            null
        }
    }
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .size(56.dp)
            .clip(shape)
            .background(Color(0xFF3A3A44))
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.AccentCyan else Palette.PanelBorder, shape)
            .dragSource(dd, DragPayload(100 + index, color), onTap),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) Image(bitmap = bmp, contentDescription = "Pola ${index + 1}", modifier = Modifier.size(52.dp))
    }
}

@Composable
private fun PatternTab(state: DrawState, dd: DragDropState, actions: ObjectActions) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("PATTERN MOTIF", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Chip("Solid", state.pattern == 0) { state.pattern = 0 }
        }
        Patterns.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { p ->
                    OpButton(
                        p.icon, p.title, Palette.AccentCyan, state.pattern == p.id, Modifier.weight(1f),
                        Modifier.dragSource(dd, DragPayload(p.id, state.color)) { state.selectPattern(p.id) },
                    )
                }
            }
        }
        if (state.customPatterns > 0) {
            Text("POLA SAYA (dari objek)", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                for (i in 0 until state.customPatterns) {
                    PatternThumb(i, state.patternRev, state.pattern == 100 + i, dd, state.color) { state.selectPattern(100 + i) }
                }
            }
        }
        Hint("Ketuk motif lalu ketuk kanvas (Fill), atau geser motif langsung ke kanvas. Motif juga dipakai bentuk (menu Shapes).")
        LabeledSlider("Skala Tile Pattern", "%.1fx".format(state.patternScale), state.patternScale, 0.2f..5f, Palette.AccentCyan) { state.patternScale = it }
        LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }

        Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
        Text("BUAT POLA DARI OBJEK", color = Palette.AccentPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        LabeledSlider("Jarak antar ulangan", "${state.patSpacing.toInt()} px", state.patSpacing, 0f..128f, Palette.AccentPink) { state.patSpacing = it }
        SwitchRow("Susunan bata (baris selang-seling)", state.patBrick) { state.patBrick = it }
        ActionButton(if (state.hasObject) "Objek terpilih → Pattern" else "Isi layer → Pattern", Palette.AccentPink, Modifier.fillMaxWidth()) { actions.toPattern() }
        Hint("Objek (apa adanya, termasuk skala/rotasi) menjadi satu sel ulangan. Tanpa seleksi, isi layer aktif dipakai. Maksimum 8 pola; yang terlama ditimpa.")

        Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
        Text("SEAMLESS REPEAT", color = Palette.AccentPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        SwitchRow("Bungkus tepi kanvas", state.seamless) { state.seamless = it }
        ActionButton("Offset ½ (cek sambungan tile)", Palette.AccentPurple, Modifier.fillMaxWidth()) { actions.offsetHalf() }
        Hint("Aktif: goresan, bentuk, dan objek yang diseret melewati tepi/sudut muncul di sisi seberang. Offset ½ menggeser layer setengah kanvas (wrap) agar sambungan terlihat di tengah.")
    }
}

@Composable
private fun ColorPopup(state: DrawState, dd: DragDropState, actions: ObjectActions, modifier: Modifier) {
    Popup(
        "Color Studio",
        if (state.colorTab == 0) "#%06X".format(state.color and 0xFFFFFF) else patternName(state.pattern),
        Palette.AccentPink, modifier,
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Color", state.colorTab == 0, Palette.AccentPink) { state.colorTab = 0 }
            Chip("Pattern", state.colorTab == 1, Palette.AccentCyan) { state.colorTab = 1 }
        }
        if (state.colorTab == 0) {
            ColorPicker(
                color = state.color,
                onColor = { state.color = it },
                eyedropperActive = state.tool == Tool.EYEDROPPER,
                onEyedropper = { state.toggleEyedropper() },
                dd = dd,
            )
        } else {
            PatternTab(state, dd, actions)
        }
    }
}

// ------------------------------------------------------------------ contextual selection bar

@Composable
private fun BarBtn(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp))
        Text(label, color = Palette.TextPrimary, fontSize = 10.sp, maxLines = 1)
    }
}

/** Quick actions that appear while an object is selected. */
@Composable
fun SelectionBar(actions: ObjectActions, modifier: Modifier = Modifier) {
    FloatingPanel(modifier, shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            BarBtn(DrawIcons.Copy, "Duplikat", AccentAmber) { actions.duplicate() }
            BarBtn(DrawIcons.CenterCanvas, "Tengah", Palette.AccentPurple) { actions.align(6) }
            BarBtn(DrawIcons.Grid, "Pattern", Palette.AccentCyan) { actions.toPattern() }
            BarBtn(DrawIcons.Trash, "Hapus", Palette.AccentPink) { actions.delete() }
            BarBtn(DrawIcons.Check, "Selesai", AccentGreen) { actions.commit() }
        }
    }
}

/** Dropdown popup for whichever panel is open. Place it TopEnd inside the canvas area. */
@Composable
fun PopupHost(
    state: DrawState,
    dd: DragDropState,
    actions: ObjectActions,
    onImport: () -> Unit,
    onExport: () -> Unit,
    onLayers: () -> Unit,
    onArtboard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (state.panel) {
        Panel.TOOLS -> ToolsPopup(onImport, onExport, onLayers, onArtboard, modifier)
        Panel.BRUSH -> BrushPopup(state, modifier)
        Panel.SHAPES -> ShapesPopup(state, modifier)
        Panel.TRANSFORM -> TransformPopup(state, actions, modifier)
        Panel.FX -> FxPopup(state, actions, onArtboard, modifier)
        Panel.PATHFINDER -> PathfinderPopup(state, modifier)
        Panel.COLOR -> ColorPopup(state, dd, actions, modifier)
    }
}


// ------------------------------------------------------------------ bottom nav pill

@Composable
private fun NavItem(icon: ImageVector, label: String, accent: Color, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Color.Transparent)
            .border(1.dp, if (selected) accent.copy(alpha = 0.35f) else Color.Transparent, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Icon(icon, label, tint = accent, modifier = Modifier.size(18.dp))
        Text(
            label,
            color = if (selected) accent else Palette.TextPrimary,
            fontSize = 14.sp, lineHeight = 16.sp, textAlign = TextAlign.Center,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** "BRUSH NAV | Brush  Shapes  Transform  Crop & FX | ✋" */
@Composable
fun BottomNav(state: DrawState, modifier: Modifier = Modifier) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            val cShape = RoundedCornerShape(16.dp)
            Column(
                Modifier
                    .clip(cShape)
                    .background(Palette.DarkBg.copy(alpha = 0.6f))
                    .border(1.dp, Palette.PanelBorder, cShape)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
            ) {
                Text("BRUSH", color = Palette.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, lineHeight = 12.sp)
                Text("NAV", color = Palette.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, lineHeight = 12.sp)
            }
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavItem(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.group == Panel.BRUSH) { state.selectGroup(Panel.BRUSH) }
                NavItem(DrawIcons.Shapes, "Shapes", Palette.AccentCyan, state.group == Panel.SHAPES) { state.selectGroup(Panel.SHAPES) }
                NavItem(DrawIcons.Transform, "Transform", AccentAmber, state.group == Panel.TRANSFORM) { state.selectGroup(Panel.TRANSFORM) }
                NavItem(DrawIcons.Wand, "Crop\n& FX", Palette.AccentPink, state.group == Panel.FX) { state.selectGroup(Panel.FX) }
            }
            val hShape = RoundedCornerShape(16.dp)
            val handOn = state.tool == Tool.HAND
            Box(
                Modifier
                    .size(42.dp)
                    .clip(hShape)
                    .background(AccentGreen.copy(alpha = if (handOn) 0.28f else 0.12f))
                    .border(1.dp, AccentGreen.copy(alpha = if (handOn) 0.9f else 0.35f), hShape)
                    .clickable { state.toggleHand() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Hand, "Hand: geser kanvas", tint = AccentGreen, modifier = Modifier.size(22.dp))
            }
        }
    }
}
