package com.lightdraw.studio

import android.graphics.Bitmap
import java.nio.ByteBuffer

/** JNI facade for the Rust engine (liblightdraw_engine.so). One `external` per `Java_..._NativeEngine_*` in engine_core.rs. */
object NativeEngine {
    init {
        System.loadLibrary("lightdraw_engine")
    }

    external fun nativeInit(w: Int, h: Int, spillDir: String, maxResident: Int): Boolean
    external fun nativeCanvasWidth(): Int
    external fun nativeCanvasHeight(): Int

    // ---- GPU feed (composited tiles: all layers + live stroke + floating object)
    external fun nativeVisibleTiles(tx0: Int, ty0: Int, tx1: Int, ty1: Int, idx: IntArray, ver: IntArray): Int
    external fun nativeCopyTile(idx: Int, buf: ByteBuffer): Boolean

    // ---- settings
    external fun nativeSetBrush(preset: Int, size: Float, opacity: Float, color: Int, blend: Int)
    external fun nativeSetStabilizer(strength: Float)
    /**
     * Studio Pens. Call right after [nativeSetBrush] (which resets the pen block to the preset's defaults).
     * pen = [hardness, spacing, pressure->size, pressure->opacity, pressure curve, speed thinning,
     *        start taper length, start tip, end taper length, end tip]; see [PEN_PARAMS].
     */
    external fun nativeSetPen(pen: FloatArray)
    /** Fills [out] (PEN_PARAMS floats) with the built-in pen block of a brush preset. */
    external fun nativeBrushDefaults(preset: Int, out: FloatArray): Boolean
    external fun nativeSetSymmetry(mode: Int, sectors: Int, mirror: Boolean)
    external fun nativeSetBg(argb: Int)
    /** Seamless repeat: strokes, shapes and dragged objects wrap around the canvas edges. */
    external fun nativeSetWrap(on: Boolean)

    // ---- brush strokes
    external fun nativeStrokeBegin(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeMove(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeEnd()
    external fun nativeStrokeCancel()

    // ---- shapes (kind: 0 line, 1 rect, 2 rounded rect, 3 ellipse, 4 triangle, 5 polygon, 6 star)
    external fun nativeShapeUpdate(
        kind: Int, x0: Float, y0: Float, x1: Float, y1: Float,
        outline: Boolean, stroke: Float, corner: Float, sides: Int,
        color: Int, opacity: Float, blend: Int, paintKind: Int, color2: Int, patternScale: Float,
    )
    external fun nativeShapeEnd()
    external fun nativeShapeCancel()

    // ---- fill / colour tools
    /** 0 ok, 1 out of bounds, 2 region too large. [kind] 0 = solid, 1..6 = built-in pattern, 100+ = user pattern. */
    external fun nativeFill(x: Int, y: Int, kind: Int, color: Int, color2: Int, scale: Float, tol: Int): Int
    external fun nativeSelectReplace(x: Int, y: Int, newColor: Int, tolH: Float, tolS: Float, tolL: Float): Int
    external fun nativePickColor(x: Int, y: Int): Int

    // ---- history
    external fun nativeUndo(): Boolean
    external fun nativeRedo(): Boolean
    /** bit0 = can undo, bit1 = can redo */
    external fun nativeHistoryState(): Int
    /** Erase the active layer (undoable). */
    external fun nativeClear()

    // ---- layers (index 0 = bottom)
    external fun nativeLayerCount(): Int
    external fun nativeActiveLayer(): Int
    external fun nativeLayerName(i: Int): String
    external fun nativeLayerVisible(i: Int): Boolean
    external fun nativeLayerOpacity(i: Int): Float
    external fun nativeAddLayer(): Boolean
    /** Duplicate Layer: copies every pixel, the visibility and the opacity of the active layer. */
    external fun nativeDuplicateLayer(): Boolean
    external fun nativeDeleteLayer(): Boolean
    external fun nativeMoveLayer(from: Int, to: Int): Boolean
    external fun nativeSetActiveLayer(i: Int)
    external fun nativeSetLayerVisible(i: Int, v: Boolean)
    external fun nativeSetLayerOpacity(i: Int, o: Float)

    // ---- objects (a "floating object" is lifted out of the active layer, edited, then baked back by nativeCommit)
    /** 0 ok, 1 nothing there, 2 too large. */
    external fun nativeSelectAt(x: Int, y: Int): Int
    external fun nativeSelectRect(x0: Int, y0: Int, x1: Int, y1: Int): Int
    external fun nativeSelectAll(): Int
    external fun nativeCommit()
    external fun nativeDeleteObject()
    external fun nativeHasObject(): Boolean
    external fun nativeObjectMove(dx: Float, dy: Float)
    /** Absolute uniform scale (1.0 = 100 %) and rotation in degrees. */
    external fun nativeObjectTransform(scale: Float, rotDeg: Float)
    external fun nativeObjectFlip(horizontal: Boolean)
    external fun nativeObjectRotate90(clockwise: Boolean)
    external fun nativeObjectHit(x: Float, y: Float): Boolean
    /** out = [scale, rotationDeg, wrap(0/1), minX, minY, maxX, maxY]; false when nothing is selected. */
    external fun nativeObjectInfo(out: FloatArray): Boolean
    /** out = x,y of TL, TR, BR, BL corners in canvas pixels; false when nothing is selected. */
    external fun nativeObjectCorners(out: FloatArray): Boolean
    /** mode: 0 left, 1 centre H, 2 right, 3 top, 4 centre V, 5 bottom, 6 centre on canvas. 0 ok, 1 nothing, 2 too large. */
    external fun nativeAlign(mode: Int): Int
    /** Duplicate Object: original stays, an offset copy floats. 0 ok, 1 nothing to copy, 2 too large. */
    external fun nativeDuplicateObject(): Int

    // ---- patterns
    /** Convert Object to Pattern: returns the slot (fill kind = 100 + slot), -1 no object, -2 too large. */
    external fun nativeObjectToPattern(spacing: Int, brick: Boolean): Int
    external fun nativePatternCount(): Int
    /** Fills [out] (size*size ARGB ints) with a 2x2 preview of user pattern [i]. */
    external fun nativePatternThumb(i: Int, size: Int, out: IntArray): Boolean
    /** Offset the active layer by (dx, dy) with wrap-around, the classic way to check a seamless tile. */
    external fun nativeOffsetWrap(dx: Int, dy: Int): Int

    // ---- FX (kind: 0 blur, 1 sharpen, 2 brightness/contrast, 3 hue/sat, 4 invert, 5 grayscale, 6 pixelate)
    /** Applies to the selected object, else to the active layer. 0 ok, 1 nothing to process, 2 too large. */
    external fun nativeApplyFx(kind: Int, a: Float, b: Float): Int

    // ---- export / import
    external fun nativeRenderToBitmap(bmp: Bitmap, bg: Int): Int
    external fun nativeExportPng(fd: Int, bg: Int): Int
    /** Full-size streamed JPEG (quality 100 = quantiser steps of 1, 4:4:4). */
    external fun nativeExportJpeg(fd: Int, bg: Int, quality: Int): Int
    external fun nativeSaveProject(fd: Int): Int
    /** (width shl 32) or height, or -1 on failure. */
    external fun nativeLoadProject(fd: Int, spillDir: String, maxResident: Int): Long
    /** Puts the bitmap on the canvas as a floating object. */
    external fun nativeImportBitmap(bmp: Bitmap, dx: Int, dy: Int): Int
}

const val PEN_PARAMS = 10

/** Second colour for two-tone patterns, derived from the active colour. */
fun secondaryOf(argb: Int): Int {
    val r = (argb shr 16) and 255
    val g = (argb shr 8) and 255
    val b = argb and 255
    val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    val target = if (lum > 0.55) 0 else 255
    val t = if (lum > 0.55) 0.65 else 0.85
    fun mix(c: Int): Int = (c + (target - c) * t).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (mix(r) shl 16) or (mix(g) shl 8) or mix(b)
}
