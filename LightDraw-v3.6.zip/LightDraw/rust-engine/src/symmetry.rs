//! Zero-allocation symmetry expansion (horizontal / vertical mirror, radial mandala up to 12 sectors).
//! Results are packed into 64-bit values: high 32 bits = x, low 32 bits = y, both signed 16.16 fixed point.

pub const MAX_COPIES: usize = 24;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SymMode {
    Off,
    Horizontal, // left <-> right mirror
    Vertical,   // top <-> bottom mirror
    Radial,
}

pub struct Symmetry {
    pub mode: SymMode,
    pub sectors: usize,
    pub mirror: bool,
    pub wrap: bool, // seamless painting: dabs that cross an edge also appear on the opposite side
    pub cx: f32,
    pub cy: f32,
    cos_t: [f32; 12],
    sin_t: [f32; 12],
}

#[inline]
pub fn pack(x: f32, y: f32) -> u64 {
    let fx = (x * 65536.0) as i32;
    let fy = (y * 65536.0) as i32;
    ((fx as u32 as u64) << 32) | (fy as u32 as u64)
}

#[inline]
pub fn unpack_x(p: u64) -> f32 {
    ((p >> 32) as u32 as i32) as f32 / 65536.0
}

#[inline]
pub fn unpack_y(p: u64) -> f32 {
    (p as u32 as i32) as f32 / 65536.0
}

impl Symmetry {
    pub fn new(width: u32, height: u32) -> Self {
        let mut s = Symmetry {
            mode: SymMode::Off,
            sectors: 6,
            mirror: false,
            wrap: false,
            cx: width as f32 * 0.5,
            cy: height as f32 * 0.5,
            cos_t: [1.0; 12],
            sin_t: [0.0; 12],
        };
        s.configure(0, 6, false);
        s
    }

    pub fn set_wrap(&mut self, on: bool) {
        self.wrap = on;
    }

    /// Artboard size (the symmetry centre is always the artboard centre).
    pub fn size(&self) -> (f32, f32) {
        (self.cx * 2.0, self.cy * 2.0)
    }

    /// `mode`: 0 off, 1 horizontal, 2 vertical, 3 radial.
    pub fn configure(&mut self, mode: i32, sectors: i32, mirror: bool) {
        self.mode = match mode {
            1 => SymMode::Horizontal,
            2 => SymMode::Vertical,
            3 => SymMode::Radial,
            _ => SymMode::Off,
        };
        self.sectors = sectors.clamp(2, 12) as usize;
        self.mirror = mirror;
        for k in 0..self.sectors {
            let a = (k as f32) * std::f32::consts::TAU / (self.sectors as f32);
            self.cos_t[k] = a.cos();
            self.sin_t[k] = a.sin();
        }
    }

    /// Expand one point into its symmetric copies. Returns the number of valid entries in `out`.
    pub fn expand(&self, x: f32, y: f32, out: &mut [u64; MAX_COPIES]) -> usize {
        match self.mode {
            SymMode::Off => {
                out[0] = pack(x, y);
                1
            }
            SymMode::Horizontal => {
                out[0] = pack(x, y);
                out[1] = pack(2.0 * self.cx - x, y);
                2
            }
            SymMode::Vertical => {
                out[0] = pack(x, y);
                out[1] = pack(x, 2.0 * self.cy - y);
                2
            }
            SymMode::Radial => {
                let dx = x - self.cx;
                let dy = y - self.cy;
                let mut n = 0usize;
                for k in 0..self.sectors {
                    let c = self.cos_t[k];
                    let s = self.sin_t[k];
                    out[n] = pack(self.cx + dx * c - dy * s, self.cy + dx * s + dy * c);
                    n += 1;
                    if self.mirror {
                        out[n] = pack(self.cx - dx * c - dy * s, self.cy - dx * s + dy * c);
                        n += 1;
                    }
                }
                n
            }
        }
    }
}
