//! Multi-layer stack. (NEW FILE: rust-engine/src/layers.rs)
//!
//! Design: `Engine.canvas` is ALWAYS the active layer's canvas, so every existing tool (brush, fill, wrap,
//! align, transform, import, undo/redo ...) keeps working unchanged and edits only the active layer. The other
//! layers keep their canvas inside `Stack.layers[i].canvas` (`None` for the active slot). Switching layer swaps
//! the two canvases (no pixel copy). Undo/redo history lives inside each canvas, so it is per layer.
//!
//! Compositing (display, pick colour, export, save) blends visible layers bottom -> top with their opacity.
//! Memory: every layer is a sparse tile canvas; the resident-tile budget is split between layers.
use std::collections::BTreeMap;
use std::path::PathBuf;

use crate::tiled_canvas::{TiledCanvas, TILE_PIXELS};

pub const MAX_LAYERS: usize = 12;

pub struct Layer {
    pub canvas: Option<TiledCanvas>, // None while this layer is the active one (its canvas is Engine.canvas)
    pub visible: bool,
    pub locked: bool,
    pub opacity: u8, // 0..=255
    pub blend: u8,   // 0 Normal, 1 Multiply, 2 Screen, 3 Overlay, 4 Soft Light, 5 Hard Light, 6 Darken, 7 Lighten, 8 Color Dodge, 9 Color Burn, 10 Difference, 11 Add
}

impl Layer {
    fn new(canvas: Option<TiledCanvas>) -> Self {
        Layer { canvas, visible: true, locked: false, opacity: 255, blend: 0 }
    }
}

pub struct Stack {
    pub layers: Vec<Layer>, // index 0 = bottom
    pub active: usize,
    pub stamp: u32, // bumped on every structural / visibility / opacity change -> forces GPU tile refresh
    base_resident: usize,
}

impl Stack {
    pub fn new(base_resident: usize) -> Self {
        Stack { layers: vec![Layer::new(None)], active: 0, stamp: 0, base_resident }
    }

    /// True when the canvas can be read directly (one visible, fully opaque layer).
    pub fn is_trivial(&self) -> bool {
        self.layers.len() == 1 && self.layers[0].visible && self.layers[0].opacity == 255 && self.layers[0].blend == 0
    }
}

#[inline]
pub fn over_px(dst: u32, src: u32) -> u32 {
    let sa = src >> 24;
    if sa == 255 {
        return src;
    }
    if sa == 0 {
        return dst;
    }
    let k = 255 - sa;
    let ch = |s: u32| ((((src >> s) & 255) + (((dst >> s) & 255) * k + 127) / 255).min(255)) << s;
    ch(0) | ch(8) | ch(16) | ch(24)
}

#[inline]
fn scale_px(p: u32, op: u32) -> u32 {
    let ch = |s: u32| (((((p >> s) & 255) * op) + 127) / 255) << s;
    ch(0) | ch(8) | ch(16) | ch(24)
}

// ---------------------------------------------------------------- layer blend modes

#[inline]
fn hard_light(cb: f32, cs: f32) -> f32 {
    if cs <= 0.5 {
        cb * 2.0 * cs
    } else {
        let t = 2.0 * cs - 1.0;
        cb + t - cb * t // screen(cb, 2cs - 1)
    }
}

#[inline]
fn soft_light(cb: f32, cs: f32) -> f32 {
    if cs <= 0.5 {
        cb - (1.0 - 2.0 * cs) * cb * (1.0 - cb)
    } else {
        let d = if cb <= 0.25 { ((16.0 * cb - 12.0) * cb + 4.0) * cb } else { cb.sqrt() };
        cb + (2.0 * cs - 1.0) * (d - cb)
    }
}

/// Separable blend function B(backdrop, source) on straight (un-premultiplied) channel values in 0..1.
fn blend_fn(mode: u8, cb: f32, cs: f32) -> f32 {
    match mode {
        1 => cb * cs,
        2 => cb + cs - cb * cs,
        3 => hard_light(cs, cb), // overlay = hard light with the layers swapped
        4 => soft_light(cb, cs),
        5 => hard_light(cb, cs),
        6 => cb.min(cs),
        7 => cb.max(cs),
        8 => {
            if cb <= 0.0 {
                0.0
            } else if cs >= 1.0 {
                1.0
            } else {
                (cb / (1.0 - cs)).min(1.0)
            }
        }
        9 => {
            if cb >= 1.0 {
                1.0
            } else if cs <= 0.0 {
                0.0
            } else {
                1.0 - ((1.0 - cb) / cs).min(1.0)
            }
        }
        10 => (cb - cs).abs(),
        11 => (cb + cs).min(1.0),
        _ => cs,
    }
}

/// `src` blended onto `dst` with a layer blend mode (both premultiplied; W3C compositing formula).
fn blend_px_layer(dst: u32, src: u32, mode: u8) -> u32 {
    if mode == 0 {
        return over_px(dst, src);
    }
    let sa = (src >> 24) as f32 / 255.0;
    if sa <= 0.0 {
        return dst;
    }
    let da = (dst >> 24) as f32 / 255.0;
    if da <= 0.0 {
        return src;
    }
    let oa = sa + da - sa * da;
    let mut out = 0u32;
    for sh in [0u32, 8, 16] {
        let sp = ((src >> sh) & 255) as f32 / 255.0;
        let dp = ((dst >> sh) & 255) as f32 / 255.0;
        let cs = (sp / sa).min(1.0);
        let cb = (dp / da).min(1.0);
        let v = ((1.0 - sa) * dp + (1.0 - da) * sp + sa * da * blend_fn(mode, cb, cs)).min(oa);
        out |= ((v * 255.0 + 0.5).clamp(0.0, 255.0) as u32) << sh;
    }
    out | (((oa * 255.0 + 0.5).clamp(0.0, 255.0) as u32) << 24)
}

fn canvas_at<'a>(active: &'a mut TiledCanvas, st: &'a mut Stack, i: usize) -> &'a mut TiledCanvas {
    if i == st.active {
        active
    } else {
        st.layers[i].canvas.as_mut().expect("inactive layer keeps its canvas")
    }
}

fn base_dir(c: &TiledCanvas) -> PathBuf {
    c.spill_dir().parent().map(|p| p.to_path_buf()).unwrap_or_else(std::env::temp_dir)
}

/// Split the resident-tile budget between layers (floor 48 tiles each).
pub fn rebalance(active: &mut TiledCanvas, st: &mut Stack) {
    let n = st.layers.len().max(1);
    let per = (st.base_resident / n).max(48);
    active.max_resident = per;
    for l in st.layers.iter_mut() {
        if let Some(c) = l.canvas.as_mut() {
            c.max_resident = per;
        }
    }
}

// ---------------------------------------------------------------- compositing

/// Blend all visible layers of one tile (bottom -> top). Returns false when nothing is drawn there.
pub fn composite_tile(active: &mut TiledCanvas, st: &mut Stack, idx: usize, out: &mut [u32]) -> bool {
    out.fill(0);
    let mut any = false;
    for i in 0..st.layers.len() {
        let (vis, op, mode) = (st.layers[i].visible, st.layers[i].opacity as u32, st.layers[i].blend);
        if !vis || op == 0 {
            continue;
        }
        let c = canvas_at(active, st, i);
        if idx >= c.tile_count() {
            continue;
        }
        if let Some(px) = c.tile_pixels(idx) {
            any = true;
            if mode == 0 && op == 255 {
                for (d, &s) in out.iter_mut().zip(px.iter()) {
                    *d = over_px(*d, s);
                }
            } else {
                for (d, &s) in out.iter_mut().zip(px.iter()) {
                    if s >> 24 != 0 {
                        *d = blend_px_layer(*d, if op == 255 { s } else { scale_px(s, op) }, mode);
                    }
                }
            }
        }
    }
    any
}

pub fn composite_pixel(active: &mut TiledCanvas, st: &mut Stack, x: i32, y: i32) -> u32 {
    let mut out = 0u32;
    for i in 0..st.layers.len() {
        let (vis, op, mode) = (st.layers[i].visible, st.layers[i].opacity as u32, st.layers[i].blend);
        if !vis || op == 0 {
            continue;
        }
        let p = canvas_at(active, st, i).get_pixel(x, y);
        out = blend_px_layer(out, if op == 255 { p } else { scale_px(p, op) }, mode);
    }
    out
}

pub fn set_viewport_all(active: &mut TiledCanvas, st: &mut Stack, tx0: i32, ty0: i32, tx1: i32, ty1: i32) {
    active.set_viewport(tx0, ty0, tx1, ty1);
    for l in st.layers.iter_mut() {
        if let Some(c) = l.canvas.as_mut() {
            c.set_viewport(tx0, ty0, tx1, ty1);
        }
    }
}

/// Union of the tiles of all visible layers; the version mixes every layer's tile version and the stack stamp.
pub fn visible_tiles(
    active: &mut TiledCanvas,
    st: &mut Stack,
    tx0: i32,
    ty0: i32,
    tx1: i32,
    ty1: i32,
    idx_out: &mut [i32],
    ver_out: &mut [i32],
) -> usize {
    let cap = idx_out.len().min(ver_out.len());
    let mut merged: BTreeMap<i32, u32> = BTreeMap::new();
    let mut ib = vec![0i32; cap];
    let mut vb = vec![0i32; cap];
    for i in 0..st.layers.len() {
        if !st.layers[i].visible || st.layers[i].opacity == 0 {
            continue;
        }
        let n = canvas_at(active, st, i).visible_tiles(tx0, ty0, tx1, ty1, &mut ib, &mut vb);
        for k in 0..n {
            let e = merged.entry(ib[k]).or_insert(0);
            *e = e.wrapping_add(vb[k] as u32);
        }
    }
    let mix = st.stamp.wrapping_mul(0x9E37_79B1);
    let mut n = 0;
    for (idx, v) in merged.into_iter().take(cap) {
        idx_out[n] = idx;
        ver_out[n] = v.wrapping_add(mix) as i32;
        n += 1;
    }
    n
}

/// Temporary single canvas with all visible layers blended (export / save). Dropped = files removed.
pub fn flatten(active: &mut TiledCanvas, st: &mut Stack) -> TiledCanvas {
    let budget = (active.tiles_x + 16).max(64);
    let mut out = TiledCanvas::new(active.width, active.height, base_dir(active), budget);
    let mut buf = vec![0u32; TILE_PIXELS];
    for idx in 0..out.tile_count() {
        if composite_tile(active, st, idx, &mut buf) {
            out.put_tile(idx, &buf);
        }
    }
    out
}

// ---------------------------------------------------------------- structure

fn duplicate_canvas(src: &mut TiledCanvas) -> TiledCanvas {
    let mut out = TiledCanvas::new(src.width, src.height, base_dir(src), src.max_resident);
    let mut buf = vec![0u32; TILE_PIXELS];
    for idx in 0..src.tile_count() {
        let has = match src.tile_pixels(idx) {
            Some(px) => {
                buf.copy_from_slice(px);
                true
            }
            None => false,
        };
        if has {
            out.put_tile(idx, &buf);
        }
    }
    out
}

fn push_active(active: &mut TiledCanvas, st: &mut Stack, new_canvas: TiledCanvas, layer: Layer) -> i32 {
    let pos = st.active + 1;
    let old = std::mem::replace(active, new_canvas);
    st.layers[st.active].canvas = Some(old);
    st.layers.insert(pos, layer);
    st.active = pos;
    st.stamp = st.stamp.wrapping_add(1);
    rebalance(active, st);
    pos as i32
}

/// New empty layer above the active one (becomes active). -1 when the limit is reached.
pub fn add(active: &mut TiledCanvas, st: &mut Stack) -> i32 {
    if st.layers.len() >= MAX_LAYERS {
        return -1;
    }
    let c = TiledCanvas::new(active.width, active.height, base_dir(active), active.max_resident);
    push_active(active, st, c, Layer::new(None))
}

/// Copy of the active layer, placed above it (becomes active).
pub fn duplicate(active: &mut TiledCanvas, st: &mut Stack) -> i32 {
    if st.layers.len() >= MAX_LAYERS {
        return -1;
    }
    let c = duplicate_canvas(active);
    let (op, vis, bl) = (st.layers[st.active].opacity, st.layers[st.active].visible, st.layers[st.active].blend);
    let mut l = Layer::new(None);
    l.opacity = op;
    l.visible = vis;
    l.blend = bl;
    push_active(active, st, c, l)
}

pub fn select(active: &mut TiledCanvas, st: &mut Stack, i: usize) -> bool {
    if i >= st.layers.len() {
        return false;
    }
    if i == st.active {
        return true;
    }
    let Some(new) = st.layers[i].canvas.take() else { return false };
    let old = std::mem::replace(active, new);
    st.layers[st.active].canvas = Some(old);
    st.active = i;
    true
}

/// Delete the active layer (never the last one). The layer below (or above for the bottom one) becomes active.
pub fn delete_active(active: &mut TiledCanvas, st: &mut Stack) -> bool {
    if st.layers.len() <= 1 {
        return false;
    }
    let i = st.active;
    st.layers.remove(i);
    let new_active = if i > 0 { i - 1 } else { 0 };
    let Some(new) = st.layers[new_active].canvas.take() else { return false };
    *active = new; // the old canvas is dropped here (spill files removed)
    st.active = new_active;
    st.stamp = st.stamp.wrapping_add(1);
    rebalance(active, st);
    true
}

/// Move the active layer one step (dir > 0 up, dir < 0 down). Returns the new index.
pub fn move_active(st: &mut Stack, dir: i32) -> i32 {
    let i = st.active as i32;
    let j = i + if dir > 0 { 1 } else { -1 };
    if j < 0 || j >= st.layers.len() as i32 {
        return i;
    }
    st.layers.swap(i as usize, j as usize);
    st.active = j as usize;
    st.stamp = st.stamp.wrapping_add(1);
    j
}

/// Blend the active layer into the one below it and remove it. Not undoable (history of the result is cleared).
pub fn merge_down(active: &mut TiledCanvas, st: &mut Stack) -> bool {
    let i = st.active;
    if i == 0 {
        return false;
    }
    let Some(mut below) = st.layers[i - 1].canvas.take() else { return false };
    let (vis, op, mode) = (st.layers[i].visible, st.layers[i].opacity as u32, st.layers[i].blend);
    if vis && op > 0 {
        let mut src = vec![0u32; TILE_PIXELS];
        let mut dst = vec![0u32; TILE_PIXELS];
        for idx in 0..active.tile_count() {
            let has = match active.tile_pixels(idx) {
                Some(px) => {
                    src.copy_from_slice(px);
                    true
                }
                None => false,
            };
            if !has {
                continue;
            }
            match below.tile_pixels(idx) {
                Some(p) => dst.copy_from_slice(p),
                None => dst.fill(0),
            }
            for (d, &s) in dst.iter_mut().zip(src.iter()) {
                *d = blend_px_layer(*d, if op == 255 { s } else { scale_px(s, op) }, mode);
            }
            below.put_tile(idx, &dst);
        }
    }
    below.clear_history();
    *active = below; // old active canvas dropped
    st.layers.remove(i);
    st.active = i - 1;
    st.layers[st.active].canvas = None;
    st.stamp = st.stamp.wrapping_add(1);
    rebalance(active, st);
    true
}

/// Move layer `from` to position `to` (drag & drop in the layer list). The active layer follows its content.
pub fn move_layer(st: &mut Stack, from: usize, to: usize) -> bool {
    let n = st.layers.len();
    if from >= n || to >= n || from == to {
        return false;
    }
    let layer = st.layers.remove(from);
    st.layers.insert(to, layer);
    let a = st.active;
    st.active = if a == from {
        to
    } else if from < a && to >= a {
        a - 1
    } else if from > a && to <= a {
        a + 1
    } else {
        a
    };
    st.stamp = st.stamp.wrapping_add(1);
    true
}

/// packed: bit0 visible, bit1 locked, bits 8..16 opacity, bits 16..24 blend mode.
pub fn info(st: &Stack, i: usize) -> i32 {
    match st.layers.get(i) {
        Some(l) => (l.visible as i32) | ((l.locked as i32) << 1) | ((l.opacity as i32) << 8) | ((l.blend as i32) << 16),
        None => 0,
    }
}
