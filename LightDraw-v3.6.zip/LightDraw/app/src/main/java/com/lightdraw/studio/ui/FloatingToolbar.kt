package com.lightdraw.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import com.lightdraw.studio.NativeEngine
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlin.math.sqrt

object Tool {
    const val DRAW = 0
    const val ERASER = 1
    const val FILL = 2
    const val SELECT_COLOR = 3
    const val EYEDROPPER = 4
    const val HAND = 5
    const val SHAPE = 6
    const val SELECT = 7   // rectangular object selection (move / duplicate / align / to pattern)
    const val WRAP = 8     // drag the whole drawing; what leaves one edge re-enters on the other (seamless tiles)
}

/** Popup panels that drop down under the top toolbar. BRUSH..FX and OBJECT double as bottom-nav groups. */
object Panel {
    const val NONE = -1
    const val TOOLS = 0
    const val BRUSH = 1
    const val SHAPES = 2
    const val TRANSFORM = 3
    const val FX = 4
    const val COLOR = 6   // colour wheel + swatches + PATTERN section
    const val OBJECT = 7  // select / duplicate / align / to pattern
    const val LAYERS = 8  // layer list dropdown (top bar layer chip)
}

/** Selected "object" = a rectangle of the drawing, in canvas pixels (inclusive). */
/** A smart guide line while moving an object: vertical at x = pos, or horizontal at y = pos (canvas px). */
data class Guide(val vertical: Boolean, val pos: Float)

/** Live preview of the two-finger object transform: scale, rotation (rad) about the selection centre, shift (canvas px). */
data class XformPreview(val s: Float, val r: Float, val dx: Float, val dy: Float)

data class SelRect(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
    val w get() = x1 - x0 + 1
    val h get() = y1 - y0 + 1
    fun shift(dx: Int, dy: Int) = SelRect(x0 + dx, y0 + dy, x1 + dx, y1 + dy)
}

/** Everything the popups can ask the canvas / engine to do. Implemented in CanvasScreen. */
class EditActions(
    val duplicate: () -> Unit,
    val align: (Int) -> Unit,
    val toPattern: () -> Unit,
    val fx: (op: Int, a: Float, b: Float) -> Unit,
    val wrapHalf: () -> Unit,
    val rotateView: (Float) -> Unit,
    val resetRotation: () -> Unit,
    val fitView: () -> Unit,
    val rotate90: () -> Unit,
    val flipH: () -> Unit,
    val copy: () -> Unit,
    val paste: () -> Unit,
    val layersChanged: () -> Unit,   // re-read the native layer stack into DrawState
    val layersRender: () -> Unit,    // redraw only (opacity slider)
    val clearLayer: () -> Unit,
    val openPaper: () -> Unit,
    val toast: (String) -> Unit,
)

private val AccentAmber = Color(0xFFF5A623)
private val AccentGreen = Color(0xFF22C55E)
private val AccentBlue = Color(0xFF60A5FA)
private val ButtonBg = Color(0xFF26262E)
private val IconIdle = Color(0xFFC8CDD6)

/** All UI-visible drawing state. Pushed to the native engine by CanvasScreen. */
@Stable
class DrawState {
    var tool by mutableIntStateOf(Tool.DRAW)
    private var prevTool = Tool.DRAW
    var color by mutableIntStateOf(0xFFA066FF.toInt())

    var brushPreset by mutableIntStateOf(0)
    var size by mutableFloatStateOf(18f)
    var opacity by mutableFloatStateOf(100f)      // %
    var stabilizer by mutableFloatStateOf(65f)    // %
    var blend by mutableIntStateOf(0)             // 0 normal 1 multiply 2 screen 3 overlay 4 add

    var pattern by mutableIntStateOf(0)           // 0 = solid colour
    var patternScale by mutableFloatStateOf(1f)
    var fillTolerance by mutableFloatStateOf(24f)

    var symMode by mutableIntStateOf(0)           // 0 off 1 horizontal 2 vertical 3 radial
    var sectors by mutableIntStateOf(6)
    var symMirror by mutableStateOf(false)

    var tolH by mutableFloatStateOf(15f)          // degrees
    var tolS by mutableFloatStateOf(20f)          // %
    var tolL by mutableFloatStateOf(20f)          // %

    // shapes
    var shapeKind by mutableIntStateOf(0)         // 0 rect 1 rounded 2 ellipse 3 triangle 4 line 5 diamond
    var shapeFilled by mutableStateOf(true)
    var shapeStroked by mutableStateOf(false)
    var shapeStrokeW by mutableFloatStateOf(6f)

    // object selection + custom pattern
    var selection by mutableStateOf<SelRect?>(null)
    var customPatternSize by mutableStateOf("")   // "" = no custom pattern yet
    var wrapEdges by mutableStateOf(true)         // moving a selection past an edge wraps to the opposite side

    var paperColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var paperVisible by mutableStateOf(true)

    /** Popup currently open (Panel.*), and the last bottom-nav group that was chosen. */
    var panel by mutableIntStateOf(Panel.NONE)
    var group by mutableIntStateOf(Panel.BRUSH)

    // layers (mirrored from the native stack by CanvasScreen.syncLayers)
    // grid / guides / seamless / object transform
    var gridOn by mutableStateOf(false)
    var gridSize by mutableIntStateOf(64)
    var snapOn by mutableStateOf(true)
    var seamGuide by mutableStateOf(false)       // border + centre cross: where the seam lands after Wrap
    var seamlessPaint by mutableStateOf(false)   // strokes crossing an edge wrap to the opposite side
    var objXform by mutableStateOf(false)        // Select tool: two fingers rotate / scale the selected object
    var guides by mutableStateOf<List<Guide>>(emptyList())
    var xform by mutableStateOf<XformPreview?>(null)
    var clipHas by mutableStateOf(false)         // something was copied (paste available)
    var moveAnywhere by mutableStateOf(false)    // Select tool: drag anywhere to move the selection
    var layerTick by mutableIntStateOf(0)
    var layerCount by mutableIntStateOf(1)
    var activeLayer by mutableIntStateOf(0)
    var activeLocked by mutableStateOf(false)
    var activeVisible by mutableStateOf(true)

    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    /** Menus are exclusive (single `panel` value) and close after an option is picked or the canvas is touched. */
    fun closePanel() {
        panel = Panel.NONE
    }

    fun togglePanel(id: Int) {
        panel = if (panel == id) Panel.NONE else id
    }

    /** Brush / Shapes / Transform / FX groups: highlight the group, toggle its popup and switch to a matching tool. */
    fun selectGroup(id: Int) {
        group = id
        when (id) {
            Panel.BRUSH -> if (tool != Tool.DRAW && tool != Tool.ERASER) tool = Tool.DRAW
            Panel.SHAPES -> tool = Tool.SHAPE
            Panel.OBJECT -> tool = Tool.SELECT
        }
        togglePanel(id)
    }

    fun toggleEyedropper() {
        if (tool == Tool.EYEDROPPER) {
            tool = prevTool
        } else {
            if (tool != Tool.HAND) prevTool = tool
            tool = Tool.EYEDROPPER
        }
    }

    fun finishEyedropper() {
        if (tool == Tool.EYEDROPPER) tool = prevTool
    }

    fun toggleHand() {
        if (tool == Tool.HAND) {
            tool = prevTool
        } else {
            if (tool != Tool.EYEDROPPER) prevTool = tool
            tool = Tool.HAND
        }
    }
}

// ------------------------------------------------------------------ top pill toolbar

@Composable
private fun TbIcon(icon: ImageVector, desc: String, active: Boolean, open: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .size(34.dp)
            .clip(shape)
            .background(
                when {
                    active -> Palette.AccentPurple.copy(alpha = 0.18f)
                    open -> Color(0xFF2E2E36)
                    else -> Color.Transparent
                }
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, desc,
            tint = when {
                active -> Palette.AccentPurple
                open -> Color.White
                else -> IconIdle
            },
            modifier = Modifier.size(20.dp),
        )
    }
}

/** "‹ Gallery | tools… | colour dot" pill, like the mock-up. */
@Composable
fun TopToolbar(
    state: DrawState,
    onGallery: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            val gShape = RoundedCornerShape(12.dp)
            Row(
                Modifier
                    .clip(gShape)
                    .background(Palette.DarkBg.copy(alpha = 0.6f))
                    .border(1.dp, Palette.PanelBorder, gShape)
                    .clickable { onGallery() }
                    .padding(start = 6.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(DrawIcons.ChevronLeft, null, tint = Palette.TextMuted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text("Gallery", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            LayerChip(state, Modifier.weight(1f))
            Spacer(Modifier.width(4.dp))
            TbIcon(DrawIcons.Wrench, "Tools", false, state.panel == Panel.TOOLS) { state.togglePanel(Panel.TOOLS) }
            Spacer(Modifier.width(4.dp))
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(state.color))
                    .border(2.dp, Color.White.copy(alpha = if (state.panel == Panel.COLOR) 0.7f else 0.25f), CircleShape)
                    .clickable { state.togglePanel(Panel.COLOR) },
            )
        }
    }
}

/** Active layer + state badges (hidden / locked). Tap = drop-down layer list. */
@Composable
private fun LayerChip(state: DrawState, modifier: Modifier) {
    val open = state.panel == Panel.LAYERS
    val locked = state.activeLocked
    val edge = if (locked) AccentAmber else Palette.AccentPurple
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .clip(shape)
            .background(if (open) edge.copy(alpha = 0.16f) else Palette.DarkBg.copy(alpha = 0.6f))
            .border(1.dp, if (open || locked) edge else Palette.PanelBorder, shape)
            .clickable { state.togglePanel(Panel.LAYERS) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(DrawIcons.Layers, "Layers", tint = edge, modifier = Modifier.size(18.dp))
        Text(
            "Layer ${state.activeLayer + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (state.layerCount > 1) Text("${state.layerCount}", color = Palette.TextMuted, fontSize = 11.sp)
        if (!state.activeVisible) Icon(DrawIcons.Eye, "Tersembunyi", tint = Palette.TextMuted.copy(alpha = 0.5f), modifier = Modifier.size(16.dp))
        if (locked) Text("🔒", fontSize = 14.sp)
        Text("▾", color = Palette.TextMuted, fontSize = 14.sp, modifier = Modifier.rotate(if (open) 180f else 0f))
    }
}

// ------------------------------------------------------------------ left vertical sliders

@Composable
fun VerticalSlider(fraction: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val push by rememberUpdatedState(onChange)
    Box(
        modifier
            .width(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> push((1f - o.y / size.height).coerceIn(0f, 1f)) },
                ) { change, _ ->
                    change.consume()
                    push((1f - change.position.y / size.height).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.width(7.dp).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFF2E2E36))) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(fraction.coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFC4C4CC))
            )
        }
    }
}

@Composable
private fun PanelDivider() {
    Box(Modifier.padding(vertical = 8.dp).width(20.dp).height(1.dp).background(Palette.PanelBorder))
}

@Composable
private fun SmallBtn(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = if (enabled) IconIdle else Palette.TextMuted.copy(alpha = 0.35f), modifier = Modifier.size(20.dp))
    }
}

/** Size + opacity vertical sliders with undo / redo underneath. */
@Composable
fun SideSliderPanel(
    state: DrawState,
    sliderHeight: Dp,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Quadratic mapping: fine control for small brushes, still reaches 200 px.
    val sizeFrac = sqrt(((state.size - 1f) / 199f).coerceIn(0f, 1f))
    val dot = (4f + 10f * sizeFrac).dp
    FloatingPanel(modifier.width(38.dp), shape = RoundedCornerShape(19.dp)) {
        Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(16.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(dot).clip(CircleShape).background(Color(0xFFB4B8C2)))
            }
            Spacer(Modifier.height(6.dp))
            VerticalSlider(sizeFrac, { state.size = 1f + 199f * it * it }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${(sizeFrac * 100f).roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            Icon(DrawIcons.Drop, "Opacity", tint = Color(0xFFB4B8C2), modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(6.dp))
            VerticalSlider(state.opacity / 100f, { state.opacity = (it * 100f).coerceIn(1f, 100f) }, Modifier.height(sliderHeight))
            Spacer(Modifier.height(4.dp))
            Text("${state.opacity.roundToInt()}%", color = Palette.TextMuted, fontSize = 10.sp)
            PanelDivider()
            SmallBtn(DrawIcons.Undo, "Undo", state.canUndo, onUndo)
            SmallBtn(DrawIcons.Redo, "Redo", state.canRedo, onRedo)
        }
    }
}

// ------------------------------------------------------------------ popups

@Composable
private fun Popup(
    title: String,
    tag: String,
    tagColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(tag, color = tagColor, fontSize = 11.sp)
            }
            Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(Palette.PanelBorder.copy(alpha = 0.6f)))
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content,
            )
        }
    }
}

@Composable
private fun OpButton(icon: ImageVector, label: String, tint: Color, selected: Boolean, modifier: Modifier, clickMod: Modifier, iconRotation: Float = 0f) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) tint.copy(alpha = 0.14f) else ButtonBg.copy(alpha = 0.7f))
            .border(1.dp, if (selected) tint else Color.Transparent, shape)
            .then(clickMod)
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(18.dp).rotate(iconRotation))
        Text(label, color = if (selected) Color.White else Palette.TextPrimary, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: Color = Palette.AccentPurple, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) accent else Palette.TextMuted,
        fontSize = 11.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) accent else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Palette.TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
}

private class BrushInfo(val icon: ImageVector, val title: String, val sub: String, val size: Float)

/** Index = preset id in the Rust engine (brush_engine::set_preset). `size` = default thickness in px. */
private val Brushes = listOf(
    BrushInfo(DrawIcons.Brush, "Graphite Pencil", "Pressure Sensitivity", 8f),
    BrushInfo(DrawIcons.Palette, "Soft Airbrush", "Smooth Gradient", 60f),
    BrushInfo(DrawIcons.Eyedropper, "Studio Ink Pen", "Sharp Line Art", 6f),
    BrushInfo(DrawIcons.Zigzag, "Calligraphy", "Angled Stroke", 14f),
    BrushInfo(DrawIcons.ShapeLine, "Technical Pen", "Constant Hairline", 3f),
    BrushInfo(DrawIcons.Brush, "G-Pen", "Thick & Thin", 10f),
    BrushInfo(DrawIcons.ShapeLine, "Fineliner", "Clean Detail", 4f),
    BrushInfo(DrawIcons.Brush, "Mechanical Pencil", "Fine Graphite", 3f),
    BrushInfo(DrawIcons.Zigzag, "Charcoal", "Soft Dark Grain", 22f),
    BrushInfo(DrawIcons.Fill, "Marker", "Broad & Even", 36f),
    BrushInfo(DrawIcons.Waves, "Dry Brush", "Faint Streaks", 30f),
    BrushInfo(DrawIcons.Palette, "Watercolor Wash", "Soft Build-up", 70f),
)

private val Blends = listOf("Normal", "Multiply", "Screen", "Overlay", "Add")

private class PatternInfo(val id: Int, val icon: ImageVector, val title: String)

private val Patterns = listOf(
    PatternInfo(1, DrawIcons.Grid, "Gingham"),
    PatternInfo(2, DrawIcons.Diamond, "Argyle"),
    PatternInfo(3, DrawIcons.Waves, "Seigaiha"),
    PatternInfo(4, DrawIcons.Zigzag, "Houndstooth"),
    PatternInfo(5, DrawIcons.Plaid, "Plaid"),
    PatternInfo(6, DrawIcons.Flower, "Floral"),
    PatternInfo(7, DrawIcons.Select, "Custom"),
)

@Composable
private fun BrushPopup(state: DrawState, modifier: Modifier) {
    Popup("Brush Library", "Dynamics Active", Palette.AccentCyan, modifier) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OpButton(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.tool != Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.DRAW; state.closePanel() })
            OpButton(DrawIcons.Eraser, "Eraser", Palette.AccentPink, state.tool == Tool.ERASER, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.ERASER; state.closePanel() })
        }
        Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Brushes.chunked(2).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEachIndexed { c, b ->
                    val id = r * 2 + c
                    val sel = state.brushPreset == id
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.10f) else ButtonBg)
                            .border(1.dp, if (sel) Palette.AccentPurple else Palette.PanelBorder, RoundedCornerShape(12.dp))
                            .clickable { state.brushPreset = id; state.size = b.size; if (state.tool != Tool.ERASER) state.tool = Tool.DRAW; state.closePanel() }
                            .padding(10.dp),
                    ) {
                        Icon(b.icon, b.title, tint = if (sel) Palette.AccentPurple else Palette.TextMuted, modifier = Modifier.size(20.dp))
                        Text(b.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(b.sub, color = Palette.TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Blends.forEachIndexed { i, n -> Chip(n, state.blend == i) { state.blend = i; state.closePanel() } }
        }
        LabeledSlider("Streamline Stabilizer", "${state.stabilizer.toInt()}%", state.stabilizer, 0f..99f, Palette.AccentCyan) { state.stabilizer = it }
        Hint("Ukuran & opacity diatur lewat slider di sisi kiri kanvas.")
    }
}

@Composable
private fun PatternSection(state: DrawState, dd: DragDropState) {
    Text("PATTERN FILL", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    Patterns.chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { p ->
                val label = if (p.id == 7 && state.customPatternSize.isNotEmpty()) state.customPatternSize else p.title
                OpButton(
                    p.icon, label, Palette.AccentCyan, state.pattern == p.id, Modifier.weight(1f),
                    Modifier.dragSource(dd, DragPayload(p.id, state.color)) {
                        if (p.id == 7 && state.customPatternSize.isEmpty()) return@dragSource
                        state.pattern = if (state.pattern == p.id) 0 else p.id
                        state.tool = Tool.FILL
                        state.closePanel()
                    },
                )
            }
            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    Hint("Ketuk motif lalu ketuk kanvas (Fill), atau geser motif ke kanvas. Custom = objek yang kamu ubah jadi pola (menu Object > To Pattern).")
    LabeledSlider("Skala Motif", "${(state.patternScale * 100).toInt()}%", state.patternScale, 0.2f..5f, Palette.AccentCyan) { state.patternScale = it }
    if (state.customPatternSize.isNotEmpty()) CustomSizeEditor(state)
    LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }
}

/** Exact W x H (px) of the custom pattern motif, with aspect-ratio lock. Resamples the stored motif (max 2048). */
@Composable
private fun CustomSizeEditor(state: DrawState) {
    val parts = state.customPatternSize.split("×")
    val curW = parts.getOrNull(0)?.toIntOrNull() ?: return
    val curH = parts.getOrNull(1)?.toIntOrNull() ?: return
    var wText by remember(state.customPatternSize) { mutableStateOf(curW.toString()) }
    var hText by remember(state.customPatternSize) { mutableStateOf(curH.toString()) }
    var lock by remember { mutableStateOf(true) }
    val ratio = curW.toFloat() / curH.coerceAtLeast(1)
    Text("UKURAN MOTIF (px)", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            wText,
            { v ->
                val t = v.filter(Char::isDigit).take(4)
                wText = t
                if (lock) t.toIntOrNull()?.let { hText = (it / ratio).roundToInt().coerceIn(1, 2048).toString() }
            },
            label = { Text("W") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
            hText,
            { v ->
                val t = v.filter(Char::isDigit).take(4)
                hText = t
                if (lock) t.toIntOrNull()?.let { wText = (it * ratio).roundToInt().coerceIn(1, 2048).toString() }
            },
            label = { Text("H") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Chip("Kunci rasio", lock, Palette.AccentCyan) { lock = !lock }
        Chip("Terapkan", false, Palette.AccentCyan) {
            val w = (wText.toIntOrNull() ?: curW).coerceIn(1, 2048)
            val h = (hText.toIntOrNull() ?: curH).coerceIn(1, 2048)
            if (NativeEngine.nativeResizeCustomPattern(w, h)) state.customPatternSize = "${w}×${h}"
        }
    }
}

@Composable
private fun ColorPopup(state: DrawState, dd: DragDropState, modifier: Modifier) {
    Popup("Color Studio", "#%06X".format(state.color and 0xFFFFFF), Palette.AccentPink, modifier) {
        ColorPicker(
            color = state.color,
            onColor = { state.color = it },
            eyedropperActive = state.tool == Tool.EYEDROPPER,
            onEyedropper = { state.toggleEyedropper(); state.closePanel() },
            dd = dd,
            onSwatchPicked = { state.closePanel() },
        )
        Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.PanelBorder))
        PatternSection(state, dd)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Fill, "Fill", Palette.AccentCyan, state.tool == Tool.FILL, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.FILL; state.closePanel() })
            OpButton(DrawIcons.Wand, "Same Color", Palette.AccentPink, state.tool == Tool.SELECT_COLOR, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.SELECT_COLOR })
        }
        if (state.tool == Tool.SELECT_COLOR) {
            Hint("Ketuk warna di kanvas: semua piksel yang cocok (seluruh artboard) diganti ke warna aktif.")
            LabeledSlider("Toleransi Hue", "${state.tolH.toInt()}°", state.tolH, 0f..180f) { state.tolH = it }
            LabeledSlider("Toleransi Saturation", "${state.tolS.toInt()}%", state.tolS, 0f..100f) { state.tolS = it }
            LabeledSlider("Toleransi Luminance", "${state.tolL.toInt()}%", state.tolL, 0f..100f) { state.tolL = it }
        }
    }
}

private class ShapeInfo(val id: Int, val icon: ImageVector, val title: String)

private val ShapeList = listOf(
    ShapeInfo(0, DrawIcons.ShapeRect, "Rectangle"),
    ShapeInfo(1, DrawIcons.ShapeRounded, "Rounded"),
    ShapeInfo(2, DrawIcons.ShapeCircle, "Ellipse"),
    ShapeInfo(3, DrawIcons.ShapeTriangle, "Triangle"),
    ShapeInfo(4, DrawIcons.ShapeLine, "Line"),
    ShapeInfo(5, DrawIcons.ShapeDiamond, "Diamond"),
)

@Composable
private fun ShapesPopup(state: DrawState, modifier: Modifier) {
    Popup("Shapes", "Anti-aliased", Palette.AccentCyan, modifier) {
        ShapeList.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { sh ->
                    OpButton(
                        sh.icon, sh.title, Palette.AccentCyan, state.shapeKind == sh.id, Modifier.weight(1f),
                        Modifier.clickable { state.shapeKind = sh.id; state.tool = Tool.SHAPE; state.closePanel() },
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Fill", state.shapeFilled, Palette.AccentCyan) { state.shapeFilled = !state.shapeFilled; if (!state.shapeFilled && !state.shapeStroked) state.shapeStroked = true }
            Chip("Stroke", state.shapeStroked, Palette.AccentCyan) { state.shapeStroked = !state.shapeStroked; if (!state.shapeFilled && !state.shapeStroked) state.shapeFilled = true }
        }
        LabeledSlider("Tebal garis / outline", "${state.shapeStrokeW.toInt()} px", state.shapeStrokeW, 1f..60f, Palette.AccentCyan) { state.shapeStrokeW = it }
        Hint("Seret di kanvas untuk menggambar (ada preview langsung), lepas untuk menyelesaikan. Fill = warna aktif, Stroke = warna pendamping.")
    }
}

@Composable
private fun TransformPopup(state: DrawState, actions: EditActions, modifier: Modifier) {
    Popup("Transform", "View · Wrap · Mirror", AccentAmber, modifier) {
        Text("VIEW KANVAS", color = AccentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Undo, "-90°", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.rotateView(-90f); state.closePanel() })
            OpButton(DrawIcons.Redo, "+90°", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.rotateView(90f); state.closePanel() })
            OpButton(DrawIcons.Transform, "Level", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.resetRotation(); state.closePanel() })
            OpButton(DrawIcons.Fit, "Fit", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.fitView(); state.closePanel() })
        }
        Text("SEAMLESS REPEAT", color = AccentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Wrap, "Wrap Drag", AccentAmber, state.tool == Tool.WRAP, Modifier.weight(1f), Modifier.clickable { state.tool = if (state.tool == Tool.WRAP) Tool.DRAW else Tool.WRAP; state.closePanel() })
            OpButton(DrawIcons.Wrap, "Wrap ½", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { actions.wrapHalf(); state.closePanel() })
        }
        Hint("Wrap Drag: seret kanvas, bagian yang keluar dari tepi muncul di sisi seberang. Wrap ½ menggeser setengah artboard supaya sambungan tepi/sudut terlihat di tengah; gambar di sana lalu ulangi.")
        Text("SEAMLESS PAINT", color = AccentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Chip("Wrap paint", state.seamlessPaint, AccentAmber) { state.seamlessPaint = !state.seamlessPaint }
            Chip("Guide seamless", state.seamGuide, AccentAmber) { state.seamGuide = !state.seamGuide }
        }
        Hint("Wrap paint: goresan yang keluar dari tepi artboard muncul di sisi seberang, jadi pola langsung seamless. Guide seamless menampilkan tepi artboard dan garis tengah (letak sambungan setelah Wrap ½).")
        Text("GRID & GUIDE", color = AccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Chip("Grid", state.gridOn, AccentBlue) { state.gridOn = !state.gridOn }
            Chip("Snap", state.snapOn, AccentBlue) { state.snapOn = !state.snapOn }
            listOf(16, 32, 64, 128, 256).forEach { n -> Chip("$n", state.gridSize == n, AccentBlue) { state.gridSize = n; state.gridOn = true } }
        }
        Hint("Snap: saat memindahkan objek, tepi dan tengahnya menempel ke tepi/tengah artboard dan garis grid; garis bantu magenta muncul saat sejajar.")
        Text("MIRROR", color = Palette.AccentPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Close, "Off", Palette.TextMuted, state.symMode == 0, Modifier.weight(1f), Modifier.clickable { state.symMode = 0 })
            OpButton(DrawIcons.Symmetry, "Horizontal", Palette.AccentPurple, state.symMode == 1, Modifier.weight(1f), Modifier.clickable { state.symMode = 1 })
            OpButton(DrawIcons.Symmetry, "Vertical", Palette.AccentPurple, state.symMode == 2, Modifier.weight(1f), Modifier.clickable { state.symMode = 2 }, iconRotation = 90f)
            OpButton(DrawIcons.Flower, "Radial", Palette.AccentPurple, state.symMode == 3, Modifier.weight(1f), Modifier.clickable { state.symMode = 3 })
        }
        if (state.symMode == 3) {
            LabeledSlider("Jumlah Sektor", "${state.sectors}", state.sectors.toFloat(), 2f..12f) { state.sectors = it.toInt().coerceIn(2, 12) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mirror tiap sektor", color = Palette.TextMuted, fontSize = 12.sp)
                Switch(
                    checked = state.symMirror, onCheckedChange = { state.symMirror = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple),
                )
            }
        }
    }
}

@Composable
private fun FxPopup(state: DrawState, actions: EditActions, onArtboard: () -> Unit, modifier: Modifier) {
    var br by remember { mutableFloatStateOf(0f) }
    var ct by remember { mutableFloatStateOf(0f) }
    var hue by remember { mutableFloatStateOf(0f) }
    var sat by remember { mutableFloatStateOf(0f) }
    Popup("Crop & FX", "Adjust", Palette.AccentPink, modifier) {
        LabeledSlider("Brightness", "${br.toInt()}", br, -100f..100f, Palette.AccentPink) { br = it }
        LabeledSlider("Contrast", "${ct.toInt()}", ct, -100f..100f, Palette.AccentPink) { ct = it }
        LabeledSlider("Hue", "${hue.toInt()}°", hue, -180f..180f, Palette.AccentPink) { hue = it }
        LabeledSlider("Saturation", "${sat.toInt()}", sat, -100f..100f, Palette.AccentPink) { sat = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OpButton(DrawIcons.Wand, "Apply", Palette.AccentPink, br != 0f || ct != 0f || hue != 0f || sat != 0f, Modifier.weight(1f), Modifier.clickable {
                if (br != 0f || ct != 0f) actions.fx(2, br / 100f, ct / 100f)
                if (hue != 0f || sat != 0f) actions.fx(3, hue, sat / 100f)
                br = 0f; ct = 0f; hue = 0f; sat = 0f
                state.closePanel()
            })
            OpButton(DrawIcons.Invert, "Invert", Palette.AccentCyan, false, Modifier.weight(1f), Modifier.clickable { actions.fx(0, 0f, 0f); state.closePanel() })
            OpButton(DrawIcons.Palette, "Grayscale", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.fx(1, 0f, 0f); state.closePanel() })
            OpButton(DrawIcons.Crop, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
        Hint("FX diterapkan ke seluruh gambar (semua piksel berwarna) dan bisa di-Undo. Alpha/transparansi tidak berubah.")
    }
}

@Composable
private fun ObjectPopup(state: DrawState, actions: EditActions, modifier: Modifier) {
    val sel = state.selection
    Popup("Object", if (sel == null) "Select" else "${sel.w}×${sel.h}", AccentBlue, modifier) {
        if (sel == null) Text("Pilih tool Select, lalu seret kotak di sekeliling objek.", color = Palette.TextMuted, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OpButton(DrawIcons.Select, "Select", AccentBlue, state.tool == Tool.SELECT, Modifier.weight(1f), Modifier.clickable { state.tool = Tool.SELECT; state.closePanel() })
            OpButton(DrawIcons.Copy, "Duplikat", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.duplicate(); state.closePanel() })
            OpButton(DrawIcons.Copy, "Salin", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.copy(); state.closePanel() })
            OpButton(DrawIcons.Import, "Tempel", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { actions.paste(); state.closePanel() })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OpButton(DrawIcons.AlignLeft, "Kiri", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(0); state.closePanel() })
            OpButton(DrawIcons.AlignCenterH, "Tengah H", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(1); state.closePanel() })
            OpButton(DrawIcons.AlignRight, "Kanan", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(2); state.closePanel() })
            OpButton(DrawIcons.CenterBoth, "Tengah", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(6); state.closePanel() })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OpButton(DrawIcons.AlignTop, "Atas", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(3); state.closePanel() })
            OpButton(DrawIcons.AlignMiddle, "Tengah V", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(4); state.closePanel() })
            OpButton(DrawIcons.AlignBottom, "Bawah", AccentBlue, false, Modifier.weight(1f), Modifier.clickable { actions.align(5); state.closePanel() })
            OpButton(DrawIcons.Grid, "Pola", Palette.AccentCyan, false, Modifier.weight(1f), Modifier.clickable { actions.toPattern(); state.closePanel() })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Wrap di tepi artboard", color = Palette.TextMuted, fontSize = 11.sp)
            Switch(checked = state.wrapEdges, onCheckedChange = { state.wrapEdges = it }, colors = SwitchDefaults.colors(checkedTrackColor = AccentBlue))
        }
    }
}


@Composable
private fun ToolsPopup(onImport: () -> Unit, onExport: () -> Unit, onLayers: () -> Unit, onArtboard: () -> Unit, modifier: Modifier) {
    Popup("Tools", "Project", Palette.AccentCyan, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OpButton(DrawIcons.Import, "Import", Palette.AccentCyan, false, Modifier.weight(1f), Modifier.clickable { onImport() })
            OpButton(DrawIcons.Export, "Export", Palette.AccentPink, false, Modifier.weight(1f), Modifier.clickable { onExport() })
            OpButton(DrawIcons.Palette, "Paper", Palette.AccentPurple, false, Modifier.weight(1f), Modifier.clickable { onLayers() })
            OpButton(DrawIcons.Settings, "Artboard", AccentAmber, false, Modifier.weight(1f), Modifier.clickable { onArtboard() })
        }
    }
}

/** Dropdown popup for whichever panel is open. Place it TopEnd inside the canvas area. */
@Composable
fun PopupHost(
    state: DrawState,
    dd: DragDropState,
    actions: EditActions,
    onImport: () -> Unit,
    onExport: () -> Unit,
    onLayers: () -> Unit,
    onArtboard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (state.panel) {
        Panel.TOOLS -> ToolsPopup(onImport, onExport, onLayers, onArtboard, modifier)
        Panel.BRUSH -> BrushPopup(state, modifier)
        Panel.SHAPES -> ShapesPopup(state, modifier)
        Panel.TRANSFORM -> TransformPopup(state, actions, modifier)
        Panel.FX -> FxPopup(state, actions, onArtboard, modifier)
        Panel.COLOR -> ColorPopup(state, dd, modifier)
        Panel.OBJECT -> ObjectPopup(state, actions, modifier)
        Panel.LAYERS -> LayerPanel(state, actions, modifier)
    }
}

// ------------------------------------------------------------------ bottom nav pill

@Composable
private fun NavItem(icon: ImageVector, label: String, accent: Color, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Color.Transparent)
            .border(1.dp, if (selected) accent.copy(alpha = 0.35f) else Color.Transparent, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Icon(icon, label, tint = accent, modifier = Modifier.size(18.dp))
        Text(
            label,
            color = if (selected) accent else Palette.TextPrimary,
            fontSize = 14.sp, lineHeight = 16.sp, textAlign = TextAlign.Center,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** "BRUSH NAV | Brush  Shapes  Transform  Crop & FX | ✋" */
@Composable
fun BottomNav(state: DrawState, modifier: Modifier = Modifier) {
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            ToolChip(state)
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavItem(DrawIcons.Brush, "Brush", Palette.AccentPurple, state.group == Panel.BRUSH) { state.selectGroup(Panel.BRUSH) }
                NavItem(DrawIcons.Shapes, "Shapes", Palette.AccentCyan, state.group == Panel.SHAPES) { state.selectGroup(Panel.SHAPES) }
                NavItem(DrawIcons.Transform, "Transform", AccentAmber, state.group == Panel.TRANSFORM) { state.selectGroup(Panel.TRANSFORM) }
                NavItem(DrawIcons.Wand, "Crop\n& FX", Palette.AccentPink, state.group == Panel.FX) { state.selectGroup(Panel.FX) }
                NavItem(DrawIcons.Select, "Object", AccentBlue, state.group == Panel.OBJECT) { state.selectGroup(Panel.OBJECT) }
            }
            val hShape = RoundedCornerShape(16.dp)
            val handOn = state.tool == Tool.HAND
            Box(
                Modifier
                    .size(42.dp)
                    .clip(hShape)
                    .background(AccentGreen.copy(alpha = if (handOn) 0.28f else 0.12f))
                    .border(1.dp, AccentGreen.copy(alpha = if (handOn) 0.9f else 0.35f), hShape)
                    .clickable { state.toggleHand() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Hand, "Hand: geser kanvas", tint = AccentGreen, modifier = Modifier.size(22.dp))
            }
        }
    }
}

/** Replaces the old "BRUSH NAV" label: shows the ACTIVE tool (icon, name, size). Tap = switch Brush <-> Eraser. */
@Composable
private fun ToolChip(state: DrawState) {
    val (icon, name, accent) = when (state.tool) {
        Tool.DRAW -> Triple(DrawIcons.Brush, Brushes.getOrNull(state.brushPreset)?.title ?: "Brush", Palette.AccentPurple)
        Tool.ERASER -> Triple(DrawIcons.Eraser, "Eraser", Palette.AccentPink)
        Tool.FILL -> Triple(DrawIcons.Fill, "Fill", Palette.AccentCyan)
        Tool.SELECT_COLOR -> Triple(DrawIcons.Wand, "Pilih warna", Palette.AccentCyan)
        Tool.EYEDROPPER -> Triple(DrawIcons.Eyedropper, "Pipet", AccentBlue)
        Tool.HAND -> Triple(DrawIcons.Hand, "Geser", AccentGreen)
        Tool.SHAPE -> Triple(DrawIcons.Shapes, "Bentuk", Palette.AccentCyan)
        Tool.SELECT -> Triple(DrawIcons.Select, "Objek", AccentBlue)
        else -> Triple(DrawIcons.Transform, "Wrap", AccentAmber)
    }
    val showSize = state.tool == Tool.DRAW || state.tool == Tool.ERASER
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .width(98.dp)
            .clip(shape)
            .background(accent.copy(alpha = 0.12f))
            .border(1.dp, accent.copy(alpha = 0.6f), shape)
            .clickable { state.tool = if (state.tool == Tool.DRAW) Tool.ERASER else Tool.DRAW }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, name, tint = accent, modifier = Modifier.size(20.dp))
        Column {
            Text(name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (showSize) "${state.size.roundToInt()} px" else "aktif", color = Palette.TextMuted, fontSize = 10.sp, maxLines = 1)
        }
    }
}


// ------------------------------------------------------------------ layer drop-down (top bar chip)

private val LayerBlends = listOf(
    "Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light",
    "Darken", "Lighten", "Dodge", "Burn", "Difference", "Add",
)

@Composable
private fun LayerPanel(state: DrawState, actions: EditActions, modifier: Modifier) {
    var dragFrom by remember { mutableIntStateOf(-1) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    var expanded by remember { mutableStateOf(false) } // options of the active layer (tap the active layer again)
    var blendMenu by remember { mutableStateOf(false) }
    val rowPx = with(LocalDensity.current) { 44.dp.toPx() } // row 40dp + 4dp gap
    val tick = state.layerTick
    val count = state.layerCount
    val active = state.activeLayer
    val actInfo = remember(tick, active) { NativeEngine.nativeLayerInfo(active) }
    var opacity by remember(tick, active) { mutableFloatStateOf(((actInfo shr 8) and 255) * 100f / 255f) }
    val actBlend = ((actInfo shr 16) and 255).coerceIn(0, LayerBlends.lastIndex)
    val actLocked = actInfo and 2 != 0

    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Layers", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("$count/12", color = Palette.TextMuted, fontSize = 11.sp)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(Palette.AccentPurple.copy(alpha = 0.2f))
                        .clickable { if (NativeEngine.nativeLayerAdd() < 0) actions.toast("Maksimum 12 layer") else { expanded = false; actions.layersChanged() } },
                    contentAlignment = Alignment.Center,
                ) { Text("＋", color = Palette.AccentPurple, fontSize = 16.sp) }
            }
            Column(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in count - 1 downTo 0) { // top layer first
                    val inf = NativeEngine.nativeLayerInfo(i)
                    val vis = inf and 1 != 0
                    val locked = inf and 2 != 0
                    val sel = i == active
                    val bl = ((inf shr 16) and 255).coerceIn(0, LayerBlends.lastIndex)
                    val rowShape = RoundedCornerShape(10.dp)
                    Row(
                        Modifier.fillMaxWidth().height(40.dp)
                            .zIndex(if (dragFrom == i) 1f else 0f)
                            .graphicsLayer { if (dragFrom == i) { translationY = dragDy; alpha = 0.88f } }
                            .pointerInput(i, count) {
                                // long-press a row, then drag it up / down to re-order the layers
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragFrom = i; dragDy = 0f },
                                    onDrag = { change, amount -> change.consume(); dragDy += amount.y },
                                    onDragEnd = {
                                        val to = (i - (dragDy / rowPx).roundToInt()).coerceIn(0, count - 1) // list is top-first
                                        if (dragFrom >= 0 && to != dragFrom && NativeEngine.nativeLayerReorder(dragFrom, to)) actions.layersChanged()
                                        dragFrom = -1; dragDy = 0f
                                    },
                                    onDragCancel = { dragFrom = -1; dragDy = 0f },
                                )
                            }
                            .clip(rowShape)
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable {
                                if (sel) expanded = !expanded
                                else if (NativeEngine.nativeLayerSelect(i)) { expanded = false; actions.layersChanged() }
                            }
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(32.dp).clip(CircleShape).clickable { NativeEngine.nativeLayerSetVisible(i, !vis); actions.layersChanged() }, contentAlignment = Alignment.Center) {
                            Icon(DrawIcons.Eye, "Tampil", tint = if (vis) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
                        }
                        Text(
                            "Layer ${i + 1}", color = if (vis) Color.White else Palette.TextMuted, fontSize = 13.sp, maxLines = 1,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
                        )
                        if (bl != 0) Text(LayerBlends[bl], color = Palette.AccentCyan, fontSize = 10.sp, maxLines = 1)
                        if (locked) Text("🔒", fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
                        if (sel) Text(if (expanded) "▴" else "▾", color = Palette.TextMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp, end = 4.dp))
                    }
                }
            }
            if (expanded) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Palette.DarkBg.copy(alpha = 0.5f)).padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Opacity", color = Palette.TextMuted, fontSize = 11.sp, modifier = Modifier.width(52.dp))
                        Slider(
                            value = opacity,
                            onValueChange = { opacity = it; NativeEngine.nativeLayerSetOpacity(active, (it * 2.55f).roundToInt()); actions.layersRender() },
                            onValueChangeFinished = { actions.layersChanged() },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = Palette.AccentPurple, activeTrackColor = Palette.AccentPurple),
                            modifier = Modifier.weight(1f),
                        )
                        Text("${opacity.roundToInt()}%", color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(34.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Mode", color = Palette.TextMuted, fontSize = 11.sp, modifier = Modifier.width(52.dp))
                        Box {
                            Text(
                                "${LayerBlends[actBlend]} ▾", color = Palette.AccentCyan, fontSize = 12.sp,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { blendMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp),
                            )
                            DropdownMenu(expanded = blendMenu, onDismissRequest = { blendMenu = false }) {
                                LayerBlends.forEachIndexed { m, n ->
                                    DropdownMenuItem(
                                        text = { Text(n, fontSize = 13.sp) },
                                        onClick = { NativeEngine.nativeLayerSetBlend(active, m); blendMenu = false; actions.layersChanged() },
                                    )
                                }
                            }
                        }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MiniBtn("Duplikat") { if (NativeEngine.nativeLayerDuplicate() < 0) actions.toast("Maksimum 12 layer") else { expanded = false; actions.layersChanged() } }
                        MiniBtn("Gabung") {
                            if (NativeEngine.nativeLayerMergeDown()) { expanded = false; actions.layersChanged(); actions.toast("Digabung ke layer bawah (tidak bisa di-undo)") }
                            else actions.toast("Tidak ada layer di bawahnya")
                        }
                        MiniBtn(if (actLocked) "Buka kunci" else "Kunci", AccentAmber) { NativeEngine.nativeLayerSetLocked(active, !actLocked); actions.layersChanged() }
                        MiniBtn("Kosongkan", Palette.AccentPink) { actions.clearLayer() }
                        MiniBtn("Hapus", Palette.AccentPink) { if (NativeEngine.nativeLayerDelete()) { expanded = false; actions.layersChanged() } else actions.toast("Layer terakhir tidak bisa dihapus") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniBtn(text: String, color: Color = Palette.TextPrimary, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Text(
        text, color = color, fontSize = 11.sp, maxLines = 1,
        modifier = Modifier.clip(shape).border(1.dp, Palette.PanelBorder, shape).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

// ------------------------------------------------------------------ object pop-up bar (Select tool)

/** Floating pill shown while the Select tool is active: Duplikat · Salin · Tempel · Geser · Tengah. */
@Composable
fun ObjectQuickBar(state: DrawState, actions: EditActions, modifier: Modifier = Modifier) {
    val hasSel = state.selection != null
    FloatingPanel(modifier, shape = RoundedCornerShape(50)) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (hasSel) {
                QuickChip("Duplikat") { actions.duplicate() }
                QuickChip("Salin") { actions.copy() }
            }
            if (state.clipHas) QuickChip("Tempel") { actions.paste() }
            if (hasSel) {
                QuickChip("Geser", state.moveAnywhere) { state.moveAnywhere = !state.moveAnywhere }
                QuickChip("Tengah") { actions.align(6) }
                QuickChip("Putar", state.objXform) { state.objXform = !state.objXform }
                QuickChip("↻ 90°") { actions.rotate90() }
                QuickChip("Balik") { actions.flipH() }
                QuickChip("✕", false, Palette.TextMuted) { state.selection = null }
            }
        }
    }
}

@Composable
private fun QuickChip(text: String, on: Boolean = false, color: Color = Color.White, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Text(
        text, color = if (on) AccentBlue else color, fontSize = 12.sp, maxLines = 1,
        modifier = Modifier.clip(shape).background(if (on) AccentBlue.copy(alpha = 0.2f) else Color.Transparent).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 9.dp),
    )
}
