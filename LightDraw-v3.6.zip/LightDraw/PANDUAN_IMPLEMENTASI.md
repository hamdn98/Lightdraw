# Panduan implementasi — LightDraw v2 (Shapes, Object, Pattern, FX, AA, Export)

> Status: kode ditulis tanpa compiler (tidak ada Rust/Kotlin/Android SDK di lingkungan pembuat).
> Jalankan CI (`.github/workflows/build.yml`) dan kirim error kompilasi bila ada; perbaikannya biasanya kecil.

## 0. Fakta arsitektur yang menentukan cakupan
App ini = **satu layer raster** (tile sparse 256×256 di Rust) + paper. Tidak ada daftar objek vektor dan tidak ada multi-layer.
Karena itu:
* **"Objek" = seleksi kotak** (tool *Select*). Semua operasi objek bekerja pada piksel di dalam kotak.
* **Duplicate Layer belum ada** karena belum ada konsep layer (lihat §9 untuk rancangan).

## 1. Peta fitur → file

| Fitur | UI | Kotlin | Rust |
|---|---|---|---|
| Transform (view) | Transform ▸ VIEW | `CanvasGLView.rotateView/resetRotation`, `fitCanvas` | – |
| Transform (seamless) | Transform ▸ SEAMLESS | `Tool.WRAP`, `CanvasScreen.wrapBy` | `fx_engine::offset_wrap` |
| Mirror | Transform ▸ MIRROR | (tidak berubah) | `symmetry.rs` |
| FX | Crop & FX | `CanvasScreen` → `nativeApplyFx` | `fx_engine::apply_fx` |
| Shapes | Shapes | `Tool.SHAPE`, `CanvasGLView.dragMove/finishDrag` | `fx_engine::draw_shape`, `nativeShape` |
| Pattern | **Color** (bagian PATTERN FILL) | `FloatingToolbar.PatternSection` | `pattern_fill` (kind 1–6) |
| Select / Duplicate Object | Object | `duplicateSelection`, `moveSelection` | `fx_engine::move_region` |
| Align | Object ▸ ALIGN | `alignSelection` | `fx_engine::align_region` |
| Object → Pattern | Object ▸ To Pattern | `selectionToPattern` | `region_to_tile` + `pattern_fill` kind 7 |
| Anti-aliasing | otomatis | `CanvasRenderer` (filter) | `brush_engine::StrokeCov`, `draw_shape` |
| Export | Gallery ▸ Export | `ExportManager.exportJpeg/exportWebpLossless` | – |

## 2. Kenapa FX & Transform "tidak berfungsi"
Versi sebelumnya: *Transform* hanya membuka menu Mirror, *FX* hanya memilih tool Fill/Same-Color. Tidak ada transformasi atau efek sungguhan.
Sekarang: Transform = rotasi/level/fit kanvas + Wrap + Mirror; FX = Brightness, Contrast, Hue, Saturation, Invert, Grayscale (semua bisa Undo).
Bila popup tidak muncul sama sekali di perangkatmu, kirim logcat; penyebab paling mungkin ada di sisi layout yang belum bisa diuji di sini.

## 3. Struktur menu baru
Bottom nav: **Brush · Shapes · Transform · Crop & FX · Object** + tombol Hand.
Top toolbar: Tools · Artboard · Brush · Shapes · Transform · FX · Pathfinder · Object · Duplicate · (warna).
**Pattern pindah ke popup Color** (lingkaran warna kanan atas): roda warna → swatch → PATTERN FILL (Gingham…Floral + Custom) → Fill / Same Color.

## 4. Algoritma alignment (`fx_engine::align_region`)
1. `content_bounds`: pindai kotak seleksi, ambil bbox piksel dengan alpha > 0 → (bx0,by0,bx1,by1). Ini "objek" sebenarnya (kotak seleksi boleh longgar).
2. bw = bx1-bx0+1, bh = by1-by0+1, W/H = ukuran artboard.
3. Hitung delta:
   * Left: dx = -bx0 · Right: dx = W-1-bx1 · Center H: dx = (W-bw)/2 - bx0
   * Top: dy = -by0 · Bottom: dy = H-1-by1 · Center V: dy = (H-bh)/2 - by0
   * Center (both): dx dan dy center.
4. `move_region(rect, dx, dy, copy=false, wrap=false)` lalu kotak seleksi digeser sebesar (dx,dy).
"Snap to canvas" = mode Center.

## 5. Algoritma seamless / wrap
**a) Wrap Drag & Wrap ½ (`offset_wrap`)** — seluruh gambar: `new(x,y) = old((x-dx) mod W, (y-dy) mod H)`.
Baca semua piksel ke buffer (≤ 4096², 64 MB), tulis ulang per tile dengan modulo. Wrap ½ (dx=W/2, dy=H/2) memindahkan sambungan tepi/sudut ke tengah supaya bisa digambar ulang → hasilnya tile yang bisa diulang tanpa garis sambung.
**b) Seret objek melewati tepi (`move_region(wrap=true)`)** — tujuan: `ox = (x0+dx) mod W`. Bila `ox + w > W` kotak dipecah di seam menjadi maksimal 2×2 potongan dan tiap potongan ditempel (`paste_piece`) → bagian yang keluar tepi muncul di sisi seberang (juga sudut).
Batasan jujur: pergeseran dilakukan saat jari diangkat (outline kotak mengikuti jari), bukan preview piksel langsung.

## 6. Convert Object → Pattern
`region_to_tile` menyalin kotak seleksi (maks 2048², unpremultiply) ke penyimpanan global `CUSTOM` di `pattern_fill.rs`.
`pattern_color(kind=7, x, y)` = `tile[(y/scale) mod h][(x/scale) mod w]`, dievaluasi dalam koordinat global sehingga seamless antar-tile. Setelah konversi app otomatis memilih Fill + pola Custom; ketuk area manapun untuk mengisi (atau seret kartu Custom ke kanvas). Kotak seleksi = satuan ulang (repeat unit), jadi atur margin kotak untuk mengatur jarak antar objek.

## 7. Anti-aliasing — akar masalah & perbaikan
Masalah lama: tiap dab di-composite dengan `over`. Piksel di tepi goresan kena puluhan dab → alfa tepi menumpuk 1-∏(1-aᵢ) → tepi menebal & "bergerigi". Selain itu renderer memakai GL_NEAREST mulai zoom 2×.
Perbaikan:
1. **Max-coverage per goresan** (`StrokeCov`): peta coverage u8 per tile selama satu goresan. Dab baru hanya menaikkan coverage dari `old` ke `new` dengan alfa inkremental `a' = (new-old)/(1-old)`, sehingga hasil = `base*(1-new)+color*new` tanpa perlu menyimpan piksel asli. Opacity slider sekarang akurat (tidak menumpuk). Mode Multiply/Screen/Overlay/Add & airbrush tetap pakai jalur lama.
2. Rim tepi dab memakai profil **smoothstep** 1 px.
3. **Shapes**: signed-distance analitik, coverage = clamp(0.5 − sd, 0, 1) → tepi ±1 px halus untuk rect/rounded/ellipse/triangle/line/diamond.
4. GL: filter bilinear sampai zoom 8× (sebelumnya blok-blok pada 2×).

## 8. Export
* JPEG: kualitas dikunci **100** (slider dihapus). JPEG tetap lossy secara format; ini kualitas maksimum yang tersedia dari encoder Android.
* Untuk hasil **identik piksel**: PNG (streaming, resolusi penuh) atau **WebP lossless** (Android 11+).
* >16 MP: JPEG/WebP diperkecil otomatis (batas memori); gunakan PNG untuk resolusi penuh.

## 9. Rancangan Duplicate Layer (tahap berikutnya)
1. Rust: `Engine.canvas: TiledCanvas` → `layers: Vec<Layer { canvas, visible, opacity, blend, name }>` + `active: usize`.
2. Semua tool menulis ke `layers[active].canvas`; undo menyimpan `(layer_id, EditRecord)`.
3. `nativeDuplicateLayer(i)`: buat `TiledCanvas` baru, salin tile resident + tile yang di-spill (`copy_tile_bytes`) → sisipkan di i+1, jadikan aktif.
4. Renderer: gambar tiap layer dari bawah ke atas (satu texture-set per layer, blend di shader) ; export & `.ldproj` (versi `LDRW2`) menulis daftar layer.
5. UI: Layers dialog → daftar layer (visible, opacity, urutan, **Duplicate**, Delete, Merge).
Perkiraan: 1–2 minggu kerja karena menyentuh renderer, history, export dan format project.

## 10. Uji manual cepat
1. Gambar goresan opacity 50% bolak-balik → tidak boleh ada area lebih gelap di tumpang-tindih.
2. Shapes → seret ellipse: preview langsung, tepi halus; Undo menghapusnya.
3. Select kotak di sekeliling gambar → Align ▸ Center → objek ke tengah artboard.
4. Duplicate → salinan bergeser 24 px; seret salinan melewati tepi kanan dengan Wrap aktif → muncul di kiri.
5. Object ▸ To Pattern → Fill area kosong → pola berulang.
6. FX ▸ Invert / Grayscale / Brightness → Undo.
7. Export JPEG → tidak ada slider, file tersimpan 100%.

---
## 11. v3 — perubahan yang sudah digabung ke kode (belum dikompilasi)

| Area | File |
|---|---|
| Crash 8K–16K: batas memori tile keras (tile di viewport ikut di-evict) | `tiled_canvas.rs` (`evict_one(.., allow_viewport)`) |
| Fill bertahap di thread latar + progres + Batal (rollback) | `fill_job.rs`, `engine_core.rs` (`nativeFillBegin/Step/Cancel/Painted`), `CanvasGLView.runFill` |
| Pola Custom tanpa lock per piksel, ubah ukuran W×H | `pattern_fill.rs` (`CustomTile`, `paint_px`, `resize_custom`), `FloatingToolbar.CustomSizeEditor` |
| Wrap seamless untuk kanvas besar (hemat RAM) | `wrap_stream.rs`, `nativeOffsetWrap` |
| Export JPEG streaming sampai 45 MP + kualitas Medium/Maksimum | `export_stream.rs`, `ExportManager`, `ExportDialog` |
| Panik Rust tidak lagi mematikan app | `Cargo.toml` (`panic = "unwind"`), `guard()` di `engine_core.rs` |
| Auto-dismiss menu (pilih opsi / sentuh kanvas / drop) | `DrawState.closePanel`, `FloatingToolbar`, `CanvasGLView.onCanvasTouch` |
| HUD zoom %, eyedropper tekan-lama (450 ms) | `CanvasGLView` (`onZoomChanged`, `longPress`), `CanvasScreen` |
| Commit transform affine (dasar handle live) | `transform.rs`, `nativeTransformRegion` (UI handle belum dibuat) |

Belum ada: Duplicate Layer (butuh refactor multi-layer, lihat §9), overlay handle transform/warp di UI.
Tes cepat: kanvas 16384², zoom fit, Fill pola Gingham → tidak crash, ada pill "Mengisi… MP", Batal mengembalikan kanvas.

### 11.1 Isi menyatu dengan garis (fill di bawah tepi anti-alias)
`fill_job.rs`: piksel tepi setengah transparan (alpha 1–254) yang menempel pada area isian digabung sebagai
`piksel lama OVER isian`, jadi tidak ada lagi pinggiran pucat di antara isian dan garis. Hanya 1 piksel dari tepi;
untuk tepi kuas yang sangat lembut naikkan Toleransi Fill. Berlaku untuk isian baru (isian lama tidak berubah).

## 12. v3.1 — layer, mode fokus, brush (belum dikompilasi)

**Layer** (`layers.rs`, `engine_core.rs`, `CanvasScreen.LayersDialog`)
- Sampai 12 layer. `Engine.canvas` selalu = layer aktif, jadi semua tool lama (kuas, fill, wrap, align, import) otomatis mengedit layer aktif.
- Dialog Layers (Tools → Layers): pilih, tampil/sembunyi, kunci 🔒, opacity, + Baru, Duplikat, Hapus, Naik/Turun, Gabung ↓, Kosongkan.
- Layer terkunci: kuas, fill, bentuk, seleksi, FX, wrap, duplikat, align, import ditolak dengan pesan "Layer terkunci"; zoom/geser/pinch dan eyedropper tetap jalan.
- Tampilan, eyedropper, export PNG/JPEG, dan render memakai gabungan semua layer yang tampil.
- Memori: budget tile dibagi rata antar layer (minimal 48 tile per layer).

Batasan yang disengaja:
- Undo/redo **per layer** (riwayat ikut layer). Tambah/hapus/urut/gabung layer tidak bisa di-undo.
- `.ldproj` masih satu layer: saat disimpan dengan banyak layer, yang tersimpan hasil gabungan.
- Nama layer belum bisa diubah ("Layer n" menurut urutan).

**Mode Fokus**: tombol bulat kecil di pojok kanan bawah kanvas menyembunyikan toolbar atas dan nav bawah; pilihan diingat (SharedPreferences `lightdraw_ui`).

**Brush** (`brush_engine.rs`, `FloatingToolbar.kt`): 12 brush (Technical Pen, G-Pen, Fineliner, Mechanical Pencil, Charcoal, Marker, Dry Brush, Watercolor Wash ditambah 4 lama). Tiap brush punya ukuran awal sendiri yang otomatis dipakai saat dipilih; daftar bisa di-scroll.

**Belum dikerjakan**: handle transform/warp di layar, duplikat/tempel lewat gestur, garis bantu perataan, grup objek, bicubic, pinggiran antar-tile di renderer.

### 12.1 Perbaikan build (log CI 17 Okt)
Rust (3 ABI, termasuk `jpeg-encoder`) sudah lolos compile. Satu-satunya error Kotlin: `AnimatedVisibility` ambigu di dalam
`BoxWithConstraints` yang berada di dalam `Column`. HUD zoom diganti `animateFloatAsState` + `graphicsLayer`.

## 13. v3.2 — redesign navigasi (belum dikompilasi)
- **Bar atas**: `‹ Gallery` | **chip Layer ▾** | ⚙ Tools | warna. Chip menampilkan nama layer aktif, jumlah layer, badge 🔒 (border amber + teks "Terkunci") dan ikon mata bila layer tersembunyi. Ketuk = dropdown layer turun di bawah bar.
- **Dropdown Layer** (`Panel.LAYERS`, `LayerPanel`): daftar layer (atas dulu) dengan 👁 tampil, 🔒 kunci, status "aktif · tersembunyi · terkunci · %", slider opacity, tombol ＋ Baru / Duplikat / ↑ Naik / ↓ Turun / Gabung ↓ / Hapus / Kosongkan / Paper. Menutup otomatis saat kanvas disentuh.
- **Bar bawah**: label "BRUSH NAV" diganti **chip tool aktif** (ikon, nama brush/tool, ukuran px; ketuk = ganti Brush ↔ Eraser). Item: Brush, Shapes, Transform, Crop & FX, Object, **Path** (Pathfinder, dulu di bar atas), tombol ✋.
- Duplikat objek ada di panel Object, Artboard di Tools dan Crop & FX. Dialog Layers lama diganti dialog **Paper** (latar kanvas).

### 13.1 Isi tanpa halo di tepi goresan lunak
`fill_job.rs`: bila titik yang diketuk berada di area transparan, area isian = semua piksel yang alpha-nya tidak hampir solid
(batas alpha 96–250, naik bersama slider Toleransi; default ≈ 168), dan warna isian digambar **di bawah** piksel yang sudah ada
(`lama OVER isian`). Tepi kuas yang setengah transparan jadi menyatu rapi dengan warna baru, tanpa garis putus-putus/pinggiran.
Catatan: goresan sangat tipis/pudar (alpha di bawah batas) bisa ditembus isian; turunkan Toleransi untuk menahannya.

### 13.2 Isi ulang (ganti warna isian) tanpa jejak warna lama
Isian pertama bersifat opak, jadi piksel tepi goresan menyimpan campuran "warna goresan + warna isian lama". Pada isian ulang
`fill_job.rs`: (1) toleransi efektif minimal 40 agar sisa-sisa pudar ikut terganti, (2) piksel tepi yang berada pada garis
"warna isian lama → tetangga luarnya" diurai (estimasi rasio campuran) lalu dibangun ulang dengan warna baru. Piksel yang bukan
campuran dibiarkan. Ini heuristik: untuk hasil yang pasti bersih, gambar garis dan isian di layer terpisah (rencana: isian
otomatis di layer bawah).

## 14. v3.3 — goresan mulus (anti-alias, spacing, filter tekstur) (belum dikompilasi)
**Kenapa bukan MSAA:** kanvas digambar sebagai kuad bertekstur; MSAA hanya menghaluskan tepi poligon (kuad 256×256 yang tak terlihat), bukan isi tekstur.
Anti-alias goresan terjadi di Rust (coverage per piksel) dan saat tekstur ditampilkan (filter).

`brush_engine.rs`
- Tepi dab: rampa coverage 1 piksel **berpusat di tepi** (setengah dalam, setengah luar). Sebelumnya rampa 1 px seluruhnya di dalam tepi sehingga pena sangat tipis hanya mencapai ±50% opasitas (garis tipis terlihat putus/bintik).
- Spacing mengikuti **ukuran dab saat ini (tekanan)**, bukan ukuran nominal, dan langkah minimum turun 1.0 → 0.3 px (pena tipis tak lagi jadi rantai manik-manik).
- Blend goresan dihitung dari **piksel asli di bawah goresan** + warna×coverage (satu kali pembulatan), bukan penambahan bertahap per dab (pembulatan 8-bit bertumpuk membuat goresan opasitas rendah berbintik).
- Kurva Bézier dipecah 2× lebih rapat.

`CanvasRenderer.kt`
- Zoom-in: selalu `GL_LINEAR` (nearest di ≥8× dihapus → tidak ada kotak-kotak).
- Zoom-out (<100%): `GL_LINEAR_MIPMAP_LINEAR`; mip chain dibuat ulang (`glGenerateMipmap`) di setiap upload tile. Tanpa mipmap, garis tipis dilewati footprint bilinear 4 texel dan tampak putus-putus.

## 15. v3.4 — mode campur layer + urutkan layer dengan jari (belum dikompilasi)
- **Mode campur per layer** (`layers.rs`): Normal, Multiply, Screen, Overlay, Soft Light, Hard Light, Darken, Lighten, Color Dodge, Color Burn, Difference, Add. Rumus W3C pada piksel premultiplied; berlaku di tampilan, eyedropper, export, dan Gabung ↓. Duplikat layer ikut menyalin mode. Dipilih lewat deretan chip "Mode campur layer aktif" di dropdown Layer; nama mode tampil di baris layer.
- **Urutkan layer**: tahan sebuah baris layer lalu geser naik/turun, lepas untuk menjatuhkan (`nativeLayerReorder`). Layer aktif mengikuti isinya.
- Catatan: mode non-Normal dihitung per piksel (float), jadi sedikit lebih berat saat menggambar di kanvas besar dengan banyak layer ber-mode.

### 15.1 Perbaikan build (log CI 17 Okt 10:36)
Rust (3 ABI) lolos. Error Kotlin: `@Composable` nyasar di atas `private val LayerBlends` (FloatingToolbar.kt:918) → dihapus.

## 16. v3.5 — UI minimalis, menu Layer ala Procreate/ibis, Object pop-up, Copy/Paste (belum dikompilasi)
- **Menu Layer** (dropdown dari chip atas): daftar baris ramping (👁, nama, badge mode campur, 🔒 hanya bila terkunci). Ketuk layer = pilih; ketuk layer aktif lagi = buka opsi inline: slider Opacity, dropdown Mode campur, tombol Duplikat / Gabung / Kunci / Kosongkan / Hapus. Tombol ＋ di header. Urut ulang = tahan lalu geser baris. Tombol Naik/Turun dan deretan chip lama dihapus.
- **Paper** pindah ke Tools (dulu tombol di panel Layer). Tombol Layers di Tools diganti Paper (chip Layer di bar atas sudah membuka daftar layer).
- **Pathfinder dihapus** (nav item, panel, dan popup).
- **Pop-up Object** (pil mengambang di bawah kanvas saat tool Select aktif): Duplikat · Salin · Tempel · Geser · Tengah · ✕.
  - Salin: menyalin kotak seleksi dari layer aktif ke clipboard mesin (maks 16 MP).
  - Tempel: membuat **layer baru** di atas layer aktif, menaruh salinan di tengah artboard, lalu menyeleksinya agar bisa diseret. Bisa ditempel berulang.
  - Geser: bila aktif, menyeret di mana saja memindahkan seleksi (tanpa harus menyentuh di dalam kotak).
  - Tengah: rata tengah ke artboard (align 6).
- **Panel Object** (nav bawah) diringkas: Select / Duplikat / Salin / Tempel, 7 tombol Align, Pola, dan saklar Wrap.
- **Gaya**: semua popup memakai padding, sudut, judul, dan tombol yang lebih kecil; border tombol hanya muncul saat dipilih; chip Layer di bar atas satu baris.

## 17. v3.6 — grid & smart guide, seamless paint, putar objek dengan jari (belum dikompilasi)
- **Grid + snap** (Transform → GRID & GUIDE): garis grid 16/32/64/128/256 px (tiap 4 garis lebih tegas). Saat memindahkan seleksi, tepi dan tengah kotak menempel (±8 px layar) ke tepi/tengah artboard dan garis grid; garis bantu magenta muncul saat sejajar. Snap bisa dimatikan terpisah dari grid. (`CanvasGLView.snapMove`)
- **Seamless** (Transform → SEAMLESS PAINT): *Wrap paint* = dab yang melewati tepi artboard juga digambar di sisi seberang (`brush_engine::stamp_sym`, 3×3 salinan hanya bila menyentuh kanvas). *Guide seamless* = garis tepi artboard + garis silang tengah (letak sambungan setelah Wrap ½).
- **Putar objek dengan jari**: pilih objek (tool Select) → ketuk **Putar** di pil Object → dua jari memutar dan menskala objek terpilih (jangkar = tengah seleksi, jari menggeser = memindahkan; rotasi menempel ke kelipatan 15° bila dalam ±3°). Pratinjau berupa garis kerangka + label sudut/skala; piksel baru diterapkan saat jari diangkat (satu langkah undo, bilinear, `nativeTransformRegion`). Pil Object juga punya **↻ 90°** dan **Balik** (cermin horizontal). Dengan Putar mati, dua jari kembali memutar/zoom tampilan.
- Simetri (Horizontal / Vertical / Radial) sudah ada di Transform → MIRROR sejak v2.
