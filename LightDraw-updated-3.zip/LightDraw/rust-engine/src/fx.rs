//! Pixel effects for the FX menu. All functions work on premultiplied RGBA8 (`u32`, R in the low byte)
//! bitmaps and run either on a floating object or on the (cropped) content of the active layer.
//!
//! kind: 0 blur (a = radius px) | 1 sharpen (a = amount 0..3) | 2 brightness/contrast (a, b = -100..100)
//!       3 hue/saturation (a = hue shift degrees, b = saturation -100..100) | 4 invert | 5 grayscale
//!       6 pixelate (a = block size px)

use crate::color_engine::rgb_to_hsl;
use crate::tiled_canvas::{pack_rgba, premul, unpremul};

pub const BLUR: i32 = 0;
pub const SHARPEN: i32 = 1;
pub const BRIGHT_CONTRAST: i32 = 2;
pub const HUE_SAT: i32 = 3;
pub const INVERT: i32 = 4;
pub const GRAYSCALE: i32 = 5;
pub const PIXELATE: i32 = 6;

/// Transparent margin an effect needs around the content so that it can spread (blur halo).
pub fn margin_for(kind: i32, a: f32) -> usize {
    match kind {
        BLUR => (a.round().max(1.0) as usize) * 3,
        SHARPEN => 6,
        _ => 0,
    }
}

/// Blur one line with a box of radius `r` (window 2r+1, outside = transparent).
fn blur_line(src: &[u32], dst: &mut [u32], r: usize) {
    let n = src.len();
    if n == 0 {
        return;
    }
    let win = (2 * r + 1) as u32;
    for sh in [0u32, 8, 16, 24] {
        let mut sum: u32 = 0;
        for j in 0..=r.min(n - 1) {
            sum += (src[j] >> sh) & 255;
        }
        for i in 0..n {
            let v = (sum + win / 2) / win;
            dst[i] = (dst[i] & !(255u32 << sh)) | (v.min(255) << sh);
            // slide the window: add src[i + r + 1], drop src[i - r]
            if i + r + 1 < n {
                sum += (src[i + r + 1] >> sh) & 255;
            }
            if i >= r {
                sum -= (src[i - r] >> sh) & 255;
            }
        }
    }
}

fn box_blur_pass(buf: &mut [u32], w: usize, h: usize, r: usize) {
    if r == 0 || w == 0 || h == 0 {
        return;
    }
    // horizontal
    let mut out = vec![0u32; w];
    for y in 0..h {
        let row = &mut buf[y * w..(y + 1) * w];
        let src: Vec<u32> = row.to_vec();
        out.fill(0);
        blur_line(&src, &mut out, r);
        row.copy_from_slice(&out);
    }
    // vertical, 16 columns at a time for cache friendliness
    const STRIP: usize = 16;
    let mut tmp = vec![0u32; STRIP * h];
    let mut tmp_out = vec![0u32; h];
    let mut c0 = 0;
    while c0 < w {
        let cols = STRIP.min(w - c0);
        for y in 0..h {
            for k in 0..cols {
                tmp[k * h + y] = buf[y * w + c0 + k];
            }
        }
        for k in 0..cols {
            tmp_out.fill(0);
            blur_line(&tmp[k * h..(k + 1) * h], &mut tmp_out, r);
            for y in 0..h {
                buf[y * w + c0 + k] = tmp_out[y];
            }
        }
        c0 += cols;
    }
}

/// Gaussian-like blur: three box passes (sigma ~= radius).
pub fn gaussian_blur(buf: &mut [u32], w: usize, h: usize, radius: f32) {
    let r = radius.round().max(0.0) as usize;
    if r == 0 {
        return;
    }
    for _ in 0..3 {
        box_blur_pass(buf, w, h, r);
    }
}

pub fn sharpen(buf: &mut [u32], w: usize, h: usize, amount: f32) {
    let mut blurred = buf.to_vec();
    gaussian_blur(&mut blurred, w, h, 2.0);
    for (p, b) in buf.iter_mut().zip(blurred.iter()) {
        let a0 = (*p >> 24) as f32;
        let mut ch = [0f32; 4];
        for (k, sh) in [0u32, 8, 16, 24].into_iter().enumerate() {
            let o = ((*p >> sh) & 255) as f32;
            let bl = ((*b >> sh) & 255) as f32;
            ch[k] = (o + amount * (o - bl)).clamp(0.0, 255.0);
        }
        let a = ch[3].max(a0 * 0.0);
        for c in ch.iter_mut().take(3) {
            *c = c.min(a); // premultiplied: colour may never exceed alpha
        }
        *p = pack_rgba(ch[0] as u8, ch[1] as u8, ch[2] as u8, a as u8);
    }
}

fn hsl_to_rgb(h: f32, s: f32, l: f32) -> (f32, f32, f32) {
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = (h.rem_euclid(360.0)) / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r1, g1, b1) = match hp as i32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    let m = l - c * 0.5;
    (r1 + m, g1 + m, b1 + m)
}

/// Apply `f` to the straight (un-premultiplied) colour of every non-transparent pixel.
fn map_straight<F: Fn(f32, f32, f32) -> (f32, f32, f32)>(buf: &mut [u32], f: F) {
    for p in buf.iter_mut() {
        let a = *p >> 24;
        if a == 0 {
            continue;
        }
        let s = unpremul(*p);
        let (r, g, b) = f((s & 255) as f32, ((s >> 8) & 255) as f32, ((s >> 16) & 255) as f32);
        let q = |v: f32| v.round().clamp(0.0, 255.0) as u8;
        *p = premul(pack_rgba(q(r), q(g), q(b), a as u8));
    }
}

pub fn pixelate(buf: &mut [u32], w: usize, h: usize, block: usize) {
    let n = block.max(1);
    if n == 1 {
        return;
    }
    let mut by = 0;
    while by < h {
        let bh = n.min(h - by);
        let mut bx = 0;
        while bx < w {
            let bw = n.min(w - bx);
            let mut sum = [0u32; 4];
            for y in by..by + bh {
                for x in bx..bx + bw {
                    let p = buf[y * w + x];
                    for (k, sh) in [0u32, 8, 16, 24].into_iter().enumerate() {
                        sum[k] += (p >> sh) & 255;
                    }
                }
            }
            let cnt = (bw * bh) as u32;
            let avg = pack_rgba((sum[0] / cnt) as u8, (sum[1] / cnt) as u8, (sum[2] / cnt) as u8, (sum[3] / cnt) as u8);
            for y in by..by + bh {
                for x in bx..bx + bw {
                    buf[y * w + x] = avg;
                }
            }
            bx += bw;
        }
        by += bh;
    }
}

/// Run an effect. Returns false for an unknown kind.
pub fn apply(kind: i32, a: f32, b: f32, buf: &mut [u32], w: usize, h: usize) -> bool {
    match kind {
        BLUR => gaussian_blur(buf, w, h, a),
        SHARPEN => sharpen(buf, w, h, a.clamp(0.0, 4.0)),
        BRIGHT_CONTRAST => {
            let c = b.clamp(-100.0, 100.0) * 2.0;
            let f = (259.0 * (c + 255.0)) / (255.0 * (259.0 - c));
            let add = a.clamp(-100.0, 100.0) * 2.55;
            map_straight(buf, |r, g, bl| (f * (r - 128.0) + 128.0 + add, f * (g - 128.0) + 128.0 + add, f * (bl - 128.0) + 128.0 + add));
        }
        HUE_SAT => {
            let sat = 1.0 + b.clamp(-100.0, 100.0) / 100.0;
            map_straight(buf, |r, g, bl| {
                let (hh, s, l) = rgb_to_hsl(r as u8, g as u8, bl as u8);
                let (nr, ng, nb) = hsl_to_rgb(hh + a, (s * sat).clamp(0.0, 1.0), l);
                (nr * 255.0, ng * 255.0, nb * 255.0)
            });
        }
        INVERT => map_straight(buf, |r, g, bl| (255.0 - r, 255.0 - g, 255.0 - bl)),
        GRAYSCALE => map_straight(buf, |r, g, bl| {
            let y = 0.299 * r + 0.587 * g + 0.114 * bl;
            (y, y, y)
        }),
        PIXELATE => pixelate(buf, w, h, a.round().max(1.0) as usize),
        _ => return false,
    }
    true
}
