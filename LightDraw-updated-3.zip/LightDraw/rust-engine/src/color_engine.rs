//! Global "Select & Edit Same Color": HSL matching with Hue / Saturation / Luminance tolerances,
//! applied tile by tile (spilled tiles are loaded one at a time, so memory stays bounded).

use crate::tiled_canvas::{pack_rgba, unpremul, TiledCanvas};

#[derive(Clone, Copy)]
pub struct HslTolerance {
    pub hue_deg: f32, // 0..180
    pub sat: f32,     // 0..1
    pub lum: f32,     // 0..1
}

/// Returns (hue 0..360, saturation 0..1, lightness 0..1).
pub fn rgb_to_hsl(r: u8, g: u8, b: u8) -> (f32, f32, f32) {
    let r = r as f32 / 255.0;
    let g = g as f32 / 255.0;
    let b = b as f32 / 255.0;
    let mx = r.max(g).max(b);
    let mn = r.min(g).min(b);
    let l = (mx + mn) * 0.5;
    let d = mx - mn;
    if d < 1e-6 {
        return (0.0, 0.0, l);
    }
    let s = (d / (1.0 - (2.0 * l - 1.0).abs()).max(1e-6)).min(1.0);
    let h = if mx == r {
        ((g - b) / d).rem_euclid(6.0)
    } else if mx == g {
        (b - r) / d + 2.0
    } else {
        (r - g) / d + 4.0
    };
    (h * 60.0, s, l)
}

struct Matcher {
    h: f32,
    s: f32,
    l: f32,
    tol: HslTolerance,
}

impl Matcher {
    fn new(target_straight: u32, tol: HslTolerance) -> Self {
        let (h, s, l) = rgb_to_hsl(
            (target_straight & 255) as u8,
            ((target_straight >> 8) & 255) as u8,
            ((target_straight >> 16) & 255) as u8,
        );
        Matcher { h, s, l, tol }
    }

    fn test(&self, straight: u32) -> bool {
        let (h, s, l) = rgb_to_hsl(
            (straight & 255) as u8,
            ((straight >> 8) & 255) as u8,
            ((straight >> 16) & 255) as u8,
        );
        if (s - self.s).abs() > self.tol.sat || (l - self.l).abs() > self.tol.lum {
            return false;
        }
        // Hue is meaningless for near-grey colours.
        let grey_a = self.s < 0.08;
        let grey_b = s < 0.08;
        if grey_a || grey_b {
            return (grey_a && grey_b) || self.tol.hue_deg >= 179.0;
        }
        let dh = (h - self.h).abs();
        dh.min(360.0 - dh) <= self.tol.hue_deg
    }
}

/// Replace every pixel whose colour is "the same" as `target_px` (premultiplied canvas pixel)
/// with `new_color` (straight RGBA), keeping each pixel's own alpha. Returns replaced pixel count.
pub fn replace_same_color(canvas: &mut TiledCanvas, target_px: u32, new_color: u32, tol: HslTolerance) -> u32 {
    if target_px >> 24 == 0 {
        return 0;
    }
    let matcher = Matcher::new(unpremul(target_px), tol);
    let (nr, ng, nb) = (new_color & 255, (new_color >> 8) & 255, (new_color >> 16) & 255);

    let mut cache_p = 0u32;
    let mut cache_r = false;
    let mut test = |p: u32| -> bool {
        if p == cache_p {
            return cache_r;
        }
        let r = (p >> 24) != 0 && matcher.test(unpremul(p));
        cache_p = p;
        cache_r = r;
        r
    };

    let mut count = 0u32;
    for idx in 0..canvas.tile_count() {
        if !canvas.exists(idx) {
            continue;
        }
        let has = match canvas.tile_pixels(idx) {
            Some(px) => px.iter().any(|&p| test(p)),
            None => false,
        };
        if !has {
            continue;
        }
        let px = canvas.tile_mut(idx);
        for p in px.iter_mut() {
            if test(*p) {
                let a = *p >> 24;
                let f = |v: u32| -> u8 { ((v * a + 127) / 255) as u8 };
                *p = pack_rgba(f(nr), f(ng), f(nb), a as u8);
                count += 1;
            }
        }
    }
    count
}
