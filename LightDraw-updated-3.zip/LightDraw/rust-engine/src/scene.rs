//! The drawing scene: layer stack, cross-layer undo log, live overlays (stroke coverage and the
//! floating object), compositing and every object-level operation. Pure Rust (no JNI), so it can be
//! unit-tested on a desktop.
//!
//! ### How the pieces fit
//! * Every layer is its own sparse `TiledCanvas`. The GPU never sees layers: `composite_tile` flattens
//!   visible layers (plus the stroke overlay and the floating object, in the right z-order) into one
//!   tile, and `tile_version` tells the renderer when that tile must be re-uploaded.
//! * Undo/redo is a *log* of operations. A pixel edit is `Op::Edit(layer id)` and means "pop the top
//!   record of that layer's own tile-snapshot history". Adding/removing/moving layers are `Presence`
//!   and `Move` operations. Because the log is ordered, undo works across layers.
//! * A *floating object* (see `float_obj.rs`) is cut out of a layer by `select_*`, edited freely and
//!   baked back by `commit_float`.

use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::sync::Arc;

use crate::brush_engine::{blend_px, over, Blend, StrokeBuf};
use crate::float_obj::Float;
use crate::fx;
use crate::object_select::{self, LiftError, MAX_OBJECT_PIXELS};
use crate::pattern_fill::{Paint, TilePattern, CUSTOM_KIND_BASE};
use crate::shapes::{self, ShapeParams};
use crate::tiled_canvas::{read_u32, TiledCanvas, PROJECT_MAGIC_V1, TILE, TILE_PIXELS};

pub const MAX_LAYERS: usize = 8;
pub const MAX_PATTERNS: usize = 8;
const MAX_LOG: usize = 80;
const MAX_PATTERN_PIXELS: usize = 4_000_000;
const PROJECT_MAGIC_V2: &[u8; 5] = b"LDRW2";
const PROJECT_MAGIC_V3: &[u8; 5] = b"LDRW3";

pub struct Layer {
    pub id: u32,
    pub name: String,
    pub visible: bool,
    pub opacity: f32,
    /// How the layer is composited onto the layers below (never `Eraser`).
    pub blend: Blend,
    pub canvas: TiledCanvas,
}

enum Op {
    /// Pixel edit on the layer with this id (the pixels live in that canvas' own history).
    Edit(u32),
    /// A layer exists (`layer == None`) or was removed and is parked here (`Some`). Applying toggles.
    Presence { index: usize, layer: Option<Layer> },
    /// Move the layer currently at `from` to `to`; applying swaps the two so it is its own inverse.
    Move { from: usize, to: usize },
}

pub struct Scene {
    pub width: u32,
    pub height: u32,
    tiles_x: usize,
    tiles_y: usize,
    base_dir: PathBuf,
    budget: usize,
    pub layers: Vec<Layer>,
    pub active: usize,
    next_id: u32,
    name_counter: u32,
    epoch: u32,
    overlay_ver: Vec<u32>,
    pub stroke: Option<StrokeBuf>,
    pub float: Option<Float>,
    undo_log: Vec<Op>,
    redo_log: Vec<Op>,
    edit_layer: Option<u32>,
    pub patterns: Vec<Arc<TilePattern>>,
    next_pattern_slot: usize,
    /// Seamless repeat: strokes, shapes and dragged objects wrap around the canvas edges.
    pub wrap: bool,
    scratch: Vec<u32>,
    tile_buf: Vec<u32>,
    row_tmp: Vec<u32>,
}

/// Composite `src` (premultiplied) onto `out` with a layer blend mode.
#[inline]
fn blend_layer_mode(out: &mut [u32], src: &[u32], opacity: f32, mode: Blend) {
    if mode == Blend::Normal || mode == Blend::Eraser {
        blend_layer(out, src, opacity);
        return;
    }
    let op = opacity.clamp(0.0, 1.0);
    for (o, &s) in out.iter_mut().zip(src.iter()) {
        let a = s >> 24;
        if a == 0 {
            continue;
        }
        // premultiplied -> straight colour (R in the low byte, as blend_px expects)
        let un = |c: u32| ((c * 255 + a / 2) / a).min(255);
        let color = un(s & 255) | (un((s >> 8) & 255) << 8) | (un((s >> 16) & 255) << 16);
        *o = blend_px(*o, color, a as f32 * (1.0 / 255.0) * op, mode);
    }
}

#[inline]
fn blend_layer(out: &mut [u32], src: &[u32], opacity: f32) {
    if opacity >= 0.999 {
        for (o, &s) in out.iter_mut().zip(src.iter()) {
            if s != 0 {
                *o = over(*o, s);
            }
        }
    } else {
        let k = (opacity.clamp(0.0, 1.0) * 255.0 + 0.5) as u32;
        for (o, &s) in out.iter_mut().zip(src.iter()) {
            if s != 0 {
                let mut m = 0u32;
                for sh in [0u32, 8, 16, 24] {
                    m |= ((((s >> sh) & 255) * k + 127) / 255) << sh;
                }
                *o = over(*o, m);
            }
        }
    }
}

impl Scene {
    pub fn new(width: u32, height: u32, base_dir: PathBuf, budget: usize) -> Scene {
        let canvas = TiledCanvas::new(width, height, base_dir.clone(), budget);
        let layer = Layer { id: 1, name: "Layer 1".to_string(), visible: true, opacity: 1.0, blend: Blend::Normal, canvas };
        Scene::from_layers(base_dir, budget, vec![layer], 0, 2, 1)
    }

    fn from_layers(base_dir: PathBuf, budget: usize, layers: Vec<Layer>, active: usize, next_id: u32, name_counter: u32) -> Scene {
        let (width, height) = (layers[0].canvas.width, layers[0].canvas.height);
        let (tiles_x, tiles_y) = (layers[0].canvas.tiles_x, layers[0].canvas.tiles_y);
        let mut s = Scene {
            width,
            height,
            tiles_x,
            tiles_y,
            base_dir,
            budget,
            active: active.min(layers.len() - 1),
            layers,
            next_id,
            name_counter,
            epoch: 1,
            overlay_ver: vec![0; tiles_x * tiles_y],
            stroke: None,
            float: None,
            undo_log: Vec::new(),
            redo_log: Vec::new(),
            edit_layer: None,
            patterns: Vec::new(),
            next_pattern_slot: 0,
            wrap: false,
            scratch: Vec::new(),
            tile_buf: Vec::new(),
            row_tmp: Vec::new(),
        };
        s.rebalance();
        s
    }

    /// Delete every spill file (scene is being replaced).
    pub fn cleanup(&self) {
        for l in &self.layers {
            l.canvas.cleanup();
        }
        for op in self.undo_log.iter().chain(self.redo_log.iter()) {
            if let Op::Presence { layer: Some(l), .. } = op {
                l.canvas.cleanup();
            }
        }
    }

    pub fn tile_count(&self) -> usize {
        self.tiles_x * self.tiles_y
    }

    pub fn tiles_x(&self) -> usize {
        self.tiles_x
    }

    /// Active layer canvas.
    pub fn cv(&mut self) -> &mut TiledCanvas {
        let a = self.active;
        &mut self.layers[a].canvas
    }

    fn layer_idx(&self, id: u32) -> Option<usize> {
        self.layers.iter().position(|l| l.id == id)
    }

    fn rebalance(&mut self) {
        let n = self.layers.len().max(1);
        let per = (self.budget / n).max(64);
        let hist = ((96usize * 1024 * 1024) / n).max(24 * 1024 * 1024);
        for l in &mut self.layers {
            l.canvas.max_resident = per;
            l.canvas.max_history_bytes = hist;
        }
    }

    pub fn set_viewport(&mut self, tx0: i32, ty0: i32, tx1: i32, ty1: i32) {
        for l in &mut self.layers {
            l.canvas.set_viewport(tx0, ty0, tx1, ty1);
        }
    }

    // ---------------------------------------------------------------- dirty tracking

    fn bump_tile(&mut self, idx: usize) {
        if idx < self.overlay_ver.len() {
            self.overlay_ver[idx] = self.overlay_ver[idx].wrapping_add(1);
        }
    }

    fn bump_rect(&mut self, r: Option<(i32, i32, i32, i32)>) {
        if let Some((tx0, ty0, tx1, ty1)) = r {
            for ty in ty0..=ty1 {
                for tx in tx0..=tx1 {
                    self.bump_tile(ty as usize * self.tiles_x + tx as usize);
                }
            }
        }
    }

    fn bump_float(&mut self) {
        let r = self.float.as_ref().and_then(|f| f.tile_rect(self.width as i32, self.height as i32));
        self.bump_rect(r);
    }

    fn flush_stroke_dirty(&mut self) {
        let d = self.stroke.as_mut().map(|s| s.take_dirty()).unwrap_or_default();
        for i in d {
            self.bump_tile(i);
        }
    }

    pub fn bump_all(&mut self) {
        self.epoch = self.epoch.wrapping_add(1);
    }

    // ---------------------------------------------------------------- history plumbing

    /// Open an edit on the active layer (every pixel-changing operation goes through this).
    pub fn begin_edit(&mut self) {
        self.finish_edit();
        let a = self.active;
        self.layers[a].canvas.begin_edit();
        self.edit_layer = Some(self.layers[a].id);
    }

    /// Close the open edit and log it (if it changed anything).
    pub fn finish_edit(&mut self) {
        if let Some(id) = self.edit_layer.take() {
            if let Some(i) = self.layer_idx(id) {
                if self.layers[i].canvas.end_edit() {
                    self.push_op(Op::Edit(id));
                }
            }
        }
    }

    /// Run a pixel edit on the active layer as one undo step (commits a floating object first).
    pub fn edit<R, F: FnOnce(&mut TiledCanvas) -> R>(&mut self, f: F) -> R {
        self.commit_float();
        self.begin_edit();
        let a = self.active;
        let r = f(&mut self.layers[a].canvas);
        self.finish_edit();
        self.bump_all();
        r
    }

    fn push_op(&mut self, op: Op) {
        self.undo_log.push(op);
        self.drop_redo();
        while self.undo_log.len() > MAX_LOG {
            if let Op::Presence { layer: Some(l), .. } = self.undo_log.remove(0) {
                l.canvas.cleanup();
            }
        }
    }

    fn drop_redo(&mut self) {
        for op in self.redo_log.drain(..) {
            if let Op::Presence { layer: Some(l), .. } = op {
                l.canvas.cleanup();
            }
        }
        for l in &mut self.layers {
            l.canvas.clear_redo();
        }
    }

    fn apply_op(&mut self, op: &mut Op, undoing: bool) -> bool {
        match op {
            Op::Edit(id) => match self.layer_idx(*id) {
                Some(i) => {
                    let c = &mut self.layers[i].canvas;
                    if undoing {
                        c.undo()
                    } else {
                        c.redo()
                    }
                }
                None => false,
            },
            Op::Presence { index, layer } => match layer.take() {
                Some(l) => {
                    let at = (*index).min(self.layers.len());
                    self.layers.insert(at, l);
                    *index = at;
                    self.active = at;
                    self.rebalance();
                    true
                }
                None => {
                    if *index < self.layers.len() && self.layers.len() > 1 {
                        *layer = Some(self.layers.remove(*index));
                        self.active = self.active.min(self.layers.len() - 1);
                        self.rebalance();
                        true
                    } else {
                        false
                    }
                }
            },
            Op::Move { from, to } => {
                if *from < self.layers.len() && *to < self.layers.len() {
                    let l = self.layers.remove(*from);
                    self.layers.insert(*to, l);
                    self.active = *to;
                    std::mem::swap(from, to);
                    true
                } else {
                    false
                }
            }
        }
    }

    pub fn can_undo(&self) -> bool {
        self.float.is_some() || !self.undo_log.is_empty()
    }

    pub fn can_redo(&self) -> bool {
        !self.redo_log.is_empty()
    }

    pub fn undo(&mut self) -> bool {
        if self.stroke.is_some() {
            return false;
        }
        self.finish_edit();
        if let Some(f) = self.float.take() {
            // Undo while an object is floating = put everything back as it was before it was lifted.
            let r = f.tile_rect(self.width as i32, self.height as i32);
            self.bump_rect(r);
            if f.lifted && matches!(self.undo_log.last(), Some(Op::Edit(id)) if *id == f.layer_id) {
                self.undo_log.pop();
                if let Some(i) = self.layer_idx(f.layer_id) {
                    self.layers[i].canvas.undo_and_forget();
                }
            }
            self.bump_all();
            return true;
        }
        while let Some(mut op) = self.undo_log.pop() {
            let ok = self.apply_op(&mut op, true);
            self.redo_log.push(op);
            if ok {
                self.bump_all();
                return true;
            }
        }
        false
    }

    pub fn redo(&mut self) -> bool {
        if self.stroke.is_some() || self.float.is_some() {
            return false;
        }
        self.finish_edit();
        while let Some(mut op) = self.redo_log.pop() {
            let ok = self.apply_op(&mut op, false);
            self.undo_log.push(op);
            if ok {
                self.bump_all();
                return true;
            }
        }
        false
    }

    // ---------------------------------------------------------------- layers

    fn new_canvas(&self) -> TiledCanvas {
        TiledCanvas::new(self.width, self.height, self.base_dir.clone(), self.budget)
    }

    pub fn add_layer(&mut self) -> bool {
        if self.layers.len() >= MAX_LAYERS {
            return false;
        }
        self.commit_float();
        self.finish_edit();
        // lowest free "Layer N": after deleting layers the numbering starts over instead of counting on to 10
        let mut n = 1u32;
        while self.layers.iter().any(|l| l.name == format!("Layer {}", n)) {
            n += 1;
        }
        self.name_counter = n;
        let layer = Layer {
            id: self.next_id,
            name: format!("Layer {}", n),
            visible: true,
            opacity: 1.0,
            blend: Blend::Normal,
            canvas: self.new_canvas(),
        };
        self.next_id += 1;
        let at = self.active + 1;
        self.layers.insert(at, layer);
        self.active = at;
        self.push_op(Op::Presence { index: at, layer: None });
        self.rebalance();
        self.bump_all();
        true
    }

    /// Copy the active layer (all pixels, visibility and opacity) and put the copy above it.
    pub fn duplicate_layer(&mut self) -> bool {
        if self.layers.len() >= MAX_LAYERS {
            return false;
        }
        self.commit_float();
        self.finish_edit();
        let mut canvas = self.new_canvas();
        let a = self.active;
        canvas.copy_from(&mut self.layers[a].canvas);
        let layer = Layer {
            id: self.next_id,
            name: format!("{} copy", self.layers[a].name),
            visible: self.layers[a].visible,
            opacity: self.layers[a].opacity,
            blend: self.layers[a].blend,
            canvas,
        };
        self.next_id += 1;
        let at = a + 1;
        self.layers.insert(at, layer);
        self.active = at;
        self.push_op(Op::Presence { index: at, layer: None });
        self.rebalance();
        self.bump_all();
        true
    }

    pub fn delete_layer(&mut self) -> bool {
        if self.layers.len() <= 1 {
            return false;
        }
        self.commit_float();
        self.finish_edit();
        let at = self.active;
        let layer = self.layers.remove(at);
        self.active = at.min(self.layers.len() - 1);
        self.push_op(Op::Presence { index: at, layer: Some(layer) });
        self.rebalance();
        self.bump_all();
        true
    }

    /// Move layer `from` to position `to` (index 0 = bottom).
    pub fn move_layer(&mut self, from: usize, to: usize) -> bool {
        if from >= self.layers.len() || to >= self.layers.len() || from == to {
            return false;
        }
        self.commit_float();
        self.finish_edit();
        let l = self.layers.remove(from);
        self.layers.insert(to, l);
        self.active = to;
        self.push_op(Op::Move { from: to, to: from });
        self.bump_all();
        true
    }

    pub fn set_active(&mut self, i: usize) {
        if i < self.layers.len() && i != self.active {
            self.commit_float();
            self.finish_edit();
            self.active = i;
        }
    }

    pub fn set_visible(&mut self, i: usize, v: bool) {
        if i < self.layers.len() {
            if i == self.active {
                self.commit_float();
            }
            self.layers[i].visible = v;
            self.bump_all();
        }
    }

    pub fn set_opacity(&mut self, i: usize, o: f32) {
        if i < self.layers.len() {
            self.layers[i].opacity = o.clamp(0.0, 1.0);
            self.bump_all();
        }
    }

    pub fn set_blend(&mut self, i: usize, b: Blend) {
        if i < self.layers.len() {
            self.layers[i].blend = if b == Blend::Eraser { Blend::Normal } else { b };
            self.bump_all();
        }
    }

    pub fn layer_blend(&self, i: usize) -> i32 {
        self.layers.get(i).map_or(0, |l| l.blend.id())
    }

    pub fn clear_active_layer(&mut self) {
        // `clear_tiles` (not `clear_all`): the scene already owns the surrounding edit / history record.
        self.edit(|c| c.clear_tiles());
    }

    // ---------------------------------------------------------------- stroke overlay

    /// Start a brush stroke (or a shape preview) on the active layer.
    pub fn start_stroke(&mut self, color: u32, blend: Blend, opacity: f32, accumulate: bool) {
        self.commit_float();
        self.finish_edit();
        if let Some(old) = self.stroke.take() {
            for &i in old.touched_tiles() {
                self.bump_tile(i);
            }
        }
        let mut b = StrokeBuf::new(self.width as i32, self.height as i32, self.tiles_x, self.tiles_y, color, blend, opacity);
        b.accumulate = accumulate;
        b.wrap = self.wrap;
        self.stroke = Some(b);
    }

    /// Call after feeding dabs so the renderer re-uploads the touched tiles.
    pub fn stroke_changed(&mut self) {
        self.flush_stroke_dirty();
    }

    /// Bake the stroke coverage into the active layer as one undo step.
    pub fn end_stroke(&mut self) {
        let buf = match self.stroke.take() {
            Some(b) => b,
            None => return,
        };
        if !buf.is_empty() {
            self.begin_edit();
            let a = self.active;
            for &idx in buf.touched_tiles() {
                if buf.blend == Blend::Eraser && !self.layers[a].canvas.exists(idx) {
                    continue;
                }
                let px = self.layers[a].canvas.tile_mut(idx);
                buf.apply_to(idx, px);
            }
            self.finish_edit();
        }
        for &i in buf.touched_tiles() {
            self.bump_tile(i);
        }
    }

    /// Throw the stroke away: the layer was never touched.
    pub fn cancel_stroke(&mut self) {
        if let Some(buf) = self.stroke.take() {
            for &i in buf.touched_tiles() {
                self.bump_tile(i);
            }
        }
    }

    /// Redraw the shape preview. `paint` only matters for filled shapes.
    pub fn shape_update(&mut self, p: &ShapeParams, color: u32, paint: Paint, opacity: f32, blend: Blend) {
        if self.stroke.is_none() {
            self.start_stroke(color, blend, opacity, false);
        }
        let wrap = self.wrap;
        if let Some(buf) = self.stroke.as_mut() {
            buf.color = color;
            buf.opacity = opacity;
            buf.blend = blend;
            buf.wrap = wrap;
            buf.paint = if p.outline || p.kind == shapes::LINE || paint.kind == 0 { None } else { Some(paint) };
            shapes::render(buf, p);
        }
        self.flush_stroke_dirty();
    }

    /// Build a paint for the fill / shape tools (`kind >= 100` selects a user pattern).
    pub fn make_paint(&self, kind: i32, c1: u32, c2: u32, scale: f32) -> Paint {
        let k = kind.clamp(0, 255) as u8;
        let custom = if k >= CUSTOM_KIND_BASE { self.patterns.get((k - CUSTOM_KIND_BASE) as usize).cloned() } else { None };
        let kind = if k >= CUSTOM_KIND_BASE && custom.is_none() { 0 } else { k };
        Paint { kind, c1, c2, scale: scale.max(0.05), custom }
    }

    // ---------------------------------------------------------------- floating object

    pub fn has_float(&self) -> bool {
        self.float.is_some()
    }

    fn lift_result(&mut self, r: Result<object_select::Lifted, LiftError>) -> i32 {
        match r {
            Ok(l) => {
                self.finish_edit();
                let id = self.layers[self.active].id;
                let mut f = Float::new(id, l.w, l.h, l.px, l.x0, l.y0, true);
                f.wrap = self.wrap;
                self.float = Some(f);
                self.bump_all();
                0
            }
            Err(e) => {
                self.finish_edit();
                match e {
                    LiftError::Nothing => 1,
                    LiftError::TooLarge => 2,
                }
            }
        }
    }

    /// Put a bitmap (premultiplied RGBA, top-left at (x0, y0)) on the canvas as a floating object, so it
    /// can be moved / scaled / rotated before it is baked into the active layer. Returns false if too large.
    pub fn import_float(&mut self, px: Vec<u32>, w: usize, h: usize, x0: i32, y0: i32) -> bool {
        if w == 0 || h == 0 || px.len() != w * h || w * h > MAX_OBJECT_PIXELS {
            return false;
        }
        self.commit_float();
        self.finish_edit();
        let id = self.layers[self.active].id;
        let mut f = Float::new(id, w, h, px, x0, y0, false);
        f.wrap = self.wrap;
        self.float = Some(f);
        self.bump_all();
        true
    }

    /// Select the connected object under (x, y) on the active layer. 0 ok, 1 nothing there, 2 too large.
    pub fn select_at(&mut self, x: i32, y: i32) -> i32 {
        self.commit_float();
        self.begin_edit();
        let a = self.active;
        let r = object_select::lift_component(&mut self.layers[a].canvas, x, y);
        self.lift_result(r)
    }

    pub fn select_rect(&mut self, x0: i32, y0: i32, x1: i32, y1: i32) -> i32 {
        self.commit_float();
        self.begin_edit();
        let a = self.active;
        let r = object_select::lift_rect(&mut self.layers[a].canvas, x0.min(x1), y0.min(y1), x0.max(x1), y0.max(y1));
        self.lift_result(r)
    }

    pub fn select_all(&mut self) -> i32 {
        self.commit_float();
        self.begin_edit();
        let a = self.active;
        let r = object_select::lift_all(&mut self.layers[a].canvas);
        self.lift_result(r)
    }

    /// Bake the floating object (every wrapped copy) into its layer.
    ///
    /// If the object was lifted out of this layer, "lift" and "commit" are fused into **one** undo
    /// step, so a single undo after moving an object puts it back where it was.
    pub fn commit_float(&mut self) {
        let mut f = match self.float.take() {
            Some(f) => f,
            None => return,
        };
        f.snap();
        let li = match self.layer_idx(f.layer_id) {
            Some(i) => i,
            None => return,
        };
        self.finish_edit();
        let merge = f.lifted && matches!(self.undo_log.last(), Some(Op::Edit(id)) if *id == f.layer_id);
        let before = self.undo_log.len();
        let (cw, ch) = (self.width as i32, self.height as i32);
        let rect = f.tile_rect(cw, ch);
        if let Some((tx0, ty0, tx1, ty1)) = rect {
            self.layers[li].canvas.begin_edit();
            self.edit_layer = Some(f.layer_id);
            for ty in ty0..=ty1 {
                for tx in tx0..=tx1 {
                    let idx = ty as usize * self.tiles_x + tx as usize;
                    let px = self.layers[li].canvas.tile_mut(idx);
                    f.draw_into_tile(tx * TILE as i32, ty * TILE as i32, px, cw, ch);
                }
            }
            self.finish_edit();
        }
        if merge && self.undo_log.len() == before + 1 {
            // log: [.., Edit(lift), Edit(commit)] -> keep only Edit(lift) and fuse the canvas records
            self.undo_log.pop();
            if !self.layers[li].canvas.merge_last_two() {
                self.undo_log.push(Op::Edit(f.layer_id));
            }
        }
        self.bump_rect(rect);
        self.bump_all();
    }

    /// Discard the floating object. If it was cut from the layer the pixels stay removed (undoable).
    pub fn delete_float(&mut self) {
        if let Some(f) = self.float.take() {
            let r = f.tile_rect(self.width as i32, self.height as i32);
            self.bump_rect(r);
            self.bump_all();
        }
    }

    /// Run `f` on the floating object, keeping the dirty tiles of the old and new position in sync.
    fn with_float<R, F: FnOnce(&mut Float) -> R>(&mut self, f: F) -> Option<R> {
        self.bump_float();
        let r = self.float.as_mut().map(f);
        self.bump_float();
        r
    }

    pub fn float_move(&mut self, dx: f32, dy: f32) {
        let (w, h) = (self.width as f32, self.height as f32);
        self.with_float(|f| {
            f.cx += dx;
            f.cy += dy;
            if f.wrap {
                // Seamless repeat: the centre re-enters from the opposite edge; the draw routine already
                // shows the wrapped copies, so nothing visible jumps.
                f.cx = f.cx.rem_euclid(w);
                f.cy = f.cy.rem_euclid(h);
            }
        });
    }

    /// Absolute uniform scale (1.0 = 100 %) and rotation in degrees.
    pub fn float_set_transform(&mut self, scale: f32, rot_deg: f32) {
        self.with_float(|f| {
            f.scale = scale.clamp(0.05, 16.0);
            f.rot = rot_deg.to_radians();
        });
    }

    pub fn float_flip(&mut self, horizontal: bool) {
        self.with_float(|f| {
            if horizontal {
                f.flip_h()
            } else {
                f.flip_v()
            }
        });
    }

    pub fn float_rotate90(&mut self, clockwise: bool) {
        self.with_float(|f| {
            f.rotate90(clockwise);
            f.snap();
        });
    }

    pub fn set_wrap(&mut self, on: bool) {
        self.wrap = on;
        self.with_float(|f| f.wrap = on);
        if let Some(s) = self.stroke.as_mut() {
            s.wrap = on;
        }
    }

    pub fn float_hit(&self, x: f32, y: f32) -> bool {
        self.float.as_ref().map_or(false, |f| f.hit(x, y, self.width as i32, self.height as i32))
    }

    /// [scale, rotation degrees, wrap(0/1), min_x, min_y, max_x, max_y] of the floating object.
    pub fn float_info(&self) -> Option<[f32; 7]> {
        self.float.as_ref().map(|f| {
            let (a, b, c, d) = f.aabb();
            [f.scale, f.rot.to_degrees(), if f.wrap { 1.0 } else { 0.0 }, a, b, c, d]
        })
    }

    pub fn float_corners(&self) -> Option<[(f32, f32); 4]> {
        self.float.as_ref().map(|f| f.corners())
    }

    // ---------------------------------------------------------------- alignment

    /// Align the object to the canvas. If nothing is selected the whole content of the layer is used.
    /// `mode`: 0 left, 1 centre horizontally, 2 right, 3 top, 4 centre vertically, 5 bottom, 6 centre on canvas.
    pub fn align(&mut self, mode: i32) -> i32 {
        if self.float.is_none() {
            let r = self.select_all();
            if r != 0 {
                return r;
            }
        }
        let (cw, ch) = (self.width as f32, self.height as f32);
        self.with_float(|f| {
            let (x0, y0, x1, y1) = f.aabb();
            let (mut dx, mut dy) = (0.0, 0.0);
            match mode {
                0 => dx = -x0,
                1 => dx = cw * 0.5 - (x0 + x1) * 0.5,
                2 => dx = cw - x1,
                3 => dy = -y0,
                4 => dy = ch * 0.5 - (y0 + y1) * 0.5,
                5 => dy = ch - y1,
                _ => {
                    dx = cw * 0.5 - (x0 + x1) * 0.5;
                    dy = ch * 0.5 - (y0 + y1) * 0.5;
                }
            }
            f.cx += dx;
            f.cy += dy;
            f.snap();
        });
        0
    }

    // ---------------------------------------------------------------- duplicate

    /// Leave the current object in place and continue with an offset copy of it. With nothing
    /// selected, the whole layer content is duplicated.
    pub fn duplicate_object(&mut self) -> i32 {
        if self.float.is_none() {
            let r = self.select_all();
            if r != 0 {
                return r;
            }
        }
        let f = self.float.as_ref().unwrap();
        let mut copy = Float {
            layer_id: f.layer_id,
            w: f.w,
            h: f.h,
            px: f.px.clone(),
            cx: f.cx,
            cy: f.cy,
            scale: f.scale,
            rot: f.rot,
            wrap: f.wrap,
            lifted: false,
        };
        let off = (f.w.max(f.h) as f32 * 0.05).clamp(12.0, 64.0);
        copy.cx += off;
        copy.cy += off;
        self.commit_float(); // the original is baked back into the layer
        self.float = Some(copy);
        self.bump_float();
        self.bump_all();
        0
    }

    // ---------------------------------------------------------------- patterns

    /// Convert the object (as it currently looks: scaled/rotated) into a repeatable tile.
    /// Returns the pattern index (use kind = 100 + index), -1 nothing selected, -2 too large.
    pub fn float_to_pattern(&mut self, spacing: usize, brick: bool) -> i32 {
        let f = match self.float.as_ref() {
            Some(f) => f,
            None => return -1,
        };
        let (px, w, h, _, _) = match f.render_bitmap(MAX_PATTERN_PIXELS) {
            Some(r) => r,
            None => return -2,
        };
        let sp = spacing.min(512);
        let (tw, th) = (w + sp, h + sp);
        if tw * th > MAX_PATTERN_PIXELS {
            return -2;
        }
        let mut tile = vec![0u32; tw * th];
        let (ox, oy) = (sp / 2, sp / 2);
        for y in 0..h {
            tile[(y + oy) * tw + ox..(y + oy) * tw + ox + w].copy_from_slice(&px[y * w..(y + 1) * w]);
        }
        let pat = Arc::new(TilePattern { w: tw, h: th, px: tile, brick });
        let slot = if self.patterns.len() < MAX_PATTERNS {
            self.patterns.push(pat);
            self.patterns.len() - 1
        } else {
            let s = self.next_pattern_slot % MAX_PATTERNS;
            self.next_pattern_slot += 1;
            self.patterns[s] = pat;
            s
        };
        slot as i32
    }

    /// Render pattern `i` repeated 2x2 into a `size` x `size` premultiplied RGBA thumbnail.
    pub fn pattern_thumb(&self, i: usize, size: usize, out: &mut [u32]) -> bool {
        let p = match self.patterns.get(i) {
            Some(p) => p.clone(),
            None => return false,
        };
        if out.len() < size * size || size == 0 {
            return false;
        }
        let step = (p.w.max(p.h) as f32 * 2.0) / size as f32;
        for y in 0..size {
            for x in 0..size {
                let mut sum = [0u32; 4];
                for (sx, sy) in [(0.25f32, 0.25f32), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)] {
                    let s = p.sample(((x as f32 + sx) * step) as u32, ((y as f32 + sy) * step) as u32, 1.0);
                    for (k, sh) in [0u32, 8, 16, 24].into_iter().enumerate() {
                        sum[k] += (s >> sh) & 255;
                    }
                }
                out[y * size + x] = (sum[0] / 4) | ((sum[1] / 4) << 8) | ((sum[2] / 4) << 16) | ((sum[3] / 4) << 24);
            }
        }
        true
    }

    /// Classic "Offset" check for seamless tiles: shifts the whole layer by (dx, dy) with wrap-around.
    pub fn offset_wrap(&mut self, dx: i32, dy: i32) -> i32 {
        let keep = self.wrap;
        self.commit_float();
        let r = self.select_all();
        if r != 0 {
            return r;
        }
        self.with_float(|f| f.wrap = true);
        self.float_move(dx as f32, dy as f32);
        self.commit_float();
        self.wrap = keep;
        0
    }

    // ---------------------------------------------------------------- FX

    /// Apply an effect to the floating object, or to the active layer when nothing is selected.
    /// 0 ok, 1 nothing to process, 2 too large.
    pub fn apply_fx(&mut self, kind: i32, a: f32, b: f32) -> i32 {
        let margin = fx::margin_for(kind, a);
        if self.float.is_some() {
            let (w, h) = {
                let f = self.float.as_ref().unwrap();
                (f.w + 2 * margin, f.h + 2 * margin)
            };
            if w * h > MAX_OBJECT_PIXELS {
                return 2;
            }
            self.with_float(|f| {
                f.pad(margin);
                fx::apply(kind, a, b, &mut f.px, f.w, f.h);
            });
            return 0;
        }
        self.commit_float();
        let a_idx = self.active;
        let (x0, y0, x1, y1) = match self.layers[a_idx].canvas.content_bbox() {
            Some(b) => b,
            None => return 1,
        };
        let m = margin as i32;
        let (x0, y0) = ((x0 - m).max(0), (y0 - m).max(0));
        let (x1, y1) = ((x1 + m).min(self.width as i32), (y1 + m).min(self.height as i32));
        let (w, h) = ((x1 - x0) as usize, (y1 - y0) as usize);
        if w * h > MAX_OBJECT_PIXELS {
            return 2;
        }
        let mut buf = vec![0u32; w * h];
        for y in 0..h {
            self.layers[a_idx].canvas.read_row((y0 as usize + y) as u32, x0 as u32, &mut buf[y * w..(y + 1) * w]);
        }
        fx::apply(kind, a, b, &mut buf, w, h);
        self.edit(|c| write_region(c, x0, y0, w, h, &buf));
        0
    }

    // ---------------------------------------------------------------- compositing

    fn float_covers(&self, rect: Option<(i32, i32, i32, i32)>, idx: usize) -> bool {
        match rect {
            Some((tx0, ty0, tx1, ty1)) => {
                let (tx, ty) = ((idx % self.tiles_x) as i32, (idx / self.tiles_x) as i32);
                tx >= tx0 && tx <= tx1 && ty >= ty0 && ty <= ty1
            }
            None => false,
        }
    }

    /// Fill `idx_out` / `ver_out` with the tiles in the inclusive tile rectangle that have anything to draw.
    pub fn visible_tiles(&mut self, tx0: i32, ty0: i32, tx1: i32, ty1: i32, idx_out: &mut [i32], ver_out: &mut [i32]) -> usize {
        self.set_viewport(tx0, ty0, tx1, ty1);
        if tx1 < tx0 || ty1 < ty0 {
            return 0;
        }
        let (mx, my) = (self.tiles_x as i32 - 1, self.tiles_y as i32 - 1);
        let (x0, x1) = (tx0.clamp(0, mx), tx1.clamp(0, mx));
        let (y0, y1) = (ty0.clamp(0, my), ty1.clamp(0, my));
        let cap = idx_out.len().min(ver_out.len());
        let frect = self.float.as_ref().and_then(|f| f.tile_rect(self.width as i32, self.height as i32));
        let mut n = 0;
        for ty in y0..=y1 {
            for tx in x0..=x1 {
                let idx = ty as usize * self.tiles_x + tx as usize;
                let has = self.layers.iter().any(|l| l.visible && l.canvas.exists(idx))
                    || self.stroke.as_ref().map_or(false, |s| s.has(idx))
                    || self.float_covers(frect, idx);
                if has && n < cap {
                    idx_out[n] = idx as i32;
                    ver_out[n] = self.tile_version(idx);
                    n += 1;
                }
            }
        }
        n
    }

    fn tile_version(&self, idx: usize) -> i32 {
        let mut h: u32 = 2_166_136_261 ^ self.epoch;
        h = h.wrapping_mul(16_777_619) ^ self.overlay_ver[idx];
        for l in &self.layers {
            h = h.wrapping_mul(16_777_619) ^ l.canvas.version(idx);
        }
        h as i32
    }

    /// Flatten visible layers + live overlays into `out` (premultiplied). Returns false if empty.
    pub fn composite_tile(&mut self, idx: usize, out: &mut [u32]) -> bool {
        out.fill(0);
        if idx >= self.tile_count() {
            return false;
        }
        let (cw, ch) = (self.width as i32, self.height as i32);
        let (tx0, ty0) = (((idx % self.tiles_x) * TILE) as i32, ((idx / self.tiles_x) * TILE) as i32);
        let frect = self.float.as_ref().and_then(|f| f.tile_rect(cw, ch));
        let tiles_x = self.tiles_x;
        let Scene { layers, stroke, float, active, scratch, .. } = self;
        let mut any = false;
        for (li, layer) in layers.iter_mut().enumerate() {
            if !layer.visible {
                continue;
            }
            let has_stroke = li == *active && stroke.as_ref().map_or(false, |s| s.has(idx));
            let has_float = float.as_ref().map_or(false, |f| f.layer_id == layer.id)
                && match frect {
                    Some((a, b, c, d)) => {
                        let (tx, ty) = ((idx % tiles_x) as i32, (idx / tiles_x) as i32);
                        tx >= a && tx <= c && ty >= b && ty <= d
                    }
                    None => false,
                };
            let opacity = layer.opacity;
            let mode = layer.blend;
            if !has_stroke && !has_float {
                if let Some(px) = layer.canvas.tile_pixels(idx) {
                    blend_layer_mode(out, px, opacity, mode);
                    any = true;
                }
                continue;
            }
            scratch.resize(TILE_PIXELS, 0);
            match layer.canvas.tile_pixels(idx) {
                Some(px) => scratch.copy_from_slice(px),
                None => scratch.fill(0),
            }
            if has_stroke {
                if let Some(s) = stroke.as_ref() {
                    s.apply_to(idx, scratch);
                }
            }
            if has_float {
                if let Some(f) = float.as_ref() {
                    f.draw_into_tile(tx0, ty0, scratch, cw, ch);
                }
            }
            blend_layer_mode(out, scratch, opacity, mode);
            any = true;
        }
        any
    }

    /// RGBA bytes of the composited tile for GPU upload.
    pub fn copy_tile_bytes(&mut self, idx: usize, dst: &mut [u8]) -> bool {
        if dst.len() < TILE_PIXELS * 4 {
            return false;
        }
        let mut buf = std::mem::take(&mut self.tile_buf);
        buf.resize(TILE_PIXELS, 0);
        let ok = self.composite_tile(idx, &mut buf);
        if ok {
            for (chunk, p) in dst.chunks_exact_mut(4).zip(buf.iter()) {
                chunk.copy_from_slice(&p.to_le_bytes());
            }
        }
        self.tile_buf = buf;
        ok
    }

    /// Composite row `y` (columns x0..x0+len) of all visible layers, premultiplied.
    pub fn composite_row(&mut self, y: u32, x0: u32, dst: &mut [u32]) {
        dst.fill(0);
        let mut tmp = std::mem::take(&mut self.row_tmp);
        tmp.resize(dst.len(), 0);
        for l in self.layers.iter_mut() {
            if !l.visible {
                continue;
            }
            l.canvas.read_row(y, x0, &mut tmp);
            blend_layer_mode(dst, &tmp, l.opacity, l.blend);
        }
        self.row_tmp = tmp;
    }

    pub fn composite_pixel(&mut self, x: i32, y: i32) -> u32 {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return 0;
        }
        let mut px = [0u32; 1];
        self.composite_row(y as u32, x as u32, &mut px);
        px[0]
    }

    // ---------------------------------------------------------------- project file

    pub fn write_project<W: Write>(&mut self, w: &mut W, bg: u32) -> io::Result<()> {
        self.commit_float();
        self.finish_edit();
        w.write_all(PROJECT_MAGIC_V3)?;
        w.write_all(&self.width.to_le_bytes())?;
        w.write_all(&self.height.to_le_bytes())?;
        w.write_all(&bg.to_le_bytes())?;
        w.write_all(&(self.layers.len() as u32).to_le_bytes())?;
        w.write_all(&(self.active as u32).to_le_bytes())?;
        for l in self.layers.iter_mut() {
            let name = l.name.as_bytes();
            let n = name.len().min(64);
            w.write_all(&(n as u16).to_le_bytes())?;
            w.write_all(&name[..n])?;
            w.write_all(&[l.visible as u8])?;
            w.write_all(&l.opacity.to_le_bytes())?;
            w.write_all(&[l.blend.id() as u8])?;
            l.canvas.write_tiles(w)?;
        }
        Ok(())
    }

    /// Reads "LDRW2" (layers) and the legacy "LDRW1" (single layer).
    pub fn read_project<R: Read>(r: &mut R, base_dir: PathBuf, budget: usize) -> io::Result<(Scene, u32)> {
        let bad = |m: &str| io::Error::new(io::ErrorKind::InvalidData, m.to_string());
        let mut magic = [0u8; 5];
        r.read_exact(&mut magic)?;
        let legacy = &magic == PROJECT_MAGIC_V1;
        let has_blend = &magic == PROJECT_MAGIC_V3;
        if !legacy && !has_blend && &magic != PROJECT_MAGIC_V2 {
            return Err(bad("bad magic"));
        }
        let (w, h, bg) = (read_u32(r)?, read_u32(r)?, read_u32(r)?);
        if !(64..=16384).contains(&w) || !(64..=16384).contains(&h) {
            return Err(bad("bad size"));
        }
        let mut layers: Vec<Layer> = Vec::new();
        let mut active = 0usize;
        let cleanup = |layers: &Vec<Layer>| {
            for l in layers {
                l.canvas.cleanup();
            }
        };
        if legacy {
            let mut canvas = TiledCanvas::new(w, h, base_dir.clone(), budget);
            if let Err(e) = canvas.read_tiles(r) {
                canvas.cleanup();
                return Err(e);
            }
            layers.push(Layer { id: 1, name: "Layer 1".into(), visible: true, opacity: 1.0, blend: Blend::Normal, canvas });
        } else {
            let count = read_u32(r)? as usize;
            active = read_u32(r)? as usize;
            if count == 0 || count > MAX_LAYERS {
                return Err(bad("bad layer count"));
            }
            for i in 0..count {
                let mut nl = [0u8; 2];
                r.read_exact(&mut nl)?;
                let n = u16::from_le_bytes(nl) as usize;
                if n > 64 {
                    cleanup(&layers);
                    return Err(bad("bad name"));
                }
                let mut nb = vec![0u8; n];
                r.read_exact(&mut nb)?;
                let mut vis = [0u8; 1];
                r.read_exact(&mut vis)?;
                let op = f32::from_bits(read_u32(r)?);
                let mut bl = [0u8; 1];
                if has_blend {
                    r.read_exact(&mut bl)?;
                }
                let mut canvas = TiledCanvas::new(w, h, base_dir.clone(), budget);
                if let Err(e) = canvas.read_tiles(r) {
                    canvas.cleanup();
                    cleanup(&layers);
                    return Err(e);
                }
                layers.push(Layer {
                    id: i as u32 + 1,
                    name: String::from_utf8_lossy(&nb).into_owned(),
                    visible: vis[0] != 0,
                    opacity: if op.is_finite() { op.clamp(0.0, 1.0) } else { 1.0 },
                    blend: match Blend::from_i32(bl[0] as i32) {
                        Blend::Eraser => Blend::Normal,
                        b => b,
                    },
                    canvas,
                });
            }
        }
        let n = layers.len() as u32;
        Ok((Scene::from_layers(base_dir, budget, layers, active, n + 1, n), bg))
    }
}

// ---------------------------------------------------------------------------------------------
// region helpers
// ---------------------------------------------------------------------------------------------

/// Overwrite the rectangle at (x0, y0) with `buf` (w x h, premultiplied). Empty-to-empty tiles are skipped.
pub fn write_region(canvas: &mut TiledCanvas, x0: i32, y0: i32, w: usize, h: usize, buf: &[u32]) {
    if w == 0 || h == 0 {
        return;
    }
    let tiles_x = canvas.tiles_x;
    let (x1, y1) = (x0 + w as i32, y0 + h as i32);
    for ty in (y0 as usize >> 8)..=((y1 - 1) as usize >> 8) {
        for tx in (x0 as usize >> 8)..=((x1 - 1) as usize >> 8) {
            let idx = ty * tiles_x + tx;
            let (ox, oy) = ((tx * TILE) as i32, (ty * TILE) as i32);
            let (lx0, lx1) = ((x0 - ox).max(0) as usize, (x1 - ox).min(TILE as i32) as usize);
            let (ly0, ly1) = ((y0 - oy).max(0) as usize, (y1 - oy).min(TILE as i32) as usize);
            if !canvas.exists(idx) {
                let any = (ly0..ly1).any(|ly| {
                    let sy = (oy + ly as i32 - y0) as usize;
                    let sx = (ox + lx0 as i32 - x0) as usize;
                    buf[sy * w + sx..sy * w + sx + (lx1 - lx0)].iter().any(|&p| p != 0)
                });
                if !any {
                    continue;
                }
            }
            let px = canvas.tile_mut(idx);
            for ly in ly0..ly1 {
                let sy = (oy + ly as i32 - y0) as usize;
                let sx = (ox + lx0 as i32 - x0) as usize;
                px[ly * TILE + lx0..ly * TILE + lx1].copy_from_slice(&buf[sy * w + sx..sy * w + sx + (lx1 - lx0)]);
            }
        }
    }
}
