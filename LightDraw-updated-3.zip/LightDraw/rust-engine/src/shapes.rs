//! Anti-aliased vector shapes rasterised through signed-distance fields.
//!
//! Every shape is described by a function `sd(x, y)` = distance in *pixels* from the pixel centre to
//! the outline (negative inside). Coverage is then
//!   * fill:    `clamp(0.5 - sd, 0, 1)`
//!   * outline: `clamp(0.5 - (|sd| - w/2), 0, 1)`
//! which is a one-pixel linear ramp centred on the true edge, so edges and corners are smooth at
//! any size / angle. Output goes into the same [`StrokeBuf`] used by brushes, so shapes get live
//! preview, exact opacity and the same bake-to-layer path.

use crate::brush_engine::{fill_cover, StrokeBuf};

pub const LINE: i32 = 0;
pub const RECT: i32 = 1;
pub const ROUND_RECT: i32 = 2;
pub const ELLIPSE: i32 = 3;
pub const TRIANGLE: i32 = 4;
pub const POLYGON: i32 = 5;
pub const STAR: i32 = 6;

#[derive(Clone, Copy, Debug)]
pub struct ShapeParams {
    pub kind: i32,
    /// Drag start / end in canvas pixels. For everything but `LINE` they span the bounding box.
    pub x0: f32,
    pub y0: f32,
    pub x1: f32,
    pub y1: f32,
    pub outline: bool,
    /// Stroke width in px (outline mode and line).
    pub stroke: f32,
    /// Corner rounding 0..1 (fraction of the smaller half-side), `ROUND_RECT` only.
    pub corner: f32,
    /// Polygon sides / star points (3..16).
    pub sides: i32,
}

#[inline]
fn seg_dist2(px: f32, py: f32, ax: f32, ay: f32, bx: f32, by: f32) -> f32 {
    let (vx, vy) = (bx - ax, by - ay);
    let (wx, wy) = (px - ax, py - ay);
    let l2 = vx * vx + vy * vy;
    let t = if l2 > 1e-9 { ((wx * vx + wy * vy) / l2).clamp(0.0, 1.0) } else { 0.0 };
    let (dx, dy) = (wx - vx * t, wy - vy * t);
    dx * dx + dy * dy
}

/// Signed distance to a closed polygon (negative inside, even-odd rule).
fn poly_sd(verts: &[(f32, f32)], px: f32, py: f32) -> f32 {
    let n = verts.len();
    let mut best = f32::MAX;
    let mut inside = false;
    let mut j = n - 1;
    for i in 0..n {
        let (ax, ay) = verts[j];
        let (bx, by) = verts[i];
        let d2 = seg_dist2(px, py, ax, ay, bx, by);
        if d2 < best {
            best = d2;
        }
        if (ay > py) != (by > py) && px < (bx - ax) * (py - ay) / (by - ay) + ax {
            inside = !inside;
        }
        j = i;
    }
    let d = best.sqrt();
    if inside {
        -d
    } else {
        d
    }
}

/// Vertices of the polygon-like shapes inscribed in the box centred (cx, cy) with half sizes (hx, hy).
pub fn polygon_vertices(kind: i32, sides: i32, cx: f32, cy: f32, hx: f32, hy: f32) -> Vec<(f32, f32)> {
    let n = sides.clamp(3, 16) as usize;
    match kind {
        TRIANGLE => vec![(cx, cy - hy), (cx + hx, cy + hy), (cx - hx, cy + hy)],
        STAR => {
            let inner = 0.45;
            let mut v = Vec::with_capacity(n * 2);
            for k in 0..n * 2 {
                let a = -std::f32::consts::FRAC_PI_2 + std::f32::consts::PI * k as f32 / n as f32;
                let r = if k % 2 == 0 { 1.0 } else { inner };
                v.push((cx + hx * r * a.cos(), cy + hy * r * a.sin()));
            }
            v
        }
        _ => {
            let mut v = Vec::with_capacity(n);
            for k in 0..n {
                let a = -std::f32::consts::FRAC_PI_2 + std::f32::consts::TAU * k as f32 / n as f32;
                v.push((cx + hx * a.cos(), cy + hy * a.sin()));
            }
            v
        }
    }
}

/// Redraw the shape into `buf` (previous coverage is discarded first).
pub fn render(buf: &mut StrokeBuf, p: &ShapeParams) {
    buf.clear();
    let sw = p.stroke.max(1.0);
    let line_like = p.kind == LINE;
    let outline = p.outline || line_like;
    let half_w = sw * 0.5;

    let (cx, cy) = ((p.x0 + p.x1) * 0.5, (p.y0 + p.y1) * 0.5);
    let hx = ((p.x1 - p.x0).abs() * 0.5).max(0.5);
    let hy = ((p.y1 - p.y0).abs() * 0.5).max(0.5);

    // pixel margin around the geometric bounds so the AA ramp / stroke is never clipped
    let margin = 2.0 + if outline { half_w } else { 0.0 };
    let (bx0, by0, bx1, by1) = if line_like {
        (p.x0.min(p.x1) - margin, p.y0.min(p.y1) - margin, p.x0.max(p.x1) + margin, p.y0.max(p.y1) + margin)
    } else {
        (cx - hx - margin, cy - hy - margin, cx + hx + margin, cy + hy + margin)
    };

    // Turn a signed distance into coverage.
    let cover = move |sd: f32| -> f32 {
        if line_like {
            (0.5 - sd).clamp(0.0, 1.0) // sd is already measured to the capsule surface
        } else if outline {
            (0.5 - (sd.abs() - half_w)).clamp(0.0, 1.0)
        } else {
            (0.5 - sd).clamp(0.0, 1.0)
        }
    };

    let wraps = buf.wrap;
    let (cw, ch) = (buf.width as f32, buf.height as f32);
    // With seamless mode on, also draw the copies shifted by +-canvas size (only those that matter).
    let mut offsets: Vec<(f32, f32)> = vec![(0.0, 0.0)];
    if wraps {
        offsets.clear();
        for oy in [-ch, 0.0, ch] {
            for ox in [-cw, 0.0, cw] {
                if bx1 + ox >= 0.0 && bx0 + ox <= cw && by1 + oy >= 0.0 && by0 + oy <= ch {
                    offsets.push((ox, oy));
                }
            }
        }
    }

    let verts = match p.kind {
        TRIANGLE | POLYGON | STAR => Some(polygon_vertices(p.kind, p.sides, cx, cy, hx, hy)),
        _ => None,
    };
    let corner_r = (p.corner.clamp(0.0, 1.0) * hx.min(hy)).max(0.0);

    for (ox, oy) in offsets {
        let (ox0, oy0) = ((bx0 + ox).floor() as i32, (by0 + oy).floor() as i32);
        let (ox1, oy1) = ((bx1 + ox).ceil() as i32, (by1 + oy).ceil() as i32);
        fill_cover(buf, ox0, oy0, ox1, oy1, |qx, qy| {
            let (x, y) = (qx - ox, qy - oy);
            let sd = match p.kind {
                LINE => seg_dist2(x, y, p.x0, p.y0, p.x1, p.y1).sqrt() - half_w,
                RECT | ROUND_RECT => {
                    let r = if p.kind == ROUND_RECT { corner_r } else { 0.0 };
                    let (qx2, qy2) = ((x - cx).abs() - (hx - r), (y - cy).abs() - (hy - r));
                    let outside = (qx2.max(0.0).powi(2) + qy2.max(0.0).powi(2)).sqrt();
                    outside + qx2.max(qy2).min(0.0) - r
                }
                ELLIPSE => {
                    let (dx, dy) = (x - cx, y - cy);
                    let k0 = ((dx / hx).powi(2) + (dy / hy).powi(2)).sqrt();
                    let k1 = ((dx / (hx * hx)).powi(2) + (dy / (hy * hy)).powi(2)).sqrt();
                    if k1 < 1e-9 {
                        -hx.min(hy)
                    } else {
                        k0 * (k0 - 1.0) / k1
                    }
                }
                _ => poly_sd(verts.as_ref().unwrap(), x, y),
            };
            cover(sd)
        });
    }
}
