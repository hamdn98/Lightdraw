//! LightDraw native engine: sparse 16K tile canvases (layers), brush / shape / pattern / FX engines,
//! floating objects and the JNI bridge.
pub mod brush_engine;
pub mod color_engine;
pub mod engine;
pub mod float_obj;
pub mod fx;
pub mod jpeg_enc;
pub mod object_select;
pub mod pattern_fill;
pub mod scene;
pub mod shapes;
pub mod stabilizer;
pub mod surface;
pub mod symmetry;
pub mod tiled_canvas;

// JNI glue (needs the `jni` / `png` crates; excluded from desktop `cargo test` builds).
#[cfg(not(test))]
pub mod engine_core;

#[cfg(test)]
mod engine_tests;
