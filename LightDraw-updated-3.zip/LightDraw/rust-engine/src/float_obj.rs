//! A *floating object*: a bitmap lifted out of a layer that can be moved, scaled, rotated, flipped,
//! duplicated, aligned, filtered and turned into a pattern before it is committed back.
//!
//! The bitmap (`px`, premultiplied RGBA) is placed on the canvas by a centre `(cx, cy)`, a uniform
//! `scale` and a rotation `rot` (radians, clockwise on screen because +y points down).
//! Sampling is exact (nearest, pixel-for-pixel) while the object is only translated/flipped, and
//! bilinear once scaled or rotated, which also gives the object a smooth anti-aliased edge.
//!
//! ## Seamless repeat (`wrap`)
//! With `wrap` on, the object is drawn once for every copy shifted by `(+-W, +-H)` that touches the
//! canvas. Dragging the object over an edge therefore makes the part that leaves re-enter from the
//! opposite side (and over a corner it appears in all four corners): exactly the offset trick used
//! to make seamless tiles. Committing bakes every visible copy.

use crate::brush_engine::over;
use crate::tiled_canvas::TILE;

pub struct Float {
    pub layer_id: u32,
    pub w: usize,
    pub h: usize,
    pub px: Vec<u32>,
    pub cx: f32,
    pub cy: f32,
    pub scale: f32,
    pub rot: f32,
    pub wrap: bool,
    /// The layer's undo log ends with the edit that cut this object out of the layer.
    pub lifted: bool,
}

/// Per-draw precomputed transform (avoids recomputing sin/cos per pixel).
struct Xf {
    cos: f32,
    sin: f32,
    inv_s: f32,
    hw: f32,
    hh: f32,
    pristine: bool,
}

impl Float {
    pub fn new(layer_id: u32, w: usize, h: usize, px: Vec<u32>, x0: i32, y0: i32, lifted: bool) -> Float {
        Float {
            layer_id,
            w,
            h,
            px,
            cx: x0 as f32 + w as f32 * 0.5,
            cy: y0 as f32 + h as f32 * 0.5,
            scale: 1.0,
            rot: 0.0,
            wrap: false,
            lifted,
        }
    }

    pub fn pristine(&self) -> bool {
        (self.scale - 1.0).abs() < 1e-4 && self.rot.abs() < 1e-4
    }

    fn xf(&self) -> Xf {
        let (sin, cos) = self.rot.sin_cos();
        Xf {
            cos,
            sin,
            inv_s: 1.0 / self.scale.max(1e-4),
            hw: self.w as f32 * 0.5,
            hh: self.h as f32 * 0.5,
            pristine: self.pristine(),
        }
    }

    /// Keep a translated-only object pixel aligned (integer top-left).
    pub fn snap(&mut self) {
        if self.pristine() {
            let hw = self.w as f32 * 0.5;
            let hh = self.h as f32 * 0.5;
            self.cx = (self.cx - hw).round() + hw;
            self.cy = (self.cy - hh).round() + hh;
        }
    }

    /// Corners in canvas space: top-left, top-right, bottom-right, bottom-left.
    pub fn corners(&self) -> [(f32, f32); 4] {
        let (sin, cos) = self.rot.sin_cos();
        let hw = self.w as f32 * 0.5 * self.scale;
        let hh = self.h as f32 * 0.5 * self.scale;
        let mut out = [(0.0, 0.0); 4];
        for (i, (lx, ly)) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)].into_iter().enumerate() {
            out[i] = (self.cx + cos * lx - sin * ly, self.cy + sin * lx + cos * ly);
        }
        out
    }

    /// Axis-aligned bounds `(min_x, min_y, max_x, max_y)` of the transformed object.
    pub fn aabb(&self) -> (f32, f32, f32, f32) {
        let c = self.corners();
        let mut r = (f32::MAX, f32::MAX, f32::MIN, f32::MIN);
        for (x, y) in c {
            r.0 = r.0.min(x);
            r.1 = r.1.min(y);
            r.2 = r.2.max(x);
            r.3 = r.3.max(y);
        }
        r
    }

    /// Offsets of every copy that is drawn (a single `(0,0)` unless `wrap`).
    pub fn instances(&self, cw: i32, ch: i32) -> Vec<(f32, f32)> {
        if !self.wrap {
            return vec![(0.0, 0.0)];
        }
        let (a0, b0, a1, b1) = self.aabb();
        let (cw, ch) = (cw as f32, ch as f32);
        let mut v = Vec::with_capacity(4);
        for oy in [-ch, 0.0, ch] {
            for ox in [-cw, 0.0, cw] {
                if a1 + ox > 0.0 && a0 + ox < cw && b1 + oy > 0.0 && b0 + oy < ch {
                    v.push((ox, oy));
                }
            }
        }
        if v.is_empty() {
            v.push((0.0, 0.0));
        }
        v
    }

    /// Inclusive tile rectangle `(tx0, ty0, tx1, ty1)` touched by the object (all copies), clamped to the canvas.
    pub fn tile_rect(&self, cw: i32, ch: i32) -> Option<(i32, i32, i32, i32)> {
        let (a0, b0, a1, b1) = self.aabb();
        let mut r: Option<(i32, i32, i32, i32)> = None;
        for (ox, oy) in self.instances(cw, ch) {
            let x0 = ((a0 + ox).floor() as i32 - 1).max(0);
            let y0 = ((b0 + oy).floor() as i32 - 1).max(0);
            let x1 = ((a1 + ox).ceil() as i32 + 1).min(cw);
            let y1 = ((b1 + oy).ceil() as i32 + 1).min(ch);
            if x0 >= x1 || y0 >= y1 {
                continue;
            }
            let t = (x0 / TILE as i32, y0 / TILE as i32, (x1 - 1) / TILE as i32, (y1 - 1) / TILE as i32);
            r = Some(match r {
                None => t,
                Some(u) => (u.0.min(t.0), u.1.min(t.1), u.2.max(t.2), u.3.max(t.3)),
            });
        }
        r
    }

    /// Is the canvas point inside the object (any wrapped copy)?
    pub fn hit(&self, x: f32, y: f32, cw: i32, ch: i32) -> bool {
        let xf = self.xf();
        for (ox, oy) in self.instances(cw, ch) {
            let (fx, fy) = (x - (self.cx + ox), y - (self.cy + oy));
            let lx = (xf.cos * fx + xf.sin * fy) * xf.inv_s;
            let ly = (-xf.sin * fx + xf.cos * fy) * xf.inv_s;
            if lx.abs() <= xf.hw + 6.0 && ly.abs() <= xf.hh + 6.0 {
                return true;
            }
        }
        false
    }

    #[inline]
    fn texel(&self, ix: i32, iy: i32) -> u32 {
        if ix < 0 || iy < 0 || ix >= self.w as i32 || iy >= self.h as i32 {
            0
        } else {
            self.px[iy as usize * self.w + ix as usize]
        }
    }

    /// Premultiplied colour at canvas pixel centre (px, py) for the copy shifted by (ox, oy).
    #[inline]
    fn sample(&self, xf: &Xf, px: f32, py: f32, ox: f32, oy: f32) -> u32 {
        let (fx, fy) = (px - (self.cx + ox), py - (self.cy + oy));
        let lx = (xf.cos * fx + xf.sin * fy) * xf.inv_s + xf.hw;
        let ly = (-xf.sin * fx + xf.cos * fy) * xf.inv_s + xf.hh;
        if xf.pristine {
            return self.texel(lx.floor() as i32, ly.floor() as i32);
        }
        let (u, v) = (lx - 0.5, ly - 0.5);
        let (x0, y0) = (u.floor(), v.floor());
        let (tx, ty) = (u - x0, v - y0);
        let (ix, iy) = (x0 as i32, y0 as i32);
        let (p00, p10, p01, p11) = (self.texel(ix, iy), self.texel(ix + 1, iy), self.texel(ix, iy + 1), self.texel(ix + 1, iy + 1));
        if (p00 | p10 | p01 | p11) >> 24 == 0 {
            return 0;
        }
        let mut out = 0u32;
        for sh in [0u32, 8, 16, 24] {
            let c = |p: u32| ((p >> sh) & 255) as f32;
            let top = c(p00) + (c(p10) - c(p00)) * tx;
            let bot = c(p01) + (c(p11) - c(p01)) * tx;
            let val = (top + (bot - top) * ty + 0.5) as u32;
            out |= val.min(255) << sh;
        }
        out
    }

    /// Composite the object (all wrapped copies) onto the premultiplied tile `out` whose top-left
    /// canvas pixel is (tx0, ty0).
    pub fn draw_into_tile(&self, tx0: i32, ty0: i32, out: &mut [u32], cw: i32, ch: i32) {
        let xf = self.xf();
        let (a0, b0, a1, b1) = self.aabb();
        let t = TILE as i32;
        for (ox, oy) in self.instances(cw, ch) {
            let x0 = ((a0 + ox).floor() as i32 - 1).max(tx0);
            let y0 = ((b0 + oy).floor() as i32 - 1).max(ty0);
            let x1 = ((a1 + ox).ceil() as i32 + 1).min(tx0 + t).min(cw);
            let y1 = ((b1 + oy).ceil() as i32 + 1).min(ty0 + t).min(ch);
            if x0 >= x1 || y0 >= y1 {
                continue;
            }
            for y in y0..y1 {
                let row = ((y - ty0) as usize) * TILE;
                for x in x0..x1 {
                    let s = self.sample(&xf, x as f32 + 0.5, y as f32 + 0.5, ox, oy);
                    if s >> 24 != 0 {
                        let i = row + (x - tx0) as usize;
                        out[i] = over(out[i], s);
                    }
                }
            }
        }
    }

    /// Rasterise the transformed object (no wrapping) into a tight bitmap.
    /// Returns `(pixels, w, h, x0, y0)` where (x0, y0) is its top-left on the canvas.
    pub fn render_bitmap(&self, max_px: usize) -> Option<(Vec<u32>, usize, usize, i32, i32)> {
        let (a0, b0, a1, b1) = self.aabb();
        let (x0, y0) = (a0.floor() as i32, b0.floor() as i32);
        let (x1, y1) = (a1.ceil() as i32, b1.ceil() as i32);
        let (w, h) = ((x1 - x0).max(1) as usize, (y1 - y0).max(1) as usize);
        if w.checked_mul(h)? > max_px {
            return None;
        }
        let xf = self.xf();
        let mut out = vec![0u32; w * h];
        for y in 0..h {
            for x in 0..w {
                out[y * w + x] = self.sample(&xf, (x0 + x as i32) as f32 + 0.5, (y0 + y as i32) as f32 + 0.5, 0.0, 0.0);
            }
        }
        Some((out, w, h, x0, y0))
    }

    // ---------------------------------------------------------------- bitmap-space edits

    /// Mirror left <-> right on screen.
    pub fn flip_h(&mut self) {
        let (w, h) = (self.w, self.h);
        for y in 0..h {
            self.px[y * w..(y + 1) * w].reverse();
        }
        self.rot = -self.rot;
    }

    /// Mirror top <-> bottom on screen.
    pub fn flip_v(&mut self) {
        let (w, h) = (self.w, self.h);
        for y in 0..h / 2 {
            let (a, b) = self.px.split_at_mut((h - 1 - y) * w);
            a[y * w..(y + 1) * w].swap_with_slice(&mut b[..w]);
        }
        self.rot = -self.rot;
    }

    /// Rotate the bitmap by 90 degrees (exact, no resampling) around its centre.
    pub fn rotate90(&mut self, clockwise: bool) {
        let (w, h) = (self.w, self.h);
        let mut out = vec![0u32; w * h];
        for y in 0..h {
            for x in 0..w {
                let (nx, ny) = if clockwise { (h - 1 - y, x) } else { (y, w - 1 - x) };
                out[ny * h + nx] = self.px[y * w + x];
            }
        }
        self.px = out;
        self.w = h;
        self.h = w;
    }

    /// Add `pad` transparent pixels on every side, keeping the object visually in place.
    pub fn pad(&mut self, pad: usize) {
        if pad == 0 {
            return;
        }
        let (nw, nh) = (self.w + 2 * pad, self.h + 2 * pad);
        let mut out = vec![0u32; nw * nh];
        for y in 0..self.h {
            out[(y + pad) * nw + pad..(y + pad) * nw + pad + self.w].copy_from_slice(&self.px[y * self.w..(y + 1) * self.w]);
        }
        self.px = out;
        self.w = nw;
        self.h = nh;
        self.snap();
    }
}
