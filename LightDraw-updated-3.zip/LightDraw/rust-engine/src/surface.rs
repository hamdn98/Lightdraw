//! Paper / cloth surface textures.
//!
//! The texture is a **tileable 256x256 height map** (0 = valley, 255 = ridge) generated procedurally, so there are
//! no image assets in the APK. It is a *non-destructive* effect: the GL renderer draws it over the artboard and the
//! exporters bake the very same map into the PNG / JPEG, so what you see is what you export.
//!
//! Shading (shared by the GL shader in `CanvasRenderer.kt` and [`Surface::shade`]), with `h` = height in 0..1 and
//! `s` = strength in 0..1:
//! ```text
//! valley = max(0, 0.5 - h) * 2          ridge = max(0, h - 0.5) * 2
//! darken = s * 0.60 * valley            lift  = s * 0.22 * ridge
//! out    = lift + in * (1 - darken)
//! ```
//! Valleys darken the colour underneath (paper, paint), ridges add a little light, so it also reads on dark paper.

pub const TILE_SIZE: usize = 256;
/// 0 none, 1 fine paper, 2 rough (cold-press) paper, 3 canvas weave, 4 paper fibres.
pub const KINDS: i32 = 5;

pub const DARKEN: f32 = 0.60;
pub const LIFT: f32 = 0.22;

#[derive(Clone)]
pub struct Surface {
    pub kind: i32,
    pub strength: f32,
    /// Canvas pixels per texel (1..8).
    pub scale: u32,
    /// Bake the texture into exported images / thumbnails.
    pub bake: bool,
    tex: Vec<u8>,
}

impl Surface {
    pub fn new() -> Surface {
        Surface { kind: 0, strength: 0.5, scale: 1, bake: true, tex: Vec::new() }
    }

    pub fn configure(&mut self, kind: i32, strength: f32, scale: i32, bake: bool) {
        let kind = kind.clamp(0, KINDS - 1);
        if kind != self.kind || (kind != 0 && self.tex.is_empty()) {
            self.tex = if kind == 0 { Vec::new() } else { tile(kind) };
        }
        self.kind = kind;
        self.strength = if strength.is_finite() { strength.clamp(0.0, 1.0) } else { 0.5 };
        self.scale = scale.clamp(1, 8) as u32;
        self.bake = bake;
    }

    /// True when exports must apply the texture.
    pub fn active(&self) -> bool {
        self.bake && self.kind != 0 && self.strength > 0.001 && !self.tex.is_empty()
    }

    /// Shade one opaque premultiplied RGBA pixel at canvas position (x, y).
    #[inline]
    pub fn shade(&self, x: usize, y: usize, p: u32) -> u32 {
        let sc = self.scale as usize;
        let h = self.tex[((y / sc) & (TILE_SIZE - 1)) * TILE_SIZE + ((x / sc) & (TILE_SIZE - 1))] as f32 * (1.0 / 255.0);
        let valley = (0.5 - h).max(0.0) * 2.0;
        let ridge = (h - 0.5).max(0.0) * 2.0;
        let keep = 1.0 - self.strength * DARKEN * valley;
        let lift = self.strength * LIFT * ridge * 255.0;
        let f = |c: u32| ((c as f32 * keep + lift + 0.5) as i32).clamp(0, 255) as u32;
        f(p & 255) | (f((p >> 8) & 255) << 8) | (f((p >> 16) & 255) << 16) | (p & 0xFF00_0000)
    }
}

// ---------------------------------------------------------------------------------------------
// generation
// ---------------------------------------------------------------------------------------------

struct Rng(u32);

impl Rng {
    fn next(&mut self) -> u32 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        self.0 = x;
        x
    }

    fn f(&mut self) -> f32 {
        (self.next() >> 8) as f32 / 16_777_216.0
    }
}

fn hash2(x: i32, y: i32, seed: u32) -> f32 {
    let mut h = (x as u32).wrapping_mul(0x27d4_eb2d) ^ (y as u32).wrapping_mul(0x1656_67b1) ^ seed.wrapping_mul(0x9e37_79b1);
    h ^= h >> 15;
    h = h.wrapping_mul(0x85eb_ca6b);
    h ^= h >> 13;
    h = h.wrapping_mul(0xc2b2_ae35);
    h ^= h >> 16;
    (h >> 8) as f32 / 16_777_216.0
}

/// Value noise whose lattice wraps every `period` cells, so the tile is seamless.
fn vnoise(u: f32, v: f32, period: i32, seed: u32) -> f32 {
    let (x, y) = (u * period as f32, v * period as f32);
    let (x0, y0) = (x.floor(), y.floor());
    let (fx, fy) = (x - x0, y - y0);
    let (ix, iy) = (x0 as i32, y0 as i32);
    let w = |i: i32| i.rem_euclid(period);
    let sm = |t: f32| t * t * (3.0 - 2.0 * t);
    let a = hash2(w(ix), w(iy), seed);
    let b = hash2(w(ix + 1), w(iy), seed);
    let c = hash2(w(ix), w(iy + 1), seed);
    let d = hash2(w(ix + 1), w(iy + 1), seed);
    let (sx, sy) = (sm(fx), sm(fy));
    let top = a + (b - a) * sx;
    let bot = c + (d - c) * sx;
    top + (bot - top) * sy
}

fn fbm(u: f32, v: f32, period: i32, octaves: u32, seed: u32) -> f32 {
    let (mut sum, mut amp, mut norm, mut p) = (0.0f32, 0.5f32, 0.0f32, period);
    for o in 0..octaves {
        sum += amp * vnoise(u, v, p.min(TILE_SIZE as i32), seed.wrapping_add(o * 977));
        norm += amp;
        amp *= 0.5;
        p *= 2;
    }
    sum / norm
}

/// Generate the height map of a texture kind (empty for kind 0).
pub fn tile(kind: i32) -> Vec<u8> {
    if kind <= 0 || kind >= KINDS {
        return Vec::new();
    }
    let n = TILE_SIZE;
    let nf = n as f32;
    let mut f = vec![0f32; n * n];
    match kind {
        1 => {
            for y in 0..n {
                for x in 0..n {
                    let (u, v) = (x as f32 / nf, y as f32 / nf);
                    f[y * n + x] = 0.55 * fbm(u, v, 64, 3, 1) + 0.45 * hash2(x as i32, y as i32, 7);
                }
            }
        }
        2 => {
            for y in 0..n {
                for x in 0..n {
                    let (u, v) = (x as f32 / nf, y as f32 / nf);
                    f[y * n + x] = 0.78 * fbm(u, v, 12, 4, 3) + 0.22 * hash2(x as i32, y as i32, 9);
                }
            }
        }
        3 => {
            // plain weave, 4 px threads: warp thread over weft on a checkerboard of cells
            for y in 0..n {
                for x in 0..n {
                    let (u, v) = (x as f32 / nf, y as f32 / nf);
                    let (cx, cy) = (x / 4, y / 4);
                    let lu = ((x % 4) as f32 + 0.5) / 4.0;
                    let lv = ((y % 4) as f32 + 0.5) / 4.0;
                    let over = (cx + cy) % 2 == 0;
                    let thread = if over {
                        0.60 + 0.40 * (std::f32::consts::PI * lu).sin()
                    } else {
                        0.35 + 0.40 * (std::f32::consts::PI * lv).sin()
                    };
                    f[y * n + x] = thread + 0.25 * (fbm(u, v, 32, 2, 5) - 0.5) + 0.10 * (hash2(x as i32, y as i32, 11) - 0.5);
                }
            }
        }
        _ => {
            for y in 0..n {
                for x in 0..n {
                    let (u, v) = (x as f32 / nf, y as f32 / nf);
                    f[y * n + x] = 0.55 * fbm(u, v, 16, 3, 21) + 0.15 * hash2(x as i32, y as i32, 23);
                }
            }
            let mut rng = Rng(0x1234_5679);
            for _ in 0..2400 {
                let (x, y) = (rng.f() * nf, rng.f() * nf);
                let a = rng.f() * std::f32::consts::TAU;
                let len = 6.0 + rng.f() * 22.0;
                let amp = (0.08 + 0.18 * rng.f()) * if rng.f() < 0.5 { -1.0 } else { 1.0 };
                let (c, s) = (a.cos(), a.sin());
                let mut t = 0.0;
                while t < len {
                    let px = ((x + c * t) as i32).rem_euclid(n as i32) as usize;
                    let py = ((y + s * t) as i32).rem_euclid(n as i32) as usize;
                    f[py * n + px] += amp;
                    t += 0.7;
                }
            }
        }
    }
    // normalise: mean -> 0.5, +-2 sigma -> full range, so valleys and ridges both exist for every kind
    let mean = f.iter().sum::<f32>() / f.len() as f32;
    let var = f.iter().map(|v| (v - mean) * (v - mean)).sum::<f32>() / f.len() as f32;
    let sd = var.sqrt().max(1e-6);
    f.iter().map(|&v| ((0.5 + (v - mean) / (4.0 * sd)).clamp(0.0, 1.0) * 255.0 + 0.5) as u8).collect()
}
