//! Brush dabs, blend modes (Normal, Multiply, Screen, Overlay, Add, Eraser) and
//! quadratic-Bezier stroke interpolation.
//!
//! ### Anti-aliasing (why strokes are smooth)
//! A stroke is *not* painted straight into the layer. Every dab writes **coverage** (0..255) into a
//! [`StrokeBuf`]: the coverage of a pixel is a signed-distance ramp (`clamp(0.5 - sd, 0, 1)`, i.e. a
//! one-pixel linear transition centred on the true geometric edge), and overlapping dabs combine with
//! `max` (airbrush: "screen" accumulation). Because the ramp is evaluated from the exact distance to the
//! nib outline - and *not* re-composited on top of itself - edges keep their sub-pixel shading at any angle,
//! and the stroke opacity stays exact even where the stroke crosses itself. When the stroke ends (or for
//! every live preview frame) the coverage is blended once into the layer with the stroke colour/opacity.
//! Shapes use the same buffer (see `shapes.rs`), so brush, pen and shape edges all look identical.

use crate::pattern_fill::Paint;
use crate::symmetry::{unpack_x, unpack_y, Symmetry, MAX_COPIES};
use crate::tiled_canvas::TILE;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Blend {
    Normal,
    Multiply,
    Screen,
    Overlay,
    Add,
    Eraser,
    Darken,
    Lighten,
    Difference,
    SoftLight,
    HardLight,
    ColorDodge,
    ColorBurn,
    Exclusion,
}

impl Blend {
    pub fn from_i32(v: i32) -> Blend {
        match v {
            1 => Blend::Multiply,
            2 => Blend::Screen,
            3 => Blend::Overlay,
            4 => Blend::Add,
            5 => Blend::Eraser,
            6 => Blend::Darken,
            7 => Blend::Lighten,
            8 => Blend::Difference,
            9 => Blend::SoftLight,
            10 => Blend::HardLight,
            11 => Blend::ColorDodge,
            12 => Blend::ColorBurn,
            13 => Blend::Exclusion,
            _ => Blend::Normal,
        }
    }

    /// Inverse of [`Blend::from_i32`] (ids are shared with the Kotlin UI; 5 = eraser is brush-only).
    pub fn id(self) -> i32 {
        match self {
            Blend::Normal => 0,
            Blend::Multiply => 1,
            Blend::Screen => 2,
            Blend::Overlay => 3,
            Blend::Add => 4,
            Blend::Eraser => 5,
            Blend::Darken => 6,
            Blend::Lighten => 7,
            Blend::Difference => 8,
            Blend::SoftLight => 9,
            Blend::HardLight => 10,
            Blend::ColorDodge => 11,
            Blend::ColorBurn => 12,
            Blend::Exclusion => 13,
        }
    }
}

#[derive(Clone, Copy)]
pub struct Brush {
    pub size: f32,
    pub opacity: f32, // 0..1 (stroke opacity)
    pub hardness: f32,
    pub spacing: f32, // fraction of diameter
    pub angle: f32,   // radians (nib orientation)
    pub aspect: f32,  // 1 = round, <1 = flat nib
    pub color: u32,   // straight RGBA, alpha ignored
    pub blend: Blend,
    pub pressure_size: f32,
    pub pressure_opacity: f32,
    pub buildup: bool, // airbrush-like accumulation
    pub preset: i32,
    /// Pressure response `p^curve` (< 1 soft: light pressure already gives a thick line, > 1 firm).
    pub pressure_curve: f32,
    /// 0..1: how much stroke speed thins the line (gives finger input a pen-like feel).
    pub speed_thin: f32,
    /// Taper at the start / end of a stroke: length as a fraction (1.0 = 16 pen diameters) and the tip
    /// thickness relative to the full width (0 = needle point, 1 = no taper, 2 = bulb end).
    pub taper_start: f32,
    pub taper_start_tip: f32,
    pub taper_end: f32,
    pub taper_end_tip: f32,
}

/// Number of values in the "pen" parameter block exchanged with the UI (see `pen_params`).
pub const PEN_PARAMS: usize = 10;
/// Densest dab spacing in canvas pixels: dabs are never further apart than the AA ramp allows
/// but may be much closer than 1 px so zoomed-in strokes stay smooth.
const MIN_STEP: f32 = 0.25;
/// Dabs remembered for the end taper replay (longer strokes simply skip the end taper).
const MAX_REC: usize = 400_000;

fn clampf(v: f32, lo: f32, hi: f32) -> f32 {
    if v.is_finite() {
        v.clamp(lo, hi)
    } else {
        lo
    }
}

#[inline]
fn ease(x: f32) -> f32 {
    let x = x.clamp(0.0, 1.0);
    x * x * (3.0 - 2.0 * x)
}

/// Width multiplier at distance `d` from the tip of a taper of length `len` (tip thickness `tip`).
#[inline]
fn taper_mul(tip: f32, len: f32, d: f32) -> f32 {
    if len <= 0.0 {
        1.0
    } else {
        tip + (1.0 - tip) * ease(d / len)
    }
}

impl Brush {
    pub fn new() -> Self {
        let mut b = Brush {
            size: 18.0,
            opacity: 1.0,
            hardness: 0.8,
            spacing: 0.08,
            angle: 0.0,
            aspect: 1.0,
            color: 0xFF66_33FF,
            blend: Blend::Normal,
            pressure_size: 0.35,
            pressure_opacity: 0.5,
            buildup: false,
            preset: 0,
            pressure_curve: 1.0,
            speed_thin: 0.0,
            taper_start: 0.0,
            taper_start_tip: 1.0,
            taper_end: 0.0,
            taper_end_tip: 1.0,
        };
        b.set_preset(0);
        b
    }

    /// 0 Graphite pencil, 1 Soft airbrush, 2 Studio ink pen, 3 Calligraphy.
    pub fn set_preset(&mut self, id: i32) {
        self.preset = id;
        self.angle = 0.0;
        self.aspect = 1.0;
        self.buildup = false;
        self.pressure_curve = 1.0;
        self.speed_thin = 0.0;
        self.taper_start = 0.0;
        self.taper_start_tip = 1.0;
        self.taper_end = 0.0;
        self.taper_end_tip = 1.0;
        match id {
            1 => {
                self.hardness = 0.0;
                self.spacing = 0.06;
                self.pressure_size = 0.0;
                self.pressure_opacity = 0.8;
                self.buildup = true;
            }
            2 => {
                self.hardness = 1.0;
                self.spacing = 0.05;
                self.pressure_size = 0.6;
                self.pressure_opacity = 0.0;
            }
            3 => {
                self.hardness = 1.0;
                self.spacing = 0.05;
                self.angle = 0.7;
                self.aspect = 0.25;
                self.pressure_size = 0.2;
                self.pressure_opacity = 0.0;
            }
            _ => {
                self.hardness = 0.8;
                self.spacing = 0.08;
                self.pressure_size = 0.35;
                self.pressure_opacity = 0.5;
            }
        }
    }

    /// The tunable "pen" block: hardness, spacing, pressure->size, pressure->opacity, pressure curve,
    /// speed thinning, start taper (len, tip), end taper (len, tip).
    pub fn pen_params(&self) -> [f32; PEN_PARAMS] {
        [
            self.hardness, self.spacing, self.pressure_size, self.pressure_opacity, self.pressure_curve,
            self.speed_thin, self.taper_start, self.taper_start_tip, self.taper_end, self.taper_end_tip,
        ]
    }

    pub fn apply_pen(&mut self, p: &[f32]) {
        if p.len() < PEN_PARAMS {
            return;
        }
        self.hardness = clampf(p[0], 0.0, 1.0);
        self.spacing = clampf(p[1], 0.01, 1.0);
        self.pressure_size = clampf(p[2], 0.0, 1.0);
        self.pressure_opacity = clampf(p[3], 0.0, 1.0);
        self.pressure_curve = clampf(p[4], 0.25, 4.0);
        self.speed_thin = clampf(p[5], 0.0, 1.0);
        self.taper_start = clampf(p[6], 0.0, 1.0);
        self.taper_start_tip = clampf(p[7], 0.0, 2.0);
        self.taper_end = clampf(p[8], 0.0, 1.0);
        self.taper_end_tip = clampf(p[9], 0.0, 2.0);
    }

    pub fn start_taper_on(&self) -> bool {
        self.taper_start > 0.001 && (self.taper_start_tip - 1.0).abs() > 0.01
    }

    pub fn end_taper_on(&self) -> bool {
        self.taper_end > 0.001 && (self.taper_end_tip - 1.0).abs() > 0.01
    }

    fn taper_len(&self, frac: f32) -> f32 {
        frac * 16.0 * self.size.max(3.0)
    }

    /// Pressure after the response curve.
    pub fn shape_pressure(&self, p: f32) -> f32 {
        p.clamp(0.0, 1.0).powf(self.pressure_curve)
    }

    /// Strength of one dab (0..1). The *stroke opacity* is applied once when the stroke is baked, so
    /// here only pen pressure (and the airbrush build-up rate) matter.
    pub fn flow(&self, pressure: f32) -> f32 {
        let f = (1.0 - self.pressure_opacity + self.pressure_opacity * pressure).clamp(0.0, 1.0);
        if self.buildup {
            f * 0.2
        } else {
            f
        }
    }
}

/// Premultiplied source-over (integer).
#[inline]
pub fn over(dst: u32, src: u32) -> u32 {
    let sa = src >> 24;
    if sa == 255 {
        return src;
    }
    if sa == 0 {
        return dst;
    }
    let inv = 255 - sa;
    let mut out = 0u32;
    for sh in [0u32, 8, 16, 24] {
        let s = (src >> sh) & 255;
        let d = (dst >> sh) & 255;
        let v = (s + (d * inv + 127) / 255).min(255);
        out |= v << sh;
    }
    out
}

#[inline]
fn to_u8(v: f32) -> u32 {
    ((v * 255.0 + 0.5) as i32).clamp(0, 255) as u32
}

#[inline]
fn blend_channel(mode: Blend, cb: f32, cs: f32) -> f32 {
    match mode {
        Blend::Multiply => cb * cs,
        Blend::Screen => cb + cs - cb * cs,
        Blend::Overlay => {
            if cb <= 0.5 {
                2.0 * cb * cs
            } else {
                1.0 - 2.0 * (1.0 - cb) * (1.0 - cs)
            }
        }
        Blend::Add => (cb + cs).min(1.0),
        Blend::Darken => cb.min(cs),
        Blend::Lighten => cb.max(cs),
        Blend::Difference => (cb - cs).abs(),
        Blend::Exclusion => cb + cs - 2.0 * cb * cs,
        Blend::HardLight => {
            if cs <= 0.5 {
                2.0 * cb * cs
            } else {
                1.0 - 2.0 * (1.0 - cb) * (1.0 - cs)
            }
        }
        Blend::SoftLight => {
            if cs <= 0.5 {
                cb - (1.0 - 2.0 * cs) * cb * (1.0 - cb)
            } else {
                let d = if cb <= 0.25 { ((16.0 * cb - 12.0) * cb + 4.0) * cb } else { cb.sqrt() };
                cb + (2.0 * cs - 1.0) * (d - cb)
            }
        }
        Blend::ColorDodge => {
            if cb <= 0.0 {
                0.0
            } else if cs >= 1.0 {
                1.0
            } else {
                (cb / (1.0 - cs)).min(1.0)
            }
        }
        Blend::ColorBurn => {
            if cb >= 1.0 {
                1.0
            } else if cs <= 0.0 {
                0.0
            } else {
                1.0 - ((1.0 - cb) / cs).min(1.0)
            }
        }
        _ => cs,
    }
}

/// Blend a straight-colour source with coverage `sa` into a premultiplied destination pixel.
pub fn blend_px(dst: u32, color: u32, sa: f32, mode: Blend) -> u32 {
    let da = ((dst >> 24) & 255) as f32 / 255.0;
    let dr = (dst & 255) as f32 / 255.0;
    let dg = ((dst >> 8) & 255) as f32 / 255.0;
    let db = ((dst >> 16) & 255) as f32 / 255.0;
    let sr = (color & 255) as f32 / 255.0;
    let sg = ((color >> 8) & 255) as f32 / 255.0;
    let sb = ((color >> 16) & 255) as f32 / 255.0;

    let (or, og, ob, oa) = match mode {
        Blend::Eraser => {
            let k = 1.0 - sa;
            (dr * k, dg * k, db * k, da * k)
        }
        Blend::Normal => {
            let k = 1.0 - sa;
            (sr * sa + dr * k, sg * sa + dg * k, sb * sa + db * k, sa + da * k)
        }
        _ => {
            let (cbr, cbg, cbb) = if da > 0.0 { (dr / da, dg / da, db / da) } else { (0.0, 0.0, 0.0) };
            let f = |cs: f32, cb: f32, dpre: f32| -> f32 {
                (1.0 - da) * sa * cs + (1.0 - sa) * dpre + sa * da * blend_channel(mode, cb, cs)
            };
            (f(sr, cbr, dr), f(sg, cbg, dg), f(sb, cbb, db), sa + da * (1.0 - sa))
        }
    };
    to_u8(or) | (to_u8(og) << 8) | (to_u8(ob) << 16) | (to_u8(oa) << 24)
}

// ---------------------------------------------------------------------------------------------
// stroke coverage buffer
// ---------------------------------------------------------------------------------------------

/// Sparse per-tile coverage of the stroke / shape being drawn, plus how to bake it (colour, blend,
/// opacity, optional pattern paint). The layer itself is only modified by [`StrokeBuf::apply_to`].
pub struct StrokeBuf {
    pub width: i32,
    pub height: i32,
    tiles_x: usize,
    cov: Vec<Option<Box<[u8]>>>,
    touched: Vec<usize>,
    dirty: Vec<usize>,
    dirty_flag: Vec<bool>,
    pub color: u32, // straight RGBA, alpha ignored
    pub blend: Blend,
    pub opacity: f32,
    /// Airbrush: overlapping dabs accumulate instead of taking the maximum.
    pub accumulate: bool,
    /// Seamless repeat: dabs / shapes that cross a canvas edge re-enter on the opposite side.
    pub wrap: bool,
    /// Pattern paint for filled shapes (None = flat colour).
    pub paint: Option<Paint>,
    /// Reusable list of (tile-local index, coverage) hits of the dab being stamped (avoids per-dab allocation).
    hits: Vec<(u32, u8)>,
}

impl StrokeBuf {
    pub fn new(width: i32, height: i32, tiles_x: usize, tiles_y: usize, color: u32, blend: Blend, opacity: f32) -> StrokeBuf {
        let total = tiles_x * tiles_y;
        let mut cov = Vec::new();
        cov.resize_with(total, || None);
        StrokeBuf {
            width,
            height,
            tiles_x,
            cov,
            touched: Vec::new(),
            dirty: Vec::new(),
            dirty_flag: vec![false; total],
            color,
            blend,
            opacity,
            accumulate: false,
            wrap: false,
            paint: None,
            hits: Vec::new(),
        }
    }

    pub fn has(&self, idx: usize) -> bool {
        self.cov.get(idx).map_or(false, |c| c.is_some())
    }

    pub fn is_empty(&self) -> bool {
        self.touched.is_empty()
    }

    /// Tiles that hold coverage (in the order they were first touched).
    pub fn touched_tiles(&self) -> &[usize] {
        &self.touched
    }

    /// Tiles whose preview changed since the last call (so the renderer re-uploads them).
    pub fn take_dirty(&mut self) -> Vec<usize> {
        for &i in &self.dirty {
            self.dirty_flag[i] = false;
        }
        std::mem::take(&mut self.dirty)
    }

    /// Forget all coverage (shape preview is redrawn from scratch); the freed tiles are reported dirty.
    pub fn clear(&mut self) {
        let old = std::mem::take(&mut self.touched);
        for idx in old {
            self.cov[idx] = None;
            self.mark_dirty(idx);
        }
    }

    #[inline]
    fn mark_dirty(&mut self, idx: usize) {
        if !self.dirty_flag[idx] {
            self.dirty_flag[idx] = true;
            self.dirty.push(idx);
        }
    }

    fn tile_cov(&mut self, idx: usize) -> &mut [u8] {
        if self.cov[idx].is_none() {
            self.cov[idx] = Some(vec![0u8; TILE * TILE].into_boxed_slice());
            self.touched.push(idx);
        }
        self.mark_dirty(idx);
        self.cov[idx].as_mut().unwrap()
    }

    /// Combine a new coverage value into the stored one.
    #[inline]
    fn merge(accumulate: bool, cur: u8, c: u8) -> u8 {
        if accumulate {
            (cur as u32 + (c as u32 * (255 - cur as u32) + 127) / 255).min(255) as u8
        } else {
            cur.max(c)
        }
    }

    /// Blend the coverage of tile `idx` into the premultiplied tile `px` (colour, blend mode, opacity, pattern).
    pub fn apply_to(&self, idx: usize, px: &mut [u32]) {
        let cov = match self.cov.get(idx).and_then(|c| c.as_ref()) {
            Some(c) => c,
            None => return,
        };
        let (ox, oy) = (((idx % self.tiles_x) * TILE) as u32, ((idx / self.tiles_x) * TILE) as u32);
        let op = self.opacity.clamp(0.0, 1.0);
        for ly in 0..TILE {
            let row = ly * TILE;
            for lx in 0..TILE {
                let c = cov[row + lx];
                if c == 0 {
                    continue;
                }
                let mut a = c as f32 * (1.0 / 255.0) * op;
                let col = match &self.paint {
                    Some(p) => {
                        let s = p.straight_at(ox + lx as u32, oy + ly as u32);
                        a *= (s >> 24) as f32 * (1.0 / 255.0);
                        s
                    }
                    None => self.color,
                };
                if a <= 0.0 {
                    continue;
                }
                px[row + lx] = blend_px(px[row + lx], col, a, self.blend);
            }
        }
    }
}

/// Run `f(pixel_centre_x, pixel_centre_y) -> coverage 0..1` over the canvas pixels of `[x0, x1) x [y0, y1)`
/// (clipped to the canvas) and merge the result into the buffer. Used by the shape renderer.
pub fn fill_cover<F: FnMut(f32, f32) -> f32>(buf: &mut StrokeBuf, x0: i32, y0: i32, x1: i32, y1: i32, mut f: F) {
    let (x0, y0) = (x0.max(0), y0.max(0));
    let (x1, y1) = (x1.min(buf.width), y1.min(buf.height));
    if x0 >= x1 || y0 >= y1 {
        return;
    }
    let acc = buf.accumulate;
    let tiles_x = buf.tiles_x;
    for ty in ((y0 as usize) >> 8)..=(((y1 - 1) as usize) >> 8) {
        for tx in ((x0 as usize) >> 8)..=(((x1 - 1) as usize) >> 8) {
            let idx = ty * tiles_x + tx;
            let bx0 = x0.max((tx * TILE) as i32);
            let bx1 = x1.min(((tx + 1) * TILE) as i32);
            let by0 = y0.max((ty * TILE) as i32);
            let by1 = y1.min(((ty + 1) * TILE) as i32);
            for y in by0..by1 {
                let ly = (y as usize) & 255;
                for x in bx0..bx1 {
                    let c = f(x as f32 + 0.5, y as f32 + 0.5);
                    if c <= 0.002 {
                        continue;
                    }
                    let v = (c.min(1.0) * 255.0 + 0.5) as u8;
                    let cov = buf.tile_cov(idx);
                    let i = ly * TILE + ((x as usize) & 255);
                    cov[i] = StrokeBuf::merge(acc, cov[i], v);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// dabs
// ---------------------------------------------------------------------------------------------

/// Stamp one dab centred at (cx, cy) into the coverage buffer (plus wrapped copies in seamless mode).
pub fn stamp(buf: &mut StrokeBuf, b: &Brush, cx: f32, cy: f32, pressure: f32) {
    if !buf.wrap {
        stamp_one(buf, b, cx, cy, pressure);
        return;
    }
    let (w, h) = (buf.width as f32, buf.height as f32);
    let (cx, cy) = (cx.rem_euclid(w), cy.rem_euclid(h));
    let ext = b.size * 0.5 * b.aspect.max(1.0) + 2.0;
    for oy in [-h, 0.0, h] {
        for ox in [-w, 0.0, w] {
            let (x, y) = (cx + ox, cy + oy);
            if x + ext > 0.0 && x - ext < w && y + ext > 0.0 && y - ext < h {
                stamp_one(buf, b, x, y, pressure);
            }
        }
    }
}

fn stamp_one(buf: &mut StrokeBuf, b: &Brush, cx: f32, cy: f32, pressure: f32) {
    let p = pressure.clamp(0.05, 1.0);
    let size = b.size * (1.0 - b.pressure_size + b.pressure_size * p);
    let flow = b.flow(p);
    if flow <= 0.0005 {
        return;
    }
    let rx = (size * 0.5).max(0.5);
    let ry = (rx * b.aspect).max(0.5);
    let (sn, cs) = b.angle.sin_cos();
    let ext = rx.max(ry) + 1.0;
    let (w, h) = (buf.width, buf.height);
    let x0 = ((cx - ext).floor() as i32).max(0);
    let y0 = ((cy - ext).floor() as i32).max(0);
    let x1 = ((cx + ext).ceil() as i32).min(w - 1);
    let y1 = ((cy + ext).ceil() as i32).min(h - 1);
    if x0 > x1 || y0 > y1 {
        return;
    }
    let acc = buf.accumulate;
    let tiles_x = buf.tiles_x;
    let mut hits = std::mem::take(&mut buf.hits);
    let hard_nib = b.hardness >= 0.999;
    let hard = b.hardness.clamp(0.0, 0.999);
    let min_r = rx.min(ry);
    let reject = 1.0 + 0.75 / min_r; // beyond this normalised distance the AA ramp is certainly 0
    let (irx2, iry2) = (1.0 / (rx * rx), 1.0 / (ry * ry));
    for ty in ((y0 >> 8) as usize)..=((y1 >> 8) as usize) {
        for tx in ((x0 >> 8) as usize)..=((x1 >> 8) as usize) {
            let idx = ty * tiles_x + tx;
            let bx0 = x0.max((tx * TILE) as i32);
            let bx1 = x1.min(((tx + 1) * TILE) as i32 - 1);
            let by0 = y0.max((ty * TILE) as i32);
            let by1 = y1.min(((ty + 1) * TILE) as i32 - 1);
            hits.clear();
            for y in by0..=by1 {
                let ly = (y as usize) & 255;
                let dy = y as f32 + 0.5 - cy;
                for x in bx0..=bx1 {
                    let dx = x as f32 + 0.5 - cx;
                    let u = dx * cs + dy * sn; // nib-space offset in px
                    let v = -dx * sn + dy * cs;
                    let (un, vn) = (u / rx, v / ry);
                    let d = (un * un + vn * vn).sqrt();
                    if d > reject {
                        continue;
                    }
                    // signed distance (px) to the nib outline: exact for a circle, first-order for an ellipse
                    let k1 = ((u * irx2).powi(2) + (v * iry2).powi(2)).sqrt();
                    let sd = if k1 < 1e-9 { -min_r } else { d * (d - 1.0) / k1 };
                    let edge = (0.5 - sd).clamp(0.0, 1.0);
                    if edge <= 0.0 {
                        continue;
                    }
                    let fall = if hard_nib || d <= hard {
                        1.0
                    } else {
                        let t = ((d - hard) / (1.0 - hard)).clamp(0.0, 1.0);
                        1.0 - t * t * (3.0 - 2.0 * t)
                    };
                    let c = edge * fall * flow;
                    if c <= 0.002 {
                        continue;
                    }
                    hits.push(((ly * TILE + ((x as usize) & 255)) as u32, (c * 255.0 + 0.5) as u8));
                }
            }
            if !hits.is_empty() {
                let cov = buf.tile_cov(idx);
                for &(i, q) in hits.iter() {
                    let i = i as usize;
                    cov[i] = StrokeBuf::merge(acc, cov[i], q);
                }
            }
        }
    }
    buf.hits = hits;
}

/// Stamp a dab and all of its symmetric copies.
pub fn stamp_sym(buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry, x: f32, y: f32, p: f32) {
    let mut out = [0u64; MAX_COPIES];
    let n = sym.expand(x, y, &mut out);
    for i in 0..n {
        stamp(buf, b, unpack_x(out[i]), unpack_y(out[i]), p);
    }
}

type Pt = (f32, f32, f32); // x, y, pressure

/// A dab that was stamped, remembered so the end taper can re-render the stroke after the pen lifts.
#[derive(Clone, Copy)]
struct Dab {
    x: f32,
    y: f32,
    p: f32,
    t: f32, // distance travelled along the stroke
}

/// Incremental stroke builder: smooth points in, evenly spaced dabs along a Bezier spline out.
pub struct StrokeState {
    have_last: bool,
    last: Pt,
    mid: Pt,
    next_in: f32,
    dabbed: bool,
    travel: f32,
    rec: Vec<Dab>,
}

impl StrokeState {
    pub fn new() -> Self {
        StrokeState { have_last: false, last: (0.0, 0.0, 1.0), mid: (0.0, 0.0, 1.0), next_in: 0.0, dabbed: false, travel: 0.0, rec: Vec::new() }
    }

    pub fn begin(&mut self) {
        let mut rec = std::mem::take(&mut self.rec);
        rec.clear();
        *self = StrokeState::new();
        self.rec = rec;
    }

    pub fn add_point(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry, x: f32, y: f32, p: f32) {
        if !self.have_last {
            self.have_last = true;
            self.last = (x, y, p);
            self.mid = (x, y, p);
            return;
        }
        let ctrl = self.last;
        let start = self.mid;
        let m1: Pt = ((ctrl.0 + x) * 0.5, (ctrl.1 + y) * 0.5, (ctrl.2 + p) * 0.5);
        self.curve(buf, b, sym, start, ctrl, m1);
        self.mid = m1;
        self.last = (x, y, p);
    }

    pub fn finish(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry) {
        if !self.have_last {
            return;
        }
        let end = self.last;
        let start = self.mid;
        self.line(buf, b, sym, start, end);
        if !self.dabbed {
            stamp_sym(buf, b, sym, end.0, end.1, end.2);
            self.dabbed = true;
        }
        if b.end_taper_on() && self.travel >= 1.0 && !self.rec.is_empty() && self.rec.len() < MAX_REC {
            self.replay_tapered(buf, b, sym);
        }
        self.have_last = false;
    }

    /// Re-render the whole stroke with the end taper (the live preview cannot know where the stroke ends).
    fn replay_tapered(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry) {
        let total = self.travel;
        let mut ls = if b.start_taper_on() { b.taper_len(b.taper_start) } else { 0.0 };
        let mut le = b.taper_len(b.taper_end);
        if ls + le > total {
            let k = total / (ls + le);
            ls *= k;
            le *= k;
        }
        buf.clear();
        let rec = std::mem::take(&mut self.rec);
        let mut bb = *b;
        for d in &rec {
            let ms = if ls > 0.0 { taper_mul(b.taper_start_tip, ls, d.t) } else { 1.0 };
            let me = taper_mul(b.taper_end_tip, le, total - d.t);
            bb.size = b.size * ms * me;
            stamp_sym(buf, &bb, sym, d.x, d.y, d.p);
        }
        self.rec = rec;
    }

    fn curve(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry, a: Pt, c: Pt, e: Pt) {
        let l1 = ((c.0 - a.0).powi(2) + (c.1 - a.1).powi(2)).sqrt();
        let l2 = ((e.0 - c.0).powi(2) + (e.1 - c.1).powi(2)).sqrt();
        // ~2 px chords: the polyline error of a quadratic Bezier stays far below the AA ramp
        let n = (((l1 + l2) / 2.0).ceil() as usize).clamp(1, 96);
        let mut prev = a;
        for i in 1..=n {
            let t = i as f32 / n as f32;
            let o = 1.0 - t;
            let pt: Pt = (
                o * o * a.0 + 2.0 * o * t * c.0 + t * t * e.0,
                o * o * a.1 + 2.0 * o * t * c.1 + t * t * e.1,
                o * o * a.2 + 2.0 * o * t * c.2 + t * t * e.2,
            );
            self.line(buf, b, sym, prev, pt);
            prev = pt;
        }
    }

    fn emit(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry, x: f32, y: f32, p: f32, t: f32) {
        let ms = if b.start_taper_on() { taper_mul(b.taper_start_tip, b.taper_len(b.taper_start), t) } else { 1.0 };
        if ms == 1.0 {
            stamp_sym(buf, b, sym, x, y, p);
        } else {
            let mut bb = *b;
            bb.size = b.size * ms;
            stamp_sym(buf, &bb, sym, x, y, p);
        }
        self.dabbed = true;
        if b.end_taper_on() && self.rec.len() < MAX_REC {
            self.rec.push(Dab { x, y, p, t });
        }
    }

    fn line(&mut self, buf: &mut StrokeBuf, b: &Brush, sym: &Symmetry, a: Pt, e: Pt) {
        let dx = e.0 - a.0;
        let dy = e.1 - a.1;
        let d = (dx * dx + dy * dy).sqrt();
        if d <= 0.0001 {
            return;
        }
        let step = (b.size * b.spacing).max(MIN_STEP);
        let mut s = self.next_in;
        while s <= d {
            let f = s / d;
            let t = self.travel + s;
            self.emit(buf, b, sym, a.0 + dx * f, a.1 + dy * f, a.2 + (e.2 - a.2) * f, t);
            s += step;
        }
        self.next_in = s - d;
        self.travel += d;
    }
}
