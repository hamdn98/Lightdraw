//! Picking an "object" out of a raster layer.
//!
//! LightDraw layers are pixel (tile) canvases, so an object is defined by what is drawn:
//!  * `lift_component` : the 8-connected region of non-transparent pixels under the tapped point
//!    (a stroke, a shape, an imported picture, a duplicated object ...);
//!  * `lift_rect`      : everything inside a marquee rectangle;
//!  * `lift_all`       : all content of the layer.
//! "Lifting" copies those pixels into a tight bitmap and erases them from the layer.

use crate::tiled_canvas::{TiledCanvas, TILE};

/// Largest object we are willing to hold in RAM (16 MP = 64 MB of RGBA).
pub const MAX_OBJECT_PIXELS: usize = 16_000_000;

pub struct Lifted {
    pub x0: i32,
    pub y0: i32,
    pub w: usize,
    pub h: usize,
    pub px: Vec<u32>,
}

#[derive(Debug, PartialEq, Eq)]
pub enum LiftError {
    Nothing,
    TooLarge,
}

/// Zero the rectangle [x0,x1) x [y0,y1) of the canvas (only tiles that actually hold content are touched).
pub fn clear_rect(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32) {
    let (x0, y0) = (x0.max(0), y0.max(0));
    let (x1, y1) = (x1.min(canvas.width as i32), y1.min(canvas.height as i32));
    if x0 >= x1 || y0 >= y1 {
        return;
    }
    let tiles_x = canvas.tiles_x;
    for ty in (y0 as usize >> 8)..=((y1 - 1) as usize >> 8) {
        for tx in (x0 as usize >> 8)..=((x1 - 1) as usize >> 8) {
            let idx = ty * tiles_x + tx;
            if !canvas.exists(idx) {
                continue;
            }
            let (ox, oy) = ((tx * TILE) as i32, (ty * TILE) as i32);
            let (lx0, lx1) = ((x0 - ox).max(0) as usize, (x1 - ox).min(TILE as i32) as usize);
            let (ly0, ly1) = ((y0 - oy).max(0) as usize, (y1 - oy).min(TILE as i32) as usize);
            let has = match canvas.tile_pixels(idx) {
                Some(px) => (ly0..ly1).any(|ly| px[ly * TILE + lx0..ly * TILE + lx1].iter().any(|&p| p != 0)),
                None => false,
            };
            if !has {
                continue;
            }
            let px = canvas.tile_mut(idx);
            for ly in ly0..ly1 {
                px[ly * TILE + lx0..ly * TILE + lx1].fill(0);
            }
        }
    }
}

/// Copy + erase the content inside the rectangle; the result is cropped to the content's bounds.
pub fn lift_rect(canvas: &mut TiledCanvas, rx0: i32, ry0: i32, rx1: i32, ry1: i32) -> Result<Lifted, LiftError> {
    let (rx0, ry0) = (rx0.max(0), ry0.max(0));
    let (rx1, ry1) = (rx1.min(canvas.width as i32), ry1.min(canvas.height as i32));
    if rx0 >= rx1 || ry0 >= ry1 {
        return Err(LiftError::Nothing);
    }
    let rw = (rx1 - rx0) as usize;
    let mut row = vec![0u32; rw];
    let (mut bx0, mut by0, mut bx1, mut by1) = (i32::MAX, i32::MAX, i32::MIN, i32::MIN);
    for y in ry0..ry1 {
        canvas.read_row(y as u32, rx0 as u32, &mut row);
        if let Some(f) = row.iter().position(|&p| p >> 24 != 0) {
            let l = row.iter().rposition(|&p| p >> 24 != 0).unwrap_or(f);
            bx0 = bx0.min(rx0 + f as i32);
            bx1 = bx1.max(rx0 + l as i32 + 1);
            by0 = by0.min(y);
            by1 = by1.max(y + 1);
        }
    }
    if bx0 == i32::MAX {
        return Err(LiftError::Nothing);
    }
    let (w, h) = ((bx1 - bx0) as usize, (by1 - by0) as usize);
    if w.saturating_mul(h) > MAX_OBJECT_PIXELS {
        return Err(LiftError::TooLarge);
    }
    let mut px = vec![0u32; w * h];
    for y in by0..by1 {
        let dst = &mut px[(y - by0) as usize * w..(y - by0 + 1) as usize * w];
        canvas.read_row(y as u32, bx0 as u32, dst);
    }
    clear_rect(canvas, bx0, by0, bx1, by1);
    Ok(Lifted { x0: bx0, y0: by0, w, h, px })
}

pub fn lift_all(canvas: &mut TiledCanvas) -> Result<Lifted, LiftError> {
    let (w, h) = (canvas.width as i32, canvas.height as i32);
    lift_rect(canvas, 0, 0, w, h)
}

// ---------------------------------------------------------------------------------------------

struct Bits {
    tiles: Vec<Option<Box<[u64]>>>,
    tiles_x: usize,
}

impl Bits {
    fn new(tiles_x: usize, total: usize) -> Bits {
        let mut tiles = Vec::new();
        tiles.resize_with(total, || None);
        Bits { tiles, tiles_x }
    }

    #[inline]
    fn loc(&self, x: i32, y: i32) -> (usize, usize, u64) {
        let t = (y as usize >> 8) * self.tiles_x + (x as usize >> 8);
        let bit = ((y as usize) & 255) * TILE + ((x as usize) & 255);
        (t, bit >> 6, 1u64 << (bit & 63))
    }

    fn get(&self, x: i32, y: i32) -> bool {
        let (t, w, m) = self.loc(x, y);
        self.tiles[t].as_ref().map_or(false, |b| b[w] & m != 0)
    }

    fn set(&mut self, x: i32, y: i32) {
        let (t, w, m) = self.loc(x, y);
        let slot = &mut self.tiles[t];
        if slot.is_none() {
            *slot = Some(vec![0u64; TILE * TILE / 64].into_boxed_slice());
        }
        slot.as_mut().unwrap()[w] |= m;
    }
}

/// Copy + erase the 8-connected non-transparent region containing (sx, sy).
pub fn lift_component(canvas: &mut TiledCanvas, sx: i32, sy: i32) -> Result<Lifted, LiftError> {
    let (cw, ch) = (canvas.width as i32, canvas.height as i32);
    if sx < 0 || sy < 0 || sx >= cw || sy >= ch || canvas.get_pixel(sx, sy) >> 24 == 0 {
        return Err(LiftError::Nothing);
    }
    let mut seen = Bits::new(canvas.tiles_x, canvas.tile_count());
    let mut spans: Vec<(i32, i32, i32)> = Vec::new(); // (y, x0, x1) inclusive
    let mut stack = vec![(sx, sy)];
    let mut count = 0usize;
    let (mut bx0, mut by0, mut bx1, mut by1) = (i32::MAX, i32::MAX, i32::MIN, i32::MIN);

    while let Some((x, y)) = stack.pop() {
        if seen.get(x, y) || canvas.get_pixel(x, y) >> 24 == 0 {
            continue;
        }
        let mut xl = x;
        while xl > 0 && !seen.get(xl - 1, y) && canvas.get_pixel(xl - 1, y) >> 24 != 0 {
            xl -= 1;
        }
        let mut xr = x;
        while xr + 1 < cw && !seen.get(xr + 1, y) && canvas.get_pixel(xr + 1, y) >> 24 != 0 {
            xr += 1;
        }
        for xx in xl..=xr {
            seen.set(xx, y);
        }
        count += (xr - xl + 1) as usize;
        if count > MAX_OBJECT_PIXELS {
            return Err(LiftError::TooLarge);
        }
        spans.push((y, xl, xr));
        bx0 = bx0.min(xl);
        bx1 = bx1.max(xr + 1);
        by0 = by0.min(y);
        by1 = by1.max(y + 1);
        for ny in [y - 1, y + 1] {
            if ny < 0 || ny >= ch {
                continue;
            }
            let mut in_run = false;
            for xx in (xl - 1).max(0)..=(xr + 1).min(cw - 1) {
                let ok = !seen.get(xx, ny) && canvas.get_pixel(xx, ny) >> 24 != 0;
                if ok && !in_run {
                    stack.push((xx, ny));
                    in_run = true;
                } else if !ok {
                    in_run = false;
                }
            }
        }
    }

    let (w, h) = ((bx1 - bx0) as usize, (by1 - by0) as usize);
    if w.saturating_mul(h) > MAX_OBJECT_PIXELS {
        return Err(LiftError::TooLarge);
    }
    let mut px = vec![0u32; w * h];
    let mut line: Vec<u32> = Vec::new();
    for &(y, x0, x1) in &spans {
        let n = (x1 - x0 + 1) as usize;
        line.resize(n, 0);
        canvas.read_row(y as u32, x0 as u32, &mut line);
        let o = (y - by0) as usize * w + (x0 - bx0) as usize;
        px[o..o + n].copy_from_slice(&line);
    }
    // erase exactly the lifted pixels (neighbouring objects inside the bbox stay in the layer)
    for &(y, x0, x1) in &spans {
        let mut x = x0;
        while x <= x1 {
            let tx = x as usize >> 8;
            let seg_end = x1.min(((tx + 1) * TILE - 1) as i32);
            let idx = (y as usize >> 8) * canvas.tiles_x + tx;
            let t = canvas.tile_mut(idx);
            let ly = (y as usize) & 255;
            for xx in x..=seg_end {
                t[ly * TILE + (xx as usize & 255)] = 0;
            }
            x = seg_end + 1;
        }
    }
    Ok(Lifted { x0: bx0, y0: by0, w, h, px })
}
