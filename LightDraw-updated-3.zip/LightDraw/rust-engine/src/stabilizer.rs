//! Streamline stabilizer: damped spring follower + short moving average.
//! Fixed-size state, no heap allocation.

pub struct Stabilizer {
    strength: f32,
    px: f32,
    py: f32,
    vx: f32,
    vy: f32,
    tx: f32,
    ty: f32,
    last_t: i64,
    started: bool,
    rx: [f32; 8],
    ry: [f32; 8],
    head: usize,
    len: usize,
    win: usize,
    k: f32,
    c: f32,
}

impl Stabilizer {
    pub fn new() -> Self {
        let mut s = Stabilizer {
            strength: 0.0,
            px: 0.0,
            py: 0.0,
            vx: 0.0,
            vy: 0.0,
            tx: 0.0,
            ty: 0.0,
            last_t: 0,
            started: false,
            rx: [0.0; 8],
            ry: [0.0; 8],
            head: 0,
            len: 0,
            win: 1,
            k: 1000.0,
            c: 60.0,
        };
        s.set_strength(0.0);
        s
    }

    /// `s` in 0..1 (0 = off, 1 = maximum smoothing).
    pub fn set_strength(&mut self, s: f32) {
        let s = s.clamp(0.0, 1.0);
        self.strength = s;
        let inv = 1.0 - s;
        self.k = 30.0 + 1400.0 * inv * inv;
        self.c = 2.0 * 0.85 * self.k.sqrt();
        self.win = 1 + (s * 6.0).round() as usize;
    }

    fn push(&mut self, x: f32, y: f32) {
        self.rx[self.head] = x;
        self.ry[self.head] = y;
        self.head = (self.head + 1) % 8;
        if self.len < 8 {
            self.len += 1;
        }
    }

    fn avg(&self) -> (f32, f32) {
        let n = self.win.min(self.len).max(1);
        let mut sx = 0.0f32;
        let mut sy = 0.0f32;
        for i in 0..n {
            let k = (self.head + 8 - 1 - i) % 8;
            sx += self.rx[k];
            sy += self.ry[k];
        }
        let nf = n as f32;
        (sx / nf, sy / nf)
    }

    fn advance(&mut self, dt: f32) {
        let mut left = dt;
        while left > 0.0 {
            let h = left.min(0.004);
            let ax = self.k * (self.tx - self.px) - self.c * self.vx;
            let ay = self.k * (self.ty - self.py) - self.c * self.vy;
            self.vx += ax * h;
            self.vy += ay * h;
            self.px += self.vx * h;
            self.py += self.vy * h;
            left -= h;
        }
    }

    pub fn begin(&mut self, x: f32, y: f32, t: i64) {
        self.px = x;
        self.py = y;
        self.vx = 0.0;
        self.vy = 0.0;
        self.tx = x;
        self.ty = y;
        self.last_t = t;
        self.started = true;
        self.head = 0;
        self.len = 0;
        self.push(x, y);
    }

    /// Feed a raw input point, get the smoothed point.
    pub fn feed(&mut self, x: f32, y: f32, t: i64) -> (f32, f32) {
        if !self.started {
            self.begin(x, y, t);
            return (x, y);
        }
        self.tx = x;
        self.ty = y;
        if self.strength < 0.01 {
            self.px = x;
            self.py = y;
            self.last_t = t;
            self.push(x, y);
            return (x, y);
        }
        let dt = (((t - self.last_t) as f32) / 1000.0).clamp(0.001, 0.05);
        self.last_t = t;
        self.advance(dt);
        let (px, py) = (self.px, self.py);
        self.push(px, py);
        self.avg()
    }

    /// After the pen is lifted: let the smoothed tip catch up with the last real point.
    /// Returns `None` once converged.
    pub fn flush_step(&mut self) -> Option<(f32, f32)> {
        if !self.started {
            return None;
        }
        let (ax, ay) = self.avg();
        if (ax - self.tx).abs() < 0.4 && (ay - self.ty).abs() < 0.4 {
            self.started = false;
            return None;
        }
        self.advance(0.008);
        let (px, py) = (self.px, self.py);
        self.push(px, py);
        Some(self.avg())
    }
}
