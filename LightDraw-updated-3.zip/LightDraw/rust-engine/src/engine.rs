//! The whole drawing engine as plain Rust (no JNI): scene (layers + objects), brush, stabilizer,
//! symmetry, export row sources. `engine_core.rs` is only a thin JNI shim around this type, which
//! keeps every behaviour unit-testable on a desktop.

use std::io::{self, Write};
use std::path::PathBuf;

use crate::brush_engine::{over, Blend, Brush, StrokeState};
use crate::color_engine::{replace_same_color, HslTolerance};
use crate::jpeg_enc::JpegEncoder;
use crate::pattern_fill::{flood_fill, FillResult};
use crate::scene::Scene;
use crate::shapes::ShapeParams;
use crate::stabilizer::Stabilizer;
use crate::surface::Surface;
use crate::symmetry::Symmetry;
use crate::tiled_canvas::{pack_rgba, premul, unpremul};

/// Android `Color` int (0xAARRGGBB) -> straight RGBA pixel (R in the low byte).
pub fn argb_to_px(c: i32) -> u32 {
    let c = c as u32;
    pack_rgba(((c >> 16) & 255) as u8, ((c >> 8) & 255) as u8, (c & 255) as u8, (c >> 24) as u8)
}

/// Straight RGBA pixel -> Android `Color` int.
pub fn px_to_argb(p: u32) -> i32 {
    let (r, g, b, a) = (p & 255, (p >> 8) & 255, (p >> 16) & 255, p >> 24);
    ((a << 24) | (r << 16) | (g << 8) | b) as i32
}

/// Premultiplied canvas pixel composited over the paper colour (straight RGBA, alpha 0 = no paper).
pub fn composite_over_bg(src: u32, bg: u32) -> u32 {
    if bg >> 24 == 0 {
        src
    } else {
        over(premul(bg), src)
    }
}

pub struct Engine {
    pub scene: Scene,
    pub brush: Brush,
    pub stab: Stabilizer,
    pub sym: Symmetry,
    stroke: StrokeState,
    drawing: bool,
    last_p: f32,
    /// Smoothed pen speed in canvas px / ms and the previous raw sample (for speed thinning).
    speed: f32,
    last_raw: (f32, f32, i64),
    /// Paper colour, straight RGBA; alpha 0 = transparent paper.
    pub bg: u32,
    /// Paper / cloth texture (drawn by the GL renderer; baked into exports when `surface.active()`).
    pub surface: Surface,
}

impl Engine {
    pub fn new(w: u32, h: u32, dir: PathBuf, budget: usize) -> Engine {
        Engine::from_scene(Scene::new(w, h, dir, budget), 0xFFFF_FFFF)
    }

    pub fn from_scene(scene: Scene, bg: u32) -> Engine {
        let sym = Symmetry::new(scene.width, scene.height);
        Engine { scene, brush: Brush::new(), stab: Stabilizer::new(), sym, stroke: StrokeState::new(), drawing: false, last_p: 1.0, speed: 0.0, last_raw: (0.0, 0.0, 0), bg, surface: Surface::new() }
    }

    // ---------------------------------------------------------------- brush strokes

    fn add_point(&mut self, x: f32, y: f32, p: f32) {
        if let Some(buf) = self.scene.stroke.as_mut() {
            self.stroke.add_point(buf, &self.brush, &self.sym, x, y, p);
        }
        self.scene.stroke_changed();
    }

    /// Pressure after the pen curve and speed thinning (a fast flick gets thinner, like a real pen).
    fn dynamics(&mut self, x: f32, y: f32, p: f32, t: i64) -> f32 {
        let mut q = self.brush.shape_pressure(p);
        let (lx, ly, lt) = self.last_raw;
        let dt = (t - lt).max(1) as f32;
        let v = ((x - lx).powi(2) + (y - ly).powi(2)).sqrt() / dt;
        self.speed = self.speed * 0.8 + v * 0.2;
        self.last_raw = (x, y, t);
        if self.brush.speed_thin > 0.001 {
            let k = (self.speed / 3.0).clamp(0.0, 1.0);
            let k = k * k * (3.0 - 2.0 * k);
            q *= 1.0 - self.brush.speed_thin * 0.85 * k;
        }
        q.clamp(0.05, 1.0)
    }

    pub fn stroke_begin(&mut self, x: f32, y: f32, p: f32, t: i64) {
        self.speed = 0.0;
        self.last_raw = (x, y, t);
        let p = self.brush.shape_pressure(p).clamp(0.05, 1.0);
        self.scene.start_stroke(self.brush.color, self.brush.blend, self.brush.opacity, self.brush.buildup);
        self.stab.begin(x, y, t);
        self.stroke.begin();
        self.drawing = true;
        self.last_p = p;
        self.add_point(x, y, p);
    }

    pub fn stroke_move(&mut self, x: f32, y: f32, p: f32, t: i64) {
        if !self.drawing {
            return;
        }
        let (sx, sy) = self.stab.feed(x, y, t);
        let p = self.dynamics(x, y, p, t);
        self.last_p = p;
        self.add_point(sx, sy, p);
    }

    pub fn stroke_end(&mut self) {
        if !self.drawing {
            return;
        }
        let mut n = 0;
        while n < 120 {
            match self.stab.flush_step() {
                Some((x, y)) => {
                    let p = self.last_p;
                    self.add_point(x, y, p);
                }
                None => break,
            }
            n += 1;
        }
        if let Some(buf) = self.scene.stroke.as_mut() {
            self.stroke.finish(buf, &self.brush, &self.sym);
        }
        self.scene.stroke_changed();
        self.scene.end_stroke();
        self.drawing = false;
    }

    pub fn stroke_cancel(&mut self) {
        if self.drawing {
            self.scene.cancel_stroke();
            self.drawing = false;
        }
    }

    // ---------------------------------------------------------------- shapes

    #[allow(clippy::too_many_arguments)]
    pub fn shape_update(&mut self, p: &ShapeParams, color: u32, opacity: f32, blend: Blend, paint_kind: i32, color2: u32, pattern_scale: f32) {
        let paint = self.scene.make_paint(paint_kind, color, color2, pattern_scale);
        self.scene.shape_update(p, color, paint, opacity, blend);
    }

    pub fn shape_end(&mut self) {
        self.scene.end_stroke();
    }

    pub fn shape_cancel(&mut self) {
        self.scene.cancel_stroke();
    }

    // ---------------------------------------------------------------- fill / colour tools

    /// 0 ok, 1 out of bounds, 2 region too large.
    pub fn fill(&mut self, x: i32, y: i32, kind: i32, c1: u32, c2: u32, scale: f32, tol: i32) -> i32 {
        let paint = self.scene.make_paint(kind, c1, c2, scale);
        match self.scene.edit(|c| flood_fill(c, x, y, tol, &paint)) {
            FillResult::Painted(_) => 0,
            FillResult::OutOfBounds => 1,
            FillResult::TooLarge => 2,
        }
    }

    pub fn select_replace(&mut self, x: i32, y: i32, new_color: u32, tol: HslTolerance) -> u32 {
        self.scene.edit(|c| {
            let target = c.get_pixel(x, y);
            replace_same_color(c, target, new_color, tol)
        })
    }

    /// Visible colour at (x, y) over the paper (opaque white when the paper is transparent), as straight RGBA.
    pub fn pick_color(&mut self, x: i32, y: i32) -> u32 {
        let p = self.scene.composite_pixel(x, y);
        let bg = if self.bg >> 24 == 0 { 0xFFFF_FFFF } else { self.bg };
        unpremul(composite_over_bg(p, bg))
    }

    // ---------------------------------------------------------------- export / render

    /// Render the flattened canvas row by row, scaled (nearest) to `dw` x `dh`, over `bg`.
    /// `sink(y, row)` receives every destination row (`dw` premultiplied RGBA pixels).
    pub fn render_rows<F: FnMut(usize, &[u32])>(&mut self, dw: usize, dh: usize, bg: u32, mut sink: F) {
        self.scene.commit_float();
        let (cw, ch) = (self.scene.width as usize, self.scene.height as usize);
        if dw == 0 || dh == 0 {
            return;
        }
        let mut src = vec![0u32; cw];
        let mut out = vec![0u32; dw];
        // texture only on an opaque paper (a transparent export keeps its alpha untouched)
        let shade = self.surface.active() && bg >> 24 == 255;
        let mut last_sy = usize::MAX;
        for y in 0..dh {
            let sy = (y * ch / dh).min(ch - 1);
            if sy != last_sy {
                self.scene.composite_row(sy as u32, 0, &mut src);
                last_sy = sy;
            }
            for (x, o) in out.iter_mut().enumerate() {
                let sx = if dw == cw { x } else { (x * cw / dw).min(cw - 1) };
                let p = composite_over_bg(src[sx], bg);
                *o = if shade { self.surface.shade(sx, sy, p) } else { p };
            }
            sink(y, &out);
        }
    }

    /// Full-size JPEG at the requested quality (100 = all quantiser steps 1, 4:4:4), streamed row by row
    /// so even a 16384 x 16384 artboard is never scaled down and never needs a full RGB buffer.
    pub fn export_jpeg<W: Write>(&mut self, out: W, bg: u32, quality: u32) -> io::Result<W> {
        let bg = if bg >> 24 == 0 { 0xFFFF_FFFF } else { bg | 0xFF00_0000 };
        let (w, h) = (self.scene.width as usize, self.scene.height as usize);
        let mut enc = JpegEncoder::new(out, w, h, quality)?;
        let mut rgb = vec![0u8; w * 3];
        let mut err: Option<io::Error> = None;
        self.render_rows(w, h, bg, |_, row| {
            if err.is_some() {
                return;
            }
            for (x, &p) in row.iter().enumerate() {
                rgb[x * 3] = (p & 255) as u8;
                rgb[x * 3 + 1] = ((p >> 8) & 255) as u8;
                rgb[x * 3 + 2] = ((p >> 16) & 255) as u8;
            }
            if let Err(e) = enc.push_row(&rgb) {
                err = Some(e);
            }
        });
        if let Some(e) = err {
            return Err(e);
        }
        enc.finish()
    }
}
