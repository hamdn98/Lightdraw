//! Dependency-free baseline JPEG encoder built for *maximum fidelity* export.
//!
//!  * quality 100 => every quantisation step is 1 (the only loss left is rounding of the DCT);
//!  * 4:4:4 (no chroma sub-sampling), so coloured edges stay as crisp as in the canvas;
//!  * streaming: rows are pushed one at a time and an 8-row strip is encoded as soon as it is full,
//!    so a 16384 x 16384 artboard never needs a full-size RGB buffer and is **never down-scaled**.
//!
//! Android's `Bitmap.compress(JPEG, 100)` cannot guarantee 4:4:4 and needs the whole bitmap in RAM,
//! which is why the export pipeline uses this encoder instead.

use std::io::{self, Write};

const ZIGZAG: [usize; 64] = [
    0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50,
    43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
];

const Q_LUMA: [u16; 64] = [
    16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37,
    56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99,
];

const Q_CHROMA: [u16; 64] = [
    17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
];

// Standard (Annex K.3) luminance Huffman tables. Used for all three components.
const DC_BITS: [u8; 16] = [0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0];
const DC_VALS: [u8; 12] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const AC_BITS: [u8; 16] = [0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d];
const AC_VALS: [u8; 162] = [
    0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1,
    0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0, 0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26,
    0x27, 0x28, 0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56,
    0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85,
    0x86, 0x87, 0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa,
    0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6,
    0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9,
    0xfa,
];

/// code, length per symbol
fn build_codes(bits: &[u8; 16], vals: &[u8]) -> [(u16, u8); 256] {
    let mut table = [(0u16, 0u8); 256];
    let mut code: u16 = 0;
    let mut k = 0usize;
    for len in 1..=16u8 {
        for _ in 0..bits[len as usize - 1] {
            table[vals[k] as usize] = (code, len);
            code += 1;
            k += 1;
        }
        code <<= 1;
    }
    table
}

pub struct JpegEncoder<W: Write> {
    out: W,
    width: usize,
    height: usize,
    padded_w: usize,
    qy: [f32; 64],
    qc: [f32; 64],
    dc_codes: [(u16, u8); 256],
    ac_codes: [(u16, u8); 256],
    dct: [[f32; 8]; 8],
    strip: Vec<u8>, // up to 8 rows of RGB
    rows_in: usize,
    rows_done: usize,
    acc: u32,
    nbits: u32,
    prev_dc: [i32; 3],
    plane: [Vec<f32>; 3],
}

fn scaled_table(base: &[u16; 64], quality: u32) -> [u16; 64] {
    let q = quality.clamp(1, 100);
    let scale = if q < 50 { 5000 / q } else { 200 - 2 * q };
    let mut t = [1u16; 64];
    for i in 0..64 {
        t[i] = ((base[i] as u32 * scale + 50) / 100).clamp(1, 255) as u16;
    }
    t
}

impl<W: Write> JpegEncoder<W> {
    /// Writes the JPEG headers. `quality` 1..=100 (100 = all quantisation steps 1).
    pub fn new(mut out: W, width: usize, height: usize, quality: u32) -> io::Result<Self> {
        if width == 0 || height == 0 || width > 65535 || height > 65535 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "bad jpeg size"));
        }
        let ql = scaled_table(&Q_LUMA, quality);
        let qc = scaled_table(&Q_CHROMA, quality);
        // SOI + JFIF (72 dpi, aspect 1:1)
        out.write_all(&[0xFF, 0xD8, 0xFF, 0xE0, 0, 16, b'J', b'F', b'I', b'F', 0, 1, 1, 0, 0, 72, 0, 72, 0, 0])?;
        // DQT (8-bit, zig-zag order)
        for (id, t) in [(0u8, &ql), (1u8, &qc)] {
            out.write_all(&[0xFF, 0xDB, 0, 67, id])?;
            let zz: Vec<u8> = (0..64).map(|i| t[ZIGZAG[i]] as u8).collect();
            out.write_all(&zz)?;
        }
        // SOF0: 8-bit, 3 components, all 1x1 sampling (4:4:4)
        out.write_all(&[0xFF, 0xC0, 0, 17, 8])?;
        out.write_all(&(height as u16).to_be_bytes())?;
        out.write_all(&(width as u16).to_be_bytes())?;
        out.write_all(&[3, 1, 0x11, 0, 2, 0x11, 1, 3, 0x11, 1])?;
        // DHT: DC table 0, AC table 0
        out.write_all(&[0xFF, 0xC4, 0, (19 + DC_VALS.len()) as u8, 0x00])?;
        out.write_all(&DC_BITS)?;
        out.write_all(&DC_VALS)?;
        out.write_all(&[0xFF, 0xC4, 0, (19 + AC_VALS.len()) as u8, 0x10])?;
        out.write_all(&AC_BITS)?;
        out.write_all(&AC_VALS)?;
        // SOS: all components use Huffman table 0
        out.write_all(&[0xFF, 0xDA, 0, 12, 3, 1, 0x00, 2, 0x00, 3, 0x00, 0, 63, 0])?;

        let mut dct = [[0f32; 8]; 8];
        for (u, row) in dct.iter_mut().enumerate() {
            let cu = if u == 0 { std::f32::consts::FRAC_1_SQRT_2 } else { 1.0 };
            for (x, v) in row.iter_mut().enumerate() {
                *v = 0.5 * cu * ((2 * x + 1) as f32 * u as f32 * std::f32::consts::PI / 16.0).cos();
            }
        }
        let padded_w = (width + 7) & !7;
        let mut qyf = [0f32; 64];
        let mut qcf = [0f32; 64];
        for i in 0..64 {
            qyf[i] = ql[i] as f32;
            qcf[i] = qc[i] as f32;
        }
        Ok(JpegEncoder {
            out,
            width,
            height,
            padded_w,
            qy: qyf,
            qc: qcf,
            dc_codes: build_codes(&DC_BITS, &DC_VALS),
            ac_codes: build_codes(&AC_BITS, &AC_VALS),
            dct,
            strip: vec![0u8; 8 * width * 3],
            rows_in: 0,
            rows_done: 0,
            acc: 0,
            nbits: 0,
            prev_dc: [0; 3],
            plane: [vec![0.0; 8 * padded_w], vec![0.0; 8 * padded_w], vec![0.0; 8 * padded_w]],
        })
    }

    /// Push one row of `width * 3` RGB bytes.
    pub fn push_row(&mut self, rgb: &[u8]) -> io::Result<()> {
        if rgb.len() < self.width * 3 || self.rows_done + self.rows_in >= self.height {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "bad row"));
        }
        let o = self.rows_in * self.width * 3;
        self.strip[o..o + self.width * 3].copy_from_slice(&rgb[..self.width * 3]);
        self.rows_in += 1;
        if self.rows_in == 8 {
            self.encode_strip()?;
        }
        Ok(())
    }

    pub fn finish(mut self) -> io::Result<W> {
        if self.rows_in > 0 {
            self.encode_strip()?;
        }
        self.flush_bits(true)?;
        self.out.write_all(&[0xFF, 0xD9])?;
        self.out.flush()?;
        Ok(self.out)
    }

    #[inline]
    fn put_bits(&mut self, code: u32, len: u32) -> io::Result<()> {
        if len == 0 {
            return Ok(());
        }
        self.acc = (self.acc << len) | (code & ((1u32 << len) - 1));
        self.nbits += len;
        while self.nbits >= 8 {
            let byte = ((self.acc >> (self.nbits - 8)) & 0xFF) as u8;
            self.out.write_all(&[byte])?;
            if byte == 0xFF {
                self.out.write_all(&[0])?;
            }
            self.nbits -= 8;
        }
        Ok(())
    }

    fn flush_bits(&mut self, pad: bool) -> io::Result<()> {
        if pad && self.nbits > 0 {
            let fill = 8 - self.nbits;
            self.put_bits((1 << fill) - 1, fill)?;
        }
        Ok(())
    }

    fn encode_strip(&mut self) -> io::Result<()> {
        let w = self.width;
        let pw = self.padded_w;
        let rows = self.rows_in;
        // RGB -> YCbCr planes (level shifted by -128), replicating the last row/column for padding
        for y in 0..8 {
            let sy = y.min(rows - 1);
            for x in 0..pw {
                let sx = x.min(w - 1);
                let i = (sy * w + sx) * 3;
                let (r, g, b) = (self.strip[i] as f32, self.strip[i + 1] as f32, self.strip[i + 2] as f32);
                let o = y * pw + x;
                self.plane[0][o] = 0.299 * r + 0.587 * g + 0.114 * b - 128.0;
                self.plane[1][o] = -0.168736 * r - 0.331264 * g + 0.5 * b;
                self.plane[2][o] = 0.5 * r - 0.418688 * g - 0.081312 * b;
            }
        }
        for bx in 0..pw / 8 {
            for c in 0..3 {
                let mut blk = [0f32; 64];
                for y in 0..8 {
                    for x in 0..8 {
                        blk[y * 8 + x] = self.plane[c][y * pw + bx * 8 + x];
                    }
                }
                let q = if c == 0 { self.qy } else { self.qc };
                let zz = self.dct_quant(&blk, &q);
                self.encode_block(&zz, c)?;
            }
        }
        self.rows_done += rows;
        self.rows_in = 0;
        Ok(())
    }

    fn dct_quant(&self, blk: &[f32; 64], q: &[f32; 64]) -> [i32; 64] {
        // F = M * blk * M^T
        let mut tmp = [0f32; 64];
        for u in 0..8 {
            for x in 0..8 {
                let mut s = 0.0;
                for y in 0..8 {
                    s += self.dct[u][y] * blk[y * 8 + x];
                }
                tmp[u * 8 + x] = s;
            }
        }
        let mut out = [0i32; 64];
        for u in 0..8 {
            for v in 0..8 {
                let mut s = 0.0;
                for x in 0..8 {
                    s += tmp[u * 8 + x] * self.dct[v][x];
                }
                let idx = u * 8 + v;
                let quant = (s / q[idx]).round() as i32;
                out[idx] = if idx == 0 { quant.clamp(-2047, 2047) } else { quant.clamp(-1023, 1023) };
            }
        }
        let mut zz = [0i32; 64];
        for i in 0..64 {
            zz[i] = out[ZIGZAG[i]];
        }
        zz
    }

    fn encode_block(&mut self, zz: &[i32; 64], comp: usize) -> io::Result<()> {
        let diff = zz[0] - self.prev_dc[comp];
        self.prev_dc[comp] = zz[0];
        let (size, bits) = Self::magnitude(diff);
        let (code, len) = self.dc_codes[size as usize];
        self.put_bits(code as u32, len as u32)?;
        self.put_bits(bits, size)?;

        let mut run = 0u32;
        for k in 1..64 {
            let v = zz[k];
            if v == 0 {
                run += 1;
                continue;
            }
            while run > 15 {
                let (code, len) = self.ac_codes[0xF0];
                self.put_bits(code as u32, len as u32)?;
                run -= 16;
            }
            let (size, bits) = Self::magnitude(v);
            let (code, len) = self.ac_codes[((run << 4) | size) as usize];
            self.put_bits(code as u32, len as u32)?;
            self.put_bits(bits, size)?;
            run = 0;
        }
        if run > 0 {
            let (code, len) = self.ac_codes[0x00];
            self.put_bits(code as u32, len as u32)?;
        }
        Ok(())
    }

    /// (category, amplitude bits) of a coefficient.
    #[inline]
    fn magnitude(v: i32) -> (u32, u32) {
        if v == 0 {
            return (0, 0);
        }
        let a = v.unsigned_abs();
        let size = 32 - a.leading_zeros();
        let bits = if v < 0 { (v - 1) as u32 & ((1u32 << size) - 1) } else { v as u32 };
        (size, bits)
    }
}
