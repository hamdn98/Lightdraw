//! Stack-based scanline flood fill over the sparse tile canvas, plus seamless procedural patterns.
//!
//! The fill runs in two passes: (1) find spans, with a cap on newly created tiles so that
//! filling a huge empty 16K area cannot exhaust memory; (2) paint the spans.
//! Patterns are evaluated in global canvas coordinates, so they tile seamlessly across tile borders.

use std::sync::Arc;

use crate::tiled_canvas::{premul, unpremul, TiledCanvas, TILE};

/// Maximum number of previously empty tiles a single fill may materialise (~100 MB).
pub const MAX_NEW_TILES: usize = 400;

pub enum FillResult {
    Painted(usize),
    OutOfBounds,
    TooLarge,
}

/// `Paint::kind` values from here on select a user pattern (`kind - CUSTOM_KIND_BASE` = slot index).
pub const CUSTOM_KIND_BASE: u8 = 100;

/// A user pattern made from a canvas object ("Object -> Pattern"): one repeat cell of premultiplied RGBA.
/// Because it is sampled with `x mod w`, `y mod h` in *global canvas coordinates* it is seamless by construction.
pub struct TilePattern {
    pub w: usize,
    pub h: usize,
    pub px: Vec<u32>,
    /// Brick layout: every second row of cells is shifted by half a cell.
    pub brick: bool,
}

impl TilePattern {
    /// Premultiplied pixel of the infinite repeat at canvas position (x, y). `scale` 1.0 = native size.
    pub fn sample(&self, x: u32, y: u32, scale: f32) -> u32 {
        if self.w == 0 || self.h == 0 {
            return 0;
        }
        let s = if scale > 0.0 { scale } else { 1.0 };
        let (sx, sy) = if (s - 1.0).abs() < 1e-4 { (x as usize, y as usize) } else { ((x as f32 / s) as usize, (y as f32 / s) as usize) };
        let row = sy / self.h;
        let mut lx = sx % self.w;
        if self.brick && row % 2 == 1 {
            lx = (lx + self.w - self.w / 2) % self.w;
        }
        self.px[(sy % self.h) * self.w + lx]
    }
}

#[derive(Clone)]
pub struct Paint {
    /// 0 solid, 1 gingham, 2 argyle, 3 seigaiha, 4 houndstooth, 5 plaid, 6 floral, >= 100 user pattern
    pub kind: u8,
    pub c1: u32, // straight RGBA
    pub c2: u32, // straight RGBA
    pub scale: f32,
    pub custom: Option<Arc<TilePattern>>,
}

impl Paint {
    /// Straight RGBA colour of this paint at canvas pixel (x, y) (alpha 0 = a gap in a user pattern).
    pub fn straight_at(&self, x: u32, y: u32) -> u32 {
        if let Some(c) = &self.custom {
            return unpremul(c.sample(x, y, self.scale));
        }
        if self.kind == 0 {
            self.c1
        } else {
            pattern_color(self.kind, x, y, self.scale, self.c1, self.c2)
        }
    }
}

#[inline]
fn fract(v: f32) -> f32 {
    v - v.floor()
}

fn mix(a: u32, b: u32, t: f32) -> u32 {
    let ch = |s: u32| -> u32 {
        let x = ((a >> s) & 255) as f32;
        let y = ((b >> s) & 255) as f32;
        ((x + (y - x) * t) + 0.5) as u32
    };
    ch(0) | (ch(8) << 8) | (ch(16) << 16) | (ch(24) << 24)
}

/// Straight RGBA colour of the pattern at canvas position (x, y).
pub fn pattern_color(kind: u8, x: u32, y: u32, scale: f32, c1: u32, c2: u32) -> u32 {
    let cell = (32.0 * scale).max(4.0);
    let fx = fract(x as f32 / cell);
    let fy = fract(y as f32 / cell);
    match kind {
        1 => {
            // gingham
            let a = fx < 0.5;
            let b = fy < 0.5;
            if a && b {
                c1
            } else if a || b {
                mix(c1, c2, 0.5)
            } else {
                c2
            }
        }
        2 => {
            // argyle: diamonds with thin diagonal stitching
            let dx = (fx - 0.5).abs();
            let dy = (fy - 0.5).abs();
            if (fx - fy).abs() < 0.02 || (fx + fy - 1.0).abs() < 0.02 {
                mix(c1, c2, 0.5)
            } else if dx + dy < 0.5 {
                c1
            } else {
                c2
            }
        }
        3 => seigaiha(x as f32, y as f32, cell, c1, c2),
        4 => {
            // houndstooth: 4 dark / 4 light threads in warp and weft with a 2/2 twill weave
            let unit = (cell / 8.0).max(1.0);
            let i = (x as f32 / unit).floor() as i64;
            let j = (y as f32 / unit).floor() as i64;
            let warp_dark = i.rem_euclid(8) < 4;
            let weft_dark = j.rem_euclid(8) < 4;
            let over = (i + j).rem_euclid(4) < 2;
            let dark = if over { warp_dark } else { weft_dark };
            if dark {
                c1
            } else {
                c2
            }
        }
        5 => {
            // plaid
            let band = |f: f32| -> u32 {
                if f < 0.3 {
                    c1
                } else if f < 0.4 {
                    mix(c1, c2, 0.5)
                } else {
                    c2
                }
            };
            mix(band(fx), band(fy), 0.5)
        }
        6 => {
            // floral: four-petal flower per cell
            let dx = fx - 0.5;
            let dy = fy - 0.5;
            let r = (dx * dx + dy * dy).sqrt();
            let th = dy.atan2(dx);
            let petal = 0.30 * (0.55 + 0.45 * (2.0 * th).cos().abs());
            if r < 0.06 {
                c2
            } else if r < petal {
                c1
            } else {
                c2
            }
        }
        _ => c1,
    }
}

fn seigaiha(x: f32, y: f32, w: f32, c1: u32, c2: u32) -> u32 {
    let r = w * 0.5;
    let h = w * 0.25;
    let row = (y / h).floor() as i32;
    let mut cr = row + 2;
    while cr >= row - 2 {
        let off = if cr.rem_euclid(2) == 1 { w * 0.5 } else { 0.0 };
        let k = ((x - off - r) / w).round();
        let ccx = k * w + r + off;
        let ccy = cr as f32 * h;
        let d = ((x - ccx).powi(2) + (y - ccy).powi(2)).sqrt();
        if d <= r {
            let ring = ((d / r) * 3.0) as i32;
            return if ring % 2 == 0 { c1 } else { c2 };
        }
        cr -= 1;
    }
    c2
}

#[inline]
fn paint_pixel(p: &Paint, x: u32, y: u32) -> u32 {
    if let Some(c) = &p.custom {
        return c.sample(x, y, p.scale);
    }
    if p.kind == 0 {
        premul(p.c1)
    } else {
        premul(pattern_color(p.kind, x, y, p.scale, p.c1, p.c2))
    }
}

#[inline]
fn chan_diff(a: u32, b: u32, sh: u32) -> i32 {
    (((a >> sh) & 255) as i32 - ((b >> sh) & 255) as i32).abs()
}

struct Filler<'a> {
    canvas: &'a mut TiledCanvas,
    visited: Vec<Option<Box<[u64]>>>,
    target: u32,
    tol: i32,
}

impl<'a> Filler<'a> {
    fn matches(&mut self, x: u32, y: u32) -> bool {
        let p = self.canvas.get_pixel(x as i32, y as i32);
        let t = self.target;
        chan_diff(p, t, 0).max(chan_diff(p, t, 8)).max(chan_diff(p, t, 16)).max(chan_diff(p, t, 24)) <= self.tol
    }

    #[inline]
    fn loc(&self, x: u32, y: u32) -> (usize, usize, u64) {
        let tidx = ((y as usize) >> 8) * self.canvas.tiles_x + ((x as usize) >> 8);
        let bit = ((y as usize) & 255) * TILE + ((x as usize) & 255);
        (tidx, bit >> 6, 1u64 << (bit & 63))
    }

    fn is_visited(&self, x: u32, y: u32) -> bool {
        let (t, w, m) = self.loc(x, y);
        match &self.visited[t] {
            Some(b) => b[w] & m != 0,
            None => false,
        }
    }

    fn mark(&mut self, x: u32, y: u32) {
        let (t, w, m) = self.loc(x, y);
        let slot = &mut self.visited[t];
        if slot.is_none() {
            *slot = Some(vec![0u64; TILE * TILE / 64].into_boxed_slice());
        }
        if let Some(b) = slot.as_mut() {
            b[w] |= m;
        }
    }
}

/// Flood fill from (sx, sy) with the given per-channel tolerance (0..255).
pub fn flood_fill(canvas: &mut TiledCanvas, sx: i32, sy: i32, tolerance: i32, paint: &Paint) -> FillResult {
    if sx < 0 || sy < 0 || sx >= canvas.width as i32 || sy >= canvas.height as i32 {
        return FillResult::OutOfBounds;
    }
    let target = canvas.get_pixel(sx, sy);
    let total = canvas.tile_count();
    let tiles_x = canvas.tiles_x;
    let (w, h) = (canvas.width, canvas.height);
    let mut spans: Vec<(u32, u32, u32)> = Vec::new(); // (y, x0, x1) inclusive
    let mut touched = vec![false; total];
    let mut new_tiles = 0usize;

    let visited = {
        let mut f = Filler {
            canvas: &mut *canvas,
            visited: (0..total).map(|_| None).collect(),
            target,
            tol: tolerance.clamp(0, 255),
        };
        let mut stack: Vec<(u32, u32)> = vec![(sx as u32, sy as u32)];
        while let Some((x, y)) = stack.pop() {
            if f.is_visited(x, y) || !f.matches(x, y) {
                continue;
            }
            let mut xl = x;
            while xl > 0 && !f.is_visited(xl - 1, y) && f.matches(xl - 1, y) {
                xl -= 1;
            }
            let mut xr = x;
            while xr + 1 < w && !f.is_visited(xr + 1, y) && f.matches(xr + 1, y) {
                xr += 1;
            }
            for xx in xl..=xr {
                f.mark(xx, y);
            }
            // tile budget
            for tx in ((xl as usize) >> 8)..=((xr as usize) >> 8) {
                let idx = ((y as usize) >> 8) * tiles_x + tx;
                if !touched[idx] {
                    touched[idx] = true;
                    if !f.canvas.exists(idx) {
                        new_tiles += 1;
                    }
                }
            }
            if new_tiles > MAX_NEW_TILES {
                return FillResult::TooLarge;
            }
            spans.push((y, xl, xr));
            for ny in [y as i64 - 1, y as i64 + 1] {
                if ny < 0 || ny >= h as i64 {
                    continue;
                }
                let ny = ny as u32;
                let mut in_run = false;
                for xx in xl..=xr {
                    let ok = !f.is_visited(xx, ny) && f.matches(xx, ny);
                    if ok && !in_run {
                        stack.push((xx, ny));
                        in_run = true;
                    } else if !ok {
                        in_run = false;
                    }
                }
            }
        }
        f.visited
    };

    let mut painted = 0usize;
    for &(y, x0, x1) in &spans {
        let mut x = x0;
        while x <= x1 {
            let tx = (x as usize) >> 8;
            let seg_end = x1.min(((tx + 1) * TILE - 1) as u32);
            let idx = ((y as usize) >> 8) * tiles_x + tx;
            let ly = (y as usize) & 255;
            let px = canvas.tile_mut(idx);
            for xx in x..=seg_end {
                px[ly * TILE + ((xx as usize) & 255)] = paint_pixel(paint, xx, y);
            }
            painted += (seg_end - x + 1) as usize;
            x = seg_end + 1;
        }
    }
    grow_under_rim(canvas, visited, &spans, paint, target, tolerance.clamp(0, 255));
    FillResult::Painted(painted)
}

/// Anti-aliased outlines leave a rim of half-transparent pixels that the tolerance does not accept
/// into the fill, which shows up as a light halo between line and fill. Paint the fill *behind* those
/// rim pixels (a few rings deep): opaque pixels stay untouched, partial ones blend over the fill.
const GROW_RINGS: usize = 3;

fn bit_loc(tiles_x: usize, x: u32, y: u32) -> (usize, usize, u64) {
    let tidx = ((y as usize) >> 8) * tiles_x + ((x as usize) >> 8);
    let bit = ((y as usize) & 255) * TILE + ((x as usize) & 255);
    (tidx, bit >> 6, 1u64 << (bit & 63))
}

fn bit_get(v: &[Option<Box<[u64]>>], tiles_x: usize, x: u32, y: u32) -> bool {
    let (t, w, m) = bit_loc(tiles_x, x, y);
    v[t].as_ref().map_or(false, |b| b[w] & m != 0)
}

fn bit_set(v: &mut [Option<Box<[u64]>>], tiles_x: usize, x: u32, y: u32) {
    let (t, w, m) = bit_loc(tiles_x, x, y);
    let slot = &mut v[t];
    if slot.is_none() {
        *slot = Some(vec![0u64; TILE * TILE / 64].into_boxed_slice());
    }
    if let Some(b) = slot.as_mut() {
        b[w] |= m;
    }
}

fn grow_under_rim(
    canvas: &mut TiledCanvas,
    visited: Vec<Option<Box<[u64]>>>,
    spans: &[(u32, u32, u32)],
    paint: &Paint,
    target: u32,
    tol: i32,
) {
    let tiles_x = canvas.tiles_x;
    let (w, h) = (canvas.width as i64, canvas.height as i64);
    let mut seen: Vec<Option<Box<[u64]>>> = (0..visited.len()).map(|_| None).collect();
    // ring 0 sources: the spans themselves
    let mut frontier: Vec<(u32, u32)> = Vec::new();
    let mut first = true;
    for _ in 0..GROW_RINGS {
        let mut cand: Vec<(u32, u32)> = Vec::new();
        let push_around = |x: i64, y: i64, cand: &mut Vec<(u32, u32)>| {
            for dy in -1i64..=1 {
                for dx in -1i64..=1 {
                    let (nx, ny) = (x + dx, y + dy);
                    if (dx != 0 || dy != 0) && nx >= 0 && ny >= 0 && nx < w && ny < h {
                        cand.push((nx as u32, ny as u32));
                    }
                }
            }
        };
        if first {
            for &(y, x0, x1) in spans {
                // only the ends and the rows above / below can touch non-region pixels
                for yy in [y as i64 - 1, y as i64 + 1] {
                    if yy < 0 || yy >= h {
                        continue;
                    }
                    for xx in (x0 as i64 - 1)..=(x1 as i64 + 1) {
                        if xx >= 0 && xx < w {
                            cand.push((xx as u32, yy as u32));
                        }
                    }
                }
                push_around(x0 as i64, y as i64, &mut cand);
                push_around(x1 as i64, y as i64, &mut cand);
            }
            first = false;
        } else {
            for &(x, y) in &frontier {
                push_around(x as i64, y as i64, &mut cand);
            }
        }
        let mut next: Vec<(u32, u32)> = Vec::new();
        for (x, y) in cand {
            if bit_get(&visited, tiles_x, x, y) || bit_get(&seen, tiles_x, x, y) {
                continue;
            }
            bit_set(&mut seen, tiles_x, x, y);
            let q = canvas.get_pixel(x as i32, y as i32);
            let a = q >> 24;
            let same = chan_diff(q, target, 0).max(chan_diff(q, target, 8)).max(chan_diff(q, target, 16)).max(chan_diff(q, target, 24)) <= tol;
            if same || a < 6 || a == 255 {
                continue;
            }
            let idx = ((y as usize) >> 8) * tiles_x + ((x as usize) >> 8);
            let px = canvas.tile_mut(idx);
            let i = ((y as usize) & 255) * TILE + ((x as usize) & 255);
            px[i] = crate::brush_engine::over(paint_pixel(paint, x, y), q);
            next.push((x, y));
        }
        if next.is_empty() {
            break;
        }
        frontier = next;
    }
}
