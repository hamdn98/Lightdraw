# JNI looks these up by name.
-keep class com.lightdraw.studio.NativeEngine { *; }
