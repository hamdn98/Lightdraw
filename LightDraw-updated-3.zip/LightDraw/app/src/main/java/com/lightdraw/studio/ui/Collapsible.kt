package com.lightdraw.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A dropdown section: a header row (title, short summary, chevron) that expands / collapses its content.
 * Open / closed is remembered in [DrawState.sections] under [key], so a popup reopens the way it was left.
 */
@Composable
internal fun Section(
    state: DrawState,
    key: String,
    title: String,
    summary: String = "",
    defaultOpen: Boolean = false,
    accent: Color = Palette.AccentPurple,
    content: @Composable ColumnScope.() -> Unit,
) {
    val open = state.sectionOpen(key, defaultOpen)
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.DarkBg.copy(alpha = 0.35f))
            .border(1.dp, if (open) accent.copy(alpha = 0.45f) else Palette.PanelBorder, shape),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { state.toggleSection(key, defaultOpen) }.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (summary.isNotEmpty()) Text(summary, color = accent, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(end = 8.dp))
            Icon(DrawIcons.ChevronDown, if (open) "Tutup" else "Buka", tint = Palette.TextMuted, modifier = Modifier.size(18.dp).rotate(if (open) 180f else 0f))
        }
        if (open) {
            Column(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content,
            )
        }
    }
}
