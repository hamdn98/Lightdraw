package com.lightdraw.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lightdraw.studio.NativeEngine
import com.lightdraw.studio.PEN_PARAMS
import com.lightdraw.studio.Palm
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * The tunable "pen" block of a brush. Same order as `Brush::pen_params` in the Rust engine:
 * hardness, spacing, pressure->size, pressure->opacity, pressure curve, speed thinning,
 * start taper (length, tip), end taper (length, tip).
 *
 * Taper length is a fraction of 16 pen diameters; a tip of 1.0 means "no taper", 0 a needle point, 2.0 a bulb end
 * that is twice as thick as the line.
 */
@Immutable
data class PenProfile(
    val hardness: Float = 0.8f,
    val spacing: Float = 0.08f,
    val pressureSize: Float = 0.35f,
    val pressureOpacity: Float = 0.5f,
    val curve: Float = 1f,
    val speedThin: Float = 0f,
    val startLen: Float = 0f,
    val startTip: Float = 1f,
    val endLen: Float = 0f,
    val endTip: Float = 1f,
) {
    fun toArray(): FloatArray =
        floatArrayOf(hardness, spacing, pressureSize, pressureOpacity, curve, speedThin, startLen, startTip, endLen, endTip)

    companion object {
        fun from(a: FloatArray) = PenProfile(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9])

        /** The engine's built-in values for a brush preset (single source of truth: Rust `Brush::set_preset`). */
        fun defaultsFor(preset: Int): PenProfile {
            val a = FloatArray(PEN_PARAMS)
            return if (NativeEngine.nativeBrushDefaults(preset, a)) from(a) else PenProfile()
        }
    }
}

class StudioPen(val name: String, val sub: String, val base: Int, val pen: PenProfile)

/** Ready-made pens. `base` is the brush preset they are built on (nib shape / build-up). */
val StudioPens = listOf(
    StudioPen("Technical", "Garis seragam", 2, PenProfile(hardness = 1f, spacing = 0.05f, pressureSize = 0f, pressureOpacity = 0f)),
    StudioPen(
        "Ink Taper", "Ujung runcing", 2,
        PenProfile(hardness = 1f, spacing = 0.05f, pressureSize = 0.6f, pressureOpacity = 0f, startLen = 0.25f, startTip = 0.1f, endLen = 0.35f, endTip = 0.05f),
    ),
    StudioPen(
        "Brush Pen", "Tekanan kuat", 2,
        PenProfile(hardness = 1f, spacing = 0.04f, pressureSize = 0.9f, pressureOpacity = 0f, curve = 0.8f, speedThin = 0.3f, startLen = 0.15f, startTip = 0.3f, endLen = 0.4f, endTip = 0f),
    ),
    StudioPen(
        "Bulb Ends", "Awal & akhir besar", 2,
        PenProfile(hardness = 1f, spacing = 0.05f, pressureSize = 0.2f, pressureOpacity = 0f, startLen = 0.12f, startTip = 1.6f, endLen = 0.12f, endTip = 1.6f),
    ),
    StudioPen(
        "Fineliner", "Ujung membulat kecil", 2,
        PenProfile(hardness = 1f, spacing = 0.05f, pressureSize = 0.15f, pressureOpacity = 0f, startLen = 0.05f, startTip = 0.6f, endLen = 0.05f, endTip = 0.6f),
    ),
    StudioPen(
        "Calligraphy", "Ujung pipih", 3,
        PenProfile(hardness = 1f, spacing = 0.05f, pressureSize = 0.3f, pressureOpacity = 0f, startLen = 0.15f, startTip = 0.4f, endLen = 0.25f, endTip = 0.3f),
    ),
    StudioPen("Marker", "Padat & lembut", 0, PenProfile(hardness = 0.9f, spacing = 0.08f, pressureSize = 0f, pressureOpacity = 0f)),
    StudioPen(
        "Dry Pencil", "Tekanan = gelap", 0,
        PenProfile(hardness = 0.6f, spacing = 0.1f, pressureSize = 0.4f, pressureOpacity = 0.7f, curve = 1.2f, startLen = 0.1f, startTip = 0.4f, endLen = 0.2f, endTip = 0.3f),
    ),
)

private val PensAccent = Color(0xFF22D3EE)

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
}

private fun pct(v: Float) = "${(v * 100).roundToInt()}%"

private fun curveName(c: Float) = when {
    c < 0.85f -> "Lembut"
    c > 1.2f -> "Keras"
    else -> "Normal"
}

/** Studio Pens: start / end thickness (taper), pressure response, speed, spacing, edge softness, plus palm rejection. */
@Composable
internal fun StudioPensPopup(state: DrawState, modifier: Modifier) {
    val pen = state.pen
    fun upd(f: PenProfile.() -> PenProfile) {
        state.pen = state.pen.f()
        state.studioPen = -1
    }

    Popup("Studio Pens", if (state.studioPen >= 0) StudioPens[state.studioPen].name else "Custom", PensAccent, modifier) {
        PenPreview(pen, state.size, Color(state.color), Modifier.fillMaxWidth().height(76.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            StudioPens.forEachIndexed { i, p ->
                Chip(p.name, state.studioPen == i, PensAccent) {
                    // tapping another pen picks it and closes the menu; tapping the active one keeps it open for tuning
                    val again = state.studioPen == i
                    state.chooseStudioPen(i)
                    if (!again) state.closePanel()
                }
            }
        }
        if (state.studioPen >= 0) Hint(StudioPens[state.studioPen].sub)

        Section(state, "pens.ends", "Awal & akhir goresan", "${pct(pen.startTip)} → ${pct(pen.endTip)}", defaultOpen = true, accent = PensAccent) {
            SectionLabel("Awal")
            LabeledSlider("Panjang taper", pct(pen.startLen), pen.startLen, 0f..1f, PensAccent) { v -> upd { copy(startLen = v) } }
            LabeledSlider("Ketebalan ujung awal", pct(pen.startTip), pen.startTip, 0f..2f, PensAccent) { v -> upd { copy(startTip = v) } }
            SectionLabel("Akhir")
            LabeledSlider("Panjang taper", pct(pen.endLen), pen.endLen, 0f..1f, PensAccent) { v -> upd { copy(endLen = v) } }
            LabeledSlider("Ketebalan ujung akhir", pct(pen.endTip), pen.endTip, 0f..2f, PensAccent) { v -> upd { copy(endTip = v) } }
            Hint("Ketebalan 100% = tanpa taper, <100% meruncing, >100% ujung membesar. Taper akhir tampil setelah pena diangkat.")
        }

        Section(state, "pens.dyn", "Respons pena", "kurva ${curveName(pen.curve)}", accent = PensAccent) {
            LabeledSlider("Tekanan → ukuran", pct(pen.pressureSize), pen.pressureSize, 0f..1f) { v -> upd { copy(pressureSize = v) } }
            LabeledSlider("Tekanan → opacity", pct(pen.pressureOpacity), pen.pressureOpacity, 0f..1f) { v -> upd { copy(pressureOpacity = v) } }
            LabeledSlider("Kurva tekanan", curveName(pen.curve), pen.curve, 0.4f..2.5f) { v -> upd { copy(curve = v) } }
            LabeledSlider("Menipis saat cepat", pct(pen.speedThin), pen.speedThin, 0f..1f) { v -> upd { copy(speedThin = v) } }
        }

        Section(state, "pens.line", "Garis", "stabilizer ${state.stabilizer.toInt()}%", accent = PensAccent) {
            LabeledSlider("Spacing dab", pct(pen.spacing), pen.spacing, 0.01f..0.5f) { v -> upd { copy(spacing = v) } }
            LabeledSlider("Kelembutan tepi (hardness)", pct(pen.hardness), pen.hardness, 0f..1f) { v -> upd { copy(hardness = v) } }
            LabeledSlider("Stabilizer", "${state.stabilizer.toInt()}%", state.stabilizer, 0f..99f, PensAccent) { state.stabilizer = it }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Reset pen", false) {
                    state.pen = PenProfile.defaultsFor(state.brushPreset)
                    state.studioPen = -1
                }
            }
        }

        Section(state, "pens.palm", "Palm rejection", palmName(state.palmMode), accent = PensAccent) {
            PalmContent(state)
        }
    }
}

private fun palmName(m: Int) = when (m) {
    Palm.OFF -> "Mati"
    Palm.AUTO -> "Otomatis"
    else -> "Stylus saja"
}

@Composable
private fun PalmContent(state: DrawState) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Chip("Mati", state.palmMode == Palm.OFF) { state.palmMode = Palm.OFF }
        Chip("Otomatis", state.palmMode == Palm.AUTO) { state.palmMode = Palm.AUTO }
        Chip("Stylus saja", state.palmMode == Palm.STYLUS_ONLY) { state.palmMode = Palm.STYLUS_ONLY }
    }
    Hint(
        when (state.palmMode) {
            Palm.OFF -> "Semua sentuhan diterima."
            Palm.AUTO -> "Saat pena menyentuh atau melayang di atas layar, jari & telapak diabaikan. Sentuhan lebar selalu diabaikan."
            else -> "Hanya pena yang menggambar. Satu jari menggeser kanvas, dua jari zoom / putar. Tap dua jari = undo tetap bisa."
        }
    )
    if (state.palmMode != Palm.OFF) {
        LabeledSlider("Ukuran dianggap telapak", "${state.palmMm.roundToInt()} mm", state.palmMm, 8f..30f, PensAccent) { state.palmMm = it }
    }
}

/** Live preview of the current pen: an S-curve with a simulated pressure bell, same taper maths as the engine. */
@Composable
private fun PenPreview(pen: PenProfile, size: Float, color: Color, modifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Canvas(
        modifier
            .clip(shape)
            .background(Palette.DarkBg.copy(alpha = 0.55f))
            .border(1.dp, Palette.PanelBorder, shape)
    ) {
        val w = this.size.width
        val h = this.size.height
        val d = (3f + size.coerceIn(1f, 80f) * 0.22f).dp.toPx().coerceAtMost(h * 0.5f)
        val pad = 16.dp.toPx()
        val total = w - 2 * pad
        var ls = pen.startLen * 16f * d
        var le = pen.endLen * 16f * d
        if (ls + le > total) {
            val k = total / (ls + le)
            ls *= k
            le *= k
        }
        fun taper(tip: Float, len: Float, dist: Float): Float {
            if (len <= 0f) return 1f
            val x = (dist / len).coerceIn(0f, 1f)
            return tip + (1f - tip) * (x * x * (3f - 2f * x))
        }
        val startOn = pen.startLen > 0.001f && abs(pen.startTip - 1f) > 0.01f
        val endOn = pen.endLen > 0.001f && abs(pen.endTip - 1f) > 0.01f
        val n = 160
        val xs = FloatArray(n + 1)
        val ys = FloatArray(n + 1)
        val ws = FloatArray(n + 1)
        for (i in 0..n) {
            val t = i.toFloat() / n
            val dist = total * t
            val ms = if (startOn) taper(pen.startTip, ls, dist) else 1f
            val me = if (endOn) taper(pen.endTip, le, total - dist) else 1f
            val p = (0.35f + 0.65f * sin(PI.toFloat() * t)).pow(pen.curve)
            xs[i] = pad + dist
            ys[i] = h / 2f + sin(2f * PI.toFloat() * t) * h * 0.16f
            ws[i] = max(d * (1f - pen.pressureSize + pen.pressureSize * p) * ms * me, 1f)
        }
        val path = Path()
        path.moveTo(xs[0], ys[0] - ws[0] / 2f)
        for (i in 1..n) path.lineTo(xs[i], ys[i] - ws[i] / 2f)
        for (i in n downTo 0) path.lineTo(xs[i], ys[i] + ws[i] / 2f)
        path.close()
        drawPath(path, color)
    }
}
