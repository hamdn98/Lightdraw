package com.lightdraw.studio.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Hand-built 24x24 vector icons (no icon library -> small APK). Tinted by the Icon composable. */
object DrawIcons {

    private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply(block).build()

    private fun ImageVector.Builder.line(w: Float = 2f, b: PathBuilder.() -> Unit) {
        path(
            fill = null,
            stroke = SolidColor(Color.White),
            strokeLineWidth = w,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
            pathBuilder = b,
        )
    }

    private fun ImageVector.Builder.solid(b: PathBuilder.() -> Unit) {
        path(fill = SolidColor(Color.White), stroke = null, pathBuilder = b)
    }

    private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        moveTo(cx - r, cy)
        arcTo(r, r, 0f, true, false, cx + r, cy)
        arcTo(r, r, 0f, true, false, cx - r, cy)
        close()
    }

    /** Regular polygon (inner = 0) or star (inner > 0, `n` points) centred at (cx, cy), first vertex pointing up. */
    private fun PathBuilder.polygon(cx: Float, cy: Float, r: Float, n: Int, inner: Float) {
        val count = if (inner > 0f) n * 2 else n
        for (k in 0 until count) {
            val a = -Math.PI / 2.0 + Math.PI * 2.0 * k / count
            val rr = if (inner > 0f && k % 2 == 1) inner else r
            val x = (cx + rr * Math.cos(a)).toFloat()
            val y = (cy + rr * Math.sin(a)).toFloat()
            if (k == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    val Brush: ImageVector by lazy {
        icon("brush") {
            line { moveTo(19.5f, 4.5f); lineTo(10.5f, 13.5f) }
            line {
                moveTo(9f, 12f); lineTo(12f, 15f)
                curveTo(12f, 18f, 9f, 20f, 4f, 20f)
                curveTo(6f, 18f, 5f, 15f, 9f, 12f); close()
            }
        }
    }
    val Pen: ImageVector by lazy {
        icon("pen") {
            line { moveTo(12f, 3f); lineTo(18f, 11f); lineTo(12f, 21f); lineTo(6f, 11f); close() }
            line { moveTo(12f, 3f); lineTo(12f, 12f) }
            solid { circle(12f, 14f, 1.5f) }
        }
    }
    val Eraser: ImageVector by lazy {
        icon("eraser") {
            line { moveTo(3.5f, 14f); lineTo(13f, 4.5f); lineTo(19.5f, 11f); lineTo(11f, 19.5f); close() }
            line { moveTo(9f, 20f); lineTo(21f, 20f) }
            line { moveTo(7.5f, 9.5f); lineTo(15f, 17f) }
        }
    }
    val Fill: ImageVector by lazy {
        icon("fill") {
            line { moveTo(5f, 11f); lineTo(11f, 5f); lineTo(17f, 11f); lineTo(11f, 17f); close() }
            line { moveTo(11f, 5f); lineTo(11f, 3f) }
            solid { circle(19f, 17f, 2f) }
        }
    }
    val Wand: ImageVector by lazy {
        icon("wand") {
            line {
                moveTo(12f, 3f); lineTo(14f, 10f); lineTo(21f, 12f); lineTo(14f, 14f)
                lineTo(12f, 21f); lineTo(10f, 14f); lineTo(3f, 12f); lineTo(10f, 10f); close()
            }
        }
    }
    val Symmetry: ImageVector by lazy {
        icon("symmetry") {
            line { moveTo(12f, 3f); lineTo(12f, 21f) }
            line { moveTo(10f, 6f); lineTo(4f, 12f); lineTo(10f, 18f); close() }
            line { moveTo(14f, 6f); lineTo(20f, 12f); lineTo(14f, 18f); close() }
        }
    }
    val Layers: ImageVector by lazy {
        icon("layers") {
            line { moveTo(12f, 3f); lineTo(21f, 8f); lineTo(12f, 13f); lineTo(3f, 8f); close() }
            line { moveTo(3f, 12f); lineTo(12f, 17f); lineTo(21f, 12f) }
            line { moveTo(3f, 16f); lineTo(12f, 21f); lineTo(21f, 16f) }
        }
    }
    val Settings: ImageVector by lazy {
        icon("settings") {
            line { moveTo(4f, 7f); lineTo(20f, 7f) }
            line { moveTo(4f, 12f); lineTo(20f, 12f) }
            line { moveTo(4f, 17f); lineTo(20f, 17f) }
            solid { circle(9f, 7f, 2.4f) }
            solid { circle(15f, 12f, 2.4f) }
            solid { circle(8f, 17f, 2.4f) }
        }
    }
    val Grid: ImageVector by lazy {
        icon("grid") {
            line { moveTo(4f, 4f); lineTo(10f, 4f); lineTo(10f, 10f); lineTo(4f, 10f); close() }
            line { moveTo(14f, 4f); lineTo(20f, 4f); lineTo(20f, 10f); lineTo(14f, 10f); close() }
            line { moveTo(4f, 14f); lineTo(10f, 14f); lineTo(10f, 20f); lineTo(4f, 20f); close() }
            line { moveTo(14f, 14f); lineTo(20f, 14f); lineTo(20f, 20f); lineTo(14f, 20f); close() }
        }
    }
    val Diamond: ImageVector by lazy {
        icon("diamond") { line { moveTo(12f, 3f); lineTo(21f, 12f); lineTo(12f, 21f); lineTo(3f, 12f); close() } }
    }
    val Waves: ImageVector by lazy {
        icon("waves") {
            line { moveTo(3f, 9f); curveTo(6f, 5f, 9f, 5f, 12f, 9f); curveTo(15f, 13f, 18f, 13f, 21f, 9f) }
            line { moveTo(3f, 16f); curveTo(6f, 12f, 9f, 12f, 12f, 16f); curveTo(15f, 20f, 18f, 20f, 21f, 16f) }
        }
    }
    val Zigzag: ImageVector by lazy {
        icon("zigzag") { line { moveTo(3f, 16f); lineTo(7.5f, 8f); lineTo(12f, 16f); lineTo(16.5f, 8f); lineTo(21f, 16f) } }
    }
    val Plaid: ImageVector by lazy {
        icon("plaid") {
            line { moveTo(4f, 8f); lineTo(20f, 8f) }
            line { moveTo(4f, 16f); lineTo(20f, 16f) }
            line { moveTo(8f, 4f); lineTo(8f, 20f) }
            line { moveTo(16f, 4f); lineTo(16f, 20f) }
        }
    }
    val Flower: ImageVector by lazy {
        icon("flower") {
            line { circle(12f, 6.5f, 3.2f) }
            line { circle(12f, 17.5f, 3.2f) }
            line { circle(6.5f, 12f, 3.2f) }
            line { circle(17.5f, 12f, 3.2f) }
            solid { circle(12f, 12f, 1.6f) }
        }
    }
    val Palette: ImageVector by lazy {
        icon("palette") {
            line { circle(12f, 12f, 9f) }
            solid { circle(8f, 10f, 1.4f) }
            solid { circle(12f, 7.5f, 1.4f) }
            solid { circle(16f, 10f, 1.4f) }
            solid { circle(8.5f, 15f, 1.4f) }
        }
    }
    val Undo: ImageVector by lazy {
        icon("undo") {
            line { moveTo(8.5f, 4.5f); lineTo(4f, 9f); lineTo(8.5f, 13.5f) }
            line {
                moveTo(4f, 9f); lineTo(14f, 9f)
                curveTo(18f, 9f, 20f, 12f, 20f, 14.5f)
                curveTo(20f, 17.5f, 18f, 20f, 14f, 20f); lineTo(8f, 20f)
            }
        }
    }
    val Redo: ImageVector by lazy {
        icon("redo") {
            line { moveTo(15.5f, 4.5f); lineTo(20f, 9f); lineTo(15.5f, 13.5f) }
            line {
                moveTo(20f, 9f); lineTo(10f, 9f)
                curveTo(6f, 9f, 4f, 12f, 4f, 14.5f)
                curveTo(4f, 17.5f, 6f, 20f, 10f, 20f); lineTo(16f, 20f)
            }
        }
    }
    val Eyedropper: ImageVector by lazy {
        icon("eyedropper") {
            line { moveTo(14f, 5f); lineTo(19f, 10f) }
            line { moveTo(16.5f, 7.5f); lineTo(6.5f, 17.5f); lineTo(5f, 20f); lineTo(7.5f, 18.5f) }
            line { moveTo(16f, 3.5f); lineTo(20.5f, 8f) }
        }
    }
    val Import: ImageVector by lazy {
        icon("import") {
            line { moveTo(12f, 16f); lineTo(12f, 4f) }
            line { moveTo(7f, 9f); lineTo(12f, 4f); lineTo(17f, 9f) }
            line { moveTo(4f, 15f); lineTo(4f, 20f); lineTo(20f, 20f); lineTo(20f, 15f) }
        }
    }
    val Export: ImageVector by lazy {
        icon("export") {
            line { moveTo(12f, 4f); lineTo(12f, 16f) }
            line { moveTo(7f, 11f); lineTo(12f, 16f); lineTo(17f, 11f) }
            line { moveTo(4f, 15f); lineTo(4f, 20f); lineTo(20f, 20f); lineTo(20f, 15f) }
        }
    }
    val Menu: ImageVector by lazy {
        icon("menu") {
            line { moveTo(4f, 6f); lineTo(20f, 6f) }
            line { moveTo(4f, 12f); lineTo(20f, 12f) }
            line { moveTo(4f, 18f); lineTo(20f, 18f) }
        }
    }
    val Close: ImageVector by lazy {
        icon("close") {
            line { moveTo(6f, 6f); lineTo(18f, 18f) }
            line { moveTo(18f, 6f); lineTo(6f, 18f) }
        }
    }
    val Eye: ImageVector by lazy {
        icon("eye") {
            line { moveTo(2f, 12f); curveTo(5f, 6f, 19f, 6f, 22f, 12f); curveTo(19f, 18f, 5f, 18f, 2f, 12f); close() }
            solid { circle(12f, 12f, 2.6f) }
        }
    }

    // ---- icons used by the pill toolbar / bottom nav
    val ChevronDown: ImageVector by lazy {
        icon("chevronDown") { line { moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f) } }
    }
    val ChevronLeft: ImageVector by lazy {
        icon("chevron_left") { line { moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) } }
    }
    val Wrench: ImageVector by lazy {
        icon("wrench") {
            line { moveTo(4.5f, 19.5f); lineTo(13f, 11f) }
            line {
                moveTo(13f, 11f)
                curveTo(11f, 8f, 12.5f, 4.5f, 16f, 4f)
                lineTo(14.2f, 6.8f); lineTo(15.2f, 8.8f); lineTo(17.2f, 9.8f); lineTo(20f, 8f)
                curveTo(19.5f, 11.5f, 16f, 13f, 13f, 11f); close()
            }
        }
    }
    val Crop: ImageVector by lazy {
        icon("crop") {
            line { moveTo(7f, 3f); lineTo(7f, 17f); lineTo(21f, 17f) }
            line { moveTo(3f, 7f); lineTo(17f, 7f); lineTo(17f, 21f) }
        }
    }
    val Shapes: ImageVector by lazy {
        icon("shapes") {
            line { moveTo(12f, 3f); lineTo(17f, 11f); lineTo(7f, 11f); close() }
            solid { circle(7f, 17f, 3.2f) }
            solid { moveTo(14f, 14f); lineTo(20f, 14f); lineTo(20f, 20f); lineTo(14f, 20f); close() }
        }
    }
    val Transform: ImageVector by lazy {
        icon("transform") {
            line { moveTo(4f, 20f); lineTo(12f, 4.5f); lineTo(20f, 20f) }
            line { moveTo(8f, 14f); lineTo(16f, 14f) }
            solid { circle(12f, 4f, 1.8f) }
        }
    }
    val Pathfinder: ImageVector by lazy {
        icon("pathfinder") {
            line { moveTo(3f, 3f); lineTo(14f, 3f); lineTo(14f, 14f); lineTo(3f, 14f); close() }
            line { moveTo(10f, 10f); lineTo(21f, 10f); lineTo(21f, 21f); lineTo(10f, 21f); close() }
        }
    }
    val Align: ImageVector by lazy {
        icon("align") {
            line { moveTo(4f, 6f); lineTo(20f, 6f) }
            line { moveTo(7f, 12f); lineTo(17f, 12f) }
            line { moveTo(5f, 18f); lineTo(19f, 18f) }
        }
    }
    val Copy: ImageVector by lazy {
        icon("copy") {
            line { moveTo(8f, 8f); lineTo(20f, 8f); lineTo(20f, 20f); lineTo(8f, 20f); close() }
            line { moveTo(4f, 16f); lineTo(4f, 4f); lineTo(16f, 4f) }
        }
    }
    val Drop: ImageVector by lazy {
        icon("drop") {
            line {
                moveTo(12f, 3f)
                curveTo(9f, 7f, 5f, 11f, 5f, 15f)
                curveTo(5f, 19f, 8f, 21f, 12f, 21f)
                curveTo(16f, 21f, 19f, 19f, 19f, 15f)
                curveTo(19f, 11f, 15f, 7f, 12f, 3f); close()
            }
        }
    }
    val Hand: ImageVector by lazy {
        icon("hand") {
            line {
                moveTo(9f, 12f); lineTo(9f, 5.5f)
                curveTo(9f, 3.8f, 12f, 3.8f, 12f, 5.5f); lineTo(12f, 10f)
            }
            line { moveTo(12f, 10f); curveTo(12f, 8.6f, 15f, 8.6f, 15f, 10f); lineTo(15f, 11f) }
            line { moveTo(15f, 11f); curveTo(15f, 9.8f, 18f, 9.8f, 18f, 11.2f); lineTo(18f, 15f) }
            line {
                moveTo(18f, 15f); curveTo(18f, 19f, 15.5f, 21f, 12.5f, 21f)
                curveTo(9.5f, 21f, 8f, 19.5f, 6.5f, 17f); lineTo(4.6f, 13.4f)
                curveTo(4f, 12f, 6f, 11.2f, 7f, 12.6f); lineTo(9f, 15f)
            }
        }
    }
    val Unite: ImageVector by lazy {
        icon("unite") {
            solid { moveTo(3f, 3f); lineTo(15f, 3f); lineTo(15f, 9f); lineTo(21f, 9f); lineTo(21f, 21f); lineTo(9f, 21f); lineTo(9f, 15f); lineTo(3f, 15f); close() }
        }
    }
    val Minus: ImageVector by lazy {
        icon("minus") { line(2.6f) { moveTo(5f, 12f); lineTo(19f, 12f) } }
    }
    val Intersect: ImageVector by lazy {
        icon("intersect") {
            line { moveTo(3f, 3f); lineTo(15f, 3f); lineTo(15f, 15f); lineTo(3f, 15f); close() }
            line { moveTo(9f, 9f); lineTo(21f, 9f); lineTo(21f, 21f); lineTo(9f, 21f); close() }
            solid { moveTo(9f, 9f); lineTo(15f, 9f); lineTo(15f, 15f); lineTo(9f, 15f); close() }
        }
    }
    val Exclude: ImageVector by lazy {
        icon("exclude") {
            line { moveTo(3f, 3f); lineTo(15f, 3f); lineTo(15f, 15f); lineTo(3f, 15f); close() }
            line { moveTo(9f, 9f); lineTo(21f, 9f); lineTo(21f, 21f); lineTo(9f, 21f); close() }
            solid { moveTo(3f, 3f); lineTo(9f, 3f); lineTo(9f, 9f); lineTo(3f, 9f); close() }
            solid { moveTo(15f, 15f); lineTo(21f, 15f); lineTo(21f, 21f); lineTo(15f, 21f); close() }
        }
    }

    // ---- shapes
    val ShapeLine: ImageVector by lazy {
        icon("shape_line") { line(2.6f) { moveTo(5f, 19f); lineTo(19f, 5f) } }
    }
    val ShapeRect: ImageVector by lazy {
        icon("shape_rect") { line { moveTo(4f, 6f); lineTo(20f, 6f); lineTo(20f, 18f); lineTo(4f, 18f); close() } }
    }
    val ShapeRound: ImageVector by lazy {
        icon("shape_round") {
            line {
                moveTo(8f, 5f); lineTo(16f, 5f); arcTo(3f, 3f, 0f, false, true, 19f, 8f)
                lineTo(19f, 16f); arcTo(3f, 3f, 0f, false, true, 16f, 19f)
                lineTo(8f, 19f); arcTo(3f, 3f, 0f, false, true, 5f, 16f)
                lineTo(5f, 8f); arcTo(3f, 3f, 0f, false, true, 8f, 5f); close()
            }
        }
    }
    val ShapeEllipse: ImageVector by lazy {
        icon("shape_ellipse") {
            line {
                moveTo(3f, 12f)
                arcTo(9f, 6.5f, 0f, true, false, 21f, 12f)
                arcTo(9f, 6.5f, 0f, true, false, 3f, 12f); close()
            }
        }
    }
    val ShapeTriangle: ImageVector by lazy {
        icon("shape_triangle") { line { moveTo(12f, 4f); lineTo(20f, 19f); lineTo(4f, 19f); close() } }
    }
    val ShapePolygon: ImageVector by lazy {
        icon("shape_polygon") { line { polygon(12f, 12.6f, 8.6f, 5, 0f) } }
    }
    val ShapeStar: ImageVector by lazy {
        icon("shape_star") { line { polygon(12f, 12.8f, 9.4f, 5, 3.9f) } }
    }

    // ---- align / transform / object actions
    val AlignLeft: ImageVector by lazy {
        icon("align_left") {
            line { moveTo(4f, 3f); lineTo(4f, 21f) }
            line(4f) { moveTo(8f, 8f); lineTo(19f, 8f) }
            line(4f) { moveTo(8f, 15f); lineTo(14f, 15f) }
        }
    }
    val AlignCenterH: ImageVector by lazy {
        icon("align_center_h") {
            line { moveTo(12f, 3f); lineTo(12f, 21f) }
            line(4f) { moveTo(5f, 8f); lineTo(19f, 8f) }
            line(4f) { moveTo(8f, 15f); lineTo(16f, 15f) }
        }
    }
    val AlignRight: ImageVector by lazy {
        icon("align_right") {
            line { moveTo(20f, 3f); lineTo(20f, 21f) }
            line(4f) { moveTo(5f, 8f); lineTo(16f, 8f) }
            line(4f) { moveTo(10f, 15f); lineTo(16f, 15f) }
        }
    }
    val AlignTop: ImageVector by lazy {
        icon("align_top") {
            line { moveTo(3f, 4f); lineTo(21f, 4f) }
            line(4f) { moveTo(8f, 8f); lineTo(8f, 19f) }
            line(4f) { moveTo(15f, 8f); lineTo(15f, 14f) }
        }
    }
    val AlignCenterV: ImageVector by lazy {
        icon("align_center_v") {
            line { moveTo(3f, 12f); lineTo(21f, 12f) }
            line(4f) { moveTo(8f, 5f); lineTo(8f, 19f) }
            line(4f) { moveTo(15f, 8f); lineTo(15f, 16f) }
        }
    }
    val AlignBottom: ImageVector by lazy {
        icon("align_bottom") {
            line { moveTo(3f, 20f); lineTo(21f, 20f) }
            line(4f) { moveTo(8f, 5f); lineTo(8f, 16f) }
            line(4f) { moveTo(15f, 10f); lineTo(15f, 16f) }
        }
    }
    val CenterCanvas: ImageVector by lazy {
        icon("center_canvas") {
            line { moveTo(4f, 4f); lineTo(20f, 4f); lineTo(20f, 20f); lineTo(4f, 20f); close() }
            line { moveTo(12f, 8f); lineTo(12f, 16f) }
            line { moveTo(8f, 12f); lineTo(16f, 12f) }
        }
    }
    val FlipH: ImageVector by lazy {
        icon("flip_h") {
            line { moveTo(12f, 3f); lineTo(12f, 21f) }
            line { moveTo(9f, 7f); lineTo(3.5f, 17f); lineTo(9f, 17f); close() }
            line { moveTo(15f, 7f); lineTo(20.5f, 17f); lineTo(15f, 17f); close() }
        }
    }
    val FlipV: ImageVector by lazy {
        icon("flip_v") {
            line { moveTo(3f, 12f); lineTo(21f, 12f) }
            line { moveTo(7f, 9f); lineTo(17f, 9f); lineTo(12f, 3.5f); close() }
            line { moveTo(7f, 15f); lineTo(17f, 15f); lineTo(12f, 20.5f); close() }
        }
    }
    val RotateCw: ImageVector by lazy {
        icon("rotate_cw") {
            line {
                moveTo(12f, 5f)
                arcTo(7f, 7f, 0f, false, true, 19f, 12f)
                arcTo(7f, 7f, 0f, false, true, 12f, 19f)
                arcTo(7f, 7f, 0f, false, true, 5f, 12f)
            }
            line { moveTo(5f, 12f); lineTo(2.5f, 9.5f) }
            line { moveTo(5f, 12f); lineTo(7.5f, 9.5f) }
        }
    }
    val RotateCcw: ImageVector by lazy {
        icon("rotate_ccw") {
            line {
                moveTo(12f, 5f)
                arcTo(7f, 7f, 0f, false, false, 5f, 12f)
                arcTo(7f, 7f, 0f, false, false, 12f, 19f)
                arcTo(7f, 7f, 0f, false, false, 19f, 12f)
            }
            line { moveTo(19f, 12f); lineTo(21.5f, 9.5f) }
            line { moveTo(19f, 12f); lineTo(16.5f, 9.5f) }
        }
    }
    val Trash: ImageVector by lazy {
        icon("trash") {
            line { moveTo(4f, 7f); lineTo(20f, 7f) }
            line { moveTo(9f, 7f); lineTo(9f, 4f); lineTo(15f, 4f); lineTo(15f, 7f) }
            line { moveTo(6.5f, 7f); lineTo(7.5f, 20f); lineTo(16.5f, 20f); lineTo(17.5f, 7f) }
        }
    }
    val Check: ImageVector by lazy {
        icon("check") { line(2.6f) { moveTo(4.5f, 12.5f); lineTo(10f, 18f); lineTo(19.5f, 6f) } }
    }
    val Select: ImageVector by lazy {
        icon("select") {
            line { moveTo(4f, 9f); lineTo(4f, 4f); lineTo(9f, 4f) }
            line { moveTo(15f, 4f); lineTo(20f, 4f); lineTo(20f, 9f) }
            line { moveTo(20f, 15f); lineTo(20f, 20f); lineTo(15f, 20f) }
            line { moveTo(9f, 20f); lineTo(4f, 20f); lineTo(4f, 15f) }
        }
    }
    val Plus: ImageVector by lazy {
        icon("plus") {
            line(2.6f) { moveTo(12f, 5f); lineTo(12f, 19f) }
            line(2.6f) { moveTo(5f, 12f); lineTo(19f, 12f) }
        }
    }
    val ArrowUp: ImageVector by lazy {
        icon("arrow_up") {
            line { moveTo(12f, 19f); lineTo(12f, 5f) }
            line { moveTo(6f, 11f); lineTo(12f, 5f); lineTo(18f, 11f) }
        }
    }
    val ArrowDown: ImageVector by lazy {
        icon("arrow_down") {
            line { moveTo(12f, 5f); lineTo(12f, 19f) }
            line { moveTo(6f, 13f); lineTo(12f, 19f); lineTo(18f, 13f) }
        }
    }
}
