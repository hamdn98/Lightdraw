package com.lightdraw.studio

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.lightdraw.studio.ui.Tool
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Edge-to-edge GL canvas. All touch handling is allocation-free:
 *  - 1 finger: draw / shape drag / select + move objects / tap tools (fill, eyedropper, select-same-colour);
 *    in Hand mode 1 finger pans
 *  - 2 fingers: pinch-zoom, pan, rotate (tap = undo)
 *  - 3 fingers tap = redo
 */
class CanvasGLView(context: Context) : GLSurfaceView(context) {

    // ---- tool state (written from Compose on the UI thread)
    var tool: Int = Tool.DRAW
    var fillKind = 0
    var fillColor = 0xFFFF3366.toInt()
    var fillScale = 1f
    var fillTolerance = 24
    var tolH = 15f
    var tolS = 0.2f
    var tolL = 0.2f

    // ---- paper / cloth texture (read by the GL thread; see surface.rs)
    @Volatile var surfaceKind = 0
    @Volatile var surfaceStrength = 0.5f
    @Volatile var surfaceScale = 1

    /** Texture drawn by the GL renderer. (The export copy lives in the engine: see `nativeSetSurface` in CanvasScreen.) */
    fun setSurface(kind: Int, strength: Float, scale: Int, bake: Boolean) {
        if (kind == surfaceKind && strength == surfaceStrength && scale == surfaceScale && bake == surfaceBake) return
        surfaceKind = kind
        surfaceStrength = strength
        surfaceScale = scale
        surfaceBake = bake
        requestRender()
    }
    private var surfaceBake = true

    // ---- palm rejection (see PalmFilter)
    private val palm = PalmFilter()
    private val touchSink: (MotionEvent) -> Unit = { handleTouch(it) }
    private var navGesture = false

    /** [Palm.OFF], [Palm.AUTO] or [Palm.STYLUS_ONLY]. */
    var palmMode: Int
        get() = palm.mode
        set(v) {
            palm.mode = v
        }

    /** Contact size (mm) from which a touch counts as a palm. */
    fun setPalmSizeMm(mm: Float) {
        palm.palmMajorPx = mm * resources.displayMetrics.xdpi / 25.4f
    }

    // ---- shape tool
    var shapeKind = 1
    var shapeOutline = false
    var shapeStroke = 8f
    var shapeCorner = 0.3f
    var shapeSides = 5
    var shapeOpacity = 1f
    var shapeBlend = 0

    /** Selection outline quad and marquee quad in *screen* pixels (8 floats each) or null. */
    var onOverlay: ((FloatArray?, FloatArray?) -> Unit)? = null
    /** Fired when a (filtered) gesture starts: the screen closes any open menu so the artwork is free. */
    var onTouchDown: (() -> Unit)? = null
    var onColorPicked: ((Int) -> Unit)? = null
    var onHistoryChanged: (() -> Unit)? = null
    var onMessage: ((String) -> Unit)? = null

    // ---- view transform (read by the GL thread)
    @Volatile var scale = 1f
    @Volatile var rot = 0f
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var cosR = 1f
    @Volatile var sinR = 0f
    @Volatile var bgArgb = 0xFFFFFFFF.toInt()
    @Volatile var canvasW = 2048
    @Volatile var canvasH = 2048

    private val renderer = CanvasRenderer(this)
    private var fitted = false
    private var minScale = 0.02f
    private val maxScale = 48f

    // ---- gesture state
    private var mode = MODE_IDLE
    private var downTime = 0L
    private var maxPointers = 0
    private var multiMoved = false
    private var downX = 0f
    private var downY = 0f
    private var lastMx = 0f
    private var lastMy = 0f
    private var lastD = 1f
    private var lastA = 0f
    private var outX = 0f
    private var outY = 0f

    // shape / selection gesture state
    private var shapeActive = false
    private var shapeX0 = 0f
    private var shapeY0 = 0f
    private var selMode = SEL_NONE
    private var lastCx = 0f
    private var lastCy = 0f
    private var marqueeQuad: FloatArray? = null
    private val cornersBuf = FloatArray(8)
    private val slop = 24f * resources.displayMetrics.density

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 0, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        refreshDims()
    }

    fun totalTiles(): Int = ((canvasW + 255) / 256) * ((canvasH + 255) / 256)

    fun refreshDims() {
        canvasW = NativeEngine.nativeCanvasWidth().coerceAtLeast(64)
        canvasH = NativeEngine.nativeCanvasHeight().coerceAtLeast(64)
        renderer.requestReset(totalTiles())
    }

    /** Call after the native canvas was replaced (new artboard / project loaded). */
    fun onCanvasReplaced() {
        refreshDims()
        fitCanvas()
        onHistoryChanged?.invoke()
        refreshOverlay()
    }

    fun setPaper(argb: Int) {
        bgArgb = argb
        requestRender()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted && w > 0 && h > 0) fitCanvas()
    }

    fun fitCanvas() {
        if (width <= 0 || height <= 0) return
        fitted = true
        val s = min(width.toFloat() / canvasW, height.toFloat() / canvasH) * 0.88f
        minScale = s * 0.5f
        scale = s
        applyRotation(0f)
        tx = width / 2f - s * canvasW / 2f
        ty = height / 2f - s * canvasH / 2f
        requestRender()
        refreshOverlay()
    }

    private fun applyRotation(r: Float) {
        rot = r
        cosR = cos(r)
        sinR = sin(r)
    }

    /** Canvas pixel -> screen pixel (result in outX / outY). Inverse of [screenToCanvas]. */
    private fun canvasToScreen(cx: Float, cy: Float) {
        outX = tx + scale * (cosR * cx - sinR * cy)
        outY = ty + scale * (sinR * cx + cosR * cy)
    }

    /** Recompute the selection outline (and marquee) in screen space and hand it to Compose. UI thread only. */
    fun refreshOverlay() {
        val cb = onOverlay ?: return
        var quad: FloatArray? = null
        if (NativeEngine.nativeHasObject() && NativeEngine.nativeObjectCorners(cornersBuf)) {
            val q = FloatArray(8)
            for (i in 0 until 4) {
                canvasToScreen(cornersBuf[2 * i], cornersBuf[2 * i + 1])
                q[2 * i] = outX
                q[2 * i + 1] = outY
            }
            quad = q
        }
        cb(quad, marqueeQuad)
    }

    private fun screenToCanvas(sx: Float, sy: Float) {
        val dx = sx - tx
        val dy = sy - ty
        outX = (cosR * dx + sinR * dy) / scale
        outY = (-sinR * dx + cosR * dy) / scale
    }

    // ------------------------------------------------------------------ history
    fun undo() {
        if (NativeEngine.nativeUndo()) afterEdit()
    }

    fun redo() {
        if (NativeEngine.nativeRedo()) afterEdit()
    }

    private fun afterEdit() {
        requestRender()
        onHistoryChanged?.invoke()
        refreshOverlay()
    }

    // ------------------------------------------------------------------ tools
    /** Pressure of the sample at history position [h] (or the current one for h < 0). Fingers report 1. */
    private fun pressure(ev: MotionEvent, h: Int = -1): Float {
        if (!PalmFilter.isStylus(ev.getToolType(0))) return 1f
        val p = if (h < 0) ev.pressure else ev.getHistoricalPressure(0, h)
        return p.coerceIn(0.05f, 1f)
    }

    /** The tool this gesture acts as: Hand when a finger navigates in stylus-only mode. */
    private val effTool: Int get() = if (navGesture) Tool.HAND else tool

    private fun isStrokeTool() = effTool == Tool.DRAW || effTool == Tool.ERASER

    // ---- shapes: drag to size, the engine redraws an anti-aliased preview, lifting the finger bakes it
    private fun moveShape(ev: MotionEvent) {
        if (!shapeActive && hypot(ev.x - downX, ev.y - downY) < 6f * resources.displayMetrics.density) return
        screenToCanvas(ev.x, ev.y)
        shapeActive = true
        NativeEngine.nativeShapeUpdate(
            shapeKind, shapeX0, shapeY0, outX, outY, shapeOutline, shapeStroke, shapeCorner, shapeSides,
            fillColor, shapeOpacity, shapeBlend, fillKind, secondaryOf(fillColor), fillScale,
        )
        requestRender()
    }

    private fun endShape() {
        if (shapeActive) {
            shapeActive = false
            NativeEngine.nativeShapeEnd()
            afterEdit()
        }
    }

    private fun cancelShapeAndSelect() {
        if (shapeActive) {
            shapeActive = false
            NativeEngine.nativeShapeCancel()
            afterEdit()
        }
        if (selMode == SEL_MARQUEE) {
            marqueeQuad = null
            refreshOverlay()
        }
        selMode = SEL_NONE
    }

    // ---- select tool: drag the selected object, tap to select, drag on empty space for a marquee
    private fun beginSelect(ev: MotionEvent) {
        screenToCanvas(ev.x, ev.y)
        lastCx = outX
        lastCy = outY
        selMode = if (NativeEngine.nativeHasObject() && NativeEngine.nativeObjectHit(outX, outY)) SEL_DRAG else SEL_PENDING
    }

    private fun updateMarquee(ev: MotionEvent) {
        screenToCanvas(downX, downY)
        val ax = outX
        val ay = outY
        screenToCanvas(ev.x, ev.y)
        val bx = outX
        val by = outY
        val q = FloatArray(8)
        val xs = floatArrayOf(ax, bx, bx, ax)
        val ys = floatArrayOf(ay, ay, by, by)
        for (i in 0 until 4) {
            canvasToScreen(xs[i], ys[i])
            q[2 * i] = outX
            q[2 * i + 1] = outY
        }
        marqueeQuad = q
        refreshOverlay()
    }

    private fun moveSelect(ev: MotionEvent) {
        when (selMode) {
            SEL_DRAG -> {
                screenToCanvas(ev.x, ev.y)
                NativeEngine.nativeObjectMove(outX - lastCx, outY - lastCy)
                lastCx = outX
                lastCy = outY
                requestRender()
                refreshOverlay()
            }
            SEL_PENDING -> if (hypot(ev.x - downX, ev.y - downY) > slop) {
                selMode = SEL_MARQUEE
                updateMarquee(ev)
            }
            SEL_MARQUEE -> updateMarquee(ev)
        }
    }

    private fun endSelect(ev: MotionEvent) {
        when (selMode) {
            SEL_DRAG -> afterEdit()
            SEL_PENDING -> {
                screenToCanvas(ev.x, ev.y)
                val had = NativeEngine.nativeHasObject()
                if (had) NativeEngine.nativeCommit()
                val r = NativeEngine.nativeSelectAt(floor(outX).toInt(), floor(outY).toInt())
                if (r == 2) onMessage?.invoke("Objek terlalu besar untuk dipilih")
                else if (r == 1 && !had) onMessage?.invoke("Tidak ada gambar di titik itu (Layer aktif)")
                afterEdit()
            }
            SEL_MARQUEE -> {
                screenToCanvas(downX, downY)
                val ax = outX
                val ay = outY
                screenToCanvas(ev.x, ev.y)
                marqueeQuad = null
                if (NativeEngine.nativeHasObject()) NativeEngine.nativeCommit()
                val r = NativeEngine.nativeSelectRect(
                    floor(min(ax, outX)).toInt(), floor(min(ay, outY)).toInt(),
                    ceil(max(ax, outX)).toInt(), ceil(max(ay, outY)).toInt(),
                )
                if (r == 2) onMessage?.invoke("Objek terlalu besar untuk dipilih")
                else if (r == 1) onMessage?.invoke("Tidak ada gambar di area itu (Layer aktif)")
                afterEdit()
            }
        }
        selMode = SEL_NONE
    }

    /** Drop a colour / pattern at a screen position (drag & drop from the swatch panel). */
    fun dropFill(sx: Float, sy: Float, kind: Int, color: Int) {
        screenToCanvas(sx, sy)
        runFill(floor(outX).toInt(), floor(outY).toInt(), kind, color)
    }

    private fun runFill(x: Int, y: Int, kind: Int, color: Int) {
        val r = NativeEngine.nativeFill(x, y, kind, color, secondaryOf(color), fillScale, fillTolerance)
        when (r) {
            1 -> onMessage?.invoke("Di luar artboard")
            2 -> onMessage?.invoke("Area terlalu besar untuk fill. Ubah warna Paper di Layers.")
        }
        afterEdit()
    }

    private fun doTap(sx: Float, sy: Float) {
        screenToCanvas(sx, sy)
        val x = floor(outX).toInt()
        val y = floor(outY).toInt()
        when (tool) {
            Tool.FILL -> runFill(x, y, fillKind, fillColor)
            Tool.EYEDROPPER -> onColorPicked?.invoke(NativeEngine.nativePickColor(x, y))
            Tool.SELECT_COLOR -> {
                val n = NativeEngine.nativeSelectReplace(x, y, fillColor, tolH, tolS, tolL)
                onMessage?.invoke(if (n > 0) "$n piksel diganti" else "Tidak ada warna yang cocok")
                afterEdit()
            }
        }
    }

    // ------------------------------------------------------------------ touch
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        palm.dispatch(ev, touchSink)
        return true
    }

    /** Pen in range above the glass: remember it so a palm landing next to it is ignored. */
    override fun onHoverEvent(event: MotionEvent): Boolean {
        palm.onHover(event)
        return super.onHoverEvent(event)
    }

    /** Receives only the pointers that survived palm rejection (see [PalmFilter]). */
    private fun handleTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                onTouchDown?.invoke()
                downTime = ev.eventTime
                maxPointers = 1
                multiMoved = false
                downX = ev.x
                downY = ev.y
                mode = MODE_SINGLE
                // Stylus-only mode: a finger never draws, it pans (and two fingers zoom / rotate)
                navGesture = palm.mode == Palm.STYLUS_ONLY && !PalmFilter.isStylus(ev.getToolType(0))
                lastMx = ev.x
                lastMy = ev.y
                if (isStrokeTool()) {
                    screenToCanvas(ev.x, ev.y)
                    NativeEngine.nativeStrokeBegin(outX, outY, pressure(ev), ev.eventTime)
                    requestRender()
                } else if (effTool == Tool.SHAPE) {
                    screenToCanvas(ev.x, ev.y)
                    shapeX0 = outX
                    shapeY0 = outY
                    shapeActive = false
                } else if (effTool == Tool.SELECT) {
                    beginSelect(ev)
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPointers = max(maxPointers, ev.pointerCount)
                val early = ev.eventTime - downTime < 300
                if (mode == MODE_SINGLE && (early || !isStrokeTool())) {
                    if (isStrokeTool()) {
                        NativeEngine.nativeStrokeCancel()
                        afterEdit()
                    }
                    cancelShapeAndSelect()
                    mode = MODE_MULTI
                }
                if (mode == MODE_MULTI && ev.pointerCount == 2) beginTransform(ev)
            }

            MotionEvent.ACTION_MOVE -> when (mode) {
                MODE_SINGLE -> if (effTool == Tool.HAND) {
                    tx += ev.x - lastMx
                    ty += ev.y - lastMy
                    lastMx = ev.x
                    lastMy = ev.y
                    requestRender()
                    refreshOverlay()
                } else if (effTool == Tool.SHAPE) {
                    moveShape(ev)
                } else if (effTool == Tool.SELECT) {
                    moveSelect(ev)
                } else if (isStrokeTool()) {
                    val hs = ev.historySize
                    for (h in 0 until hs) {
                        screenToCanvas(ev.getHistoricalX(0, h), ev.getHistoricalY(0, h))
                        NativeEngine.nativeStrokeMove(outX, outY, pressure(ev, h), ev.getHistoricalEventTime(h))
                    }
                    screenToCanvas(ev.x, ev.y)
                    NativeEngine.nativeStrokeMove(outX, outY, pressure(ev), ev.eventTime)
                    requestRender()
                }

                MODE_MULTI -> if (ev.pointerCount == 2) updateTransform(ev)
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == MODE_SINGLE && ev.actionIndex == 0 && isStrokeTool()) {
                    NativeEngine.nativeStrokeEnd()
                    afterEdit()
                    mode = MODE_IDLE
                } else if (mode == MODE_MULTI && ev.pointerCount - 1 == 2) {
                    beginTransformExcluding(ev, ev.actionIndex)
                }
            }

            MotionEvent.ACTION_UP -> {
                when (mode) {
                    MODE_SINGLE -> {
                        if (isStrokeTool()) {
                            NativeEngine.nativeStrokeEnd()
                            afterEdit()
                        } else if (effTool == Tool.SHAPE) {
                            endShape()
                        } else if (effTool == Tool.SELECT) {
                            endSelect(ev)
                        } else if (!navGesture && hypot(ev.x - downX, ev.y - downY) < slop) {
                            doTap(ev.x, ev.y)
                        }
                    }

                    MODE_MULTI -> if (!multiMoved && ev.eventTime - downTime < 400) {
                        if (maxPointers == 2) undo() else if (maxPointers >= 3) redo()
                    }
                }
                mode = MODE_IDLE
            }

            MotionEvent.ACTION_CANCEL -> {
                if (mode == MODE_SINGLE && isStrokeTool()) {
                    NativeEngine.nativeStrokeCancel()
                    afterEdit()
                }
                cancelShapeAndSelect()
                mode = MODE_IDLE
            }
        }
    }

    private fun beginTransform(ev: MotionEvent) {
        beginTransformBetween(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1))
    }

    private fun beginTransformExcluding(ev: MotionEvent, lifted: Int) {
        var a = -1
        var b = -1
        for (i in 0 until ev.pointerCount) {
            if (i == lifted) continue
            if (a < 0) a = i else b = i
        }
        if (a >= 0 && b >= 0) beginTransformBetween(ev.getX(a), ev.getY(a), ev.getX(b), ev.getY(b))
    }

    private fun beginTransformBetween(x0: Float, y0: Float, x1: Float, y1: Float) {
        lastMx = (x0 + x1) * 0.5f
        lastMy = (y0 + y1) * 0.5f
        lastD = max(1f, hypot(x1 - x0, y1 - y0))
        lastA = atan2(y1 - y0, x1 - x0)
    }

    private fun updateTransform(ev: MotionEvent) {
        val x0 = ev.getX(0)
        val y0 = ev.getY(0)
        val x1 = ev.getX(1)
        val y1 = ev.getY(1)
        val mx = (x0 + x1) * 0.5f
        val my = (y0 + y1) * 0.5f
        val d = max(1f, hypot(x1 - x0, y1 - y0))
        val a = atan2(y1 - y0, x1 - x0)
        if (!multiMoved) {
            if (hypot(mx - lastMx, my - lastMy) < slop && kotlin.math.abs(d - lastD) < slop) return
            multiMoved = true
            lastMx = mx; lastMy = my; lastD = d; lastA = a // no jump when the gesture engages
            return
        }
        screenToCanvas(lastMx, lastMy) // canvas point that was under the previous centroid
        val qx = outX
        val qy = outY
        val ns = (scale * d / lastD).coerceIn(minScale, maxScale)
        var da = a - lastA
        if (da > PI.toFloat()) da -= 2f * PI.toFloat()
        if (da < -PI.toFloat()) da += 2f * PI.toFloat()
        applyRotation(rot + da)
        tx = mx - ns * (cosR * qx - sinR * qy)
        ty = my - ns * (sinR * qx + cosR * qy)
        scale = ns
        lastMx = mx; lastMy = my; lastD = d; lastA = a
        requestRender()
        refreshOverlay()
    }

    private companion object {
        const val MODE_IDLE = 0
        const val MODE_SINGLE = 1
        const val MODE_MULTI = 2
        const val SEL_NONE = 0
        const val SEL_PENDING = 1
        const val SEL_DRAG = 2
        const val SEL_MARQUEE = 3
    }
}
