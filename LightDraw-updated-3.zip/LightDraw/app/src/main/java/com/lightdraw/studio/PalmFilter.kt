package com.lightdraw.studio

import android.view.MotionEvent

/** Palm-rejection modes (stored in [com.lightdraw.studio.ui.DrawState.palmMode]). */
object Palm {
    /** Every touch is accepted. */
    const val OFF = 0

    /** While a pen is touching / hovering (or just left), fingers are ignored; big contact blobs are ignored always. */
    const val AUTO = 1

    /** Like [AUTO], and fingers never draw: one finger pans, two fingers pinch / rotate; only the pen draws. */
    const val STYLUS_ONLY = 2
}

/**
 * Palm rejection that sits in front of the canvas gesture code.
 *
 * Every raw [MotionEvent] goes through [dispatch]. Pointers classified as "palm" are removed from the stream, so the
 * gesture code downstream never sees them: a resting hand can neither start a stroke nor cancel the pen stroke that is in
 * progress (the old code treated any second pointer within 300 ms as a pinch and cancelled the stroke).
 *
 * A new pointer is a palm when
 *  - mode is not [Palm.OFF] and the system reports `TOOL_TYPE_PALM` (API 34+), or
 *  - its contact ellipse (`getTouchMajor`) is at least [palmMajorPx], or
 *  - it is a finger while a stylus is down, hovering, or was seen within [GRACE_MS] (the hand rests on the glass a
 *    moment before / after the pen).
 * When the pen lands while fingers were already accepted, those fingers were a resting hand: they are cancelled.
 */
class PalmFilter {
    var mode = Palm.AUTO

    /** Contact size (px) from which a touch counts as a palm. */
    var palmMajorPx = 120f

    private var rejectMask = 0 // pointer ids that are being ignored
    private var stylusMask = 0 // pointer ids of styluses that are down
    private var lastStylusTime = Long.MIN_VALUE / 2

    private val acc = IntArray(MAX)
    private val props = Array(MAX) { MotionEvent.PointerProperties() }
    private val coords = Array(MAX) { MotionEvent.PointerCoords() }

    /** Feed hover events (pen in range above the glass) so the palm that lands next to a hovering pen is ignored. */
    fun onHover(ev: MotionEvent) {
        if (isStylus(ev.getToolType(0))) lastStylusTime = ev.eventTime
    }

    fun reset() {
        rejectMask = 0
        stylusMask = 0
    }

    private fun penBusy(now: Long) = stylusMask != 0 || now - lastStylusTime < GRACE_MS

    private fun shouldReject(ev: MotionEvent, i: Int): Boolean {
        if (mode == Palm.OFF) return false
        val tt = ev.getToolType(i)
        if (isStylus(tt)) return false
        if (tt == TOOL_TYPE_PALM) return true
        if (ev.getTouchMajor(i) >= palmMajorPx) return true
        return penBusy(ev.eventTime)
    }

    /** Calls [sink] with the cleaned-up event(s) for [raw] (zero, one or, when the pen cancels a hand, two). */
    fun dispatch(raw: MotionEvent, sink: (MotionEvent) -> Unit) {
        val act = raw.actionMasked
        val n = minOf(raw.pointerCount, MAX)
        val aIdx = raw.actionIndex
        val aBit = 1 shl (raw.getPointerId(aIdx) and 31)
        val now = raw.eventTime
        for (i in 0 until n) if (isStylus(raw.getToolType(i))) lastStylusTime = now

        if (act == MotionEvent.ACTION_DOWN) reset()
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            if (isStylus(raw.getToolType(aIdx))) {
                stylusMask = stylusMask or aBit
                if (mode != Palm.OFF) {
                    // the pen arrived: whatever finger is still being tracked was a resting hand
                    var m = 0
                    for (i in 0 until n) {
                        if (i != aIdx && rejectMask and (1 shl (raw.getPointerId(i) and 31)) == 0) acc[m++] = i
                    }
                    if (m > 0) {
                        send(raw, MotionEvent.ACTION_CANCEL, m, 0, false, sink)
                        for (k in 0 until m) rejectMask = rejectMask or (1 shl (raw.getPointerId(acc[k]) and 31))
                    }
                }
                rejectMask = rejectMask and aBit.inv()
            } else if (shouldReject(raw, aIdx)) {
                rejectMask = rejectMask or aBit
            } else {
                rejectMask = rejectMask and aBit.inv()
            }
        }

        var m = 0
        var actionPos = -1
        for (i in 0 until n) {
            if (rejectMask and (1 shl (raw.getPointerId(i) and 31)) == 0) {
                if (i == aIdx) actionPos = m
                acc[m++] = i
            }
        }
        val actionAccepted = actionPos >= 0
        val canceledBySystem = raw.flags and FLAG_CANCELED != 0

        when (act) {
            MotionEvent.ACTION_MOVE -> {
                if (m == n) sink(raw) else if (m > 0) send(raw, MotionEvent.ACTION_MOVE, m, 0, true, sink)
            }

            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (!actionAccepted) {
                    if (m > 0) send(raw, MotionEvent.ACTION_MOVE, m, 0, false, sink)
                } else if (m == n) {
                    sink(raw)
                } else if (m == 1) {
                    send(raw, MotionEvent.ACTION_DOWN, m, 0, false, sink)
                } else {
                    send(raw, MotionEvent.ACTION_POINTER_DOWN, m, actionPos, false, sink)
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                stylusMask = stylusMask and aBit.inv()
                if (!actionAccepted) {
                    rejectMask = rejectMask and aBit.inv()
                    if (m > 0) send(raw, MotionEvent.ACTION_MOVE, m, 0, false, sink)
                } else if (canceledBySystem) {
                    // the system decided afterwards that this contact was a palm: drop the whole gesture
                    send(raw, MotionEvent.ACTION_CANCEL, m, 0, false, sink)
                    for (i in 0 until n) rejectMask = rejectMask or (1 shl (raw.getPointerId(i) and 31))
                } else if (m == n) {
                    sink(raw)
                } else if (m == 1) {
                    send(raw, MotionEvent.ACTION_UP, m, 0, false, sink)
                } else {
                    send(raw, MotionEvent.ACTION_POINTER_UP, m, actionPos, false, sink)
                }
                if (act == MotionEvent.ACTION_UP) reset()
            }

            MotionEvent.ACTION_CANCEL -> {
                if (m > 0) {
                    if (m == n) sink(raw) else send(raw, MotionEvent.ACTION_CANCEL, m, 0, false, sink)
                }
                reset()
            }
        }
    }

    /** Builds an event holding only the pointers in [acc] (first [m]) and hands it to [sink]. */
    private fun send(raw: MotionEvent, action: Int, m: Int, actionPos: Int, history: Boolean, sink: (MotionEvent) -> Unit) {
        val hs = if (history) raw.historySize else 0
        for (k in 0 until m) raw.getPointerProperties(acc[k], props[k])
        fun load(h: Int) {
            for (k in 0 until m) {
                if (h < hs) raw.getHistoricalPointerCoords(acc[k], h, coords[k]) else raw.getPointerCoords(acc[k], coords[k])
            }
        }
        val full = if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP) {
            action or (actionPos shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        } else {
            action
        }
        load(0)
        val t0 = if (hs > 0) raw.getHistoricalEventTime(0) else raw.eventTime
        val ev = MotionEvent.obtain(
            raw.downTime, t0, full, m, props, coords, raw.metaState, raw.buttonState,
            raw.xPrecision, raw.yPrecision, raw.deviceId, raw.edgeFlags, raw.source, raw.flags and FLAG_CANCELED.inv(),
        )
        for (h in 1 until hs) {
            load(h)
            ev.addBatch(raw.getHistoricalEventTime(h), coords, raw.metaState)
        }
        if (hs > 0) {
            load(hs)
            ev.addBatch(raw.eventTime, coords, raw.metaState)
        }
        try {
            sink(ev)
        } finally {
            ev.recycle()
        }
    }

    companion object {
        private const val MAX = 10
        private const val GRACE_MS = 700L
        private const val TOOL_TYPE_PALM = 5 // MotionEvent.TOOL_TYPE_PALM (API 34)
        private const val FLAG_CANCELED = 0x20 // MotionEvent.FLAG_CANCELED (API 33)

        fun isStylus(toolType: Int) = toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER
    }
}
