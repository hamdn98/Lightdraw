package com.lightdraw.studio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Palette taken from the HTML mockup. */
object Palette {
    val DarkBg = Color(0xFF0F0F11)
    val CanvasBg = Color(0xFF18181C)
    val PanelBg = Color(0xFF1E1E24)
    val PanelBorder = Color(0xFF2B2B36)
    val AccentPurple = Color(0xFFA066FF)
    val AccentCyan = Color(0xFF00E5FF)
    val AccentPink = Color(0xFFFF3366)
    val TextPrimary = Color(0xFFE2E8F0)
    val TextMuted = Color(0xFF9CA3AF)
}

@Composable
fun LightDrawTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.AccentPurple,
            secondary = Palette.AccentCyan,
            tertiary = Palette.AccentPink,
            background = Palette.DarkBg,
            surface = Palette.PanelBg,
            surfaceVariant = Palette.PanelBorder,
            onPrimary = Color.White,
            onSurface = Palette.TextPrimary,
            onBackground = Palette.TextPrimary,
        ),
        typography = Typography(),
        content = content,
    )
}

/** Rounded dark floating panel (Procreate / Ibis style). Also swallows touches so the canvas below is not drawn on. */
@Composable
fun FloatingPanel(modifier: Modifier = Modifier, shape: RoundedCornerShape = RoundedCornerShape(16.dp), content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        shape = shape,
        color = Palette.PanelBg.copy(alpha = 0.94f),
        border = BorderStroke(1.dp, Palette.PanelBorder),
        shadowElevation = 10.dp,
        content = content,
    )
}

@Composable
fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: Color = Palette.AccentPurple,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Palette.TextMuted, fontSize = 12.sp)
            Text(valueText, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Palette.PanelBorder,
            ),
            modifier = Modifier.height(28.dp),
        )
    }
}
