package com.lightdraw.studio

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.lightdraw.studio.ui.DragDropState
import com.lightdraw.studio.ui.EditActions
import com.lightdraw.studio.ui.SelRect
import com.lightdraw.studio.ui.DrawIcons
import com.lightdraw.studio.ui.DrawState
import com.lightdraw.studio.ui.FloatingPanel
import com.lightdraw.studio.ui.BottomNav
import com.lightdraw.studio.ui.LabeledSlider
import com.lightdraw.studio.ui.Palette
import com.lightdraw.studio.ui.Panel
import com.lightdraw.studio.ui.PopupHost
import com.lightdraw.studio.ui.SideSliderPanel
import com.lightdraw.studio.ui.TopToolbar
import com.lightdraw.studio.ui.Tool
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun CanvasScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val export = remember { ExportManager(ctx) }
    // Default artboard 2048x2048: light on RAM; pick a bigger one in Artboard settings.
    remember { NativeEngine.nativeInit(2048, 2048, export.spillDir, export.maxResidentTiles()) }

    val state = remember { DrawState() }
    val dd = remember { DragDropState() }
    var canvasView by remember { mutableStateOf<CanvasGLView?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var showArtboard by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun refreshHistory() {
        val h = NativeEngine.nativeHistoryState()
        state.canUndo = h and 1 != 0
        state.canRedo = h and 2 != 0
    }

    fun afterCanvasReplaced() {
        canvasView?.onCanvasReplaced()
        generation++
        refreshHistory()
    }

    // ---- overlay state (selection outline, rubber band, move ghost, view changes)
    var viewTick by remember { mutableIntStateOf(0) }
    var marquee by remember { mutableStateOf<Rect?>(null) }
    var ghost by remember { mutableStateOf<Offset?>(null) }

    fun afterEditRefresh() {
        canvasView?.requestRender()
        refreshHistory()
    }

    fun canvasW() = NativeEngine.nativeCanvasWidth()
    fun canvasH() = NativeEngine.nativeCanvasHeight()

    fun clampSel(r: SelRect): SelRect {
        val w = canvasW()
        val h = canvasH()
        val x0 = r.x0.coerceIn(0, w - 1)
        val y0 = r.y0.coerceIn(0, h - 1)
        return SelRect(x0, y0, r.x1.coerceIn(x0, w - 1), r.y1.coerceIn(y0, h - 1))
    }

    /** New selection rectangle after moving by (dx, dy); with wrap the origin re-enters on the opposite edge. */
    fun movedSel(s: SelRect, dx: Int, dy: Int): SelRect {
        if (!state.wrapEdges) return clampSel(s.shift(dx, dy))
        val w = canvasW()
        val h = canvasH()
        val x0 = Math.floorMod(s.x0 + dx, w)
        val y0 = Math.floorMod(s.y0 + dy, h)
        return SelRect(x0, y0, minOf(x0 + s.w - 1, w - 1), minOf(y0 + s.h - 1, h - 1))
    }

    fun requireSel(): SelRect? {
        val s = state.selection
        if (s == null) toast("Pilih objek dulu: tool Select, lalu seret kotak di sekeliling objek")
        return s
    }

    fun duplicateSelection() {
        val s = requireSel() ?: return
        val off = 24
        when (NativeEngine.nativeMoveRegion(s.x0, s.y0, s.x1, s.y1, off, off, true, state.wrapEdges)) {
            0 -> { state.selection = movedSel(s, off, off); afterEditRefresh(); toast("Objek diduplikasi") }
            2 -> toast("Seleksi terlalu besar (maks 16 MP)")
            else -> toast("Seleksi kosong / di luar artboard")
        }
    }

    fun moveSelection(dx: Int, dy: Int) {
        val s = state.selection ?: return
        when (NativeEngine.nativeMoveRegion(s.x0, s.y0, s.x1, s.y1, dx, dy, false, state.wrapEdges)) {
            0 -> { state.selection = movedSel(s, dx, dy); afterEditRefresh() }
            2 -> toast("Seleksi terlalu besar (maks 16 MP)")
            else -> toast("Seleksi di luar artboard")
        }
    }

    fun alignSelection(mode: Int) {
        val s = requireSel() ?: return
        val r = NativeEngine.nativeAlignRegion(s.x0, s.y0, s.x1, s.y1, mode)
        if (r == Long.MIN_VALUE) {
            toast("Tidak ada piksel objek di dalam seleksi")
            return
        }
        state.selection = clampSel(s.shift((r shr 32).toInt(), r.toInt()))
        afterEditRefresh()
    }

    fun selectionToPattern() {
        val s = requireSel() ?: return
        patDlg = s
    }

    fun makePattern(s: SelRect, outW: Int, outH: Int) {
        val r = NativeEngine.nativeSetPatternFromRegion(s.x0, s.y0, s.x1, s.y1, outW, outH)
        when {
            r > 0 -> {
                val w = r ushr 16
                val h = r and 0xFFFF
                state.customPatternSize = "${w}×${h}"
                state.pattern = 7
                state.tool = Tool.FILL
                state.panel = Panel.COLOR
                toast("Pola Custom ${w}×${h} siap: ketuk area untuk mengisi")
            }
            r == -1 -> toast("Seleksi kosong, tidak ada gambar untuk dijadikan pola")
            else -> toast("Ukuran pola terlalu besar (maks 2048×2048)")
        }
    }

    fun wrapBy(dx: Int, dy: Int) {
        if (NativeEngine.nativeOffsetWrap(dx, dy) == 2) toast("Artboard terlalu besar untuk Wrap (maks 4096×4096)") else afterEditRefresh()
    }

    // ---- delete / color magic / crop / perspective
    var cropDlg by remember { mutableStateOf<SelRect?>(null) }
    var patDlg by remember { mutableStateOf<SelRect?>(null) }
    var warpSrc by remember { mutableStateOf<SelRect?>(null) }
    var zoomHud by remember { mutableStateOf<Int?>(null) }
    var lastZoom by remember { mutableIntStateOf(-1) }

    fun deleteSelection() {
        val s = requireSel() ?: return
        if (NativeEngine.nativeClearRegion(s.x0, s.y0, s.x1, s.y1) == 0) {
            afterEditRefresh()
            toast("Objek dihapus")
        } else {
            toast("Seleksi kosong")
        }
    }

    fun colorMagic() {
        val s = state.selection
        val n = NativeEngine.nativeShuffleColors(s?.x0 ?: 0, s?.y0 ?: 0, s?.x1 ?: 0, s?.y1 ?: 0, s == null, System.nanoTime())
        afterEditRefresh()
        toast(if (n > 0) "Colorway diacak (${if (s == null) "seluruh gambar" else "seleksi"})" else "Tidak ada warna untuk diacak")
    }

    fun startWarp() {
        val s = requireSel() ?: return
        warpSrc = s
        state.warpQuad = listOf(
            s.x0.toFloat(), s.y0.toFloat(), s.x1 + 1f, s.y0.toFloat(),
            s.x1 + 1f, s.y1 + 1f, s.x0.toFloat(), s.y1 + 1f,
        )
        state.tool = Tool.WARP
        state.panel = Panel.NONE
    }

    fun cancelWarp() {
        state.warpQuad = null
        warpSrc = null
        if (state.tool == Tool.WARP) state.tool = Tool.SELECT
    }

    fun rotateWarp(deg: Float) {
        val q = state.warpQuad ?: return
        val cx = (q[0] + q[2] + q[4] + q[6]) / 4f
        val cy = (q[1] + q[3] + q[5] + q[7]) / 4f
        val a = Math.toRadians(deg.toDouble())
        val c = kotlin.math.cos(a).toFloat()
        val sn = kotlin.math.sin(a).toFloat()
        state.warpQuad = List(8) { i ->
            val x = q[i / 2 * 2] - cx
            val y = q[i / 2 * 2 + 1] - cy
            if (i % 2 == 0) cx + x * c - y * sn else cy + x * sn + y * c
        }
    }

    fun applyWarp() {
        val q = state.warpQuad ?: return
        val src = warpSrc ?: return
        when (NativeEngine.nativeWarpRegion(src.x0, src.y0, src.x1, src.y1, q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7])) {
            0 -> {
                val xs = listOf(q[0], q[2], q[4], q[6])
                val ys = listOf(q[1], q[3], q[5], q[7])
                state.selection = clampSel(SelRect(xs.min().toInt(), ys.min().toInt(), xs.max().toInt(), ys.max().toInt()))
                cancelWarp()
                afterEditRefresh()
                toast("Transformasi diterapkan")
            }
            2 -> toast("Area terlalu besar untuk warp (maks 16 MP)")
            else -> toast("Bentuk quad tidak valid")
        }
    }

    val actions = EditActions(
        duplicate = { duplicateSelection() },
        align = { alignSelection(it) },
        toPattern = { selectionToPattern() },
        fx = { op, a, b ->
            val n = NativeEngine.nativeApplyFx(op, a, b)
            afterEditRefresh()
            toast(if (n > 0) "FX diterapkan" else "Belum ada gambar untuk diubah")
        },
        wrapHalf = { wrapBy(canvasW() / 2, canvasH() / 2) },
        rotateView = { canvasView?.rotateView(it) },
        resetRotation = { canvasView?.resetRotation() },
        fitView = { canvasView?.fitCanvas() },
        deleteSelection = { deleteSelection() },
        colorMagic = { colorMagic() },
        cropToSelection = { requireSel()?.let { cropDlg = it } },
        startWarp = { startWarp() },
    )

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = export.importImage(uri)
            busy = false
            r.onSuccess { canvasView?.requestRender(); refreshHistory(); toast("Gambar diimpor ke kanvas") }
                .onFailure { toast("Gagal impor: ${it.message}") }
        }
    }
    val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = export.loadProject(uri)
            busy = false
            r.onSuccess { afterCanvasReplaced(); toast("Project dibuka (${it.first}×${it.second})") }
                .onFailure { toast("Gagal membuka project: ${it.message}") }
        }
    }

    // ---- push UI state to the native engine
    LaunchedEffect(state.brushPreset, state.size, state.opacity, state.color, state.blend, state.tool, generation) {
        NativeEngine.nativeSetBrush(
            state.brushPreset, state.size, state.opacity / 100f, state.color,
            if (state.tool == Tool.ERASER) 5 else state.blend,
        )
    }
    LaunchedEffect(state.seamless, generation) { NativeEngine.nativeSetSeamless(state.seamless) }
    LaunchedEffect(state.stabilizer, generation) { NativeEngine.nativeSetStabilizer(state.stabilizer / 100f) }
    LaunchedEffect(state.symMode, state.sectors, state.symMirror, generation) {
        NativeEngine.nativeSetSymmetry(state.symMode, state.sectors, state.symMirror)
    }
    LaunchedEffect(state.paperColor, state.paperVisible, canvasView, generation) {
        val bg = if (state.paperVisible) state.paperColor else 0
        NativeEngine.nativeSetBg(bg)
        canvasView?.setPaper(bg)
    }
    // The canvas now sits inside a rounded frame, so drop positions (root coords) are made view-local.
    var canvasOrigin by remember { mutableStateOf(Offset.Zero) }
    SideEffect {
        dd.onDrop = { p, pos ->
            state.panel = Panel.NONE // the popup was only hidden (alpha 0) while dragging; now close it for good
            canvasView?.dropFill(pos.x - canvasOrigin.x, pos.y - canvasOrigin.y, p.kind, p.color)
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.DarkBg)) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(8.dp)) {
            // ---- pill toolbar: Gallery | tools | colour
            TopToolbar(
                state = state,
                onGallery = { showExport = true },
                onArtboard = { showArtboard = true },
                onDuplicate = { duplicateSelection() },
            )
            Spacer(Modifier.height(8.dp))

            // ---- canvas area (rounded frame) with floating sliders + dropdown popup
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { canvasOrigin = it.positionInRoot() },
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> CanvasGLView(c).also { canvasView = it } },
                    update = { v ->
                        v.tool = state.tool
                        v.fillKind = state.pattern
                        v.fillColor = state.color
                        v.fillScale = state.patternScale
                        v.fillTolerance = state.fillTolerance.toInt()
                        v.tolH = state.tolH
                        v.tolS = state.tolS / 100f
                        v.tolL = state.tolL / 100f
                        v.shapeKind = state.shapeKind
                        v.shapeFlags = (if (state.shapeFilled) 1 else 0) or (if (state.shapeStroked) 2 else 0)
                        v.shapeStrokeW = state.shapeStrokeW
                        val sel = state.selection
                        v.hasSel = sel != null
                        if (sel != null) { v.selX0 = sel.x0; v.selY0 = sel.y0; v.selX1 = sel.x1; v.selY1 = sel.y1 }
                        v.onSelect = { x0, y0, x1, y1 ->
                            state.selection = if (x0 == -1 && y0 == -1 && x1 == -1 && y1 == -1) null else clampSel(SelRect(x0, y0, x1, y1))
                        }
                        v.onMoveSelection = { dx, dy -> moveSelection(dx, dy) }
                        v.onWrapDrag = { dx, dy -> wrapBy(dx, dy) }
                        v.onMarquee = { r -> marquee = r?.let { Rect(it.left, it.top, it.right, it.bottom) } }
                        v.onGhost = { dx, dy -> ghost = if (dx.isNaN()) null else Offset(dx, dy) }
                        v.onViewChanged = { viewTick++; val z = v.zoomPercent(); if (z != lastZoom) { lastZoom = z; zoomHud = z } }
                        v.grainKind = state.textureKind
                        v.grainStrength = state.textureStrength
                        v.grainOver = state.textureOver
                        v.warpQuad = state.warpQuad?.toFloatArray()
                        v.onWarpDrag = { idx, dx, dy ->
                            val q = state.warpQuad
                            if (q != null) state.warpQuad = q.mapIndexed { i, f ->
                                if (idx == 4 || i / 2 == idx) f + (if (i % 2 == 0) dx else dy) else f
                            }
                        }
                        v.onBusy = { busy = it }
                        v.onShapeCommitted = { x0, y0, x1, y1 -> state.selection = clampSel(SelRect(x0, y0, x1, y1)) }
                        v.onColorPicked = { argb -> state.color = argb; state.finishEyedropper() }
                        v.onHistoryChanged = { refreshHistory() }
                        v.onMessage = { m -> toast(m) }
                    },
                )
                CanvasFrame(state.selection, ghost, marquee, state.warpQuad, canvasView, viewTick, Modifier.fillMaxSize())

                val sliderH = ((maxHeight - 200.dp) / 2).coerceIn(48.dp, 110.dp)
                SideSliderPanel(
                    state = state,
                    sliderHeight = sliderH,
                    onUndo = { canvasView?.undo() },
                    onRedo = { canvasView?.redo() },
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp),
                )

                if (state.panel != Panel.NONE) {
                    PopupHost(
                        state = state,
                        dd = dd,
                        actions = actions,
                        onImport = { state.panel = Panel.NONE; imagePicker.launch("image/*") },
                        onExport = { state.panel = Panel.NONE; showExport = true },
                        onLayers = { state.panel = Panel.NONE; showLayers = true },
                        onArtboard = { state.panel = Panel.NONE; showArtboard = true },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(start = 54.dp, top = 8.dp, end = 8.dp)
                            // Auto-minimize: while a swatch / pattern is being dragged the popup is only made invisible.
                            // Removing it from the tree would cancel the running drag gesture and lose the drop.
                            .graphicsLayer { alpha = if (dd.payload != null) 0f else 1f },
                    )
                }

                if (state.warpQuad != null) {
                    FloatingPanel(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), shape = RoundedCornerShape(22.dp)) {
                        Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { cancelWarp() }) { Text("Batal", color = Palette.AccentPink) }
                            TextButton(onClick = { rotateWarp(-15f) }) { Text("↺ 15°") }
                            TextButton(onClick = { rotateWarp(15f) }) { Text("↻ 15°") }
                            TextButton(onClick = { applyWarp() }) { Text("Terapkan", color = Palette.AccentCyan) }
                        }
                    }
                }

                // pinch-to-zoom percentage HUD (auto hides)
                val hud = zoomHud
                LaunchedEffect(hud) {
                    if (hud != null) {
                        delay(900)
                        zoomHud = null
                    }
                }
                if (hud != null) {
                    Text(
                        "$hud%", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            BottomNav(state)
        }

        // ---- drag ghost
        val payload = dd.payload
        if (payload != null) {
            Box(
                Modifier
                    .offset { IntOffset(dd.pos.x.roundToInt() - 24, dd.pos.y.roundToInt() - 24) }
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(payload.color).copy(alpha = 0.85f))
                    .border(2.dp, if (payload.kind == 0) Color.White else Palette.AccentCyan, CircleShape)
            )
        }

        if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Palette.AccentPurple)
        }
    }

    patDlg?.let { sel ->
        PatternSizeDialog(sel, onDismiss = { patDlg = null }) { w, h ->
            patDlg = null
            makePattern(sel, w, h)
        }
    }
    cropDlg?.let { sel ->
        AlertDialog(
            onDismissRequest = { cropDlg = null },
            containerColor = Palette.PanelBg,
            titleContentColor = Color.White,
            textContentColor = Palette.TextPrimary,
            title = { Text("Crop artboard") },
            text = { Text("Artboard dipotong menjadi ${sel.w}×${sel.h} px. Riwayat Undo akan dihapus; simpan project dulu bila perlu.") },
            confirmButton = {
                TextButton(onClick = {
                    cropDlg = null
                    val r = NativeEngine.nativeCropCanvas(sel.x0, sel.y0, sel.x1, sel.y1)
                    if (r >= 0) {
                        state.selection = null
                        afterCanvasReplaced()
                        toast("Artboard ${(r shr 32).toInt()}×${(r and 0xFFFFFFFFL).toInt()}")
                    } else {
                        toast("Crop gagal")
                    }
                }) { Text("Crop") }
            },
            dismissButton = { TextButton(onClick = { cropDlg = null }) { Text("Batal") } },
        )
    }
    if (showArtboard) ArtboardDialog(
        lowRam = remember { export.isLowRam() },
        onDismiss = { showArtboard = false },
        onCreate = { w, h ->
            showArtboard = false
            NativeEngine.nativeInit(w, h, export.spillDir, export.maxResidentTiles())
            afterCanvasReplaced()
            toast("Artboard baru ${w}×${h}")
        },
    )

    if (showExport) ExportDialog(
        paperVisible = state.paperVisible,
        onDismiss = { showExport = false },
        onOpenProject = { showExport = false; projectPicker.launch(arrayOf("*/*")) },
        onExport = { fmt, transparent, high ->
            showExport = false
            scope.launch {
                busy = true
                val r = when (fmt) {
                    0 -> export.exportPng(state.paperColor, transparent)
                    1 -> export.exportJpeg(state.paperColor, if (high) 100 else 85)
                    3 -> export.exportWebp(state.paperColor, transparent, high, if (high) 100 else 85)
                    else -> export.saveProject()
                }
                busy = false
                r.onSuccess {
                    toast(
                        when (fmt) {
                            2 -> "Project disimpan di Download/DrawingApp"
                            else -> "Tersimpan di Pictures/DrawingApp" + (export.note?.let { "\n$it" } ?: "")
                        }
                    )
                }.onFailure { toast("Export gagal: ${it.message}") }
            }
        },
    )

    if (showLayers) LayersDialog(
        state = state,
        onClear = { NativeEngine.nativeClear(); canvasView?.requestRender(); refreshHistory() },
        onDismiss = { showLayers = false },
    )
}

// ------------------------------------------------------------------ canvas frame

/**
 * Rounds the corners of the (rectangular) GL surface by painting the outside corners in the app background,
 * and draws the selection outline (follows pan / zoom / rotate), the rubber band and the move ghost.
 */
@Composable
private fun CanvasFrame(
    sel: SelRect?,
    ghost: Offset?,
    marquee: Rect?,
    warp: List<Float>?,
    view: CanvasGLView?,
    tick: Int,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val r = CornerRadius(22.dp.toPx())
        val rect = Rect(0f, 0f, size.width, size.height)
        val mask = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(rect)
            addRoundRect(RoundRect(rect, r))
        }
        drawPath(mask, Palette.DarkBg)
        drawRoundRect(Palette.PanelBorder, cornerRadius = r, style = Stroke(1.dp.toPx()))

        @Suppress("UNUSED_VARIABLE") val redrawOnViewChange = tick
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
        if (sel != null && view != null) {
            val sx = ghost?.x ?: 0f
            val sy = ghost?.y ?: 0f
            val pts = FloatArray(2)
            val path = Path()
            val corners = arrayOf(
                sel.x0 to sel.y0, (sel.x1 + 1) to sel.y0, (sel.x1 + 1) to (sel.y1 + 1), sel.x0 to (sel.y1 + 1),
            )
            corners.forEachIndexed { i, (cx, cy) ->
                view.canvasToScreen(cx + sx, cy + sy, pts)
                if (i == 0) path.moveTo(pts[0], pts[1]) else path.lineTo(pts[0], pts[1])
            }
            path.close()
            drawPath(path, Color.White, style = Stroke(3.dp.toPx(), pathEffect = dash))
            drawPath(path, Color(0xFF60A5FA), style = Stroke(1.5.dp.toPx(), pathEffect = dash))
        }
        if (warp != null && view != null) {
            val pts = FloatArray(2)
            val sp = ArrayList<Offset>(4)
            for (i in 0..3) {
                view.canvasToScreen(warp[2 * i], warp[2 * i + 1], pts)
                sp.add(Offset(pts[0], pts[1]))
            }
            val path = Path().apply {
                moveTo(sp[0].x, sp[0].y)
                for (i in 1..3) lineTo(sp[i].x, sp[i].y)
                close()
            }
            drawPath(path, Color(0x2260A5FA))
            drawPath(path, Color.White, style = Stroke(3.dp.toPx()))
            drawPath(path, Color(0xFFA066FF), style = Stroke(1.5.dp.toPx()))
            for (o in sp) {
                drawCircle(Color.White, 11.dp.toPx(), o)
                drawCircle(Color(0xFFA066FF), 8.dp.toPx(), o)
            }
        }
        if (marquee != null) {
            drawRect(Color(0xFF60A5FA), topLeft = marquee.topLeft, size = marquee.size, style = Stroke(2.dp.toPx(), pathEffect = dash))
        }
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
private fun FormatChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) Palette.AccentPurple else Palette.TextMuted,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(shape)
            .background(if (selected) Palette.AccentPurple.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) Palette.AccentPurple else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

private val ArtboardPresets = listOf(
    "512²" to (512 to 512), "1024²" to (1024 to 1024), "2048²" to (2048 to 2048),
    "4096²" to (4096 to 4096), "8192²" to (8192 to 8192), "16384²" to (16384 to 16384),
    "A4 300dpi" to (2480 to 3508), "Full HD" to (1080 to 1920),
)

/** Convert-to-pattern sizing: custom W x H in px with aspect-ratio lock (and quick % presets). */
@Composable
private fun PatternSizeDialog(sel: SelRect, onDismiss: () -> Unit, onConfirm: (Int, Int) -> Unit) {
    var wText by remember { mutableStateOf(sel.w.toString()) }
    var hText by remember { mutableStateOf(sel.h.toString()) }
    var lock by remember { mutableStateOf(true) }
    val ratio = sel.h.toFloat() / sel.w.toFloat()
    val w = wText.toIntOrNull()
    val h = hText.toIntOrNull()
    val error = when {
        w == null || h == null -> "Masukkan angka yang valid"
        w !in 8..2048 || h !in 8..2048 -> "Ukuran pola harus 8 – 2048 px"
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Objek menjadi pola") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Seleksi ${sel.w}×${sel.h} px menjadi satu ubin (tile) yang berulang tanpa sambungan.", fontSize = 12.sp, color = Palette.TextMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(25, 50, 100, 200).forEach { pct ->
                        FormatChip("$pct%", false) {
                            wText = (sel.w * pct / 100).coerceIn(8, 2048).toString()
                            hText = (sel.h * pct / 100).coerceIn(8, 2048).toString()
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        wText,
                        {
                            wText = it.filter(Char::isDigit).take(4)
                            val nw = wText.toIntOrNull()
                            if (lock && nw != null) hText = (nw * ratio).toInt().coerceAtLeast(1).toString()
                        },
                        label = { Text("Lebar px") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        hText,
                        {
                            hText = it.filter(Char::isDigit).take(4)
                            val nh = hText.toIntOrNull()
                            if (lock && nh != null) wText = (nh / ratio).toInt().coerceAtLeast(1).toString()
                        },
                        label = { Text("Tinggi px") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Kunci rasio aspek", fontSize = 13.sp)
                    Switch(lock, { lock = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                }
                if (error != null) Text(error, color = Palette.AccentPink, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(enabled = error == null, onClick = { onConfirm(w!!, h!!) }) { Text("Buat pola") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun ArtboardDialog(lowRam: Boolean, onDismiss: () -> Unit, onCreate: (Int, Int) -> Unit) {
    var wText by remember { mutableStateOf("2048") }
    var hText by remember { mutableStateOf("2048") }
    val w = wText.toIntOrNull()
    val h = hText.toIntOrNull()
    val error = when {
        w == null || h == null -> "Masukkan angka yang valid"
        w !in 512..16384 || h !in 512..16384 -> "Ukuran harus 512 – 16384 px"
        else -> null
    }
    val warning = when {
        error != null -> null
        lowRam && maxOf(w!!, h!!) > 8192 -> "RAM perangkat terbatas: hanya tile yang dilukis memakai memori; fill area sangat luas dibatasi. Gunakan Export PNG."
        w!!.toLong() * h!! > 8192L * 8192L -> "Artboard sangat besar. Tile kosong tidak memakai RAM."
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Artboard Resolution") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ArtboardPresets.forEach { (label, size) ->
                        FormatChip(label, w == size.first && h == size.second) { wText = size.first.toString(); hText = size.second.toString() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        wText, { wText = it.filter(Char::isDigit).take(5) }, label = { Text("Lebar px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        hText, { hText = it.filter(Char::isDigit).take(5) }, label = { Text("Tinggi px") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                }
                if (error != null) Text(error, color = Palette.AccentPink, fontSize = 12.sp)
                if (warning != null) Text(warning, color = Palette.TextMuted, fontSize = 11.sp)
                Text("Membuat artboard baru menggantikan kanvas saat ini. Simpan project dulu bila perlu.", color = Palette.TextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(enabled = error == null, onClick = { onCreate(w!!, h!!) }) { Text("Buat") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun ExportDialog(
    paperVisible: Boolean,
    onDismiss: () -> Unit,
    onOpenProject: () -> Unit,
    onExport: (fmt: Int, transparent: Boolean, high: Boolean) -> Unit,
) {
    var fmt by remember { mutableIntStateOf(0) }
    var transparent by remember { mutableStateOf(!paperVisible) }
    var high by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Export Studio") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FormatChip("PNG", fmt == 0) { fmt = 0 }
                    FormatChip("JPEG", fmt == 1) { fmt = 1 }
                    FormatChip("Project", fmt == 2) { fmt = 2 }
                    if (Build.VERSION.SDK_INT >= 30) FormatChip("WebP", fmt == 3) { fmt = 3 }
                }
                when (fmt) {
                    0 -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Background transparan", fontSize = 13.sp)
                            Switch(transparent, { transparent = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                        }
                        Text("Disimpan ke Pictures/DrawingApp. Kanvas besar di-stream langsung dari tile native (tanpa Bitmap raksasa).", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    1, 3 -> {
                        Text("KUALITAS", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FormatChip("Medium (85)", !high) { high = false }
                            FormatChip(if (fmt == 3) "High · Lossless" else "High · Maksimum (100)", high) { high = true }
                        }
                        if (fmt == 3) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Background transparan", fontSize = 13.sp)
                                Switch(transparent, { transparent = it }, colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple))
                            }
                        }
                        Text(
                            if (fmt == 3) "High = WebP lossless (identik piksel, tanpa artefak). Medium = lossy 85, file lebih kecil."
                            else "High = JPEG kualitas 100 (tetap lossy sebagai format). Untuk hasil identik piksel pakai PNG / WebP lossless.",
                            color = Palette.TextMuted, fontSize = 11.sp,
                        )
                        Text("Resolusi penuh sampai 45 MP selama memori perangkat cukup; selebihnya diperkecil otomatis. PNG selalu resolusi penuh.", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    else -> Text("Menyimpan semua tile (terkompresi) ke Download/DrawingApp sebagai .ldproj.", color = Palette.TextMuted, fontSize = 11.sp)
                }
                TextButton(onClick = onOpenProject) { Text("Buka project (.ldproj)…", color = Palette.AccentCyan) }
            }
        },
        confirmButton = { TextButton(onClick = { onExport(fmt, transparent, high) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private val PaperChoices = listOf(0xFFFFFFFF, 0xFFFFF8E7, 0xFFD9D9D9, 0xFF3A3A44, 0xFF18181C, 0xFF000000).map { it.toInt() }

@Composable
private fun LayersDialog(state: DrawState, onClear: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.PanelBg,
        titleContentColor = Color.White,
        textContentColor = Palette.TextPrimary,
        title = { Text("Layers") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.AccentPurple.copy(alpha = 0.12f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Drawing", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Sparse tile layer (aktif)", color = Palette.TextMuted, fontSize = 11.sp)
                    }
                    TextButton(onClick = onClear) { Text("Hapus semua", color = Palette.AccentPink) }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.DarkBg.copy(alpha = 0.5f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Paper", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Latar kanvas (dipakai export JPEG)", color = Palette.TextMuted, fontSize = 11.sp)
                        }
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { state.paperVisible = !state.paperVisible }, contentAlignment = Alignment.Center) {
                            Icon(DrawIcons.Eye, "Visible", tint = if (state.paperVisible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PaperChoices.forEach { c ->
                            Box(
                                Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                                    .border(if (c == state.paperColor) 2.dp else 1.dp, if (c == state.paperColor) Palette.AccentPurple else Color.White.copy(alpha = 0.25f), CircleShape)
                                    .clickable { state.paperColor = c; state.paperVisible = true }
                            )
                        }
                    }
                    Text("Paper tersembunyi = transparan (kotak-kotak).", color = Palette.TextMuted, fontSize = 11.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}
