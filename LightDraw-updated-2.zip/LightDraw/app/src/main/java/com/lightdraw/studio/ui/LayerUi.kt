package com.lightdraw.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lightdraw.studio.NativeEngine
import kotlin.math.roundToInt

/** What the layer UI needs from the screen: refresh after a native change, show a message. */
class LayerOps(val changed: () -> Unit, val toast: (String) -> Unit)

/** Blend mode ids shared with the engine (5 = eraser is brush-only and not listed). */
internal val BlendOptions = listOf(
    0 to "Normal", 1 to "Multiply", 2 to "Screen", 3 to "Overlay", 4 to "Add", 6 to "Darken", 7 to "Lighten",
    8 to "Difference", 9 to "Soft Light", 10 to "Hard Light", 11 to "Color Dodge", 12 to "Color Burn", 13 to "Exclusion",
)

internal fun blendName(id: Int) = BlendOptions.firstOrNull { it.first == id }?.second ?: "Normal"

/** Paper / cloth textures (ids shared with the engine; 0 = none). */
internal val SurfaceNames = listOf("Tidak ada", "Kertas halus", "Kertas kasar", "Kanvas kain", "Serat kertas")

private val PaperChoices = listOf(0xFFFFFFFF, 0xFFFFF8E7, 0xFFD9D9D9, 0xFF3A3A44, 0xFF18181C, 0xFF000000).map { it.toInt() }
private val LayerGreen = Color(0xFF22C55E)
private val LayerAmber = Color(0xFFF5A623)

private class LayerRow(val index: Int, val name: String, val visible: Boolean, val blend: Int)

private fun readLayers(): List<LayerRow> =
    List(NativeEngine.nativeLayerCount()) { LayerRow(it, NativeEngine.nativeLayerName(it), NativeEngine.nativeLayerVisible(it), NativeEngine.nativeLayerBlend(it)) }

@Composable
private fun LayerButton(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(tint.copy(alpha = 0.12f))
            .border(1.dp, Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp))
        Text(label, fontSize = 11.sp, color = Palette.TextPrimary)
    }
}

/** Layers dropdown: layer list + actions, blend & opacity of the active layer, paper colour and cloth texture. */
@Composable
internal fun LayersPopup(state: DrawState, ops: LayerOps, modifier: Modifier) {
    val rev = state.layerRev
    val rows = remember(rev) { readLayers() }
    val active = remember(rev) { NativeEngine.nativeActiveLayer() }
    val activeOpacity = remember(rev) { NativeEngine.nativeLayerOpacity(active) }
    val activeBlend = rows.getOrNull(active)?.blend ?: 0

    Popup("Layers", "${rows.size} layer", Palette.AccentPurple, modifier) {
        Section(state, "layers.list", "Layer", rows.getOrNull(active)?.name ?: "", defaultOpen = true) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in rows.indices.reversed()) {
                    val r = rows[i]
                    val isActive = r.index == active
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isActive) Palette.AccentPurple.copy(alpha = 0.16f) else Palette.DarkBg.copy(alpha = 0.5f))
                            .border(1.dp, if (isActive) Palette.AccentPurple else Palette.PanelBorder, RoundedCornerShape(12.dp))
                            .clickable { NativeEngine.nativeSetActiveLayer(r.index); ops.changed() }
                            .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(if (isActive) "Aktif · ${blendName(r.blend)}" else blendName(r.blend), color = Palette.TextMuted, fontSize = 11.sp)
                        }
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).clickable { NativeEngine.nativeSetLayerVisible(r.index, !r.visible); ops.changed() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(DrawIcons.Eye, "Visible", tint = if (r.visible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LayerButton(DrawIcons.Plus, "Tambah", Palette.AccentCyan, Modifier.weight(1f)) {
                    if (!NativeEngine.nativeAddLayer()) ops.toast("Maksimum 8 layer")
                    ops.changed()
                }
                LayerButton(DrawIcons.Copy, "Duplikat", Palette.AccentPurple, Modifier.weight(1f)) {
                    if (!NativeEngine.nativeDuplicateLayer()) ops.toast("Maksimum 8 layer")
                    ops.changed()
                }
                LayerButton(DrawIcons.Trash, "Hapus", Palette.AccentPink, Modifier.weight(1f)) {
                    if (!NativeEngine.nativeDeleteLayer()) ops.toast("Layer terakhir tidak bisa dihapus")
                    ops.changed()
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LayerButton(DrawIcons.ArrowUp, "Naik", LayerAmber, Modifier.weight(1f)) { NativeEngine.nativeMoveLayer(active, active + 1); ops.changed() }
                LayerButton(DrawIcons.ArrowDown, "Turun", LayerAmber, Modifier.weight(1f)) { NativeEngine.nativeMoveLayer(active, active - 1); ops.changed() }
                LayerButton(DrawIcons.Eraser, "Kosongkan", LayerAmber, Modifier.weight(1f)) { NativeEngine.nativeClear(); ops.changed() }
            }
        }

        Section(state, "layers.blend", "Blend & Opacity", "${blendName(activeBlend)} · ${(activeOpacity * 100).roundToInt()}%", defaultOpen = true) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                BlendOptions.forEach { (id, name) ->
                    Chip(name, activeBlend == id) { NativeEngine.nativeSetLayerBlend(active, id); ops.changed() }
                }
            }
            LabeledSlider("Opacity layer aktif", "${(activeOpacity * 100).roundToInt()}%", activeOpacity, 0f..1f) {
                NativeEngine.nativeSetLayerOpacity(active, it)
                ops.changed()
            }
            Hint("Blend dan opacity berlaku untuk layer aktif terhadap layer di bawahnya.")
        }

        Section(state, "layers.paper", "Kertas & Tekstur", SurfaceNames[state.surfaceKind.coerceIn(0, SurfaceNames.size - 1)], accent = Palette.AccentCyan) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Warna kertas", color = Palette.TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Box(Modifier.size(36.dp).clip(CircleShape).clickable { state.paperVisible = !state.paperVisible }, contentAlignment = Alignment.Center) {
                    Icon(DrawIcons.Eye, "Paper terlihat", tint = if (state.paperVisible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                PaperChoices.forEach { c ->
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                            .border(if (c == state.paperColor) 2.dp else 1.dp, if (c == state.paperColor) Palette.AccentPurple else Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { state.paperColor = c; state.paperVisible = true }
                    )
                }
            }
            Text("Tekstur permukaan", color = Palette.TextPrimary, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                SurfaceNames.forEachIndexed { i, n -> Chip(n, state.surfaceKind == i, Palette.AccentCyan) { state.surfaceKind = i } }
            }
            if (state.surfaceKind != 0) {
                LabeledSlider("Kekuatan", "${(state.surfaceStrength * 100).roundToInt()}%", state.surfaceStrength, 0f..1f, Palette.AccentCyan) { state.surfaceStrength = it }
                LabeledSlider("Skala butiran", "${state.surfaceScale}x", state.surfaceScale.toFloat(), 1f..8f, Palette.AccentCyan) { state.surfaceScale = it.roundToInt().coerceIn(1, 8) }
                SwitchRow("Sertakan di export", state.surfaceBake) { state.surfaceBake = it }
            }
            Hint(
                "Tekstur tidak merusak gambar: ia dilukis di atas kertas dan karya (lembah menggelap, puncak sedikit terang) dan bisa dimatikan kapan saja. " +
                    "Terlihat saat kanvas diperbesar; export PNG/JPEG memakai kertas buram saja (kertas transparan tidak diberi tekstur)."
            )
        }
    }
}

/** Bottom bar: replaces the old navigator. Layer chips (tap = select, tap the active one = open the Layers menu), add, hand. */
@Composable
fun LayerBar(state: DrawState, ops: LayerOps, modifier: Modifier = Modifier) {
    val rev = state.layerRev
    val rows = remember(rev) { readLayers() }
    val active = remember(rev) { NativeEngine.nativeActiveLayer() }
    FloatingPanel(modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            val open = state.panel == Panel.LAYERS
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Palette.AccentPurple.copy(alpha = if (open) 0.28f else 0.12f))
                    .border(1.dp, Palette.AccentPurple.copy(alpha = if (open) 0.9f else 0.35f), RoundedCornerShape(16.dp))
                    .clickable { state.togglePanel(Panel.LAYERS) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Layers, "Menu layer", tint = Palette.AccentPurple, modifier = Modifier.size(22.dp))
            }
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (i in rows.indices.reversed()) {
                    val r = rows[i]
                    val isActive = i == active
                    val shape = RoundedCornerShape(50)
                    Row(
                        Modifier
                            .clip(shape)
                            .background(if (isActive) Palette.AccentPurple.copy(alpha = 0.20f) else Palette.DarkBg.copy(alpha = 0.55f))
                            .border(1.dp, if (isActive) Palette.AccentPurple else Palette.PanelBorder, shape)
                            .clickable {
                                if (isActive) {
                                    state.togglePanel(Panel.LAYERS)
                                } else {
                                    NativeEngine.nativeSetActiveLayer(i)
                                    ops.changed()
                                }
                            }
                            .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            r.name, color = if (isActive) Color.White else Palette.TextPrimary, fontSize = 13.sp,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1,
                        )
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).clickable { NativeEngine.nativeSetLayerVisible(i, !r.visible); ops.changed() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(DrawIcons.Eye, "Visible", tint = if (r.visible) Palette.AccentCyan else Palette.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Palette.AccentCyan.copy(alpha = 0.12f))
                    .border(1.dp, Palette.AccentCyan.copy(alpha = 0.4f), CircleShape)
                    .clickable {
                        if (!NativeEngine.nativeAddLayer()) ops.toast("Maksimum 8 layer")
                        ops.changed()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Plus, "Tambah layer", tint = Palette.AccentCyan, modifier = Modifier.size(20.dp))
            }
            val handOn = state.tool == Tool.HAND
            val hShape = RoundedCornerShape(16.dp)
            Box(
                Modifier
                    .size(42.dp)
                    .clip(hShape)
                    .background(LayerGreen.copy(alpha = if (handOn) 0.28f else 0.12f))
                    .border(1.dp, LayerGreen.copy(alpha = if (handOn) 0.9f else 0.35f), hShape)
                    .clickable { state.toggleHand() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Hand, "Hand: geser kanvas", tint = LayerGreen, modifier = Modifier.size(22.dp))
            }
        }
    }
}
