//! Resumable scanline flood fill for 8K-16K canvases.  (NEW FILE: rust-engine/src/fill_job.rs)
//!
//! Why this replaces `pattern_fill::flood_fill` for big canvases:
//!  * paints while scanning -> no `spans` Vec, no second pass
//!  * works in slices (`step(budget)`), so the engine mutex is released between slices and the
//!    GL thread keeps rendering; Kotlin runs the loop off the UI thread and can cancel it
//!  * 3-row cache instead of one `get_pixel` (tile lookup + LRU bump) per pixel
//!  * custom pattern (kind 7) is an `Arc` snapshot, so no Mutex lock per pixel
//!  * abort / cancel => `canvas.cancel_edit()` restores everything (undo snapshots already exist)
use std::sync::Arc;

use crate::pattern_fill::{custom_snapshot, paint_px, CustomTile, Paint};
use crate::tiled_canvas::{TiledCanvas, TILE};

/// Pending (x, y) run starts. 8M * 8 B = 64 MB worst case (checkerboard-like images).
pub const MAX_STACK: usize = 8_000_000;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Step {
    Working,
    Done,
    TooLarge,
}

type Visited = Vec<Option<Box<[u64]>>>; // one 256x256 bitset (8 KB) per touched tile

#[inline]
fn loc(tiles_x: usize, x: u32, y: u32) -> (usize, usize, u64) {
    let t = ((y as usize) >> 8) * tiles_x + ((x as usize) >> 8);
    let bit = ((y as usize) & 255) * TILE + ((x as usize) & 255);
    (t, bit >> 6, 1u64 << (bit & 63))
}

#[inline]
fn is_visited(v: &Visited, tiles_x: usize, x: u32, y: u32) -> bool {
    let (t, w, m) = loc(tiles_x, x, y);
    matches!(&v[t], Some(b) if b[w] & m != 0)
}

fn mark_run(v: &mut Visited, tiles_x: usize, y: u32, x0: u32, x1: u32) {
    for x in x0..=x1 {
        let (t, w, m) = loc(tiles_x, x, y);
        let slot = &mut v[t];
        if slot.is_none() {
            *slot = Some(vec![0u64; TILE * TILE / 64].into_boxed_slice());
        }
        if let Some(b) = slot.as_mut() {
            b[w] |= m;
        }
    }
}

#[inline]
fn close(p: u32, t: u32, tol: i32) -> bool {
    let d = |s: u32| (((p >> s) & 255) as i32 - ((t >> s) & 255) as i32).abs();
    d(0).max(d(8)).max(d(16)).max(d(24)) <= tol
}

/// Alpha-aware membership. On an empty (transparent) target the region is every pixel that is not nearly opaque,
/// and the fill is drawn UNDER what is already there, so the soft, semi-transparent edge of a stroke keeps its
/// anti-aliasing and blends into the new colour instead of leaving a halo / outline.
#[inline]
fn member(p: u32, target: u32, tol: i32, amax: u32, under: bool) -> bool {
    if under {
        (p >> 24) <= amax
    } else {
        close(p, target, tol)
    }
}

/// `old` OVER `fill` (both premultiplied).
#[inline]
fn under_px(old: u32, fill: u32) -> u32 {
    let a = old >> 24;
    if a == 0 {
        return fill;
    }
    if a == 255 {
        return old;
    }
    let k = 255 - a;
    let ch = |s: u32| (((old >> s) & 255) + ((((fill >> s) & 255) * k + 127) / 255)).min(255) << s;
    ch(0) | ch(8) | ch(16) | ch(24)
}

pub struct FillJob {
    paint: Paint,
    custom: Option<Arc<CustomTile>>,
    target: u32,
    tol: i32,
    under: bool, // transparent target: alpha-aware, fill goes under existing pixels
    amax: u32,   // highest alpha still counted as part of the region
    w: u32,
    h: u32,
    tiles_x: usize,
    visited: Visited,
    stack: Vec<(u32, u32)>,
    cache: [(i64, Vec<u32>); 3],
    next: usize,
    painted: u64,
    fringe: Vec<(u32, u32, u32)>, // (x, y, original pixel) next to the region that were not matched
}

impl FillJob {
    /// Caller must have called `canvas.begin_edit()`. `None` = start point outside the canvas.
    pub fn new(canvas: &mut TiledCanvas, sx: i32, sy: i32, tol: i32, paint: Paint) -> Option<Self> {
        if sx < 0 || sy < 0 || sx >= canvas.width as i32 || sy >= canvas.height as i32 {
            return None;
        }
        let target = canvas.get_pixel(sx, sy);
        let total = canvas.tile_count();
        Some(FillJob {
            custom: if paint.kind == 7 { custom_snapshot() } else { None },
            paint,
            target,
            tol: tol.clamp(0, 255),
            under: target >> 24 == 0,
            amax: (96 + tol.clamp(0, 255) as u32 * 3).min(250),
            w: canvas.width,
            h: canvas.height,
            tiles_x: canvas.tiles_x,
            visited: (0..total).map(|_| None).collect(),
            stack: vec![(sx as u32, sy as u32)],
            cache: [(-1, Vec::new()), (-1, Vec::new()), (-1, Vec::new())],
            next: 0,
            painted: 0,
            fringe: Vec::new(),
        })
    }

    pub fn painted(&self) -> u64 {
        self.painted
    }

    fn row_slot(&mut self, canvas: &mut TiledCanvas, y: u32) -> usize {
        for i in 0..3 {
            if self.cache[i].0 == y as i64 {
                return i;
            }
        }
        let i = self.next;
        self.next = (self.next + 1) % 3;
        let w = self.w as usize;
        self.cache[i].1.resize(w, 0);
        canvas.read_row(y, 0, &mut self.cache[i].1);
        self.cache[i].0 = y as i64;
        i
    }

    fn paint_run(&mut self, canvas: &mut TiledCanvas, y: u32, x0: u32, x1: u32) {
        let ly = (y as usize) & 255;
        let mut x = x0;
        while x <= x1 {
            let tx = (x as usize) >> 8;
            let seg_end = x1.min(((tx + 1) * TILE - 1) as u32);
            let idx = ((y as usize) >> 8) * self.tiles_x + tx;
            let px = canvas.tile_mut(idx);
            for xx in x..=seg_end {
                let i = ly * TILE + ((xx as usize) & 255);
                let f = paint_px(&self.paint, self.custom.as_deref(), xx, y);
                px[i] = if self.under { under_px(px[i], f) } else { f };
            }
            self.painted += (seg_end - x + 1) as u64;
            x = seg_end + 1;
        }
    }

    /// Anti-aliased edge pixel next to the filled region: draw the fill *underneath* it (existing OVER fill)
    /// instead of leaving a pale gap. Fully transparent and fully opaque pixels are left alone.
    fn under_fill(&mut self, canvas: &mut TiledCanvas, orig: u32, x: u32, y: u32) {
        let a = orig >> 24;
        if a == 0 || a == 255 || is_visited(&self.visited, self.tiles_x, x, y) {
            return;
        }
        mark_run(&mut self.visited, self.tiles_x, y, x, x); // composite each edge pixel only once
        let f = paint_px(&self.paint, self.custom.as_deref(), x, y);
        let k = 255 - a;
        let ch = |s: u32| (((orig >> s) & 255) + ((((f >> s) & 255) * k + 127) / 255)).min(255);
        let v = ch(0) | (ch(8) << 8) | (ch(16) << 16) | (ch(24) << 24);
        let idx = ((y as usize) >> 8) * self.tiles_x + ((x as usize) >> 8);
        canvas.tile_mut(idx)[((y as usize) & 255) * TILE + ((x as usize) & 255)] = v;
    }

    /// Paint until roughly `budget_px` pixels were written in this call (or the fill is finished).
    pub fn step(&mut self, canvas: &mut TiledCanvas, budget_px: u64) -> Step {
        for c in self.cache.iter_mut() {
            c.0 = -1; // the canvas may have been read/rendered between slices
        }
        let start = self.painted;
        let (tiles_x, target, tol, w, h) = (self.tiles_x, self.target, self.tol, self.w, self.h);
        let (under, amax) = (self.under, self.amax);
        while let Some((x, y)) = self.stack.pop() {
            let s = self.row_slot(canvas, y);
            if is_visited(&self.visited, tiles_x, x, y) || !member(self.cache[s].1[x as usize], target, tol, amax, under) {
                continue;
            }
            let (mut xl, mut xr) = (x, x);
            {
                let row = &self.cache[s].1;
                while xl > 0 && !is_visited(&self.visited, tiles_x, xl - 1, y) && member(row[(xl - 1) as usize], target, tol, amax, under) {
                    xl -= 1;
                }
                while xr + 1 < w && !is_visited(&self.visited, tiles_x, xr + 1, y) && member(row[(xr + 1) as usize], target, tol, amax, under) {
                    xr += 1;
                }
            }
            mark_run(&mut self.visited, tiles_x, y, xl, xr);
            self.paint_run(canvas, y, xl, xr);
            // left / right neighbours of the run that stopped it (edge pixels of lines and shapes)
            if xl > 0 && !is_visited(&self.visited, tiles_x, xl - 1, y) {
                let o = self.cache[s].1[(xl - 1) as usize];
                self.fringe.push((xl - 1, y, o));
            }
            if xr + 1 < w && !is_visited(&self.visited, tiles_x, xr + 1, y) {
                let o = self.cache[s].1[(xr + 1) as usize];
                self.fringe.push((xr + 1, y, o));
            }

            for ny in [y as i64 - 1, y as i64 + 1] {
                if ny < 0 || ny >= h as i64 {
                    continue;
                }
                let ns = self.row_slot(canvas, ny as u32);
                let row = &self.cache[ns].1;
                let mut in_run = false;
                let lo = xl.saturating_sub(1); // one extra pixel each side catches diagonal edge pixels
                let hi = (xr + 1).min(w - 1);
                for xx in lo..=hi {
                    let vis = is_visited(&self.visited, tiles_x, xx, ny as u32);
                    let p = row[xx as usize];
                    let ok = !vis && member(p, target, tol, amax, under);
                    if xx >= xl && xx <= xr {
                        if ok && !in_run {
                            self.stack.push((xx, ny as u32));
                            in_run = true;
                        } else if !ok {
                            in_run = false;
                        }
                    }
                    if !vis && !ok {
                        self.fringe.push((xx, ny as u32, p));
                    }
                }
            }
            while let Some((fx, fy, o)) = self.fringe.pop() {
                self.under_fill(canvas, o, fx, fy);
            }
            if self.stack.len() > MAX_STACK {
                return Step::TooLarge;
            }
            if self.painted - start >= budget_px {
                return Step::Working;
            }
        }
        Step::Done
    }
}
