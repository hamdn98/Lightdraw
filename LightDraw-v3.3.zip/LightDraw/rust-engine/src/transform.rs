//! Commit step of the live transform handles. (NEW FILE: rust-engine/src/transform.rs)
//! Kotlin shows handles + a preview; when the finger lifts it sends ONE affine matrix:
//!   x' = a*x + b*y + tx ,  y' = c*x + d*y + ty    (canvas pixel coordinates, source = selection rect)
//! The rect is lifted (<= 4096x4096), cleared, and re-drawn with bilinear sampling over transparent
//! borders, which gives anti-aliased edges. One undo step (caller wraps begin_edit/end_edit).
use crate::fx_engine::MAX_BUFFER_PIXELS;
use crate::tiled_canvas::{TiledCanvas, TILE};

#[inline]
fn over(dst: u32, src: u32) -> u32 {
    let sa = src >> 24;
    if sa == 255 {
        return src;
    }
    let k = 255 - sa;
    let f = |s: u32| (((src >> s) & 255) + (((dst >> s) & 255) * k + 127) / 255).min(255) << s;
    f(0) | f(8) | f(16) | f(24)
}

/// m = [a, b, tx, c, d, ty]. Returns 0 ok, 1 empty/singular, 2 too large.
pub fn transform_region(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32, m: [f32; 6]) -> i32 {
    let (cw, ch) = (canvas.width as i32, canvas.height as i32);
    let (rx0, ry0) = (x0.min(x1).max(0), y0.min(y1).max(0));
    let (rx1, ry1) = (x0.max(x1).min(cw - 1), y0.max(y1).min(ch - 1));
    if rx0 > rx1 || ry0 > ry1 {
        return 1;
    }
    let (w, h) = ((rx1 - rx0 + 1) as usize, (ry1 - ry0 + 1) as usize);
    if w * h > MAX_BUFFER_PIXELS {
        return 2;
    }
    let [a, b, tx, c, d, ty] = m;
    let det = a * d - b * c;
    if det.abs() < 1e-6 {
        return 1;
    }
    let (ia, ib, ic, id) = (d / det, -b / det, -c / det, a / det);

    // lift
    let mut src = vec![0u32; w * h];
    for y in 0..h {
        canvas.read_row((ry0 as usize + y) as u32, rx0 as u32, &mut src[y * w..(y + 1) * w]);
    }
    // clear the source rectangle
    let tiles_x = canvas.tiles_x;
    for ty_i in (ry0 as usize >> 8)..=(ry1 as usize >> 8) {
        for tx_i in (rx0 as usize >> 8)..=(rx1 as usize >> 8) {
            let idx = ty_i * tiles_x + tx_i;
            if !canvas.exists(idx) {
                continue;
            }
            let px = canvas.tile_mut(idx);
            for y in (ry0 as usize).max(ty_i * TILE)..=(ry1 as usize).min(ty_i * TILE + TILE - 1) {
                for x in (rx0 as usize).max(tx_i * TILE)..=(rx1 as usize).min(tx_i * TILE + TILE - 1) {
                    px[(y & 255) * TILE + (x & 255)] = 0;
                }
            }
        }
    }
    // destination bounding box = transformed rect corners
    let corners = [(rx0 as f32, ry0 as f32), ((rx1 + 1) as f32, ry0 as f32), (rx0 as f32, (ry1 + 1) as f32), ((rx1 + 1) as f32, (ry1 + 1) as f32)];
    let (mut bx0, mut by0, mut bx1, mut by1) = (f32::MAX, f32::MAX, f32::MIN, f32::MIN);
    for (px, py) in corners {
        let (X, Y) = (a * px + b * py + tx, c * px + d * py + ty);
        bx0 = bx0.min(X);
        by0 = by0.min(Y);
        bx1 = bx1.max(X);
        by1 = by1.max(Y);
    }
    let (bx0, by0) = ((bx0.floor() as i32 - 1).max(0), (by0.floor() as i32 - 1).max(0));
    let (bx1, by1) = ((bx1.ceil() as i32 + 1).min(cw - 1), (by1.ceil() as i32 + 1).min(ch - 1));
    if bx0 > bx1 || by0 > by1 {
        return 0;
    }
    let at = |ix: i32, iy: i32| -> [f32; 4] {
        if ix < 0 || iy < 0 || ix >= w as i32 || iy >= h as i32 {
            return [0.0; 4];
        }
        let p = src[iy as usize * w + ix as usize];
        [(p & 255) as f32, ((p >> 8) & 255) as f32, ((p >> 16) & 255) as f32, (p >> 24) as f32]
    };
    let mut scratch = vec![0u32; TILE * TILE];
    for ty_i in (by0 as usize >> 8)..=(by1 as usize >> 8) {
        for tx_i in (bx0 as usize >> 8)..=(bx1 as usize >> 8) {
            let (tx0, ty0) = (tx_i * TILE, ty_i * TILE);
            let (xa, xb) = ((bx0 as usize).max(tx0), (bx1 as usize).min(tx0 + TILE - 1));
            let (ya, yb) = ((by0 as usize).max(ty0), (by1 as usize).min(ty0 + TILE - 1));
            scratch.fill(0);
            let mut any = false;
            for Y in ya..=yb {
                for X in xa..=xb {
                    let (fx, fy) = (X as f32 + 0.5 - tx, Y as f32 + 0.5 - ty);
                    let u = ia * fx + ib * fy - rx0 as f32 - 0.5;
                    let v = ic * fx + id * fy - ry0 as f32 - 0.5;
                    let (iu, iv) = (u.floor(), v.floor());
                    let (tu, tv) = (u - iu, v - iv);
                    let (iu, iv) = (iu as i32, iv as i32);
                    let (p00, p10, p01, p11) = (at(iu, iv), at(iu + 1, iv), at(iu, iv + 1), at(iu + 1, iv + 1));
                    let mut o = [0u32; 4];
                    for k in 0..4 {
                        let top = p00[k] + (p10[k] - p00[k]) * tu;
                        let bot = p01[k] + (p11[k] - p01[k]) * tu;
                        o[k] = (top + (bot - top) * tv + 0.5).clamp(0.0, 255.0) as u32;
                    }
                    if o[3] > 0 {
                        any = true;
                        scratch[(Y - ty0) * TILE + (X - tx0)] = o[0].min(o[3]) | (o[1].min(o[3]) << 8) | (o[2].min(o[3]) << 16) | (o[3] << 24);
                    }
                }
            }
            if any {
                let px = canvas.tile_mut(ty_i * tiles_x + tx_i);
                for Y in ya..=yb {
                    for X in xa..=xb {
                        let s = scratch[(Y - ty0) * TILE + (X - tx0)];
                        if s != 0 {
                            let i = (Y - ty0) * TILE + (X - tx0);
                            px[i] = over(px[i], s);
                        }
                    }
                }
            }
        }
    }
    0
}
