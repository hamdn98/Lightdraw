//! JNI bindings (Kotlin class `com.lightdraw.studio.NativeEngine`) and global engine state.
#![allow(non_snake_case)]

use std::ffi::c_void;
use std::fs;
use std::fs::File;
use std::io::{BufReader, BufWriter, Write};
use std::os::unix::io::FromRawFd;
use std::path::PathBuf;
use std::sync::Mutex;

use jni::objects::{JByteBuffer, JIntArray, JObject, JString};
use jni::sys::{jboolean, jfloat, jint, jlong, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

use crate::brush_engine::{over, Blend, Brush, StrokeState};
use crate::color_engine::{replace_same_color, HslTolerance};
use crate::fx_engine::{self, ShapeSpec};
use crate::export_stream;
use crate::fill_job::{self, FillJob};
use crate::layers::{self, Stack};
use crate::pattern_fill::{flood_fill, resize_custom, set_custom_pattern, FillResult, Paint};
use crate::transform;
use crate::wrap_stream;
use crate::stabilizer::Stabilizer;
use crate::symmetry::Symmetry;
use crate::tiled_canvas::{pack_rgba, premul, unpremul, TiledCanvas, TILE, TILE_PIXELS};

// ---------------------------------------------------------------- Android bitmap FFI

#[repr(C)]
struct AndroidBitmapInfo {
    width: u32,
    height: u32,
    stride: u32,
    format: i32,
    flags: u32,
}

#[cfg_attr(target_os = "android", link(name = "jnigraphics"))]
extern "C" {
    fn AndroidBitmap_getInfo(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject, info: *mut AndroidBitmapInfo) -> i32;
    fn AndroidBitmap_lockPixels(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject, addr: *mut *mut c_void) -> i32;
    fn AndroidBitmap_unlockPixels(env: *mut jni::sys::JNIEnv, bitmap: jni::sys::jobject) -> i32;
}

const BITMAP_FORMAT_RGBA_8888: i32 = 1;

// ---------------------------------------------------------------- engine state

struct Engine {
    canvas: TiledCanvas,
    brush: Brush,
    stab: Stabilizer,
    sym: Symmetry,
    stroke: StrokeState,
    drawing: bool,
    shape_open: bool, // a shape preview edit is open (cancelled / redrawn while dragging)
    last_p: f32,
    bg: u32, // straight RGBA, alpha 0 = transparent paper
    stack: Stack, // layers: `canvas` above is always the active layer
    fill_job: Option<FillJob>, // resumable flood fill in progress (see nativeFillBegin / Step)
}

impl Engine {
    fn from_canvas(canvas: TiledCanvas, bg: u32) -> Self {
        let stack = Stack::new(canvas.max_resident);
        let sym = Symmetry::new(canvas.width, canvas.height);
        Engine {
            canvas,
            brush: Brush::new(),
            stab: Stabilizer::new(),
            sym,
            stroke: StrokeState::new(),
            drawing: false,
            shape_open: false,
            last_p: 1.0,
            bg,
            fill_job: None,
            stack,
        }
    }
}

static ENGINE: Mutex<Option<Engine>> = Mutex::new(None);

/// Canvas to read for render / export / save: the active layer itself when it is the only visible layer,
/// otherwise a temporary flattened copy (removed again when dropped).
fn with_flat<R>(e: &mut Engine, f: impl FnOnce(&mut TiledCanvas) -> R) -> R {
    if e.stack.is_trivial() {
        return f(&mut e.canvas);
    }
    let mut flat = layers::flatten(&mut e.canvas, &mut e.stack);
    f(&mut flat)
}

/// Turns a Rust panic into an error value instead of killing the whole app (release uses panic = "unwind").
fn guard<R>(default: R, f: impl FnOnce() -> R + std::panic::UnwindSafe) -> R {
    std::panic::catch_unwind(f).unwrap_or(default)
}

fn with_engine<R, F: FnOnce(&mut Engine) -> R>(default: R, f: F) -> R {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    match g.as_mut() {
        Some(e) => f(e),
        None => default,
    }
}

fn replace_engine(new_engine: Engine) {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(old) = g.take() {
        old.canvas.cleanup();
    }
    *g = Some(new_engine);
}

fn argb_to_px(c: i32) -> u32 {
    let c = c as u32;
    pack_rgba(((c >> 16) & 255) as u8, ((c >> 8) & 255) as u8, (c & 255) as u8, (c >> 24) as u8)
}

fn px_to_argb(p: u32) -> i32 {
    let (r, g, b, a) = (p & 255, (p >> 8) & 255, (p >> 16) & 255, p >> 24);
    ((a << 24) | (r << 16) | (g << 8) | b) as i32
}

/// Premultiplied canvas pixel composited over the paper colour (straight RGBA).
fn composite_over_bg(src: u32, bg: u32) -> u32 {
    if bg >> 24 == 0 {
        src
    } else {
        over(premul(bg), src)
    }
}

// ---------------------------------------------------------------- init / info

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeInit(
    mut env: JNIEnv,
    _this: JObject,
    w: jint,
    h: jint,
    dir: JString,
    max_resident: jint,
) -> jboolean {
    let dir: String = match env.get_string(&dir) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let first = ENGINE.lock().unwrap_or_else(|e| e.into_inner()).is_none();
    if first {
        let _ = fs::remove_dir_all(&dir); // stale spill files from a previous process
    }
    let canvas = TiledCanvas::new(w.max(0) as u32, h.max(0) as u32, PathBuf::from(dir), max_resident.max(64) as usize);
    replace_engine(Engine::from_canvas(canvas, 0xFFFF_FFFF));
    JNI_TRUE
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCanvasWidth(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.canvas.width as jint)
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCanvasHeight(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.canvas.height as jint)
}

// ---------------------------------------------------------------- GPU feed

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeVisibleTiles(
    mut env: JNIEnv,
    _this: JObject,
    tx0: jint,
    ty0: jint,
    tx1: jint,
    ty1: jint,
    idx: JIntArray,
    ver: JIntArray,
) -> jint {
    let mut ib = [0i32; 4096];
    let mut vb = [0i32; 4096];
    let n = with_engine(0usize, |e| {
        layers::set_viewport_all(&mut e.canvas, &mut e.stack, tx0, ty0, tx1, ty1);
        layers::visible_tiles(&mut e.canvas, &mut e.stack, tx0, ty0, tx1, ty1, &mut ib, &mut vb)
    });
    if n > 0 {
        let _ = env.set_int_array_region(&idx, 0, &ib[..n]);
        let _ = env.set_int_array_region(&ver, 0, &vb[..n]);
    }
    n as jint
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeCopyTile(
    mut env: JNIEnv,
    _this: JObject,
    idx: jint,
    buf: JByteBuffer,
) -> jboolean {
    let ptr = match env.get_direct_buffer_address(&buf) {
        Ok(p) => p,
        Err(_) => return JNI_FALSE,
    };
    let cap = env.get_direct_buffer_capacity(&buf).unwrap_or(0);
    if ptr.is_null() || cap < TILE_PIXELS * 4 || idx < 0 {
        return JNI_FALSE;
    }
    let dst = unsafe { std::slice::from_raw_parts_mut(ptr, TILE_PIXELS * 4) };
    let ok = with_engine(false, |e| {
        let i = idx as usize;
        if i >= e.canvas.tile_count() {
            return false;
        }
        if e.stack.is_trivial() {
            return e.canvas.copy_tile_bytes(i, dst);
        }
        let mut buf = vec![0u32; TILE_PIXELS];
        if !layers::composite_tile(&mut e.canvas, &mut e.stack, i, &mut buf) {
            return false;
        }
        for (chunk, p) in dst.chunks_exact_mut(4).zip(buf.iter()) {
            chunk.copy_from_slice(&p.to_le_bytes());
        }
        true
    });
    if ok {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

// ---------------------------------------------------------------- settings

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetBrush(
    _env: JNIEnv,
    _this: JObject,
    preset: jint,
    size: jfloat,
    opacity: jfloat,
    color: jint,
    blend: jint,
) {
    with_engine((), |e| {
        e.brush.set_preset(preset);
        e.brush.size = size.clamp(1.0, 512.0);
        e.brush.opacity = opacity.clamp(0.0, 1.0);
        e.brush.color = argb_to_px(color);
        e.brush.blend = Blend::from_i32(blend);
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetStabilizer(_env: JNIEnv, _this: JObject, strength: jfloat) {
    with_engine((), |e| e.stab.set_strength(strength));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetSymmetry(
    _env: JNIEnv,
    _this: JObject,
    mode: jint,
    sectors: jint,
    mirror: jboolean,
) {
    with_engine((), |e| e.sym.configure(mode, sectors, mirror != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetBg(_env: JNIEnv, _this: JObject, argb: jint) {
    with_engine((), |e| e.bg = argb_to_px(argb));
}

// ---------------------------------------------------------------- strokes

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeBegin(
    _env: JNIEnv,
    _this: JObject,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    t: jlong,
) {
    with_engine((), |e| {
        e.canvas.begin_edit();
        e.stab.begin(x, y, t);
        e.stroke.begin();
        e.drawing = true;
        e.last_p = p;
        e.stroke.add_point(&mut e.canvas, &e.brush, &e.sym, x, y, p);
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeMove(
    _env: JNIEnv,
    _this: JObject,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    t: jlong,
) {
    with_engine((), |e| {
        if !e.drawing {
            return;
        }
        let (sx, sy) = e.stab.feed(x, y, t);
        e.last_p = p;
        e.stroke.add_point(&mut e.canvas, &e.brush, &e.sym, sx, sy, p);
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeEnd(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| {
        if !e.drawing {
            return;
        }
        let mut n = 0;
        while n < 120 {
            match e.stab.flush_step() {
                Some((x, y)) => {
                    let p = e.last_p;
                    e.stroke.add_point(&mut e.canvas, &e.brush, &e.sym, x, y, p);
                }
                None => break,
            }
            n += 1;
        }
        e.stroke.finish(&mut e.canvas, &e.brush, &e.sym);
        e.canvas.end_edit();
        e.drawing = false;
    });
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeStrokeCancel(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| {
        if e.drawing {
            e.canvas.cancel_edit();
            e.drawing = false;
        }
    });
}

// ---------------------------------------------------------------- FX / transform / object tools

/// op 0 invert, 1 grayscale, 2 brightness(a) + contrast(b), 3 hue shift(a, deg) + saturation(b). Returns tiles touched.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeApplyFx(
    _env: JNIEnv,
    _this: JObject,
    op: jint,
    a: jfloat,
    b: jfloat,
) -> jint {
    with_engine(-1, |e| {
        e.canvas.begin_edit();
        let n = fx_engine::apply_fx(&mut e.canvas, op, a, b);
        e.canvas.end_edit();
        n as jint
    })
}

/// Wrap-around offset of the whole drawing. 0 ok, 2 canvas too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeOffsetWrap(_env: JNIEnv, _this: JObject, dx: jint, dy: jint) -> jint {
    guard(-1, || {
        with_engine(-1, |e| {
            e.canvas.begin_edit();
            let tmp = e.canvas.spill_dir().join("wrap");
            let r = wrap_stream::offset_wrap_streamed(&mut e.canvas, dx, dy, &tmp);
            if r == 0 {
                e.canvas.end_edit();
            } else {
                e.canvas.cancel_edit();
            }
            r
        })
    })
}

/// Move / duplicate a rectangle (optionally wrapping across canvas edges). 0 ok, 1 empty, 2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeMoveRegion(
    _env: JNIEnv,
    _this: JObject,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
    dx: jint,
    dy: jint,
    copy: jboolean,
    wrap: jboolean,
) -> jint {
    with_engine(-1, |e| {
        e.canvas.begin_edit();
        let r = fx_engine::move_region(&mut e.canvas, x0, y0, x1, y1, dx, dy, copy != 0, wrap != 0);
        e.canvas.end_edit();
        r
    })
}

/// Align the object inside the rectangle to the canvas. Returns (dx shl 32) | (dy & 0xFFFFFFFF), or i64::MIN when empty.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeAlignRegion(
    _env: JNIEnv,
    _this: JObject,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
    mode: jint,
) -> jlong {
    with_engine(i64::MIN, |e| {
        e.canvas.begin_edit();
        let r = fx_engine::align_region(&mut e.canvas, x0, y0, x1, y1, mode);
        e.canvas.end_edit();
        match r {
            Some((dx, dy)) => ((dx as i64) << 32) | (dy as u32 as i64),
            None => i64::MIN,
        }
    })
}

/// Turn the pixels inside the rectangle into the custom pattern (kind 7). Returns (w shl 16) | h, or -1 empty / -2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSetPatternFromRegion(
    _env: JNIEnv,
    _this: JObject,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
) -> jint {
    with_engine(-1, |e| match fx_engine::region_to_tile(&mut e.canvas, x0, y0, x1, y1) {
        Ok((w, h, px)) => {
            set_custom_pattern(w, h, px);
            ((w << 16) | h) as jint
        }
        Err(1) => -1,
        Err(_) => -2,
    })
}

/// Draw (or preview) an anti-aliased shape. `commit = false` keeps the edit open and the next call replaces it.
/// flags: bit0 filled, bit1 stroked. kind: 0 rect, 1 rounded rect, 2 ellipse, 3 triangle, 4 line, 5 diamond.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeShape(
    _env: JNIEnv,
    _this: JObject,
    kind: jint,
    x0: jfloat,
    y0: jfloat,
    x1: jfloat,
    y1: jfloat,
    fill: jint,
    stroke: jint,
    flags: jint,
    sw: jfloat,
    commit: jboolean,
) -> jint {
    with_engine(-1, |e| {
        if e.shape_open {
            e.canvas.cancel_edit();
            e.shape_open = false;
        }
        e.canvas.begin_edit();
        let spec = ShapeSpec {
            kind,
            x0,
            y0,
            x1,
            y1,
            fill: argb_to_px(fill),
            stroke: argb_to_px(stroke),
            filled: flags & 1 != 0,
            stroked: flags & 2 != 0,
            sw: sw.max(1.0),
        };
        fx_engine::draw_shape(&mut e.canvas, &spec);
        if commit != 0 {
            e.canvas.end_edit();
        } else {
            e.shape_open = true;
        }
        0
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeShapeCancel(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| {
        if e.shape_open {
            e.canvas.cancel_edit();
            e.shape_open = false;
        }
    });
}

// ---------------------------------------------------------------- fill / colour tools

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFill(
    _env: JNIEnv,
    _this: JObject,
    x: jint,
    y: jint,
    kind: jint,
    color: jint,
    color2: jint,
    scale: jfloat,
    tol: jint,
) -> jint {
    with_engine(-1, |e| {
        let paint = Paint {
            kind: kind.clamp(0, 255) as u8,
            c1: argb_to_px(color),
            c2: argb_to_px(color2),
            scale: scale.max(0.1),
        };
        e.canvas.begin_edit();
        let r = flood_fill(&mut e.canvas, x, y, tol, &paint);
        e.canvas.end_edit();
        match r {
            FillResult::Painted(_) => 0,
            FillResult::OutOfBounds => 1,
            FillResult::TooLarge => 2,
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSelectReplace(
    _env: JNIEnv,
    _this: JObject,
    x: jint,
    y: jint,
    new_color: jint,
    tol_h: jfloat,
    tol_s: jfloat,
    tol_l: jfloat,
) -> jint {
    with_engine(-1, |e| {
        let target = e.canvas.get_pixel(x, y);
        let tol = HslTolerance { hue_deg: tol_h.clamp(0.0, 180.0), sat: tol_s.clamp(0.0, 1.0), lum: tol_l.clamp(0.0, 1.0) };
        e.canvas.begin_edit();
        let n = replace_same_color(&mut e.canvas, target, argb_to_px(new_color), tol);
        e.canvas.end_edit();
        n.min(i32::MAX as u32) as jint
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativePickColor(_env: JNIEnv, _this: JObject, x: jint, y: jint) -> jint {
    with_engine(0, |e| {
        let p = if e.stack.is_trivial() { e.canvas.get_pixel(x, y) } else { layers::composite_pixel(&mut e.canvas, &mut e.stack, x, y) };
        let bg = if e.bg >> 24 == 0 { 0xFFFF_FFFF } else { e.bg };
        px_to_argb(unpremul(composite_over_bg(p, bg)))
    })
}

// ---------------------------------------------------------------- history

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeUndo(_env: JNIEnv, _this: JObject) -> jboolean {
    if with_engine(false, |e| e.canvas.undo()) {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeRedo(_env: JNIEnv, _this: JObject) -> jboolean {
    if with_engine(false, |e| e.canvas.redo()) {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

/// bit0 = can undo, bit1 = can redo
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeHistoryState(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| (e.canvas.can_undo() as jint) | ((e.canvas.can_redo() as jint) << 1))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeClear(_env: JNIEnv, _this: JObject) {
    with_engine((), |e| e.canvas.clear_all());
}

// ---------------------------------------------------------------- export / import

unsafe fn render_scaled(canvas: &mut TiledCanvas, base: *mut u8, dw: usize, dh: usize, stride: usize, bg: u32) -> i32 {
    let cw = canvas.width as usize;
    let ch = canvas.height as usize;
    if dw == 0 || dh == 0 {
        return 5;
    }
    let mut scratch = vec![0u32; cw];
    for y in 0..dh {
        let sy = (y * ch / dh).min(ch - 1);
        canvas.read_row(sy as u32, 0, &mut scratch);
        let row = std::slice::from_raw_parts_mut(base.add(y * stride) as *mut u32, dw);
        if dw == cw {
            for x in 0..dw {
                row[x] = composite_over_bg(scratch[x], bg);
            }
        } else {
            for x in 0..dw {
                let sx = (x * cw / dw).min(cw - 1);
                row[x] = composite_over_bg(scratch[sx], bg);
            }
        }
    }
    0
}

/// Render the whole canvas, scaled (nearest) to the bitmap size, over the given paper colour.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeRenderToBitmap(
    env: JNIEnv,
    _this: JObject,
    bitmap: JObject,
    bg: jint,
) -> jint {
    let raw_env = env.get_raw();
    let bmp = bitmap.as_raw();
    let mut info = AndroidBitmapInfo { width: 0, height: 0, stride: 0, format: 0, flags: 0 };
    unsafe {
        if AndroidBitmap_getInfo(raw_env, bmp, &mut info) != 0 {
            return 1;
        }
        if info.format != BITMAP_FORMAT_RGBA_8888 {
            return 2;
        }
        let mut addr: *mut c_void = std::ptr::null_mut();
        if AndroidBitmap_lockPixels(raw_env, bmp, &mut addr) != 0 || addr.is_null() {
            return 3;
        }
        let bgp = argb_to_px(bg);
        let r = with_engine(4, |e| {
            with_flat(e, |c| render_scaled(c, addr as *mut u8, info.width as usize, info.height as usize, info.stride as usize, bgp))
        });
        AndroidBitmap_unlockPixels(raw_env, bmp);
        r
    }
}

fn export_png(canvas: &mut TiledCanvas, fd: i32, bg: u32, maximum: bool) -> Result<(), String> {
    let file = unsafe { File::from_raw_fd(fd) };
    let out = BufWriter::with_capacity(1 << 20, file);
    let (cw, ch) = (canvas.width as usize, canvas.height as usize);
    let transparent = bg >> 24 == 0;
    let mut enc = png::Encoder::new(out, cw as u32, ch as u32);
    enc.set_color(if transparent { png::ColorType::Rgba } else { png::ColorType::Rgb });
    enc.set_depth(png::BitDepth::Eight);
    enc.set_compression(if maximum { png::Compression::Best } else { png::Compression::Fast });
    let mut writer = enc.write_header().map_err(|e| e.to_string())?;
    {
        let mut stream = writer.stream_writer().map_err(|e| e.to_string())?;
        let mut row = vec![0u32; cw];
        let mut bytes: Vec<u8> = Vec::with_capacity(cw * 4);
        for y in 0..ch {
            canvas.read_row(y as u32, 0, &mut row);
            bytes.clear();
            for &p in row.iter() {
                if transparent {
                    let s = unpremul(p);
                    bytes.extend_from_slice(&[(s & 255) as u8, ((s >> 8) & 255) as u8, ((s >> 16) & 255) as u8, (s >> 24) as u8]);
                } else {
                    let c = composite_over_bg(p, bg);
                    bytes.extend_from_slice(&[(c & 255) as u8, ((c >> 8) & 255) as u8, ((c >> 16) & 255) as u8]);
                }
            }
            stream.write_all(&bytes).map_err(|e| e.to_string())?;
        }
        // dropping the stream finalises the IDAT stream; dropping the writer finishes the file
    }
    drop(writer);
    Ok(())
}

/// Streaming PNG export (row by row) - safe for 16K canvases. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeExportPng(_env: JNIEnv, _this: JObject, fd: jint, bg: jint, maximum: jint) -> jint {
    let bgp = argb_to_px(bg);
    guard(-1, || {
        with_engine(-1, |e| {
            with_flat(e, |c| match export_png(c, fd, bgp, maximum != 0) {
                Ok(()) => 0,
                Err(_) => 1,
            })
        })
    })
}

/// Streaming JPEG export, down-scaled to at most `max_px` pixels. Returns (w << 32) | h, or -1. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeExportJpeg(_env: JNIEnv, _this: JObject, fd: jint, bg: jint, maximum: jint, max_px: jlong) -> jlong {
    let bgp = argb_to_px(bg);
    guard(-1, || {
        with_engine(-1, |e| {
            with_flat(e, |c| match export_stream::export_jpeg(c, fd, bgp, maximum != 0, max_px.max(1) as u64) {
                Ok((w, h)) => ((w as i64) << 32) | h as i64,
                Err(_) => -1,
            })
        })
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeSaveProject(_env: JNIEnv, _this: JObject, fd: jint) -> jint {
    with_engine(-1, |e| {
        let file = unsafe { File::from_raw_fd(fd) };
        let mut w = BufWriter::with_capacity(1 << 20, file);
        let bg = e.bg;
        // NOTE: .ldproj is still a single-layer format: with several layers the blended result is saved.
        match with_flat(e, |c| c.write_project(&mut w, bg).and_then(|_| w.flush())) {
            Ok(()) => 0,
            Err(_) => 1,
        }
    })
}

/// Returns (width << 32) | height, or -1 on failure. Takes ownership of `fd`.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLoadProject(
    mut env: JNIEnv,
    _this: JObject,
    fd: jint,
    dir: JString,
    max_resident: jint,
) -> jlong {
    let dir: String = match env.get_string(&dir) {
        Ok(s) => s.into(),
        Err(_) => return -1,
    };
    let file = unsafe { File::from_raw_fd(fd) };
    let mut r = BufReader::with_capacity(1 << 20, file);
    match TiledCanvas::read_project(&mut r, PathBuf::from(dir), max_resident.max(64) as usize) {
        Ok((canvas, bg)) => {
            let (w, h) = (canvas.width as i64, canvas.height as i64);
            replace_engine(Engine::from_canvas(canvas, bg));
            (w << 32) | h
        }
        Err(_) => -1,
    }
}

unsafe fn import_rows(canvas: &mut TiledCanvas, base: *const u8, bw: usize, bh: usize, stride: usize, dx: i32, dy: i32) {
    let cw = canvas.width as i32;
    let ch = canvas.height as i32;
    let tiles_x = canvas.tiles_x;
    for sy in 0..bh {
        let y = dy + sy as i32;
        if y < 0 || y >= ch {
            continue;
        }
        let row = std::slice::from_raw_parts(base.add(sy * stride) as *const u32, bw);
        let sx_start = (-dx).max(0) as usize;
        let sx_end = (cw - dx).min(bw as i32).max(0) as usize;
        let mut sx = sx_start;
        while sx < sx_end {
            let x = (dx + sx as i32) as usize;
            let tx = x >> 8;
            let seg = ((tx + 1) * TILE - x).min(sx_end - sx);
            let src = &row[sx..sx + seg];
            if src.iter().any(|&p| (p >> 24) != 0) {
                let idx = ((y as usize) >> 8) * tiles_x + tx;
                let base_i = ((y as usize) & 255) * TILE + (x & 255);
                let px = canvas.tile_mut(idx);
                for (k, &s) in src.iter().enumerate() {
                    px[base_i + k] = over(px[base_i + k], s);
                }
            }
            sx += seg;
        }
    }
}

/// Blit an ARGB_8888 (premultiplied) bitmap onto the canvas at (dx, dy). One undo step.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeImportBitmap(
    env: JNIEnv,
    _this: JObject,
    bitmap: JObject,
    dx: jint,
    dy: jint,
) -> jint {
    let raw_env = env.get_raw();
    let bmp = bitmap.as_raw();
    let mut info = AndroidBitmapInfo { width: 0, height: 0, stride: 0, format: 0, flags: 0 };
    unsafe {
        if AndroidBitmap_getInfo(raw_env, bmp, &mut info) != 0 {
            return 1;
        }
        if info.format != BITMAP_FORMAT_RGBA_8888 {
            return 2;
        }
        let mut addr: *mut c_void = std::ptr::null_mut();
        if AndroidBitmap_lockPixels(raw_env, bmp, &mut addr) != 0 || addr.is_null() {
            return 3;
        }
        let r = with_engine(4, |e| {
            e.canvas.begin_edit();
            import_rows(&mut e.canvas, addr as *const u8, info.width as usize, info.height as usize, info.stride as usize, dx, dy);
            e.canvas.end_edit();
            0
        });
        AndroidBitmap_unlockPixels(raw_env, bmp);
        r
    }
}


// ---------------------------------------------------------------- resumable fill (8K-16K safe)

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFillBegin(
    _env: JNIEnv,
    _this: JObject,
    x: jint,
    y: jint,
    kind: jint,
    color: jint,
    color2: jint,
    scale: jfloat,
    tol: jint,
) -> jint {
    guard(-1, || {
        with_engine(-1, |e| {
            let paint = Paint { kind: kind.clamp(0, 255) as u8, c1: argb_to_px(color), c2: argb_to_px(color2), scale: scale.max(0.1) };
            if e.fill_job.take().is_some() {
                e.canvas.cancel_edit();
            }
            e.canvas.begin_edit();
            match FillJob::new(&mut e.canvas, x, y, tol, paint) {
                Some(j) => {
                    e.fill_job = Some(j);
                    0
                }
                None => {
                    e.canvas.cancel_edit();
                    1
                }
            }
        })
    })
}

/// 0 working, 1 done, 2 too large (rolled back), 3 no job.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFillStep(_env: JNIEnv, _this: JObject, budget: jint) -> jint {
    guard(-1, || {
        with_engine(3, |e| {
            let Some(mut job) = e.fill_job.take() else { return 3 };
            match job.step(&mut e.canvas, budget.max(10_000) as u64) {
                fill_job::Step::Working => {
                    e.fill_job = Some(job);
                    0
                }
                fill_job::Step::Done => {
                    e.canvas.end_edit();
                    1
                }
                fill_job::Step::TooLarge => {
                    e.canvas.cancel_edit();
                    2
                }
            }
        })
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFillCancel(_env: JNIEnv, _this: JObject) {
    guard((), || {
        with_engine((), |e| {
            if e.fill_job.take().is_some() {
                e.canvas.cancel_edit();
            }
        })
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeFillPainted(_env: JNIEnv, _this: JObject) -> jlong {
    guard(0, || with_engine(0, |e| e.fill_job.as_ref().map_or(0, |j| j.painted() as jlong)))
}

// ---------------------------------------------------------------- live transform commit / pattern resize

/// Affine commit of a selection: x' = a x + b y + tx, y' = c x + d y + ty. 0 ok, 1 empty, 2 too large.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeTransformRegion(
    _env: JNIEnv,
    _this: JObject,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
    a: jfloat,
    b: jfloat,
    tx: jfloat,
    c: jfloat,
    d: jfloat,
    ty: jfloat,
) -> jint {
    guard(-1, || {
        with_engine(-1, |e| {
            e.canvas.begin_edit();
            let r = transform::transform_region(&mut e.canvas, x0, y0, x1, y1, [a, b, tx, c, d, ty]);
            if r == 0 {
                e.canvas.end_edit();
            } else {
                e.canvas.cancel_edit();
            }
            r
        })
    })
}

/// Resample the custom pattern motif to w x h pixels. Returns true on success.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeResizeCustomPattern(_env: JNIEnv, _this: JObject, w: jint, h: jint) -> jboolean {
    if guard(false, || resize_custom(w.max(1) as u32, h.max(1) as u32)) {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}


// ---------------------------------------------------------------- layers

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerCount(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(1, |e| e.stack.layers.len() as jint)
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerActive(_env: JNIEnv, _this: JObject) -> jint {
    with_engine(0, |e| e.stack.active as jint)
}

/// bit0 visible, bit1 locked, bits 8..16 opacity (0..255).
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerInfo(_env: JNIEnv, _this: JObject, i: jint) -> jint {
    with_engine(0, |e| layers::info(&e.stack, i.max(0) as usize))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerSelect(_env: JNIEnv, _this: JObject, i: jint) -> jboolean {
    let ok = guard(false, || with_engine(false, |e| i >= 0 && layers::select(&mut e.canvas, &mut e.stack, i as usize)));
    if ok { JNI_TRUE } else { JNI_FALSE }
}

/// New empty layer above the active one. Returns its index, -1 at the layer limit.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerAdd(_env: JNIEnv, _this: JObject) -> jint {
    guard(-1, || with_engine(-1, |e| layers::add(&mut e.canvas, &mut e.stack)))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerDuplicate(_env: JNIEnv, _this: JObject) -> jint {
    guard(-1, || with_engine(-1, |e| layers::duplicate(&mut e.canvas, &mut e.stack)))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerDelete(_env: JNIEnv, _this: JObject) -> jboolean {
    let ok = guard(false, || with_engine(false, |e| layers::delete_active(&mut e.canvas, &mut e.stack)));
    if ok { JNI_TRUE } else { JNI_FALSE }
}

/// dir > 0 moves the active layer up, dir < 0 down. Returns the new index.
#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerMove(_env: JNIEnv, _this: JObject, dir: jint) -> jint {
    guard(0, || with_engine(0, |e| layers::move_active(&mut e.stack, dir)))
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerMergeDown(_env: JNIEnv, _this: JObject) -> jboolean {
    let ok = guard(false, || with_engine(false, |e| layers::merge_down(&mut e.canvas, &mut e.stack)));
    if ok { JNI_TRUE } else { JNI_FALSE }
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerSetVisible(_env: JNIEnv, _this: JObject, i: jint, v: jboolean) {
    with_engine((), |e| {
        if let Some(l) = e.stack.layers.get_mut(i.max(0) as usize) {
            l.visible = v != 0;
            e.stack.stamp = e.stack.stamp.wrapping_add(1);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerSetLocked(_env: JNIEnv, _this: JObject, i: jint, v: jboolean) {
    with_engine((), |e| {
        if let Some(l) = e.stack.layers.get_mut(i.max(0) as usize) {
            l.locked = v != 0;
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_lightdraw_studio_NativeEngine_nativeLayerSetOpacity(_env: JNIEnv, _this: JObject, i: jint, opacity: jint) {
    with_engine((), |e| {
        if let Some(l) = e.stack.layers.get_mut(i.max(0) as usize) {
            l.opacity = opacity.clamp(0, 255) as u8;
            e.stack.stamp = e.stack.stamp.wrapping_add(1);
        }
    })
}
