//! Memory-bounded seamless offset (wrap-around) for any canvas size up to 16384^2.
//! (NEW FILE: rust-engine/src/wrap_stream.rs; replaces the `w*h > MAX_BUFFER_PIXELS` early-out in
//! `fx_engine::offset_wrap` -- call this one when the canvas is larger than 4096^2, or always.)
//!
//! Pass 1 gathers every destination tile from the (still untouched) canvas, row by row with at most
//! one horizontal wrap, and stores it RLE-compressed in `tmp`. Pass 2 writes the tiles back inside the
//! caller's begin_edit/end_edit, so the whole operation stays one undo step.
//! Peak RAM: one 256 KB tile buffer + whatever the canvas LRU already holds.
use std::fs;
use std::path::Path;

use crate::tiled_canvas::{rle_decode, rle_encode, TiledCanvas, TILE};

pub fn offset_wrap_streamed(canvas: &mut TiledCanvas, dx: i32, dy: i32, tmp: &Path) -> i32 {
    let (w, h) = (canvas.width as usize, canvas.height as usize);
    let dx = dx.rem_euclid(w as i32) as usize;
    let dy = dy.rem_euclid(h as i32) as usize;
    if dx == 0 && dy == 0 {
        return 0;
    }
    let _ = fs::remove_dir_all(tmp);
    if fs::create_dir_all(tmp).is_err() {
        return 3;
    }
    let n = canvas.tile_count();
    let tiles_x = canvas.tiles_x;
    let mut non_empty = vec![false; n];
    let mut buf = vec![0u32; TILE * TILE];

    // ---- pass 1: gather
    for idx in 0..n {
        let x0 = (idx % tiles_x) * TILE;
        let y0 = (idx / tiles_x) * TILE;
        let tw = (w - x0).min(TILE);
        let th = (h - y0).min(TILE);
        buf.fill(0);
        for ly in 0..th {
            let sy = (y0 + ly + h - dy) % h;
            let sx0 = (x0 + w - dx) % w;
            let first = tw.min(w - sx0);
            let row = ly * TILE;
            canvas.read_row(sy as u32, sx0 as u32, &mut buf[row..row + first]);
            if first < tw {
                canvas.read_row(sy as u32, 0, &mut buf[row + first..row + tw]);
            }
        }
        if buf.iter().any(|&p| p != 0) {
            if fs::write(tmp.join(format!("w{}.rle", idx)), rle_encode(&buf)).is_err() {
                let _ = fs::remove_dir_all(tmp);
                return 3; // disk full: nothing was modified yet
            }
            non_empty[idx] = true;
        }
    }

    // ---- pass 2: write back (undo snapshots are taken by tile_mut)
    for idx in 0..n {
        if non_empty[idx] {
            if let Ok(data) = fs::read(tmp.join(format!("w{}.rle", idx))) {
                let px = canvas.tile_mut(idx);
                if !rle_decode(&data, px) {
                    px.fill(0);
                }
            }
        } else if canvas.exists(idx) {
            canvas.tile_mut(idx).fill(0);
        }
    }
    let _ = fs::remove_dir_all(tmp);
    0
}
