//! Stack-based scanline flood fill over the sparse tile canvas, plus seamless procedural patterns.
//!
//! The fill runs in two passes: (1) find spans, with a cap on newly created tiles so that
//! filling a huge empty 16K area cannot exhaust memory; (2) paint the spans.
//! Patterns are evaluated in global canvas coordinates, so they tile seamlessly across tile borders.

use std::sync::{Arc, Mutex};

use crate::tiled_canvas::{pack_rgba, premul, unpremul, TiledCanvas, TILE};

/// Pattern kind 7: a repeat tile cut from the drawing ("Convert object to pattern"). Straight RGBA pixels.
pub struct CustomTile {
    pub w: u32,
    pub h: u32,
    pub px: Vec<u32>,
}

static CUSTOM: Mutex<Option<Arc<CustomTile>>> = Mutex::new(None);

pub fn set_custom_pattern(w: u32, h: u32, px: Vec<u32>) {
    let mut g = CUSTOM.lock().unwrap_or_else(|e| e.into_inner());
    *g = Some(Arc::new(CustomTile { w, h, px }));
}

pub fn custom_snapshot() -> Option<Arc<CustomTile>> {
    CUSTOM.lock().unwrap_or_else(|e| e.into_inner()).clone()
}

pub fn sample_custom(t: &CustomTile, x: u32, y: u32, scale: f32) -> u32 {
    if t.w == 0 || t.h == 0 {
        return 0;
    }
    let sx = ((x as f32 / scale).floor() as i64).rem_euclid(t.w as i64) as usize;
    let sy = ((y as f32 / scale).floor() as i64).rem_euclid(t.h as i64) as usize;
    t.px[sy * t.w as usize + sx]
}

fn custom_color(x: u32, y: u32, scale: f32) -> u32 {
    custom_snapshot().map_or(0, |t| sample_custom(&t, x, y, scale))
}

/// Resample the stored motif to exactly nw x nh pixels (1..=2048). Bilinear on premultiplied values.
pub fn resize_custom(nw: u32, nh: u32) -> bool {
    let Some(t) = custom_snapshot() else { return false };
    if t.w == 0 || t.h == 0 {
        return false;
    }
    let (nw, nh) = (nw.clamp(1, 2048), nh.clamp(1, 2048));
    let mut out = vec![0u32; (nw * nh) as usize];
    for y in 0..nh {
        for x in 0..nw {
            let fx = ((x as f32 + 0.5) * t.w as f32 / nw as f32 - 0.5).max(0.0);
            let fy = ((y as f32 + 0.5) * t.h as f32 / nh as f32 - 0.5).max(0.0);
            let (x0, y0) = (fx as u32, fy as u32);
            let (x1, y1) = ((x0 + 1).min(t.w - 1), (y0 + 1).min(t.h - 1));
            let (tx, ty) = (fx - x0 as f32, fy - y0 as f32);
            let px = |xx: u32, yy: u32| premul(t.px[(yy * t.w + xx) as usize]);
            let mut o = [0f32; 4];
            for (k, sh) in [0u32, 8, 16, 24].iter().enumerate() {
                let g = |p: u32| ((p >> sh) & 255) as f32;
                let top = g(px(x0, y0)) * (1.0 - tx) + g(px(x1, y0)) * tx;
                let bot = g(px(x0, y1)) * (1.0 - tx) + g(px(x1, y1)) * tx;
                o[k] = top * (1.0 - ty) + bot * ty;
            }
            out[(y * nw + x) as usize] = unpremul(pack_rgba((o[0] + 0.5) as u8, (o[1] + 0.5) as u8, (o[2] + 0.5) as u8, (o[3] + 0.5) as u8));
        }
    }
    set_custom_pattern(nw, nh, out);
    true
}

/// Maximum number of previously empty tiles a single fill may materialise (~100 MB).
pub const MAX_NEW_TILES: usize = 400;

pub enum FillResult {
    Painted(usize),
    OutOfBounds,
    TooLarge,
}

#[derive(Clone, Copy)]
pub struct Paint {
    /// 0 solid, 1 gingham, 2 argyle, 3 seigaiha, 4 houndstooth, 5 plaid, 6 floral, 7 custom (from the drawing)
    pub kind: u8,
    pub c1: u32, // straight RGBA
    pub c2: u32, // straight RGBA
    pub scale: f32,
}

#[inline]
fn fract(v: f32) -> f32 {
    v - v.floor()
}

fn mix(a: u32, b: u32, t: f32) -> u32 {
    let ch = |s: u32| -> u32 {
        let x = ((a >> s) & 255) as f32;
        let y = ((b >> s) & 255) as f32;
        ((x + (y - x) * t) + 0.5) as u32
    };
    ch(0) | (ch(8) << 8) | (ch(16) << 16) | (ch(24) << 24)
}

/// Straight RGBA colour of the pattern at canvas position (x, y).
pub fn pattern_color(kind: u8, x: u32, y: u32, scale: f32, c1: u32, c2: u32) -> u32 {
    if kind == 7 {
        return custom_color(x, y, scale.max(0.1));
    }
    let cell = (32.0 * scale).max(4.0);
    let fx = fract(x as f32 / cell);
    let fy = fract(y as f32 / cell);
    match kind {
        1 => {
            // gingham
            let a = fx < 0.5;
            let b = fy < 0.5;
            if a && b {
                c1
            } else if a || b {
                mix(c1, c2, 0.5)
            } else {
                c2
            }
        }
        2 => {
            // argyle: diamonds with thin diagonal stitching
            let dx = (fx - 0.5).abs();
            let dy = (fy - 0.5).abs();
            if (fx - fy).abs() < 0.02 || (fx + fy - 1.0).abs() < 0.02 {
                mix(c1, c2, 0.5)
            } else if dx + dy < 0.5 {
                c1
            } else {
                c2
            }
        }
        3 => seigaiha(x as f32, y as f32, cell, c1, c2),
        4 => {
            // houndstooth: 4 dark / 4 light threads in warp and weft with a 2/2 twill weave
            let unit = (cell / 8.0).max(1.0);
            let i = (x as f32 / unit).floor() as i64;
            let j = (y as f32 / unit).floor() as i64;
            let warp_dark = i.rem_euclid(8) < 4;
            let weft_dark = j.rem_euclid(8) < 4;
            let over = (i + j).rem_euclid(4) < 2;
            let dark = if over { warp_dark } else { weft_dark };
            if dark {
                c1
            } else {
                c2
            }
        }
        5 => {
            // plaid
            let band = |f: f32| -> u32 {
                if f < 0.3 {
                    c1
                } else if f < 0.4 {
                    mix(c1, c2, 0.5)
                } else {
                    c2
                }
            };
            mix(band(fx), band(fy), 0.5)
        }
        6 => {
            // floral: four-petal flower per cell
            let dx = fx - 0.5;
            let dy = fy - 0.5;
            let r = (dx * dx + dy * dy).sqrt();
            let th = dy.atan2(dx);
            let petal = 0.30 * (0.55 + 0.45 * (2.0 * th).cos().abs());
            if r < 0.06 {
                c2
            } else if r < petal {
                c1
            } else {
                c2
            }
        }
        _ => c1,
    }
}

fn seigaiha(x: f32, y: f32, w: f32, c1: u32, c2: u32) -> u32 {
    let r = w * 0.5;
    let h = w * 0.25;
    let row = (y / h).floor() as i32;
    let mut cr = row + 2;
    while cr >= row - 2 {
        let off = if cr.rem_euclid(2) == 1 { w * 0.5 } else { 0.0 };
        let k = ((x - off - r) / w).round();
        let ccx = k * w + r + off;
        let ccy = cr as f32 * h;
        let d = ((x - ccx).powi(2) + (y - ccy).powi(2)).sqrt();
        if d <= r {
            let ring = ((d / r) * 3.0) as i32;
            return if ring % 2 == 0 { c1 } else { c2 };
        }
        cr -= 1;
    }
    c2
}

/// Pixel of the paint with the custom tile already resolved (no lock per pixel).
pub fn paint_px(p: &Paint, custom: Option<&CustomTile>, x: u32, y: u32) -> u32 {
    match p.kind {
        0 => premul(p.c1),
        7 => premul(custom.map_or(0, |c| sample_custom(c, x, y, p.scale))),
        k => premul(pattern_color(k, x, y, p.scale, p.c1, p.c2)),
    }
}

#[inline]
fn paint_pixel(p: &Paint, x: u32, y: u32) -> u32 {
    if p.kind == 0 {
        premul(p.c1)
    } else {
        premul(pattern_color(p.kind, x, y, p.scale, p.c1, p.c2))
    }
}

#[inline]
fn chan_diff(a: u32, b: u32, sh: u32) -> i32 {
    (((a >> sh) & 255) as i32 - ((b >> sh) & 255) as i32).abs()
}

struct Filler<'a> {
    canvas: &'a mut TiledCanvas,
    visited: Vec<Option<Box<[u64]>>>,
    target: u32,
    tol: i32,
}

impl<'a> Filler<'a> {
    fn matches(&mut self, x: u32, y: u32) -> bool {
        let p = self.canvas.get_pixel(x as i32, y as i32);
        let t = self.target;
        chan_diff(p, t, 0).max(chan_diff(p, t, 8)).max(chan_diff(p, t, 16)).max(chan_diff(p, t, 24)) <= self.tol
    }

    #[inline]
    fn loc(&self, x: u32, y: u32) -> (usize, usize, u64) {
        let tidx = ((y as usize) >> 8) * self.canvas.tiles_x + ((x as usize) >> 8);
        let bit = ((y as usize) & 255) * TILE + ((x as usize) & 255);
        (tidx, bit >> 6, 1u64 << (bit & 63))
    }

    fn is_visited(&self, x: u32, y: u32) -> bool {
        let (t, w, m) = self.loc(x, y);
        match &self.visited[t] {
            Some(b) => b[w] & m != 0,
            None => false,
        }
    }

    fn mark(&mut self, x: u32, y: u32) {
        let (t, w, m) = self.loc(x, y);
        let slot = &mut self.visited[t];
        if slot.is_none() {
            *slot = Some(vec![0u64; TILE * TILE / 64].into_boxed_slice());
        }
        if let Some(b) = slot.as_mut() {
            b[w] |= m;
        }
    }
}

/// Flood fill from (sx, sy) with the given per-channel tolerance (0..255).
pub fn flood_fill(canvas: &mut TiledCanvas, sx: i32, sy: i32, tolerance: i32, paint: &Paint) -> FillResult {
    if sx < 0 || sy < 0 || sx >= canvas.width as i32 || sy >= canvas.height as i32 {
        return FillResult::OutOfBounds;
    }
    let target = canvas.get_pixel(sx, sy);
    let total = canvas.tile_count();
    let tiles_x = canvas.tiles_x;
    let (w, h) = (canvas.width, canvas.height);
    let mut spans: Vec<(u32, u32, u32)> = Vec::new(); // (y, x0, x1) inclusive
    let mut touched = vec![false; total];
    let mut new_tiles = 0usize;

    {
        let mut f = Filler {
            canvas: &mut *canvas,
            visited: (0..total).map(|_| None).collect(),
            target,
            tol: tolerance.clamp(0, 255),
        };
        let mut stack: Vec<(u32, u32)> = vec![(sx as u32, sy as u32)];
        while let Some((x, y)) = stack.pop() {
            if f.is_visited(x, y) || !f.matches(x, y) {
                continue;
            }
            let mut xl = x;
            while xl > 0 && !f.is_visited(xl - 1, y) && f.matches(xl - 1, y) {
                xl -= 1;
            }
            let mut xr = x;
            while xr + 1 < w && !f.is_visited(xr + 1, y) && f.matches(xr + 1, y) {
                xr += 1;
            }
            for xx in xl..=xr {
                f.mark(xx, y);
            }
            // tile budget
            for tx in ((xl as usize) >> 8)..=((xr as usize) >> 8) {
                let idx = ((y as usize) >> 8) * tiles_x + tx;
                if !touched[idx] {
                    touched[idx] = true;
                    if !f.canvas.exists(idx) {
                        new_tiles += 1;
                    }
                }
            }
            if new_tiles > MAX_NEW_TILES {
                return FillResult::TooLarge;
            }
            spans.push((y, xl, xr));
            for ny in [y as i64 - 1, y as i64 + 1] {
                if ny < 0 || ny >= h as i64 {
                    continue;
                }
                let ny = ny as u32;
                let mut in_run = false;
                for xx in xl..=xr {
                    let ok = !f.is_visited(xx, ny) && f.matches(xx, ny);
                    if ok && !in_run {
                        stack.push((xx, ny));
                        in_run = true;
                    } else if !ok {
                        in_run = false;
                    }
                }
            }
        }
    }

    let mut painted = 0usize;
    for &(y, x0, x1) in &spans {
        let mut x = x0;
        while x <= x1 {
            let tx = (x as usize) >> 8;
            let seg_end = x1.min(((tx + 1) * TILE - 1) as u32);
            let idx = ((y as usize) >> 8) * tiles_x + tx;
            let ly = (y as usize) & 255;
            let px = canvas.tile_mut(idx);
            for xx in x..=seg_end {
                px[ly * TILE + ((xx as usize) & 255)] = paint_pixel(paint, xx, y);
            }
            painted += (seg_end - x + 1) as usize;
            x = seg_end + 1;
        }
    }
    FillResult::Painted(painted)
}
