//! Whole-canvas FX, wrap-around offset (seamless tiling), region move / copy / align and an
//! anti-aliased shape rasteriser. Everything works tile by tile on the sparse canvas and is
//! recorded in the normal undo history (the JNI wrappers call begin_edit / end_edit).

use crate::brush_engine::{blend_px, over, Blend};
use crate::color_engine::rgb_to_hsl;
use crate::tiled_canvas::{pack_rgba, premul, unpremul, TiledCanvas, TILE};

/// Largest buffer (in pixels) that wrap-offset / region operations are allowed to hold in RAM (64 MB).
pub const MAX_BUFFER_PIXELS: usize = 4096 * 4096;

#[inline]
fn cl(v: f32) -> u32 {
    (v + 0.5).clamp(0.0, 255.0) as u32
}

fn hsl_to_rgb(h: f32, s: f32, l: f32) -> (u32, u32, u32) {
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = h.rem_euclid(360.0) / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r1, g1, b1) = match hp as i32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    let m = l - c * 0.5;
    (cl((r1 + m) * 255.0), cl((g1 + m) * 255.0), cl((b1 + m) * 255.0))
}

// ------------------------------------------------------------------ FX

/// op 0 invert, 1 grayscale, 2 brightness(a)/contrast(b) in -1..1, 3 hue shift(a, degrees)/saturation(b, -1..1).
/// Alpha is never touched. Returns the number of tiles processed.
pub fn apply_fx(canvas: &mut TiledCanvas, op: i32, a: f32, b: f32) -> u32 {
    let mut n = 0u32;
    for idx in 0..canvas.tile_count() {
        if !canvas.exists(idx) {
            continue;
        }
        let px = canvas.tile_mut(idx);
        for p in px.iter_mut() {
            let al = *p >> 24;
            if al == 0 {
                continue;
            }
            let s = unpremul(*p);
            let (r, g, bl) = ((s & 255) as f32, ((s >> 8) & 255) as f32, ((s >> 16) & 255) as f32);
            let (nr, ng, nb) = match op {
                0 => (255 - r as u32, 255 - g as u32, 255 - bl as u32),
                1 => {
                    let y = cl(0.299 * r + 0.587 * g + 0.114 * bl);
                    (y, y, y)
                }
                2 => {
                    let f = |v: f32| cl(((v / 255.0 - 0.5) * (1.0 + b) + 0.5 + a) * 255.0);
                    (f(r), f(g), f(bl))
                }
                3 => {
                    let (h, sat, l) = rgb_to_hsl(r as u8, g as u8, bl as u8);
                    hsl_to_rgb(h + a, (sat * (1.0 + b)).clamp(0.0, 1.0), l)
                }
                _ => (r as u32, g as u32, bl as u32),
            };
            *p = premul(pack_rgba(nr as u8, ng as u8, nb as u8, al as u8));
        }
        n += 1;
    }
    n
}

// ------------------------------------------------------------------ wrap offset (seamless)

/// Shift the whole drawing by (dx, dy); whatever leaves one edge re-enters on the opposite edge.
/// Returns 0 ok, 2 canvas too large for the in-memory buffer.
pub fn offset_wrap(canvas: &mut TiledCanvas, dx: i32, dy: i32) -> i32 {
    let w = canvas.width as usize;
    let h = canvas.height as usize;
    if w * h > MAX_BUFFER_PIXELS {
        return 2;
    }
    let dx = dx.rem_euclid(w as i32) as usize;
    let dy = dy.rem_euclid(h as i32) as usize;
    if dx == 0 && dy == 0 {
        return 0;
    }
    let mut src = vec![0u32; w * h];
    for y in 0..h {
        canvas.read_row(y as u32, 0, &mut src[y * w..(y + 1) * w]);
    }
    let tiles_x = canvas.tiles_x;
    let mut buf = vec![0u32; TILE * TILE];
    for idx in 0..canvas.tile_count() {
        let x0 = (idx % tiles_x) * TILE;
        let y0 = (idx / tiles_x) * TILE;
        let x1 = (x0 + TILE).min(w);
        let y1 = (y0 + TILE).min(h);
        buf.fill(0);
        let mut any = false;
        for y in y0..y1 {
            let sy = (y + h - dy) % h;
            for x in x0..x1 {
                let sx = (x + w - dx) % w;
                let v = src[sy * w + sx];
                if v != 0 {
                    any = true;
                }
                buf[(y - y0) * TILE + (x - x0)] = v;
            }
        }
        if any || canvas.exists(idx) {
            canvas.tile_mut(idx).copy_from_slice(&buf);
        }
    }
    0
}

// ------------------------------------------------------------------ region move / copy / align

fn clamp_rect(canvas: &TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32) -> Option<(i32, i32, i32, i32)> {
    let (a, b) = (x0.min(x1).max(0), y0.min(y1).max(0));
    let (c, d) = (x0.max(x1).min(canvas.width as i32 - 1), y0.max(y1).min(canvas.height as i32 - 1));
    if a > c || b > d {
        None
    } else {
        Some((a, b, c, d))
    }
}

/// Composite `pw x ph` pixels from `src` (row stride `sw`, origin `sox, soy`) onto the canvas at (dx, dy), clipped.
fn paste_piece(canvas: &mut TiledCanvas, src: &[u32], sw: usize, sox: usize, soy: usize, pw: usize, ph: usize, dx: i32, dy: i32) {
    let cw = canvas.width as i32;
    let ch = canvas.height as i32;
    let gx0 = dx.max(0);
    let gy0 = dy.max(0);
    let gx1 = (dx + pw as i32 - 1).min(cw - 1);
    let gy1 = (dy + ph as i32 - 1).min(ch - 1);
    if gx0 > gx1 || gy0 > gy1 {
        return;
    }
    let tiles_x = canvas.tiles_x;
    for ty in ((gy0 as usize) >> 8)..=((gy1 as usize) >> 8) {
        for tx in ((gx0 as usize) >> 8)..=((gx1 as usize) >> 8) {
            let bx0 = gx0.max((tx * TILE) as i32);
            let bx1 = gx1.min(((tx + 1) * TILE) as i32 - 1);
            let by0 = gy0.max((ty * TILE) as i32);
            let by1 = gy1.min(((ty + 1) * TILE) as i32 - 1);
            // Skip tiles that would only receive transparent pixels.
            let mut any = false;
            'scan: for y in by0..=by1 {
                for x in bx0..=bx1 {
                    let s = src[(soy + (y - dy) as usize) * sw + sox + (x - dx) as usize];
                    if s >> 24 != 0 {
                        any = true;
                        break 'scan;
                    }
                }
            }
            if !any {
                continue;
            }
            let px = canvas.tile_mut(ty * tiles_x + tx);
            for y in by0..=by1 {
                let ly = (y as usize) & 255;
                for x in bx0..=bx1 {
                    let s = src[(soy + (y - dy) as usize) * sw + sox + (x - dx) as usize];
                    if s >> 24 != 0 {
                        let li = ly * TILE + ((x as usize) & 255);
                        px[li] = over(px[li], s);
                    }
                }
            }
        }
    }
}

/// Move (`copy = false`) or duplicate (`copy = true`) the rectangle by (dx, dy).
/// With `wrap`, pixels pushed past a canvas edge re-enter on the opposite side (seamless repeat).
/// Returns 0 ok, 1 empty/outside, 2 region too large.
pub fn move_region(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32, dx: i32, dy: i32, copy: bool, wrap: bool) -> i32 {
    let (x0, y0, x1, y1) = match clamp_rect(canvas, x0, y0, x1, y1) {
        Some(r) => r,
        None => return 1,
    };
    let w = (x1 - x0 + 1) as usize;
    let h = (y1 - y0 + 1) as usize;
    if w * h > MAX_BUFFER_PIXELS {
        return 2;
    }
    let mut src = vec![0u32; w * h];
    for y in 0..h {
        canvas.read_row((y0 as usize + y) as u32, x0 as u32, &mut src[y * w..(y + 1) * w]);
    }
    if !copy {
        let tiles_x = canvas.tiles_x;
        for ty in ((y0 as usize) >> 8)..=((y1 as usize) >> 8) {
            for tx in ((x0 as usize) >> 8)..=((x1 as usize) >> 8) {
                let idx = ty * tiles_x + tx;
                if !canvas.exists(idx) {
                    continue;
                }
                let bx0 = x0.max((tx * TILE) as i32);
                let bx1 = x1.min(((tx + 1) * TILE) as i32 - 1);
                let by0 = y0.max((ty * TILE) as i32);
                let by1 = y1.min(((ty + 1) * TILE) as i32 - 1);
                let px = canvas.tile_mut(idx);
                for y in by0..=by1 {
                    let ly = (y as usize) & 255;
                    for x in bx0..=bx1 {
                        px[ly * TILE + ((x as usize) & 255)] = 0;
                    }
                }
            }
        }
    }
    if wrap {
        let cw = canvas.width as i32;
        let ch = canvas.height as i32;
        let ox = (x0 + dx).rem_euclid(cw);
        let oy = (y0 + dy).rem_euclid(ch);
        // Split the destination into at most 2 x 2 pieces at the canvas seams.
        let first_w = (cw - ox).min(w as i32) as usize;
        let first_h = (ch - oy).min(h as i32) as usize;
        let xs = [(0usize, ox, first_w), (first_w, 0, w - first_w)];
        let ys = [(0usize, oy, first_h), (first_h, 0, h - first_h)];
        for &(sx, px0, pw) in &xs {
            for &(sy, py0, ph) in &ys {
                if pw > 0 && ph > 0 {
                    paste_piece(canvas, &src, w, sx, sy, pw, ph, px0, py0);
                }
            }
        }
    } else {
        paste_piece(canvas, &src, w, 0, 0, w, h, x0 + dx, y0 + dy);
    }
    0
}

/// Bounding box of the non-transparent pixels inside the rectangle (inclusive), if any.
pub fn content_bounds(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32) -> Option<(i32, i32, i32, i32)> {
    let (x0, y0, x1, y1) = clamp_rect(canvas, x0, y0, x1, y1)?;
    let w = (x1 - x0 + 1) as usize;
    let mut row = vec![0u32; w];
    let (mut bx0, mut by0, mut bx1, mut by1) = (i32::MAX, i32::MAX, i32::MIN, i32::MIN);
    for y in y0..=y1 {
        canvas.read_row(y as u32, x0 as u32, &mut row);
        for (i, &p) in row.iter().enumerate() {
            if p >> 24 != 0 {
                let x = x0 + i as i32;
                bx0 = bx0.min(x);
                bx1 = bx1.max(x);
                by0 = by0.min(y);
                by1 = by1.max(y);
            }
        }
    }
    if bx0 > bx1 {
        None
    } else {
        Some((bx0, by0, bx1, by1))
    }
}

/// Align the object (content bounds inside the rectangle) to the canvas and move it there.
/// mode: 0 left, 1 centre horizontally, 2 right, 3 top, 4 centre vertically, 5 bottom, 6 centre on both axes.
/// Returns the applied (dx, dy), or None when the rectangle holds no pixels.
pub fn align_region(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32, mode: i32) -> Option<(i32, i32)> {
    let (bx0, by0, bx1, by1) = content_bounds(canvas, x0, y0, x1, y1)?;
    let cw = canvas.width as i32;
    let ch = canvas.height as i32;
    let bw = bx1 - bx0 + 1;
    let bh = by1 - by0 + 1;
    let (mut dx, mut dy) = (0, 0);
    match mode {
        0 => dx = -bx0,
        1 => dx = (cw - bw) / 2 - bx0,
        2 => dx = cw - 1 - bx1,
        3 => dy = -by0,
        4 => dy = (ch - bh) / 2 - by0,
        5 => dy = ch - 1 - by1,
        _ => {
            dx = (cw - bw) / 2 - bx0;
            dy = (ch - bh) / 2 - by0;
        }
    }
    if dx != 0 || dy != 0 {
        if move_region(canvas, x0, y0, x1, y1, dx, dy, false, false) != 0 {
            return None;
        }
    }
    Some((dx, dy))
}

/// Copy the rectangle as a straight-RGBA tile for the custom pattern. Returns (w, h, pixels) or an error code
/// (1 = empty, 2 = too large).
pub fn region_to_tile(canvas: &mut TiledCanvas, x0: i32, y0: i32, x1: i32, y1: i32) -> Result<(u32, u32, Vec<u32>), i32> {
    let (x0, y0, x1, y1) = clamp_rect(canvas, x0, y0, x1, y1).ok_or(1)?;
    let w = (x1 - x0 + 1) as usize;
    let h = (y1 - y0 + 1) as usize;
    if w * h > 2048 * 2048 {
        return Err(2);
    }
    let mut out = vec![0u32; w * h];
    for y in 0..h {
        canvas.read_row((y0 as usize + y) as u32, x0 as u32, &mut out[y * w..(y + 1) * w]);
    }
    if out.iter().all(|&p| p >> 24 == 0) {
        return Err(1);
    }
    for p in out.iter_mut() {
        *p = unpremul(*p);
    }
    Ok((w as u32, h as u32, out))
}

// ------------------------------------------------------------------ anti-aliased shapes

#[derive(Clone, Copy)]
pub struct ShapeSpec {
    /// 0 rectangle, 1 rounded rectangle, 2 ellipse, 3 triangle, 4 line, 5 diamond
    pub kind: i32,
    pub x0: f32,
    pub y0: f32,
    pub x1: f32,
    pub y1: f32,
    pub fill: u32,   // straight RGBA
    pub stroke: u32, // straight RGBA
    pub filled: bool,
    pub stroked: bool,
    pub sw: f32, // stroke width (line thickness for kind 4)
}

fn dist_seg(px: f32, py: f32, ax: f32, ay: f32, bx: f32, by: f32) -> f32 {
    let (vx, vy) = (bx - ax, by - ay);
    let (wx, wy) = (px - ax, py - ay);
    let len2 = vx * vx + vy * vy;
    let t = if len2 > 1e-6 { ((wx * vx + wy * vy) / len2).clamp(0.0, 1.0) } else { 0.0 };
    ((wx - vx * t).powi(2) + (wy - vy * t).powi(2)).sqrt()
}

/// Signed distance (negative inside) from pixel centre (px, py) to the shape outline, in pixels.
fn shape_sd(s: &ShapeSpec, px: f32, py: f32, cx: f32, cy: f32, hx: f32, hy: f32) -> f32 {
    let (dx, dy) = (px - cx, py - cy);
    match s.kind {
        0 | 1 => {
            let r = if s.kind == 1 { (hx.min(hy) * 0.3).max(0.0) } else { 0.0 };
            let qx = dx.abs() - (hx - r);
            let qy = dy.abs() - (hy - r);
            (qx.max(0.0).powi(2) + qy.max(0.0).powi(2)).sqrt() + qx.max(qy).min(0.0) - r
        }
        2 => {
            let k = ((dx / hx).powi(2) + (dy / hy).powi(2)).sqrt();
            (k - 1.0) * hx.min(hy)
        }
        3 => {
            let (ax, ay) = (cx, cy - hy);
            let (bx, by) = (cx + hx, cy + hy);
            let (qx, qy) = (cx - hx, cy + hy);
            let d = dist_seg(px, py, ax, ay, bx, by)
                .min(dist_seg(px, py, bx, by, qx, qy))
                .min(dist_seg(px, py, qx, qy, ax, ay));
            let cr = |x1: f32, y1: f32, x2: f32, y2: f32| (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1);
            let (c1, c2, c3) = (cr(ax, ay, bx, by), cr(bx, by, qx, qy), cr(qx, qy, ax, ay));
            let inside = (c1 >= 0.0 && c2 >= 0.0 && c3 >= 0.0) || (c1 <= 0.0 && c2 <= 0.0 && c3 <= 0.0);
            if inside { -d } else { d }
        }
        4 => dist_seg(px, py, s.x0, s.y0, s.x1, s.y1) - s.sw * 0.5,
        _ => {
            let k = dx.abs() / hx + dy.abs() / hy - 1.0;
            k / (1.0 / (hx * hx) + 1.0 / (hy * hy)).sqrt()
        }
    }
}

/// Rasterise one shape with analytic ~1 px anti-aliasing (coverage = clamp(0.5 - signed distance)).
pub fn draw_shape(canvas: &mut TiledCanvas, s: &ShapeSpec) {
    let lx = s.x0.min(s.x1);
    let rx = s.x0.max(s.x1);
    let ty_ = s.y0.min(s.y1);
    let by_ = s.y0.max(s.y1);
    let (cx, cy) = ((lx + rx) * 0.5, (ty_ + by_) * 0.5);
    let (hx, hy) = (((rx - lx) * 0.5).max(0.5), ((by_ - ty_) * 0.5).max(0.5));
    let pad = if s.kind == 4 { s.sw * 0.5 + 2.0 } else { 2.0 };
    let w = canvas.width as i32;
    let h = canvas.height as i32;
    let gx0 = ((lx - pad).floor() as i32).max(0);
    let gy0 = ((ty_ - pad).floor() as i32).max(0);
    let gx1 = ((rx + pad).ceil() as i32).min(w - 1);
    let gy1 = ((by_ + pad).ceil() as i32).min(h - 1);
    if gx0 > gx1 || gy0 > gy1 {
        return;
    }
    let half = s.sw * 0.5;
    let tiles_x = canvas.tiles_x;
    for ty in ((gy0 as usize) >> 8)..=((gy1 as usize) >> 8) {
        for tx in ((gx0 as usize) >> 8)..=((gx1 as usize) >> 8) {
            let bx0 = gx0.max((tx * TILE) as i32);
            let bx1 = gx1.min(((tx + 1) * TILE) as i32 - 1);
            let by0 = gy0.max((ty * TILE) as i32);
            let by1 = gy1.min(((ty + 1) * TILE) as i32 - 1);
            let px = canvas.tile_mut(ty * tiles_x + tx);
            for y in by0..=by1 {
                let ly = (y as usize) & 255;
                for x in bx0..=bx1 {
                    let sd = shape_sd(s, x as f32 + 0.5, y as f32 + 0.5, cx, cy, hx, hy);
                    let li = ly * TILE + ((x as usize) & 255);
                    if s.kind == 4 {
                        let c = (0.5 - sd).clamp(0.0, 1.0);
                        if c > 0.002 {
                            px[li] = blend_px(px[li], s.fill, c, Blend::Normal);
                        }
                        continue;
                    }
                    if s.filled {
                        let c = (0.5 - sd).clamp(0.0, 1.0);
                        if c > 0.002 {
                            px[li] = blend_px(px[li], s.fill, c, Blend::Normal);
                        }
                    }
                    if s.stroked {
                        // inner stroke: ring centred half a stroke-width inside the outline
                        let ring = (sd + half).abs() - half;
                        let c = (0.5 - ring).clamp(0.0, 1.0);
                        if c > 0.002 {
                            px[li] = blend_px(px[li], s.stroke, c, Blend::Normal);
                        }
                    }
                }
            }
        }
    }
}
