//! Streaming exporters, capped at `max_px` (45 MP). (NEW FILE: rust-engine/src/export_stream.rs)
//! No full-size Bitmap and no full-size RGB buffer: rows are pulled from the tile canvas on demand.
//!
//! Cargo.toml:   jpeg-encoder = "0.6"      (pure Rust, no C toolchain needed for the NDK build)
//!
//! !! Written without a compiler. `ImageBuffer` is the jpeg-encoder trait for custom pixel sources;
//! !! check the exact signature of `fill_buffers` / `JpegColorType` in the version you pin
//! !! (see image_buffer.rs in the crate) -- the YCbCr conversion below follows its RGB implementation.
use std::cell::RefCell;
use std::fs::File;
use std::io::BufWriter;
use std::os::unix::io::FromRawFd;

use jpeg_encoder::{Encoder, ImageBuffer, JpegColorType, SamplingFactor};

use crate::tiled_canvas::TiledCanvas;

pub const MAX_EXPORT_PIXELS: u64 = 45_000_000;

/// Largest (w, h) with w*h <= max_px and the canvas aspect ratio. Never upscales.
pub fn fit_pixels(cw: u32, ch: u32, max_px: u64) -> (u32, u32) {
    let total = cw as u64 * ch as u64;
    if total <= max_px {
        return (cw, ch);
    }
    let s = (max_px as f64 / total as f64).sqrt();
    (((cw as f64 * s).floor() as u32).max(1), ((ch as f64 * s).floor() as u32).max(1))
}

#[inline]
fn over_bg(p: u32, bg: u32) -> (u32, u32, u32) {
    // p premultiplied RGBA, bg opaque straight RGB packed like pack_rgba
    let a = p >> 24;
    let f = |s: u32| ((p >> s) & 255) + (((bg >> s) & 255) * (255 - a) + 127) / 255;
    (f(0).min(255), f(8).min(255), f(16).min(255))
}

struct Rows<'a> {
    canvas: RefCell<&'a mut TiledCanvas>,
    line: RefCell<Vec<u32>>,
    last: RefCell<i64>,
    bg: u32,
    cw: u32,
    ch: u32,
    dw: u32,
    dh: u32,
}

impl ImageBuffer for Rows<'_> {
    fn get_jpeg_color_type(&self) -> JpegColorType {
        JpegColorType::Ycbcr
    }
    fn width(&self) -> u16 {
        self.dw as u16
    }
    fn height(&self) -> u16 {
        self.dh as u16
    }
    fn fill_buffers(&self, y: u16, buffers: &mut [Vec<u8>; 4]) {
        for b in buffers.iter_mut() {
            b.clear();
        }
        let sy = ((y as u64 * self.ch as u64) / self.dh as u64) as u32; // nearest-row sampling
        if *self.last.borrow() != sy as i64 {
            self.canvas.borrow_mut().read_row(sy, 0, &mut self.line.borrow_mut());
            *self.last.borrow_mut() = sy as i64;
        }
        let line = self.line.borrow();
        for x in 0..self.dw {
            let sx = ((x as u64 * self.cw as u64) / self.dw as u64) as usize;
            let (r, g, b) = over_bg(line[sx], self.bg);
            let (r, g, b) = (r as f32, g as f32, b as f32);
            let yy = 0.299 * r + 0.587 * g + 0.114 * b;
            let cb = 128.0 - 0.168736 * r - 0.331264 * g + 0.5 * b;
            let cr = 128.0 + 0.5 * r - 0.418688 * g - 0.081312 * b;
            buffers[0].push((yy + 0.5).clamp(0.0, 255.0) as u8);
            buffers[1].push((cb + 0.5).clamp(0.0, 255.0) as u8);
            buffers[2].push((cr + 0.5).clamp(0.0, 255.0) as u8);
        }
    }
}

/// maximum=false -> quality 85, 4:2:0 (small).  maximum=true -> quality 100, 4:4:4 (JPEG stays lossy;
/// use PNG for pixel-exact output). Takes ownership of `fd`. Returns the written (w, h).
pub fn export_jpeg(canvas: &mut TiledCanvas, fd: i32, bg: u32, maximum: bool, max_px: u64) -> Result<(u32, u32), String> {
    let (cw, ch) = (canvas.width, canvas.height);
    let (dw, dh) = fit_pixels(cw, ch, max_px.min(MAX_EXPORT_PIXELS));
    if dw > 65535 || dh > 65535 {
        return Err("jpeg dimension limit".into());
    }
    let file = unsafe { File::from_raw_fd(fd) };
    let out = BufWriter::with_capacity(1 << 20, file);
    let mut enc = Encoder::new(out, if maximum { 100 } else { 85 });
    enc.set_sampling_factor(if maximum { SamplingFactor::R_4_4_4 } else { SamplingFactor::R_4_2_0 });
    let rows = Rows {
        canvas: RefCell::new(canvas),
        line: RefCell::new(vec![0u32; cw as usize]),
        last: RefCell::new(-1),
        bg: bg | 0xFF00_0000,
        cw,
        ch,
        dw,
        dh,
    };
    enc.encode_image(rows).map_err(|e| e.to_string())?;
    Ok((dw, dh))
}
