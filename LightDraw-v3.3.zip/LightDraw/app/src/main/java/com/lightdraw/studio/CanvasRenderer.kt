package com.lightdraw.studio

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * OpenGL ES 3.0 renderer. Draws the paper quad and the visible 256x256 tiles through one
 * canvas->clip projection matrix (pan / zoom / rotation). Only a pool of tile textures is kept
 * on the GPU; everything else stays in native memory. No allocations inside onDrawFrame.
 */
class CanvasRenderer(private val v: CanvasGLView) : GLSurfaceView.Renderer {

    private companion object {
        const val TILE = 256
        const val POOL = 256
        const val UPLOAD_BUDGET = 6

        const val VERT = """#version 300 es
layout(location=0) in vec2 aPos;
uniform mat4 uMvp;
uniform vec4 uRect;
out vec2 vUv;
out vec2 vCanvas;
void main(){
    vec2 p = uRect.xy + aPos * uRect.zw;
    vUv = aPos;
    vCanvas = p;
    gl_Position = uMvp * vec4(p, 0.0, 1.0);
}"""

        const val FRAG_TILE = """#version 300 es
precision highp float;
in vec2 vUv;
uniform sampler2D uTex;
out vec4 o;
void main(){ o = texture(uTex, vUv); }"""

        const val FRAG_FLAT = """#version 300 es
precision highp float;
in vec2 vCanvas;
uniform vec4 uColor;
uniform float uChecker;
out vec4 o;
void main(){
    vec4 c = uColor;
    if (uChecker > 0.5) {
        vec2 q = floor(vCanvas / 32.0);
        float k = mod(q.x + q.y, 2.0);
        c = vec4(vec3(mix(0.80, 0.92, k)), 1.0);
    }
    o = vec4(c.rgb * c.a, c.a);
}"""
    }

    private var tileProg = 0
    private var flatProg = 0
    private var uMvpT = 0
    private var uRectT = 0
    private var uTexT = 0
    private var uMvpF = 0
    private var uRectF = 0
    private var uColorF = 0
    private var uCheckF = 0

    private val mvp = FloatArray(16)
    private val tileBuf: ByteBuffer = ByteBuffer.allocateDirect(TILE * TILE * 4).order(ByteOrder.nativeOrder())
    private val idxBuf = IntArray(4096)
    private val verBuf = IntArray(4096)

    private val texIds = IntArray(POOL)
    private val texTile = IntArray(POOL) { -1 }
    private val texVer = IntArray(POOL)
    private val texStamp = IntArray(POOL)
    private var slotOfTile = IntArray(0)
    private var frame = 0

    private var vw = 1
    private var vh = 1
    private var lastFilterNearest = false

    @Volatile private var resetTiles = -1

    /** Called from any thread when the canvas was replaced. */
    fun requestReset(totalTiles: Int) {
        resetTiles = totalTiles
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        tileProg = link(VERT, FRAG_TILE)
        flatProg = link(VERT, FRAG_FLAT)
        uMvpT = GLES30.glGetUniformLocation(tileProg, "uMvp")
        uRectT = GLES30.glGetUniformLocation(tileProg, "uRect")
        uTexT = GLES30.glGetUniformLocation(tileProg, "uTex")
        uMvpF = GLES30.glGetUniformLocation(flatProg, "uMvp")
        uRectF = GLES30.glGetUniformLocation(flatProg, "uRect")
        uColorF = GLES30.glGetUniformLocation(flatProg, "uColor")
        uCheckF = GLES30.glGetUniformLocation(flatProg, "uChecker")

        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        val quad = floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f)
        val fb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(quad).position(0)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, 0)

        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE_MINUS_SRC_ALPHA) // premultiplied alpha

        // GL context (re)created: all old texture names are invalid.
        texIds.fill(0)
        texTile.fill(-1)
        resetTiles = max(resetTiles, v.totalTiles())
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = max(1, width)
        vh = max(1, height)
        GLES30.glViewport(0, 0, vw, vh)
    }

    override fun onDrawFrame(gl: GL10?) {
        frame++
        val rt = resetTiles
        if (rt >= 0) {
            resetTiles = -1
            if (slotOfTile.size != rt) slotOfTile = IntArray(rt)
            slotOfTile.fill(-1)
            texTile.fill(-1)
        }

        GLES30.glClearColor(0.059f, 0.059f, 0.067f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)

        val cw = v.canvasW
        val ch = v.canvasH
        val s = v.scale
        val c = v.cosR
        val sn = v.sinR
        val a = 2f / vw
        val b = 2f / vh
        // canvas px -> NDC (column-major)
        mvp[0] = a * s * c
        mvp[1] = -b * s * sn
        mvp[2] = 0f
        mvp[3] = 0f
        mvp[4] = -a * s * sn
        mvp[5] = -b * s * c
        mvp[6] = 0f
        mvp[7] = 0f
        mvp[8] = 0f
        mvp[9] = 0f
        mvp[10] = 1f
        mvp[11] = 0f
        mvp[12] = a * v.tx - 1f
        mvp[13] = 1f - b * v.ty
        mvp[14] = 0f
        mvp[15] = 1f

        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, 0)

        // paper
        val bg = v.bgArgb
        val ba = ((bg ushr 24) and 255) / 255f
        GLES30.glUseProgram(flatProg)
        GLES30.glUniformMatrix4fv(uMvpF, 1, false, mvp, 0)
        GLES30.glUniform4f(uRectF, 0f, 0f, cw.toFloat(), ch.toFloat())
        GLES30.glUniform4f(uColorF, ((bg shr 16) and 255) / 255f, ((bg shr 8) and 255) / 255f, (bg and 255) / 255f, ba)
        GLES30.glUniform1f(uCheckF, if (ba == 0f) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        // visible tile range = bounding box of the screen corners in canvas space
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (i in 0 until 4) {
            val sx = if (i and 1 == 0) 0f else vw.toFloat()
            val sy = if (i and 2 == 0) 0f else vh.toFloat()
            val dx = sx - v.tx
            val dy = sy - v.ty
            val cx = (c * dx + sn * dy) / s
            val cy = (-sn * dx + c * dy) / s
            minX = min(minX, cx); maxX = max(maxX, cx)
            minY = min(minY, cy); maxY = max(maxY, cy)
        }
        val tx0 = floor(minX / TILE).toInt()
        val ty0 = floor(minY / TILE).toInt()
        val tx1 = floor(maxX / TILE).toInt()
        val ty1 = floor(maxY / TILE).toInt()
        val n = NativeEngine.nativeVisibleTiles(tx0, ty0, tx1, ty1, idxBuf, verBuf)

        GLES30.glUseProgram(tileProg)
        GLES30.glUniformMatrix4fv(uMvpT, 1, false, mvp, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniform1i(uTexT, 0)
        // Zoom-in: always bilinear (no blocky squares). Zoom-out: mip-mapped, otherwise thin lines are skipped by the
        // 4-texel bilinear footprint and turn into dashes / stair-steps. Every upload regenerates the mip chain.
        val magFilter = GLES30.GL_LINEAR
        val minFilter = if (s < 1f) GLES30.GL_LINEAR_MIPMAP_LINEAR else GLES30.GL_LINEAR
        val tilesX = (cw + TILE - 1) / TILE

        var uploads = 0
        var pending = false
        for (i in 0 until n) {
            val idx = idxBuf[i]
            val ver = verBuf[i]
            if (idx < 0 || idx >= slotOfTile.size) continue
            var slot = slotOfTile[idx]
            if (slot < 0) {
                slot = acquireSlot()
                if (slot < 0) continue
                slotOfTile[idx] = slot
                texTile[slot] = idx
                texVer[slot] = -1
            }
            texStamp[slot] = frame
            if (texIds[slot] == 0) createTexture(slot)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texIds[slot])
            if (texVer[slot] != ver) {
                if (uploads < UPLOAD_BUDGET) {
                    tileBuf.clear()
                    if (NativeEngine.nativeCopyTile(idx, tileBuf)) {
                        tileBuf.position(0)
                        GLES30.glTexSubImage2D(
                            GLES30.GL_TEXTURE_2D, 0, 0, 0, TILE, TILE,
                            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, tileBuf
                        )
                        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
                    }
                    texVer[slot] = ver
                    uploads++
                } else {
                    pending = true
                    if (texVer[slot] == -1) continue
                }
            }
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, minFilter)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, magFilter)
            GLES30.glUniform4f(
                uRectT,
                (idx % tilesX * TILE).toFloat(), (idx / tilesX * TILE).toFloat(), TILE.toFloat(), TILE.toFloat()
            )
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        }
        if (pending) v.requestRender()
    }

    private fun acquireSlot(): Int {
        var best = -1
        var bestStamp = Int.MAX_VALUE
        for (i in 0 until POOL) {
            if (texTile[i] < 0) return i
            if (texStamp[i] < frame && texStamp[i] < bestStamp) {
                bestStamp = texStamp[i]
                best = i
            }
        }
        if (best >= 0) {
            val old = texTile[best]
            if (old >= 0 && old < slotOfTile.size) slotOfTile[old] = -1
            texTile[best] = -1
        }
        return best
    }

    private fun createTexture(slot: Int) {
        val id = IntArray(1)
        GLES30.glGenTextures(1, id, 0)
        texIds[slot] = id[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, TILE, TILE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D) // complete mip chain from the start (a mip filter without levels renders black)
    }

    private fun link(vs: String, fs: String): Int {
        val p = GLES30.glCreateProgram()
        val a = compile(GLES30.GL_VERTEX_SHADER, vs)
        val b = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        GLES30.glAttachShader(p, a)
        GLES30.glAttachShader(p, b)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("GL link failed: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("GL compile failed: " + GLES30.glGetShaderInfoLog(s))
        return s
    }
}
