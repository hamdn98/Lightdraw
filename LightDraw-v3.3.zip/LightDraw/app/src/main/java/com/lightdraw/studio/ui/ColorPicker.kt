package com.lightdraw.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

// ------------------------------------------------------------------ drag & drop onto the canvas

/** kind 0 = solid colour, 1..6 = pattern id. */
class DragPayload(val kind: Int, val color: Int)

@Stable
class DragDropState {
    var payload by mutableStateOf<DragPayload?>(null)
    var pos by mutableStateOf(Offset.Zero) // root coordinates
    var onDrop: ((DragPayload, Offset) -> Unit)? = null

    fun start(p: DragPayload, at: Offset) {
        payload = p
        pos = at
    }

    fun move(delta: Offset) {
        pos += delta
    }

    fun end() {
        val p = payload
        if (p != null) onDrop?.invoke(p, pos)
        payload = null
    }

    fun cancel() {
        payload = null
    }
}

/** Tap = onTap, long drag = drag the payload onto the canvas. */
fun Modifier.dragSource(dd: DragDropState, payload: DragPayload, onTap: () -> Unit): Modifier = composed {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val tap by rememberUpdatedState(onTap)
    val data by rememberUpdatedState(payload)
    this
        .onGloballyPositioned { origin = it.positionInRoot() }
        .pointerInput(Unit) { detectTapGestures(onTap = { tap() }) }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { off -> dd.start(data, origin + off) },
                onDragEnd = { dd.end() },
                onDragCancel = { dd.cancel() },
            ) { change, amount ->
                change.consume()
                dd.move(amount)
            }
        }
}

// ------------------------------------------------------------------ HSV model

data class Hsv(val h: Float, val s: Float, val v: Float) {
    fun toArgb(): Int = Color.hsv(h.coerceIn(0f, 360f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)).toArgb()
}

fun argbToHsv(argb: Int): Hsv {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, a)
    return Hsv(a[0], a[1], a[2])
}

private val HueStops = listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color.hsv(it.coerceAtMost(359.99f), 1f, 1f) }

val DefaultSwatches: List<Int> = listOf(
    0xFFFF3366, 0xFFFF6B35, 0xFFFFD700, 0xFF00FF66, 0xFF00E5FF, 0xFFA066FF,
    0xFFE91E63, 0xFFFF9800, 0xFFCDDC39, 0xFF009688, 0xFF2196F3, 0xFF673AB7,
    0xFFFFFFFF, 0xFFBDBDBD, 0xFF757575, 0xFF424242, 0xFF212121, 0xFF000000,
).map { it.toInt() }

private fun squareSide(size: Float): Float = (size / 2f - size * 0.13f - 6f) * 1.4142f

/** Interactive HSL colour wheel (hue ring) with an inner saturation/value square. */
@Composable
private fun HsvWheel(hsv: Hsv, onChange: (Hsv) -> Unit, modifier: Modifier = Modifier) {
    var mode by remember { mutableIntStateOf(0) }
    var sizePx by remember { mutableFloatStateOf(0f) }
    val cur by rememberUpdatedState(hsv)
    val push by rememberUpdatedState(onChange)

    fun pick(p: Offset): Int {
        val c = sizePx / 2f
        return if (hypot(p.x - c, p.y - c) > c - sizePx * 0.13f - 4f) 0 else 1
    }

    fun handle(p: Offset, m: Int) {
        val c = sizePx / 2f
        if (m == 0) {
            var ang = Math.toDegrees(atan2(p.y - c, p.x - c).toDouble()).toFloat()
            if (ang < 0f) ang += 360f
            push(cur.copy(h = ang))
        } else {
            val side = squareSide(sizePx)
            val left = c - side / 2f
            val top = c - side / 2f
            push(cur.copy(s = ((p.x - left) / side).coerceIn(0f, 1f), v = (1f - (p.y - top) / side).coerceIn(0f, 1f)))
        }
    }

    Canvas(
        modifier
            .aspectRatio(1f)
            .onSizeChanged { sizePx = it.width.toFloat() }
            .pointerInput(Unit) { detectTapGestures { handle(it, pick(it)) } }
            .pointerInput(Unit) {
                detectDragGestures(onDragStart = { mode = pick(it); handle(it, mode) }) { change, _ ->
                    change.consume()
                    handle(change.position, mode)
                }
            }
    ) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val ringW = size.width * 0.13f
        val ringR = size.width / 2f - ringW / 2f
        drawCircle(Brush.sweepGradient(HueStops, center = c), radius = ringR, center = c, style = Stroke(ringW))

        val ang = Math.toRadians(hsv.h.toDouble())
        val hp = Offset(c.x + cos(ang).toFloat() * ringR, c.y + sin(ang).toFloat() * ringR)
        drawCircle(Color.hsv(hsv.h.coerceIn(0f, 360f), 1f, 1f), radius = ringW / 2f - 2f, center = hp)
        drawCircle(Color.White, radius = ringW / 2f, center = hp, style = Stroke(3f))

        val side = squareSide(size.width)
        val tl = Offset(c.x - side / 2f, c.y - side / 2f)
        val sz = Size(side, side)
        drawRect(
            Brush.horizontalGradient(listOf(Color.White, Color.hsv(hsv.h.coerceIn(0f, 360f), 1f, 1f)), startX = tl.x, endX = tl.x + side),
            topLeft = tl, size = sz,
        )
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = tl.y, endY = tl.y + side),
            topLeft = tl, size = sz,
        )
        val sp = Offset(tl.x + hsv.s * side, tl.y + (1f - hsv.v) * side)
        drawCircle(Color.Black, radius = 11f, center = sp, style = Stroke(2f))
        drawCircle(Color.White, radius = 9f, center = sp, style = Stroke(3f))
    }
}

@Composable
fun SwatchChip(color: Int, selected: Boolean, dd: DragDropState, onTap: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(color))
            .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .dragSource(dd, DragPayload(0, color), onTap)
    )
}

/**
 * Colour wheel + HSV square + hex/HSL read-out + eyedropper + draggable swatches.
 * Drag a swatch onto the canvas to flood-fill that spot.
 */
@Composable
fun ColorPicker(
    color: Int,
    onColor: (Int) -> Unit,
    eyedropperActive: Boolean,
    onEyedropper: () -> Unit,
    dd: DragDropState,
    onSwatchPicked: () -> Unit = {},
) {
    var hsv by remember { mutableStateOf(argbToHsv(color)) }
    LaunchedEffect(color) { if (hsv.toArgb() != color) hsv = argbToHsv(color) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("HSL COLOR SUITE", color = Palette.AccentPink, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (eyedropperActive) Palette.AccentPink.copy(alpha = 0.25f) else Color.Transparent)
                    .clickable { onEyedropper() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(DrawIcons.Eyedropper, "Eyedropper", tint = if (eyedropperActive) Palette.AccentPink else Palette.TextMuted, modifier = Modifier.size(18.dp))
            }
        }

        HsvWheel(
            hsv = hsv,
            onChange = { n -> hsv = n; onColor(n.toArgb()) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )

        val hsl = FloatArray(3).also { ColorUtils.colorToHSL(color, it) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(color)).border(2.dp, Color.White.copy(alpha = 0.4f), CircleShape))
            Column {
                Text("#%06X".format(color and 0xFFFFFF), color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                Text(
                    "H ${hsl[0].toInt()}°  S ${(hsl[1] * 100).toInt()}%  L ${(hsl[2] * 100).toInt()}%",
                    color = Palette.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                )
            }
        }

        Text("Swatches Studio  (tap = pilih, geser ke kanvas = isi)", color = Palette.TextMuted, fontSize = 11.sp)
        DefaultSwatches.chunked(6).forEach { rowColors ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowColors.forEach { sw -> SwatchChip(sw, sw == color, dd) { onColor(sw); onSwatchPicked() } }
            }
        }
    }
}
