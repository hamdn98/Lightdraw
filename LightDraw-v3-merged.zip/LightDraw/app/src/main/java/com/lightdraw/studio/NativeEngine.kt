package com.lightdraw.studio

import android.graphics.Bitmap
import java.nio.ByteBuffer

/** JNI facade for the Rust engine (liblightdraw_engine.so). */
object NativeEngine {
    init {
        System.loadLibrary("lightdraw_engine")
    }

    external fun nativeInit(w: Int, h: Int, spillDir: String, maxResident: Int): Boolean
    external fun nativeCanvasWidth(): Int
    external fun nativeCanvasHeight(): Int

    external fun nativeVisibleTiles(tx0: Int, ty0: Int, tx1: Int, ty1: Int, idx: IntArray, ver: IntArray): Int
    external fun nativeCopyTile(idx: Int, buf: ByteBuffer): Boolean

    external fun nativeSetBrush(preset: Int, size: Float, opacity: Float, color: Int, blend: Int)
    external fun nativeSetStabilizer(strength: Float)
    external fun nativeSetSymmetry(mode: Int, sectors: Int, mirror: Boolean)
    external fun nativeSetBg(argb: Int)

    external fun nativeStrokeBegin(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeMove(x: Float, y: Float, p: Float, t: Long)
    external fun nativeStrokeEnd()
    external fun nativeStrokeCancel()

    /** 0 ok, 1 out of bounds, 2 region too large. */
    external fun nativeFill(x: Int, y: Int, kind: Int, color: Int, color2: Int, scale: Float, tol: Int): Int
    /** Resumable flood fill (safe for 8K-16K): begin -> step until != 0. step: 0 working, 1 done, 2 too complex (rolled back), 3 no job. */
    external fun nativeFillBegin(x: Int, y: Int, kind: Int, color: Int, color2: Int, scale: Float, tol: Int): Int
    external fun nativeFillStep(budgetPx: Int): Int
    external fun nativeFillCancel()
    external fun nativeFillPainted(): Long

    external fun nativeSelectReplace(x: Int, y: Int, newColor: Int, tolH: Float, tolS: Float, tolL: Float): Int
    external fun nativePickColor(x: Int, y: Int): Int

    external fun nativeUndo(): Boolean
    external fun nativeRedo(): Boolean
    /** bit0 = can undo, bit1 = can redo */
    external fun nativeHistoryState(): Int
    external fun nativeClear()

    // ---- FX / transform / object tools
    /** op 0 invert, 1 grayscale, 2 brightness(a)+contrast(b) in -1..1, 3 hue(a, deg)+saturation(b). */
    external fun nativeApplyFx(op: Int, a: Float, b: Float): Int
    /** Wrap-around shift of the whole drawing. 0 ok, 2 canvas too large. */
    external fun nativeOffsetWrap(dx: Int, dy: Int): Int
    /** Move / duplicate a rectangle, optionally wrapping across canvas edges. 0 ok, 1 empty, 2 too large. */
    external fun nativeMoveRegion(x0: Int, y0: Int, x1: Int, y1: Int, dx: Int, dy: Int, copy: Boolean, wrap: Boolean): Int
    /** mode 0 left, 1 centre H, 2 right, 3 top, 4 centre V, 5 bottom, 6 centre both. (dx shl 32) or dy, Long.MIN_VALUE when empty. */
    external fun nativeAlignRegion(x0: Int, y0: Int, x1: Int, y1: Int, mode: Int): Long
    /** Region -> custom pattern (kind 7). (w shl 16) or h, -1 empty, -2 too large. */
    external fun nativeSetPatternFromRegion(x0: Int, y0: Int, x1: Int, y1: Int): Int
    /** kind 0 rect, 1 rounded, 2 ellipse, 3 triangle, 4 line, 5 diamond. flags bit0 fill, bit1 stroke. commit=false = live preview. */
    external fun nativeShape(kind: Int, x0: Float, y0: Float, x1: Float, y1: Float, fill: Int, stroke: Int, flags: Int, sw: Float, commit: Boolean): Int
    external fun nativeShapeCancel()

    /** Affine commit of a selection: x' = a x + b y + tx, y' = c x + d y + ty. 0 ok, 1 empty, 2 too large. */
    external fun nativeTransformRegion(x0: Int, y0: Int, x1: Int, y1: Int, a: Float, b: Float, tx: Float, c: Float, d: Float, ty: Float): Int
    /** Resample the custom pattern motif to w x h pixels (max 2048). */
    external fun nativeResizeCustomPattern(w: Int, h: Int): Boolean

    external fun nativeRenderToBitmap(bmp: Bitmap, bg: Int): Int
    /** maximum: 0 = fast compression, 1 = best compression (both lossless). Streams row by row at full resolution. */
    external fun nativeExportPng(fd: Int, bg: Int, maximum: Int): Int
    /** Streaming JPEG, down-scaled to at most maxPx pixels. maximum: 0 = q85 4:2:0, 1 = q100 4:4:4. (w shl 32) or h, -1 on failure. */
    external fun nativeExportJpeg(fd: Int, bg: Int, maximum: Int, maxPx: Long): Long
    external fun nativeSaveProject(fd: Int): Int
    /** (width shl 32) or height, or -1 on failure. */
    external fun nativeLoadProject(fd: Int, spillDir: String, maxResident: Int): Long
    external fun nativeImportBitmap(bmp: Bitmap, dx: Int, dy: Int): Int
}

/** Second colour for two-tone patterns, derived from the active colour. */
fun secondaryOf(argb: Int): Int {
    val r = (argb shr 16) and 255
    val g = (argb shr 8) and 255
    val b = argb and 255
    val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    val target = if (lum > 0.55) 0 else 255
    val t = if (lum > 0.55) 0.65 else 0.85
    fun mix(c: Int): Int = (c + (target - c) * t).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (mix(r) shl 16) or (mix(g) shl 8) or mix(b)
}
