package com.lightdraw.studio.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Tool {
    const val DRAW = 0
    const val ERASER = 1
    const val FILL = 2
    const val SELECT_COLOR = 3
    const val EYEDROPPER = 4
}

/** All UI-visible drawing state. Pushed to the native engine by CanvasScreen. */
@Stable
class DrawState {
    var tool by mutableIntStateOf(Tool.DRAW)
    private var prevTool = Tool.DRAW
    var color by mutableIntStateOf(0xFFFF3366.toInt())

    var brushPreset by mutableIntStateOf(0)
    var size by mutableFloatStateOf(18f)
    var opacity by mutableFloatStateOf(100f)      // %
    var stabilizer by mutableFloatStateOf(65f)    // %
    var blend by mutableIntStateOf(0)             // 0 normal 1 multiply 2 screen 3 overlay 4 add

    var pattern by mutableIntStateOf(0)           // 0 = solid colour
    var patternScale by mutableFloatStateOf(1f)
    var fillTolerance by mutableFloatStateOf(24f)

    var symMode by mutableIntStateOf(0)           // 0 off 1 horizontal 2 vertical 3 radial
    var sectors by mutableIntStateOf(6)
    var symMirror by mutableStateOf(false)

    var tolH by mutableFloatStateOf(15f)          // degrees
    var tolS by mutableFloatStateOf(20f)          // %
    var tolL by mutableFloatStateOf(20f)          // %

    var paperColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var paperVisible by mutableStateOf(true)

    var studioTab by mutableIntStateOf(0)
    var studioOpen by mutableStateOf(true)
    var railExpanded by mutableStateOf(false)

    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    fun toggleEyedropper() {
        if (tool == Tool.EYEDROPPER) {
            tool = prevTool
        } else {
            prevTool = tool
            tool = Tool.EYEDROPPER
        }
    }

    fun finishEyedropper() {
        if (tool == Tool.EYEDROPPER) tool = prevTool
    }
}

// ------------------------------------------------------------------ left floating tool rail

@Composable
private fun RailItem(icon: ImageVector, label: String, selected: Boolean, expanded: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Palette.AccentPurple.copy(alpha = 0.15f) else Color.Transparent)
            .border(1.dp, if (selected) Palette.AccentPurple.copy(alpha = 0.3f) else Color.Transparent, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(icon, label, tint = if (selected) Palette.AccentPurple else Palette.TextMuted, modifier = Modifier.size(20.dp))
        if (expanded) Text(label, color = if (selected) Palette.AccentPurple else Palette.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Collapsible floating toolbar: Draw, Eraser, Fill, Color Edit, Symmetry, Layers, Settings. */
@Composable
fun FloatingToolbar(
    state: DrawState,
    onLayers: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val expanded = state.railExpanded
    FloatingPanel(modifier.width(if (expanded) 164.dp else 52.dp).animateContentSize()) {
        Column(
            Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()).padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            RailItem(if (expanded) DrawIcons.Close else DrawIcons.Menu, "Toolbox Studio", false, expanded) { state.railExpanded = !expanded }
            RailItem(DrawIcons.Brush, "Streamline Brush", state.tool == Tool.DRAW, expanded) { state.tool = Tool.DRAW; state.studioTab = 0 }
            RailItem(DrawIcons.Eraser, "Eraser Engine", state.tool == Tool.ERASER, expanded) { state.tool = Tool.ERASER; state.studioTab = 0 }
            RailItem(DrawIcons.Fill, "Scanline Fill", state.tool == Tool.FILL, expanded) { state.tool = Tool.FILL; state.studioTab = 1 }
            RailItem(DrawIcons.Wand, "Select & Edit Color", state.tool == Tool.SELECT_COLOR, expanded) {
                state.tool = Tool.SELECT_COLOR; state.studioTab = 2; state.studioOpen = true
            }
            RailItem(DrawIcons.Symmetry, "Mirror & Symmetry", state.symMode != 0, expanded) { state.studioTab = 3; state.studioOpen = true }
            RailItem(DrawIcons.Layers, "Layers", false, expanded) { onLayers() }
            RailItem(DrawIcons.Settings, "Artboard", false, expanded) { onSettings() }
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp, start = 6.dp, bottom = 4.dp).clickable { state.studioTab = 2; state.studioOpen = true },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color(state.color)).border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape))
                if (expanded) Text("#%06X".format(state.color and 0xFFFFFF), color = Color.White, fontSize = 11.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ right studio panel

@Composable
private fun Chip(text: String, selected: Boolean, accent: Color = Palette.AccentPurple, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text,
        color = if (selected) accent else Palette.TextMuted,
        fontSize = 11.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.15f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) accent else Palette.PanelBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun Card(icon: ImageVector, title: String, subtitle: String, selected: Boolean, accent: Color, modifier: Modifier, onClickModifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.10f) else Palette.DarkBg.copy(alpha = 0.4f))
            .border(1.dp, if (selected) accent else Palette.PanelBorder, shape)
            .then(onClickModifier)
            .padding(10.dp),
    ) {
        Icon(icon, title, tint = if (selected) accent else Palette.TextMuted, modifier = Modifier.size(20.dp))
        Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Palette.TextMuted, fontSize = 10.sp)
    }
}

private class BrushInfo(val icon: ImageVector, val title: String, val sub: String)

private val Brushes = listOf(
    BrushInfo(DrawIcons.Brush, "Graphite Pencil", "Pressure Sensitivity"),
    BrushInfo(DrawIcons.Palette, "Soft Airbrush", "Smooth Gradient"),
    BrushInfo(DrawIcons.Eyedropper, "Studio Ink Pen", "Sharp Line Art"),
    BrushInfo(DrawIcons.Zigzag, "Calligraphy", "Angled Stroke"),
)

private val Blends = listOf("Normal", "Multiply", "Screen", "Overlay", "Add")

private class PatternInfo(val id: Int, val icon: ImageVector, val title: String, val sub: String)

private val Patterns = listOf(
    PatternInfo(1, DrawIcons.Grid, "Gingham", "Classic Checkered"),
    PatternInfo(2, DrawIcons.Diamond, "Argyle", "Diamond Grid"),
    PatternInfo(3, DrawIcons.Waves, "Seigaiha", "Japanese Fish Scale"),
    PatternInfo(4, DrawIcons.Zigzag, "Houndstooth", "Woven Twill"),
    PatternInfo(5, DrawIcons.Plaid, "Plaid", "Tartan Bands"),
    PatternInfo(6, DrawIcons.Flower, "Floral", "Four-Petal Bloom"),
)

@Composable
private fun BrushTab(state: DrawState) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("SELECT BRUSH PRESETS", color = Palette.AccentPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Dynamics Active", color = Palette.TextMuted, fontSize = 10.sp)
        }
        Brushes.chunked(2).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEachIndexed { c, b ->
                    val id = r * 2 + c
                    Card(b.icon, b.title, b.sub, state.brushPreset == id, Palette.AccentPurple, Modifier.weight(1f), Modifier.clickable { state.brushPreset = id; state.tool = Tool.DRAW })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Blends.forEachIndexed { i, n -> Chip(n, state.blend == i) { state.blend = i } }
        }
        LabeledSlider("Ukuran Brush", "${state.size.toInt()} px", state.size, 1f..200f) { state.size = it }
        LabeledSlider("Opacity / Transparansi", "${state.opacity.toInt()}%", state.opacity, 1f..100f) { state.opacity = it }
        LabeledSlider("Streamline Stabilizer", "${state.stabilizer.toInt()}%", state.stabilizer, 0f..99f, Palette.AccentCyan) { state.stabilizer = it }
    }
}

@Composable
private fun PatternTab(state: DrawState, dd: DragDropState) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("VECTOR PATTERN FILL", color = Palette.AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Seamless Tiling", color = Palette.TextMuted, fontSize = 10.sp)
        }
        Patterns.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { p ->
                    Card(
                        p.icon, p.title, p.sub, state.pattern == p.id, Palette.AccentCyan, Modifier.weight(1f),
                        Modifier.dragSource(dd, DragPayload(p.id, state.color)) {
                            state.pattern = if (state.pattern == p.id) 0 else p.id
                            if (state.pattern != 0) state.tool = Tool.FILL
                        },
                    )
                }
            }
        }
        Text("Pilih motif lalu pakai tool Fill, atau geser kartu motif ke kanvas.", color = Palette.TextMuted, fontSize = 10.sp)
        LabeledSlider("Skala Tile Pattern", "%.1fx".format(state.patternScale), state.patternScale, 0.2f..5f, Palette.AccentCyan) { state.patternScale = it }
        LabeledSlider("Toleransi Fill", "${state.fillTolerance.toInt()}", state.fillTolerance, 0f..128f, Palette.AccentCyan) { state.fillTolerance = it }
    }
}

@Composable
private fun ColorTab(state: DrawState, dd: DragDropState) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ColorPicker(
            color = state.color,
            onColor = { state.color = it },
            eyedropperActive = state.tool == Tool.EYEDROPPER,
            onEyedropper = { state.toggleEyedropper() },
            dd = dd,
        )
        Text("SELECT & EDIT SAME COLOR", color = Palette.AccentPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(
            "Pilih tool Select & Edit Color, lalu ketuk warna di kanvas: semua piksel yang cocok (seluruh artboard) diganti ke warna aktif.",
            color = Palette.TextMuted, fontSize = 10.sp,
        )
        LabeledSlider("Toleransi Hue", "${state.tolH.toInt()}°", state.tolH, 0f..180f) { state.tolH = it }
        LabeledSlider("Toleransi Saturation", "${state.tolS.toInt()}%", state.tolS, 0f..100f) { state.tolS = it }
        LabeledSlider("Toleransi Luminance", "${state.tolL.toInt()}%", state.tolL, 0f..100f) { state.tolL = it }
        Chip("Aktifkan Select & Edit Color", state.tool == Tool.SELECT_COLOR) { state.tool = Tool.SELECT_COLOR }
    }
}

@Composable
private fun MirrorTab(state: DrawState) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("ZERO-ALLOC SYMMETRY", color = Palette.AccentPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Native Rust Math", color = Palette.TextMuted, fontSize = 10.sp)
        }
        val options = listOf(
            Triple(0, "Off", "Tanpa simetri"),
            Triple(1, "Horizontal Mirror", "Simetri Cermin Kiri-Kanan"),
            Triple(2, "Vertical Mirror", "Simetri Cermin Atas-Bawah"),
            Triple(3, "Radial Mandala", "Rotasi Lingkaran Presisi (2-12 sektor)"),
        )
        options.forEach { (id, title, sub) ->
            val sel = state.symMode == id
            val shape = RoundedCornerShape(12.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Palette.DarkBg.copy(alpha = 0.4f))
                    .border(1.dp, if (sel) Palette.AccentPurple else Palette.PanelBorder, shape)
                    .clickable { state.symMode = id }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier.size(16.dp).clip(CircleShape).border(2.dp, if (sel) Palette.AccentPurple else Palette.TextMuted, CircleShape)
                        .padding(3.dp).background(if (sel) Palette.AccentPurple else Color.Transparent, CircleShape)
                )
                Column {
                    Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(sub, color = Palette.TextMuted, fontSize = 10.sp)
                }
            }
        }
        if (state.symMode == 3) {
            LabeledSlider("Jumlah Sektor", "${state.sectors}", state.sectors.toFloat(), 2f..12f) { state.sectors = it.toInt().coerceIn(2, 12) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mirror tiap sektor", color = Palette.TextMuted, fontSize = 12.sp)
                Switch(
                    checked = state.symMirror, onCheckedChange = { state.symMirror = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = Palette.AccentPurple),
                )
            }
        }
        Text("Pusat simetri = tengah artboard.", color = Palette.TextMuted, fontSize = 10.sp)
    }
}

/** Right floating studio panel: Brush / Pattern / Color / Mirror tabs. */
@Composable
fun StudioPanel(state: DrawState, dd: DragDropState, modifier: Modifier = Modifier) {
    FloatingPanel(modifier.width(284.dp)) {
        Column(Modifier.heightIn(max = 520.dp)) {
            Row(Modifier.fillMaxWidth().background(Palette.DarkBg.copy(alpha = 0.5f))) {
                listOf("Brush", "Pattern", "Color", "Mirror").forEachIndexed { i, t ->
                    val sel = state.studioTab == i
                    Box(
                        Modifier.weight(1f).clickable { state.studioTab = i }
                            .background(if (sel) Palette.AccentPurple.copy(alpha = 0.08f) else Color.Transparent)
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(t, color = if (sel) Palette.AccentPurple else Palette.TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Box(Modifier.padding(top = 4.dp).size(width = 28.dp, height = 2.dp).background(if (sel) Palette.AccentPurple else Color.Transparent))
                        }
                    }
                }
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
                when (state.studioTab) {
                    0 -> BrushTab(state)
                    1 -> PatternTab(state, dd)
                    2 -> ColorTab(state, dd)
                    else -> MirrorTab(state)
                }
            }
        }
    }
}
